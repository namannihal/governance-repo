# lmp-spec-agent

The specification layer, on its own. Turns documents into reviewed, approved,
machine-readable facts — and refuses to hand them to anything until a human has
signed them off.

**No dependencies.** Not on `lmp-discovery-agent`, not on `State.ps1`, not on any
particular build agent. Windows PowerShell 5.1, no modules.

## What it is for

Migration programmes run on documents nobody re-reads. A fact discovered in week one
becomes a sentence in a Word file, and by the time an IaC agent needs it, someone is
guessing. This package makes every fact carry its evidence, and makes "not approved
yet" a machine-enforced answer rather than a hope.

## The workflow

```
/spec-init     create the store and the four intake folders
/spec-ingest   documents -> statements with evidence -> canonical spec + three views
/spec-review   human sign-off, in triage order, recorded in an append-only log
/spec-status   is the gate open? which statements are blocking?
```

Then your existing agent calls:

```powershell
Spec.ps1 -Root <root> -Command resolve -View devops-spec -MinStatus approved -Format json
```

Exit **0** = proceed. Exit **3** = a human has not approved this; write nothing.

Full contract in [docs/INTEGRATION.md](docs/INTEGRATION.md). Hand that file to whoever
owns your IaC agent — it is the only thing they need.

## Quick start

```powershell
$spec = ".\.apm\scripts\powershell\Spec.ps1"
$root = ".\.lmp-migrate\claims-api"

& $spec -Root $root -Command init
# drop documents into $root\src\{comigrate-assessment,aimigrate-assessment,existing-sad,application-docs}

& $spec -Root $root -Command register-sources     # hashes everything, records what could NOT be read
& $spec -Root $root -Command add-statement -FactKey azure.target.queue -Value servicebus-premium `
        -SourceId src-1a25e3bd -Locator "line 3" -Quote "Queue: SQS" -Method inferred
& $spec -Root $root -Command build                # canonical + 3 views + conflicts + review markdown

& $spec -Root $root -Command resolve -View devops-spec -MinStatus approved
# -> exit 3, lists what is blocking

& $spec -Root $root -Command review -Target stmt-7472c831 -Action approve -Actor n.nihal
& $spec -Root $root -Command resolve -View devops-spec -MinStatus approved
# -> exit 0, emits the payload and a plan_hash
```

## Commands

| Command | Does | Exits |
|---|---|---|
| `init` | create the store | 0, 5 if it exists |
| `register-sources` | hash every file, record read / not-read **with a reason** | 0, 2 if nothing readable, 4 if no `src/` |
| `add-statement` | one atomic claim with source, locator, quote, method | 0, 2 on bad args, 4 on unknown source |
| `build` | dedupe, project views, detect conflicts, render Markdown | 0, 2 if no statements |
| `resolve` | **the gate** | 0, 2 empty, 3 not approved, 4 unknown view |
| `review` | record a human decision | 0, 2 without `-Actor`, 4 unknown statement |
| `verify` | recompute bindings, void approvals whose evidence moved | 0 |
| `status` | triage counts | 0 |

## Why it does not hallucinate

1. **Read or refuse.** Every file is hashed and recorded as read, or not-read *with a
   reason*. A cloud placeholder or a binary wearing an `.xlsx` name is named explicitly.
2. **No evidence, no run.** Nothing readable → `exit 2`, and nothing is written.
3. **Every claim carries a receipt** — source file, locator, and the actual quote.
4. **Tier is computed, never claimed.** It comes from *how* the fact was obtained.
   Tier E always needs a human.
5. **Absence is a finding.** No RTO in any document becomes an open question, not a
   plausible number.
6. **Approval binds to the evidence.** Edit the source and `verify` voids the approval
   automatically, with reason `source-changed`.

## What is in the store

```
out/
├── sources/source-register.json         id, sha256, read or not-read, why not
├── statements.json                      the atomic claim store
├── evidence-map.json                    source -> statements, for impact analysis
├── conflicts/unresolved-conflicts.json  same fact_key, competing values
├── specifications/
│   ├── system-spec.json                 canonical, deduped by fact_key
│   ├── development-spec.json  ┐
│   ├── devops-spec.json       ├─ views: statement IDs, never copies
│   └── refactoring-spec.json  ┘
├── decisions/decision-log.jsonl         append-only, never regenerated
└── review/*.md                          generated, READ-ONLY
```

One statement store. The three specs are **views** over it, organised by audience
rather than by phase, holding statement IDs rather than duplicated text — so a fact
corrected once is corrected everywhere it appears.

Everything under `specifications/` and `review/` can be deleted and rebuilt.
`statements.json` and `decision-log.jsonl` cannot.

## Tests

```powershell
.\tests\Invoke-Tests.ps1                 # unit + integration + contract
.\tests\Invoke-Tests.ps1 -Suite contract # run this one in a customer environment
.\tests\Invoke-StaticAnalysis.ps1
```

The **contract** suite runs `tests/mock-consumer.ps1` — a ~40-line compliant consumer —
against the gate. It proves the refusal and release behaviour without needing your real
build agent, and doubles as the shortest reference for writing one.

## Known gaps

Not built: the eight downstream artifacts (`requirements`, `nfr`, `adr`, `sad`,
`migration-plan`, `migration-backlog`, `cost-profile`, `test-plan`), artifact versioning
and supersession, and reviewer routing.

The agent layer (`.agent.md`, `.prompt.md`) has been written and reviewed but never
exercised in a live Copilot session — the scripts beneath it are tested, the prose is not.
