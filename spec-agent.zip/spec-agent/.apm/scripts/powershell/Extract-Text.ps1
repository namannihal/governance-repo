<#
.SYNOPSIS
    Convert intake documents into Markdown the agent can actually read.

.DESCRIPTION
    A .docx is a ZIP of XML; a .xlsx is the same. Reading one directly returns binary,
    so without this step every Word document under src\ is invisible to the normaliser
    even though the scan report cheerfully lists it.

    Mirrors src\<folder>\... into <Out>\<folder>\....md. Knows nothing about adapters -
    it walks whatever folders exist under src\, so adding an intake source costs
    nothing here.

    Exit 2 = nothing extractable was found.

    PowerShell 5.1 compatible. No modules required. ASCII only on purpose: PS 5.1
    reads a BOM-less .ps1 as ANSI, so a stray non-ASCII character is a parse error.

.EXAMPLE
    .\Extract-Text.ps1 -Root .lmp-migrate\payments-api -Command extract
    .\Extract-Text.ps1 -Command file -Path .\design.docx
#>
[CmdletBinding()]
param(
    [string]$Root = '.',
    [ValidateSet('extract', 'file')][string]$Command = 'extract',
    [string]$Out,
    [string]$Path
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:WNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:SsNs = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
$script:RNs = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
$script:PrNs = 'http://schemas.openxmlformats.org/package/2006/relationships'

# One member of a supplied ZIP may not exceed this once decompressed. A vendor
# export is untrusted input; without this a 1 MB file can expand to fill the disk.
$script:MaxMemberBytes = 64MB

$Tick = [char]96

$script:TextExt = @('.md', '.txt', '.json', '.xml', '.yaml', '.yml', '.log', '.ini', '.cfg')
$script:Extractable = $script:TextExt + @('.docx', '.xlsx', '.csv', '.tsv', '.drawio')

# Listed honestly rather than silently ignored: each one needs a human step first.
$script:NeedsManual = @{
    '.pdf'  = 'PDF - export to .docx or .txt and re-run'
    '.doc'  = 'legacy Word binary - save as .docx and re-run'
    '.xls'  = 'legacy Excel binary - save as .xlsx and re-run'
    '.ppt'  = 'legacy PowerPoint binary - save as .pptx and export the text'
    '.pptx' = 'slides - export the text to .docx or .md'
    '.vsd'  = 'Visio - export to PDF then text, or describe it in a .md'
    '.vsdx' = 'Visio - export to PDF then text, or describe it in a .md'
    '.msg'  = 'Outlook message - save the body as .txt'
    '.png'  = 'image - describe it in a .md alongside'
    '.jpg'  = 'image - describe it in a .md alongside'
    '.jpeg' = 'image - describe it in a .md alongside'
    '.gif'  = 'image - describe it in a .md alongside'
    '.bmp'  = 'image - describe it in a .md alongside'
    '.zip'  = 'archive - unpack it into the source folder'
    '.7z'   = 'archive - unpack it into the source folder'
    '.rar'  = 'archive - unpack it into the source folder'
}

$script:Ignored = @('.gitkeep', 'readme.md', '.ds_store', 'thumbs.db')

# Windows cloud-storage placeholder bits: OFFLINE, RECALL_ON_OPEN,
# RECALL_ON_DATA_ACCESS. A OneDrive/SharePoint file that was never downloaded has
# a real size on disk but no content.
$script:PlaceholderBits = 0x1000 -bor 0x40000 -bor 0x400000

function Test-FileProblem([string]$FilePath) {
    # Name the common reasons an Office file is unreadable. Without this, ZIP parsing
    # reports 'Central Directory corrupt' and hides which of them it actually was.
    # Attributes first: reading a placeholder throws before we learn anything.
    $item = Get-Item -LiteralPath $FilePath -Force
    if (([int]$item.Attributes -band $script:PlaceholderBits) -ne 0) {
        return "cloud placeholder - not downloaded to this machine. Right-click it, 'Always keep on this device' (or just open it once), then re-run."
    }
    $buf = New-Object byte[] 8
    try {
        $fs = [System.IO.File]::OpenRead($FilePath)
        try { $n = $fs.Read($buf, 0, 8) } finally { $fs.Dispose() }
    }
    catch { return ('cannot be read from disk - ' + $_.Exception.Message.Trim()) }
    if ($n -lt 8) { return 'file is too small to be a .docx/.xlsx' }
    $ole = @(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1)
    $isOle = $true
    for ($i = 0; $i -lt 8; $i++) { if ($buf[$i] -ne $ole[$i]) { $isOle = $false; break } }
    if ($isOle) {
        return 'legacy Office binary inside a modern extension - open it and use Save As to write a real .docx/.xlsx, then re-run'
    }
    if ($buf[0] -ne 0x50 -or $buf[1] -ne 0x4B) {
        return 'not a ZIP archive - this is not a real .docx/.xlsx'
    }
    return $null
}

function Get-Stamp { (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }

function Format-Cell([string]$Text) {
    if ($null -eq $Text) { return '' }
    $Text.Replace('|', '\|').Replace("`n", ' ').Replace("`r", ' ').Trim()
}

function Compress-Blanks($Lines) {
    $out = New-Object System.Collections.ArrayList
    foreach ($line in $Lines) {
        $s = if ($null -eq $line) { '' } else { [string]$line }
        if (-not $s.Trim()) {
            if ($out.Count -gt 0 -and -not ([string]$out[$out.Count - 1]).Trim()) { continue }
            [void]$out.Add('')
        }
        else { [void]$out.Add($s.TrimEnd()) }
    }
    while ($out.Count -gt 0 -and -not ([string]$out[0]).Trim()) { $out.RemoveAt(0) }
    while ($out.Count -gt 0 -and -not ([string]$out[$out.Count - 1]).Trim()) { $out.RemoveAt($out.Count - 1) }
    $out.ToArray()
}

function Convert-RowsToMarkdown($Rows) {
    $keep = @()
    foreach ($r in $Rows) {
        $has = $false
        foreach ($c in $r) { if ($c -and ([string]$c).Trim()) { $has = $true; break } }
        if ($has) { $keep += , @($r) }
    }
    if ($keep.Count -eq 0) { return @() }
    $width = 0
    foreach ($r in $keep) { if ($r.Count -gt $width) { $width = $r.Count } }
    $out = @()
    $sep = @()
    for ($i = 0; $i -lt $width; $i++) { $sep += ' --- ' }
    for ($i = 0; $i -lt $keep.Count; $i++) {
        $a = @($keep[$i])
        while ($a.Count -lt $width) { $a += '' }
        $out += ('| ' + ($a -join ' | ') + ' |')
        if ($i -eq 0) { $out += ('|' + ($sep -join '|') + '|') }
    }
    $out
}

function Read-ZipEntry($Zip, [string]$Name) {
    $entry = $Zip.GetEntry($Name)
    if ($null -eq $entry) { return $null }
    if ($entry.Length -gt $script:MaxMemberBytes) {
        throw ("$Name expands to $($entry.Length) bytes; limit is $($script:MaxMemberBytes)")
    }
    $stream = $entry.Open()
    try {
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
    }
    finally { $stream.Dispose() }
}

function ConvertTo-SafeXml([string]$Xml) {
    # XmlResolver = $null blocks external entity resolution (XXE); intake documents
    # are untrusted third-party exports.
    $doc = New-Object System.Xml.XmlDocument
    $doc.XmlResolver = $null
    $doc.LoadXml($Xml)
    $doc
}

function New-NsManager($Doc, [hashtable]$Map) {
    $ns = New-Object System.Xml.XmlNamespaceManager($Doc.NameTable)
    foreach ($k in $Map.Keys) { $ns.AddNamespace($k, $Map[$k]) }
    # XmlNamespaceManager is IEnumerable, so a bare `$ns` returns its prefixes as an
    # array instead of the manager itself.
    Write-Output -NoEnumerate $ns
}

# --------------------------------------------------------------- .docx

function Get-ParaText($Node) {
    # w:instrText and w:delText are absent by omission - field codes and tracked
    # deletions are not document content.
    $sb = New-Object System.Text.StringBuilder
    foreach ($n in $Node.SelectNodes('.//w:t | .//w:tab | .//w:br | .//w:cr', $script:Ns)) {
        switch ($n.LocalName) {
            't' { [void]$sb.Append($n.InnerText) }
            'tab' { [void]$sb.Append("`t") }
            default { [void]$sb.Append("`n") }
        }
    }
    $sb.ToString()
}

function Get-ParaStyle($P) {
    $st = $P.SelectSingleNode('w:pPr/w:pStyle', $script:Ns)
    if ($null -eq $st) { return '' }
    $st.GetAttribute('val', $script:WNs)
}

function Get-HeadingLevel([string]$Style) {
    # Word's Heading1 sits under the document Title, so it maps to '##'.
    $s = ($Style -replace '\s', '').ToLowerInvariant()
    if ($s -eq 'title') { return 1 }
    if ($s -eq 'subtitle') { return 2 }
    if ($s -match '^heading(\d)$') { return [Math]::Min([int]$Matches[1] + 1, 6) }
    return 0
}

function Get-ListLevel($P) {
    $num = $P.SelectSingleNode('w:pPr/w:numPr', $script:Ns)
    if ($null -eq $num) { return -1 }
    $ilvl = $num.SelectSingleNode('w:ilvl', $script:Ns)
    if ($null -eq $ilvl) { return 0 }
    $n = 0
    if ([int]::TryParse($ilvl.GetAttribute('val', $script:WNs), [ref]$n)) {
        return [Math]::Max(0, [Math]::Min($n, 6))
    }
    return 0
}

function Convert-WordTable($Tbl) {
    $rows = @()
    foreach ($tr in $Tbl.SelectNodes('w:tr', $script:Ns)) {
        $cells = @()
        foreach ($tc in $tr.SelectNodes('w:tc', $script:Ns)) {
            $parts = @()
            foreach ($p in $tc.SelectNodes('w:p', $script:Ns)) {
                $t = (Get-ParaText $p).Trim()
                if ($t) { $parts += $t }
            }
            $cells += (Format-Cell ($parts -join ' '))
        }
        if ($cells.Count -gt 0) { $rows += , $cells }
    }
    Convert-RowsToMarkdown $rows
}

function Get-BodyChild($Node) {
    # Flatten content controls; a title page is often wrapped in w:sdt.
    $out = @()
    foreach ($child in $Node.ChildNodes) {
        if ($child.LocalName -eq 'sdt') {
            $content = $child.SelectSingleNode('w:sdtContent', $script:Ns)
            if ($null -ne $content) { $out += @(Get-BodyChild $content) }
        }
        else { $out += $child }
    }
    $out
}

function Convert-DocxToMarkdown([string]$FilePath) {
    $problem = Test-FileProblem $FilePath
    if ($problem) { throw $problem }
    $zip = [System.IO.Compression.ZipFile]::OpenRead($FilePath)
    try { $raw = Read-ZipEntry $zip 'word/document.xml' } finally { $zip.Dispose() }
    if ($null -eq $raw) { throw 'no word/document.xml - not a Word file' }

    $doc = ConvertTo-SafeXml $raw
    $script:Ns = New-NsManager $doc @{ 'w' = $script:WNs }
    $body = $doc.DocumentElement.SelectSingleNode('w:body', $script:Ns)
    if ($null -eq $body) { return @() }

    $lines = @()
    foreach ($child in @(Get-BodyChild $body)) {
        if ($child.LocalName -eq 'p') {
            $text = (Get-ParaText $child).Replace("`t", '  ').Trim()
            if (-not $text) { continue }
            $level = Get-HeadingLevel (Get-ParaStyle $child)
            $lvl = Get-ListLevel $child
            if ($level -gt 0) { $lines += @('', ('#' * $level + ' ' + $text), '') }
            elseif ($lvl -ge 0) { $lines += (('  ' * $lvl) + '- ' + $text) }
            else { $lines += @($text, '') }
        }
        elseif ($child.LocalName -eq 'tbl') {
            $table = @(Convert-WordTable $child)
            if ($table.Count -gt 0) { $lines += @('') + $table + @('') }
        }
    }
    Compress-Blanks $lines
}

# --------------------------------------------------------------- .xlsx

function Get-ColumnIndex([string]$Ref) {
    if ($Ref -notmatch '^([A-Za-z]+)(\d+)$') { return -1 }
    $n = 0
    foreach ($ch in $Matches[1].ToUpperInvariant().ToCharArray()) {
        $n = $n * 26 + ([int][char]$ch - 64)
    }
    $n - 1
}

function Convert-XlsxToMarkdown([string]$FilePath) {
    $problem = Test-FileProblem $FilePath
    if ($problem) { throw $problem }
    $zip = [System.IO.Compression.ZipFile]::OpenRead($FilePath)
    try {
        $sstRaw = Read-ZipEntry $zip 'xl/sharedStrings.xml'
        $wbRaw = Read-ZipEntry $zip 'xl/workbook.xml'
        $relRaw = Read-ZipEntry $zip 'xl/_rels/workbook.xml.rels'
        if ($null -eq $wbRaw -or $null -eq $relRaw) { throw 'no workbook - not an Excel file' }

        $shared = @()
        if ($null -ne $sstRaw) {
            $sst = ConvertTo-SafeXml $sstRaw
            $sns = New-NsManager $sst @{ 'x' = $script:SsNs }
            foreach ($si in $sst.DocumentElement.SelectNodes('x:si', $sns)) {
                $sb = New-Object System.Text.StringBuilder
                foreach ($t in $si.SelectNodes('.//x:t', $sns)) { [void]$sb.Append($t.InnerText) }
                $shared += $sb.ToString()
            }
        }

        $rels = ConvertTo-SafeXml $relRaw
        $rns = New-NsManager $rels @{ 'p' = $script:PrNs }
        $rid = @{}
        foreach ($rel in $rels.DocumentElement.SelectNodes('p:Relationship', $rns)) {
            $target = $rel.GetAttribute('Target').Replace('\', '/')
            if ($target.StartsWith('/')) { $target = $target.Substring(1) }
            elseif (-not $target.StartsWith('xl/')) { $target = 'xl/' + $target }
            $rid[$rel.GetAttribute('Id')] = $target
        }

        $wb = ConvertTo-SafeXml $wbRaw
        $wns = New-NsManager $wb @{ 'x' = $script:SsNs; 'r' = $script:RNs }
        $sheets = @()
        foreach ($sh in $wb.DocumentElement.SelectNodes('x:sheets/x:sheet', $wns)) {
            $member = $rid[$sh.GetAttribute('id', $script:RNs)]
            if ($member) {
                $name = $sh.GetAttribute('name')
                if (-not $name) { $name = 'sheet' }
                $sheets += , @($name, $member)
            }
        }
        if ($sheets.Count -eq 0) { throw 'no sheets found - not an Excel file' }

        $lines = @()
        foreach ($pair in $sheets) {
            $raw = Read-ZipEntry $zip $pair[1]
            $rows = @()
            if ($null -ne $raw) {
                $ws = ConvertTo-SafeXml $raw
                $xns = New-NsManager $ws @{ 'x' = $script:SsNs }
                foreach ($row in $ws.DocumentElement.SelectNodes('x:sheetData/x:row', $xns)) {
                    $cells = @{}
                    $i = 0
                    foreach ($c in $row.SelectNodes('x:c', $xns)) {
                        $idx = Get-ColumnIndex $c.GetAttribute('r')
                        if ($idx -lt 0) { $idx = $i }
                        $t = $c.GetAttribute('t')
                        $val = ''
                        if ($t -eq 'inlineStr') {
                            foreach ($n in $c.SelectNodes('x:is//x:t', $xns)) { $val += $n.InnerText }
                        }
                        else {
                            $v = $c.SelectSingleNode('x:v', $xns)
                            if ($null -ne $v) { $val = $v.InnerText }
                            if ($t -eq 's') {
                                $si = 0
                                if ([int]::TryParse($val, [ref]$si) -and $si -ge 0 -and $si -lt $shared.Count) {
                                    $val = $shared[$si]
                                }
                                else { $val = '' }
                            }
                        }
                        $cells[$idx] = Format-Cell $val
                        $i++
                    }
                    if ($cells.Count -gt 0) {
                        $max = ($cells.Keys | Measure-Object -Maximum).Maximum
                        $arr = @()
                        for ($k = 0; $k -le $max; $k++) {
                            $arr += $(if ($cells.ContainsKey($k)) { $cells[$k] } else { '' })
                        }
                        $rows += , $arr
                    }
                    else { $rows += , @() }
                }
            }
            $table = @(Convert-RowsToMarkdown $rows)
            $lines += @('', ('## Sheet: ' + $pair[0]), '')
            $lines += $(if ($table.Count -gt 0) { $table } else { @('_empty sheet_') })
        }
        Compress-Blanks $lines
    }
    finally { $zip.Dispose() }
}

# --------------------------------------------------------------- .drawio

function Convert-DrawioLabel([string]$Text) {
    if (-not $Text) { return '' }
    $t = [regex]::Replace($Text, '<br\s*/?>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<[^>]+>', '')
    [System.Net.WebUtility]::HtmlDecode($t).Replace("`n", ' ').Trim()
}

function Get-DrawioModel($Dia) {
    # A page is either inline <mxGraphModel> or draw.io's base64 + raw-deflate form.
    $model = $Dia.SelectSingleNode('mxGraphModel')
    if ($null -ne $model) { return $model }
    $payload = $Dia.InnerText.Trim()
    if (-not $payload) { return $null }
    try { $raw = [System.Convert]::FromBase64String($payload) } catch { return $null }
    foreach ($skip in @(0, 2)) {
        try {
            $bytes = if ($skip -eq 0) { $raw } else { [byte[]]($raw[$skip..($raw.Length - 1)]) }
            $ms = New-Object System.IO.MemoryStream(, $bytes)
            $ds = New-Object System.IO.Compression.DeflateStream($ms, [System.IO.Compression.CompressionMode]::Decompress)
            $sr = New-Object System.IO.StreamReader($ds, [System.Text.Encoding]::UTF8)
            try { $xml = $sr.ReadToEnd() } finally { $sr.Dispose() }
            return (ConvertTo-SafeXml ([System.Uri]::UnescapeDataString($xml))).DocumentElement
        }
        catch { continue }
    }
    return $null
}

function Get-DrawioCells($Model) {
    $nodes = New-Object System.Collections.Specialized.OrderedDictionary
    $edges = @()
    foreach ($el in $Model.SelectNodes('.//object | .//mxCell')) {
        if ($el.LocalName -eq 'object') {
            $cell = $el.SelectSingleNode('mxCell')
            $cid = $el.GetAttribute('id')
            $label = Convert-DrawioLabel $el.GetAttribute('label')
        }
        else {
            # An mxCell wrapped in <object> carries no id; it is handled above.
            $cell = $el
            $cid = $el.GetAttribute('id')
            $label = Convert-DrawioLabel $el.GetAttribute('value')
        }
        if ($null -eq $cell -or -not $cid -or $nodes.Contains($cid)) { continue }
        if ($cell.GetAttribute('edge') -eq '1') {
            $edges += , @($cell.GetAttribute('source'), $cell.GetAttribute('target'), $label)
        }
        elseif ($cell.GetAttribute('vertex') -eq '1') {
            $nodes[$cid] = $label
        }
    }
    @{ nodes = $nodes; edges = $edges }
}

function Convert-DrawioToMarkdown([string]$FilePath) {
    $doc = ConvertTo-SafeXml (Read-TextFile $FilePath)
    $root = $doc.DocumentElement
    $pages = @()
    if ($root.LocalName -eq 'mxfile') {
        $i = 0
        foreach ($d in $root.SelectNodes('diagram')) {
            $i++
            $name = $d.GetAttribute('name')
            if (-not $name) { $name = "Page-$i" }
            $pages += , @($name, (Get-DrawioModel $d))
        }
    }
    elseif ($root.LocalName -eq 'mxGraphModel') { $pages += , @('Page-1', $root) }
    else { throw ("not a draw.io file (root element is <" + $root.LocalName + ">)") }
    if ($pages.Count -eq 0) { throw 'no diagram pages found' }

    $lines = @(
        '> Deterministic graph extraction. Shapes, labels and connections are read from',
        '> the file. Protocol, data-flow direction and component roles are **not** inferred',
        '> here -- a connection means the diagram joins two shapes, nothing more.'
    )
    foreach ($page in $pages) {
        $lines += @('', ('## Page: ' + $page[0]), '')
        $model = $page[1]
        if ($null -eq $model) { $lines += '_Page content could not be decoded._'; continue }

        $g = Get-DrawioCells $model
        $nodes = $g.nodes
        $labelled = @($nodes.Keys | Where-Object { $nodes[$_] })
        $lines += @(('### Shapes ({0} labelled, {1} unlabelled)' -f $labelled.Count, ($nodes.Count - $labelled.Count)), '')
        if ($labelled.Count -gt 0) {
            $rows = @(, @('id', 'label'))
            foreach ($k in ($labelled | Sort-Object)) { $rows += , @($k, (Format-Cell $nodes[$k])) }
            $lines += @(Convert-RowsToMarkdown $rows)
        }
        else { $lines += '_No labelled shapes._' }

        $dangling = 0
        $erows = @(, @('from', 'to', 'label'))
        foreach ($e in $g.edges) {
            $a = if ($nodes.Contains($e[0])) { $nodes[$e[0]] } else { $null }
            $b = if ($nodes.Contains($e[1])) { $nodes[$e[1]] } else { $null }
            if ($null -eq $a -or $null -eq $b) { $dangling++ }
            $erows += , @((Format-Cell $(if ($null -ne $a) { $a } else { '(unconnected)' })),
                (Format-Cell $(if ($null -ne $b) { $b } else { '(unconnected)' })),
                (Format-Cell $e[2]))
        }
        $lines += @('', ('### Connections ({0})' -f $g.edges.Count), '')
        if ($g.edges.Count -gt 0) { $lines += @(Convert-RowsToMarkdown $erows) }
        else { $lines += '_No connections._' }
        if ($dangling -gt 0) {
            $lines += @('', ('**{0} connection(s) have a loose end** in the source diagram.' -f $dangling))
        }
    }
    Compress-Blanks $lines
}

# --------------------------------------------------------------- flat files

function Read-TextFile([string]$FilePath) {
    [System.IO.File]::ReadAllText($FilePath, [System.Text.Encoding]::UTF8)
}

function Split-TextLines([string]$Text) {
    # A single trailing newline ends the last line, it does not start an empty one.
    ($Text -replace "`r?`n$", '') -split "`r?`n"
}

function Split-DelimitedText([string]$Text, [char]$Delim) {
    $rows = @()
    $row = @()
    $cur = New-Object System.Text.StringBuilder
    $inQuotes = $false
    for ($i = 0; $i -lt $Text.Length; $i++) {
        $ch = $Text[$i]
        if ($inQuotes) {
            if ($ch -eq '"') {
                if (($i + 1) -lt $Text.Length -and $Text[$i + 1] -eq '"') { [void]$cur.Append('"'); $i++ }
                else { $inQuotes = $false }
            }
            else { [void]$cur.Append($ch) }
        }
        elseif ($ch -eq '"') { $inQuotes = $true }
        elseif ($ch -eq $Delim) { $row += (Format-Cell $cur.ToString()); [void]$cur.Clear() }
        elseif ($ch -eq "`n") {
            $row += (Format-Cell $cur.ToString()); [void]$cur.Clear()
            $rows += , $row; $row = @()
        }
        elseif ($ch -ne "`r") { [void]$cur.Append($ch) }
    }
    if ($cur.Length -gt 0 -or $row.Count -gt 0) {
        $row += (Format-Cell $cur.ToString())
        $rows += , $row
    }
    $rows
}

function Convert-CsvToMarkdown([string]$FilePath) {
    $delim = if ($FilePath.ToLowerInvariant().EndsWith('.tsv')) { "`t" } else { ',' }
    Convert-RowsToMarkdown @(Split-DelimitedText (Read-TextFile $FilePath) ([char]$delim))
}

function Convert-FileToMarkdown([string]$FilePath) {
    $ext = [System.IO.Path]::GetExtension($FilePath).ToLowerInvariant()
    switch ($ext) {
        '.docx' { return @{ lines = @(Convert-DocxToMarkdown $FilePath); kind = 'docx' } }
        '.xlsx' { return @{ lines = @(Convert-XlsxToMarkdown $FilePath); kind = 'xlsx' } }
        '.csv' { return @{ lines = @(Convert-CsvToMarkdown $FilePath); kind = 'csv' } }
        '.tsv' { return @{ lines = @(Convert-CsvToMarkdown $FilePath); kind = 'csv' } }
        '.drawio' { return @{ lines = @(Convert-DrawioToMarkdown $FilePath); kind = 'drawio' } }
        '.json' {
            # Verbatim, not re-serialised: evidence cites line numbers in the original file.
            return @{ lines = @('```json') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'json' }
        }
        '.xml' { return @{ lines = @('```xml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'xml' } }
        '.yaml' { return @{ lines = @('```yaml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'yaml' } }
        '.yml' { return @{ lines = @('```yaml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'yaml' } }
    }
    if ($script:TextExt -contains $ext) {
        return @{ lines = @(Compress-Blanks @(Split-TextLines (Read-TextFile $FilePath))); kind = 'text' }
    }
    throw ("no extractor for '" + $ext + "'")
}

# --------------------------------------------------------------- driver

if ($Command -eq 'file') {
    if (-not $Path) { [Console]::Error.WriteLine('extract: -Path is required with -Command file'); exit 1 }
    try { $r = Convert-FileToMarkdown (Resolve-Path -LiteralPath $Path).Path }
    catch { [Console]::Error.WriteLine('extract: ' + $_.Exception.Message); exit 1 }
    Write-Output ($r.lines -join "`n")
    exit 0
}

$SrcRoot = Join-Path $Root 'src'
if (-not $Out) { $Out = Join-Path (Join-Path (Join-Path $Root 'out') 'intake') 'extracted' }

if (-not (Test-Path -LiteralPath $SrcRoot)) {
    [Console]::Error.WriteLine("extract: no src folder at $SrcRoot")
    [Console]::Error.WriteLine('  Run /discovery-init-migration first.')
    exit 4
}

$done = @(); $skipped = @(); $failed = @()

foreach ($folderDir in (Get-ChildItem -LiteralPath $SrcRoot -Directory | Sort-Object Name)) {
    if ($folderDir.Name.StartsWith('.')) { continue }
    $folder = $folderDir.Name
    $prefix = $folderDir.FullName.TrimEnd('\') + '\'
    foreach ($file in (Get-ChildItem -LiteralPath $folderDir.FullName -File -Recurse -Force | Sort-Object FullName)) {
        if ($file.Name.StartsWith('.') -or ($script:Ignored -contains $file.Name.ToLowerInvariant())) { continue }
        $rel = $file.FullName.Substring($prefix.Length).Replace('\', '/')
        if ($rel -like '.*' -or $rel -like '*/.*') { continue }
        $label = $folder + '/' + $rel
        $ext = $file.Extension.ToLowerInvariant()

        if ($script:NeedsManual.ContainsKey($ext)) {
            $skipped += , @($label, $script:NeedsManual[$ext]); continue
        }
        if ($script:Extractable -notcontains $ext) {
            $skipped += , @($label, ("unrecognised type '" + $ext + "' - no extractor")); continue
        }
        try { $r = Convert-FileToMarkdown $file.FullName }
        catch { $failed += , @($label, $_.Exception.Message); continue }

        $dest = Join-Path (Join-Path $Out $folder) ($rel.Replace('/', '\') + '.md')
        $destDir = Split-Path -Parent $dest
        if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }

        $body = @($r.lines)
        if ($body.Count -eq 0) { $body = @('_No text content found in this file._') }
        $header = @(
            ('# ' + [System.IO.Path]::GetFileName($rel)), '',
            ('> Extracted from ' + $Tick + 'src/' + $label + $Tick + ' by ' + $Tick + 'Extract-Text.ps1' + $Tick + ' (' + $r.kind + ') at ' + (Get-Stamp) + '.'),
            '> Mechanical text extraction: images, formatting and embedded objects are not preserved.',
            '', '---', ''
        )
        (((@($header) + $body) -join "`n") + "`n") | Set-Content -LiteralPath $dest -Encoding UTF8 -NoNewline
        $display = $dest.Replace('\', '/')
        $rootPrefix = $Root.TrimEnd('\', '/').Replace('\', '/') + '/'
        if ($display.StartsWith($rootPrefix)) { $display = $display.Substring($rootPrefix.Length) }
        $done += , @($label, $r.kind, $display, ($folder + '/' + $rel + '.md'), $body.Count)
    }
}

$lines = @('# Extracted intake', '', ('Generated ' + (Get-Stamp) + ' by ' + $Tick + 'Extract-Text.ps1' + $Tick + '.'), '',
    ('Every downstream reader uses **these** files, not the originals under ' + $Tick + 'src/' + $Tick + '. The originals are never modified.'), '',
    '| Source | Extractor | Lines | Extracted to |', '|---|---|---|---|')
foreach ($d in $done) {
    $lines += ('| ' + $Tick + 'src/' + $d[0] + $Tick + ' | ' + $d[1] + ' | ' + $d[4] + ' | [' + $Tick + $d[2] + $Tick + '](' + $d[3] + ') |')
}
if ($done.Count -eq 0) { $lines += '| _none_ | | | |' }
if ($skipped.Count -gt 0) {
    $lines += @('', '## Not extracted', '', 'These were **not read**. Do not cite them as evidence.', '', '| File | Why |', '|---|---|')
    foreach ($s in $skipped) { $lines += ('| ' + $Tick + 'src/' + $s[0] + $Tick + ' | ' + $s[1] + ' |') }
}
if ($failed.Count -gt 0) {
    $lines += @('', '## Failed', '', 'Present and of a supported type, but could not be parsed.', '', '| File | Error |', '|---|---|')
    foreach ($f in $failed) { $lines += ('| ' + $Tick + 'src/' + $f[0] + $Tick + ' | ' + $f[1].Replace('|', '\|') + ' |') }
}
if (-not (Test-Path -LiteralPath $Out)) { New-Item -ItemType Directory -Path $Out -Force | Out-Null }
$indexPath = Join-Path $Out 'INDEX.md'
(($lines -join "`n") + "`n") | Set-Content -LiteralPath $indexPath -Encoding UTF8 -NoNewline
Write-Output "index -> $indexPath"

foreach ($d in $done) {
    Write-Output ('extracted  {0} {1} {2,4} lines -> {3}' -f $d[0].PadRight(45), $d[1].PadRight(6), $d[4], $d[2])
}
foreach ($s in $skipped) { Write-Output ('SKIPPED    {0} {1}' -f $s[0].PadRight(45), $s[1]) }
foreach ($f in $failed) { [Console]::Error.WriteLine(('FAILED     {0} {1}' -f $f[0].PadRight(45), $f[1])) }

Write-Output ''
Write-Output ("{0} extracted, {1} skipped, {2} failed" -f $done.Count, $skipped.Count, $failed.Count)

if ($done.Count -eq 0) {
    [Console]::Error.WriteLine('')
    [Console]::Error.WriteLine("STOP: nothing could be extracted from $SrcRoot.")
    [Console]::Error.WriteLine('  Files were present but none is machine-readable.')
    [Console]::Error.WriteLine('  Convert at least one to .docx, .xlsx, .csv, .md or .txt and re-run.')
    exit 2
}
exit 0
