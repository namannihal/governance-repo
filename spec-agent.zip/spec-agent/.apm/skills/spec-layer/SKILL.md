---
name: spec-layer
description: "How the statement store, the canonical spec, the three views and the review gate fit together. Use when running /spec-ingest, /spec-review, or when a downstream agent reports exit 3."
---

# The spec layer

One statement store. Every phase appends to it and reads from it. The three
"specs" are views over the same statements, organised by audience rather than by
phase, and they hold statement ids rather than copies of the text.

## The files

| File | Written by | Purpose |
|---|---|---|
| `out/sources/source-register.json` | `register-sources` | every file, its hash, and whether it could be read |
| `out/statements.json` | `add-statement` | the atomic claim store |
| `out/evidence-map.json` | `build` | source id to statement ids, for impact analysis |
| `out/conflicts/unresolved-conflicts.json` | `build` | same fact_key, competing values |
| `out/specifications/system-spec.json` | `build` | canonical, one entry per fact_key |
| `out/specifications/{development,devops,refactoring}-spec.json` | `build` | the three views |
| `out/decisions/decision-log.jsonl` | `review`, `verify` | append-only, never regenerated |
| `out/review/*.md` | `build` | generated, read-only |

Everything under `specifications/` and `review/` can be deleted and rebuilt. The
statement store and the decision log cannot.

## The lifecycle

```
register-sources -> add-statement (many) -> build -> review (human) -> resolve
```

`build` is safe to re-run at any time. `review` is the only thing that changes a
status. `resolve` is the only thing a downstream agent may call.

## Status

```
draft -> needs-review -> changes-requested -> approved -> superseded
```

New statements start at `needs-review`. Approval is a human act: `review`
requires `-Actor`, and refuses without one.

## Two things that void an approval automatically

**The evidence moved.** Approval stores a hash over the value plus the evidence,
including the sha256 of each source file. `verify` recomputes it. If a source
document was edited, the approval is void and the statement returns to
`needs-review` with reason `source-changed`.

**A conflict opened.** If a second statement appears with the same `fact_key` and
a different value, `build` marks both low confidence, blocks the sections that
contain them, and voids any approval on them with reason `conflict-opened`.

Neither is a failure. Both are the system noticing that what was agreed no longer
matches what is there.

## Tiers and confidence

Tier comes from `-Method`, never from the caller. Confidence comes from tier,
except that an open conflict forces `low` regardless. Human approval does not
raise confidence; it sets a review status. A low-confidence fact that has been
approved is still low-confidence, and the view says so.

## Routing

`fact_key` prefixes decide which views a statement lands in.

| Prefix | Views | Section |
|---|---|---|
| `api.` `contract.` | development | contracts |
| `data.` | development | data-model |
| `behaviour.` | development, refactoring | behaviour |
| `nfr.` | devops, development | nfr |
| `infra.` `aws.` `azure.` | devops (aws also refactoring) | infrastructure |
| `deploy.` `env.` `config.` `monitor.` `rollback.` | devops | matching section |
| `arch.` `debt.` | refactoring | current-architecture, technical-debt |
| `dependency.` | refactoring, devops | dependencies |
| `risk.` | devops, refactoring | risks |

Anything unmatched lands in section `unrouted` and is counted in the review
summary. That is deliberate - a silently defaulted fact is worse than a visibly
homeless one.

## Reading the exit codes

| Exit | Meaning |
|---|---|
| 0 | success |
| 2 | hard stop: no evidence, nothing to build, or a required argument missing |
| 3 | prerequisite unmet: not approved, or a blocked section |
| 4 | missing store, unknown view, unknown statement, unknown source |
| 5 | already exists |

Exit 3 from `resolve` is the gate working. It means a human has not agreed yet.

## When a downstream agent reports exit 3

Run this to see what is blocking:

```
Spec.ps1 -Command resolve -View devops-spec -MinStatus approved
```

It lists every statement below the threshold with its current status. Approve the
ones that are right; use `-Action request-changes` on the ones that are not.
Never lower `-MinStatus` to get past it.
