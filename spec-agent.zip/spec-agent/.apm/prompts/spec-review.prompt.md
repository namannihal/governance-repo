---
mode: agent
description: "Walk a human through reviewing the spec in triage order, record every decision, and re-check approvals whose evidence has moved."
---

# /spec-review

Agent: [spec-reviewer](../agents/spec-reviewer.agent.md) |
Skill: [spec-layer](../skills/spec-layer/SKILL.md)

## Steps

1. **Re-check bindings before anything else:**

   ```
   Spec.ps1 -Root <root> -Command verify
   ```

   Voids any approval whose source document changed. If it voids anything, say so
   first - the user is about to review a spec they thought was already signed off.

2. **Show the triage numbers:**

   ```
   Spec.ps1 -Root <root> -Command status
   ```

3. **Work in this order.** Not file order.

   | Order | Class | Why it comes first |
   |---|---|---|
   | 1 | open conflicts | they block whole sections; nothing downstream runs |
   | 2 | tier E | a guess; always needs a human |
   | 3 | tier D | weak inference |
   | 4 | unrouted | no domain matched, so nobody owns it |
   | 5 | tier A/B | offer a spot-check, not a full pass |

4. **For each statement, show the evidence** so it can be judged without opening the
   document:

   ```
   stmt-7472c831   azure.target.queue = servicebus-premium
     tier C (inferred), confidence medium
     source: assessment.md, line 3
     quote:  "Queue: SQS"
   ```

5. **Record the decision:**

   ```
   Spec.ps1 -Root <root> -Command review -Target <id> -Action approve         -Actor <who>
   Spec.ps1 -Root <root> -Command review -Target <id> -Action request-changes -Actor <who> -Rationale "<why>"
   ```

   Both append to `out/decisions/decision-log.jsonl`, which is append-only and never
   regenerated. Approving stores a hash over the evidence, so `verify` can void it
   later if the source moves.

6. **Rebuild after resolving conflicts**, or the affected sections stay blocked:

   ```
   Spec.ps1 -Root <root> -Command build
   ```

7. **Confirm the gate has actually opened:**

   ```
   Spec.ps1 -Root <root> -Command resolve -View devops-spec -MinStatus approved
   ```

   Exit 0 means a consumer can now proceed. Exit 3 means it still cannot, and you
   should say which statements are responsible.

## Report

Say what is still open, not just what was done. "Three conflicts remain, so
devops-spec will still refuse" is useful. "Reviewed 40 statements" is not.

## Never

- Approve on the reviewer's behalf, or infer approval from silence.
- Lower `-MinStatus` to make a refusal go away.
- Edit `out/review/*.md`.
- Present an approved low-confidence statement as settled. Approval sets a status;
  it does not raise confidence.
