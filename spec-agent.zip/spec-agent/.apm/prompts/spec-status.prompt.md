---
mode: agent
description: "Report the state of the spec, and say plainly whether a downstream consumer would be allowed to run."
---

# /spec-status

Agent: [spec](../agents/spec.agent.md)

Use this to answer "where are we?" and, more often, "why did my build agent refuse?"

## Steps

1. **Re-check bindings**, so nothing you report is stale:

   ```
   Spec.ps1 -Root <root> -Command verify
   ```

2. **Counts:**

   ```
   Spec.ps1 -Root <root> -Command status
   ```

3. **Test each gate the way a consumer would:**

   ```
   Spec.ps1 -Root <root> -Command resolve -View devops-spec      -MinStatus approved
   Spec.ps1 -Root <root> -Command resolve -View development-spec -MinStatus approved
   Spec.ps1 -Root <root> -Command resolve -View refactoring-spec -MinStatus approved
   ```

   Record the exit code for each. That is the real answer to "is it ready".

## Report

Lead with the gate, because it is what people are asking about:

```
devops-spec        REFUSES   (exit 3)  4 statements unapproved, 1 section blocked
development-spec   READY     (exit 0)  12 statements, plan_hash 9f3c...
refactoring-spec   EMPTY     (exit 2)  no statements routed here yet
```

Then the numbers behind it: total statements, how many approved, how many tier D or E,
how many open conflicts, how many sources could not be read.

## When someone asks why their agent refused

Exit 3 has exactly two causes. Name which one:

| Cause | Fix |
|---|---|
| statements below `-MinStatus` | run `/spec-review` and approve them |
| a section is blocked | an open conflict; resolve it, then `build` again |

Do not suggest lowering `-MinStatus`, and do not describe what the spec would contain
if it were approved. Neither is the answer to the question they asked.
