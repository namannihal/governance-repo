---
mode: agent
description: "Create the spec store and the intake folders for a migration."
---

# /spec-init

Agent: [spec](../agents/spec.agent.md)

## Steps

1. **Ask for the migration root** if the user did not give one. Convention is
   `.lmp-migrate/<slug>`, but any folder works - this package has no opinion.

2. **Create the store:**

   ```
   Spec.ps1 -Root <root> -Command init
   ```

   | Exit | Meaning | What you do |
   |---|---|---|
   | 0 | created | carry on |
   | 5 | already exists | **stop and say so.** Do not pass `-Force` |

   `-Force` discards every statement and every approval in the store. Only use it if
   the user asks to start over, in those words, after you have told them what it does.

3. **Create the intake folders** so the user knows where to put documents:

   ```
   <root>\src\comigrate-assessment\     CoMigrate assessment export
   <root>\src\aimigrate-assessment\     AI Migrate intake report
   <root>\src\existing-sad\             a SAD that already exists
   <root>\src\application-docs\         anything else: design docs, runbooks, diagrams, spreadsheets
   ```

4. **Tell the user what was created and what to do next:** drop documents into those
   folders, then run `/spec-ingest`.

## Precedence, if they ask

`comigrate` -> `aimigrate` -> `existing_sad` -> `appdocs`

A later source may **fill** a gap. It may never **override** a higher one. So a
structured export always wins over a Word document that disagrees with it.
