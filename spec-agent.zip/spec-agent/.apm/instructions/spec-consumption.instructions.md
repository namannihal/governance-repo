---
applyTo: "**"
description: "The contract for any agent that reads this spec, including agents shipped by someone else. Hand this to whoever owns your IaC agent."
---

# Consuming the spec

These rules apply to every agent that reads this specification, whether or not it
ships in this package. They exist because a build agent that improvises is worse than
one that stops.

## One way in

```
Spec.ps1 -Root <root> -Command resolve -View <view> -MinStatus approved -Format json
```

That is the entire input surface. Specifically:

- **Never** open `out/specifications/*.json` directly. Those contain statements at
  every status, including drafts. `resolve` is what filters them.
- **Never** read `out/statements.json`. It is the writer's format, not a contract, and
  it will change shape.
- **Never** read `src/`. The documents were interpreted once, under review. Re-reading
  them produces a second opinion nobody approved.
- **Never** carry facts between commands in conversation. If a later command needs a
  fact, it resolves again.

## Exit codes are the protocol

| Exit | Meaning | Required behaviour |
|---|---|---|
| 0 | resolved | proceed |
| 2 | nothing to resolve, or an unmappable value | stop, name the `fact_key` |
| 3 | not approved, or a blocked section | stop, write nothing, list the blockers |
| 4 | missing store or unknown view | stop, report the path |

**Exit 3 must never be worked around.** Do not retry at a lower `-MinStatus`, do not
generate a subset, do not describe what you would have produced. A refusal softened
into a partial answer is how an unapproved decision reaches an environment.

## Redirecting stderr

If you shell out to `Spec.ps1` with `2>&1` while `$ErrorActionPreference` is `Stop`,
the child's error output becomes a **terminating error in your process**. Your agent
then dies with exit 1 instead of propagating the refusal, and the gate silently stops
working. Relax the preference across the call:

```powershell
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$out  = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SpecScript ... 2>&1
$code = $LASTEXITCODE
$ErrorActionPreference = $prevEap
```

This shipped as a real bug in our own build agent and was caught only by a test that
asserted on the exit code rather than on the happy path.

## The plan hash

`resolve` returns a `plan_hash` over the exact statements it handed you. Write it next
to whatever you generate.

Its purpose is that an approval can be checked against a deployment: change a statement
and the hash changes, so an approval naming the old hash no longer describes what is
about to be applied.

**Never compute your own hash over your own output.** It has to cover the inputs, or it
cannot detect that the inputs moved.

## Absence

If something you need is not in the resolved payload, it does not exist. The correct
response is a hard stop naming what is missing. Filling the gap with a sensible default
is the failure this design exists to prevent, and a sensible default is the hardest
kind to spot later.

## Weak facts stay weak

A statement can be `approved` and still be tier D or E. Approval sets a review status;
it does not raise confidence. If you act on a low-confidence fact, say so in your
output rather than presenting it as settled.

## Writing back

Consumers write only their own artifacts. Never write a statement, never edit the
decision log, never change a review status. Those belong to `/spec-review` and to a
named human.
