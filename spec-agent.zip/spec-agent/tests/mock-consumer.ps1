<#
.SYNOPSIS
    A minimal compliant consumer of the spec layer. Reference implementation.

.DESCRIPTION
    About forty lines of real logic. It does exactly what docs/INTEGRATION.md requires
    and nothing else, so it doubles as:

      - the fixture the contract test suite runs against
      - the shortest useful example for whoever is wiring up a real agent

    It writes a trivial artifact (a manifest listing what it would build) rather than
    real infrastructure, because the point is the contract, not the output.

.EXAMPLE
    .\mock-consumer.ps1 -Root C:\tmp\demo -SpecScript ..\.apm\scripts\powershell\Spec.ps1

.NOTES
    Exit codes are deliberately identical to the ones it receives, because a consumer
    that swallows the gate's exit code has broken the gate.
      0  produced an artifact
      2  an approved value has no mapping, or nothing to build
      3  refused - the spec is not approved
      4  missing store or unknown view
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Root,
    [Parameter(Mandatory = $true)][string]$SpecScript,
    [string]$View = 'devops-spec',
    [string]$OutDir
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

if (-not (Test-Path $SpecScript)) {
    [Console]::Error.WriteLine("ERROR: Spec.ps1 not found at '$SpecScript'")
    exit 4
}
if (-not $OutDir) { $OutDir = Join-Path $Root 'out\consumer' }

# Everything this consumer knows. A value outside this table is a hard stop.
$KNOWN = @{
    'apim-premium'       = 'api-gateway'
    'functions-premium'  = 'compute'
    'cosmosdb'           = 'datastore'
    'blob-ragzrs'        = 'objectstore'
    'servicebus-premium' = 'queue'
    'frontdoor'          = 'edge'
}

# --- the gate -------------------------------------------------------------- #
# EAP is relaxed across the call: with 2>&1 under Stop, the child's stderr would
# raise a terminating error here and this process would die with exit 1 instead of
# propagating the refusal.
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$out = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SpecScript `
    -Root $Root -Command resolve -View $View -MinStatus approved -Format json 2>&1
$code = $LASTEXITCODE
$ErrorActionPreference = $prevEap

if ($code -eq 3) {
    [Console]::Error.WriteLine('REFUSED: the spec is not approved. Writing nothing.')
    foreach ($line in @($out)) { [Console]::Error.WriteLine("  $line") }
    exit 3
}
if ($code -ne 0) {
    foreach ($line in @($out)) { [Console]::Error.WriteLine("  $line") }
    exit $code
}

# --- act on the payload ---------------------------------------------------- #
$json = ($out | Where-Object { $_ -is [string] }) -join "`n"
$plan = $json | ConvertFrom-Json

$targets = @(@($plan.statements) | Where-Object { $_.fact_key -like 'azure.target.*' })
if ($targets.Count -eq 0) {
    [Console]::Error.WriteLine('nothing to build: no azure.target.* statements in the approved view')
    exit 2
}

$unmapped = @($targets | Where-Object { -not $KNOWN.ContainsKey($_.value) })
if ($unmapped.Count -gt 0) {
    [Console]::Error.WriteLine('HARD STOP: approved value(s) this consumer does not know:')
    foreach ($u in $unmapped) { [Console]::Error.WriteLine("  $($u.fact_key) = $($u.value)") }
    exit 2
}

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
$manifest = [ordered]@{
    view          = $plan.view
    plan_hash     = $plan.plan_hash          # bind the output to the inputs
    built         = @($targets | ForEach-Object { $KNOWN[$_.value] })
    statement_ids = @($targets | ForEach-Object { $_.id })
    weak_facts    = @($targets | Where-Object { $_.tier -in @('D', 'E') } | ForEach-Object { $_.id })
}
Set-Content -Path (Join-Path $OutDir 'manifest.json') `
    -Value (($manifest | ConvertTo-Json -Depth 20) + "`r`n") -Encoding UTF8 -NoNewline

Write-Output ("built {0} component(s), plan_hash {1}" -f $targets.Count, $plan.plan_hash)
if ($manifest.weak_facts.Count -gt 0) {
    Write-Output ("NOTE: {0} of these rest on tier D/E evidence" -f $manifest.weak_facts.Count)
}
exit 0
