<#
.SYNOPSIS
    Static analysis for the PowerShell in this repo, with no module dependency.

.DESCRIPTION
    PSScriptAnalyzer is not installed and apm.yml promises these packages need no
    modules, so this uses the PowerShell parser that ships with 5.1 and adds the
    handful of project-specific rules that have actually caused bugs here.

    Rules
      PARSE001  file does not parse
      ENC001    non-ASCII byte - these scripts are read as ANSI on some machines
      ENC002    UTF-8 BOM - a BOM has been mistaken for content by downstream parsers
      STY001    aliased cmdlet - unreadable and can be shadowed
      STY002    Write-Host in a shipped script - use Write-Output so callers can capture
      BUG001    $x -eq $null - PowerShell needs $null on the left to compare safely
      BUG002    empty catch block - swallows the failure it was written to notice
      BUG003    exit (Invoke-Something) - captures the function output as the exit code
      DOC001    no comment-based help
      HYG001    trailing whitespace
      HYG002    tab character

    STY002 and BUG003 apply only to shipped scripts. A test harness writes to the
    console on purpose, and this file holds its own rule patterns as string literals.

.EXAMPLE
    .\Invoke-StaticAnalysis.ps1
    .\Invoke-StaticAnalysis.ps1 -FailOn Error
#>
[CmdletBinding()]
param(
    [string[]]$Path,
    [ValidateSet('Error', 'Warning', 'None')][string]$FailOn = 'Error'
)

$ErrorActionPreference = 'Continue'

$script:Findings = New-Object System.Collections.ArrayList

$ALIASES = @{
    'gci' = 'Get-ChildItem'; 'ls' = 'Get-ChildItem'; 'dir' = 'Get-ChildItem'
    'cat' = 'Get-Content'; 'gc' = 'Get-Content'; 'type' = 'Get-Content'
    '%' = 'ForEach-Object'; '?' = 'Where-Object'
    'select' = 'Select-Object'; 'where' = 'Where-Object'; 'foreach' = 'ForEach-Object'
    'sort' = 'Sort-Object'; 'measure' = 'Measure-Object'
    'rm' = 'Remove-Item'; 'del' = 'Remove-Item'; 'cp' = 'Copy-Item'; 'mv' = 'Move-Item'
    'echo' = 'Write-Output'; 'sc' = 'Set-Content'; 'iex' = 'Invoke-Expression'
}

function Add-Finding([string]$File, [int]$Line, [string]$Rule, [string]$Severity, [string]$Message) {
    [void]$script:Findings.Add([pscustomobject]@{
            File = $File; Line = $Line; Rule = $Rule; Severity = $Severity; Message = $Message
        })
}

function Test-OneFile([string]$FullPath, [string]$Display, [bool]$IsShipped) {

    # --- encoding ------------------------------------------------------------ #
    $bytes = [System.IO.File]::ReadAllBytes($FullPath)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        Add-Finding $Display 1 'ENC002' 'Warning' 'file starts with a UTF-8 BOM'
    }
    $line = 1
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        if ($bytes[$i] -eq 0x0A) { $line++ }
        if ($bytes[$i] -gt 127) {
            Add-Finding $Display $line 'ENC001' 'Error' ("non-ASCII byte 0x{0:X2}" -f $bytes[$i])
            break
        }
    }

    # --- parse --------------------------------------------------------------- #
    $tokens = $null; $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($FullPath, [ref]$tokens, [ref]$errors)
    if ($errors -and $errors.Count -gt 0) {
        foreach ($e in $errors) {
            Add-Finding $Display $e.Extent.StartLineNumber 'PARSE001' 'Error' $e.Message
        }
        return
    }

    # --- aliases ------------------------------------------------------------- #
    $cmds = $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)
    foreach ($c in $cmds) {
        $name = $c.GetCommandName()
        if ($name -and $ALIASES.ContainsKey($name.ToLowerInvariant())) {
            Add-Finding $Display $c.Extent.StartLineNumber 'STY001' 'Warning' `
                ("alias '{0}' - use {1}" -f $name, $ALIASES[$name.ToLowerInvariant()])
        }
        if ($name -eq 'Write-Host' -and $IsShipped) {
            Add-Finding $Display $c.Extent.StartLineNumber 'STY002' 'Warning' `
                'Write-Host cannot be captured or redirected by a caller'
        }
    }

    # --- $x -eq $null -------------------------------------------------------- #
    $bins = $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.BinaryExpressionAst] }, $true)
    foreach ($b in $bins) {
        if ($b.Operator -eq 'Ieq' -or $b.Operator -eq 'Ine') {
            $right = $b.Right.Extent.Text
            $left = $b.Left.Extent.Text
            if ($right -eq '$null' -and $left -ne '$null') {
                Add-Finding $Display $b.Extent.StartLineNumber 'BUG001' 'Warning' `
                    ("'{0}' - put `$null on the left so arrays compare correctly" -f $b.Extent.Text)
            }
        }
    }

    # --- empty catch --------------------------------------------------------- #
    $catches = $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.CatchClauseAst] }, $true)
    foreach ($c in $catches) {
        if ($c.Body.Statements.Count -eq 0) {
            Add-Finding $Display $c.Extent.StartLineNumber 'BUG002' 'Warning' 'empty catch block swallows the error'
        }
    }

    # --- exit (Invoke-Something) --------------------------------------------- #
    # This one is here because it shipped in Spec.ps1 and silently ate every line of
    # command output until the tests caught it.
    $text = [System.IO.File]::ReadAllText($FullPath)
    $lines = $text -split "`r?`n"
    for ($i = 0; $i -lt $lines.Length; $i++) {
        if ($IsShipped -and $lines[$i] -match 'exit\s*\(\s*[A-Z][\w-]+\s') {
            Add-Finding $Display ($i + 1) 'BUG003' 'Error' `
                'exit (Command ...) captures the command output stream as the exit expression'
        }
        if ($lines[$i] -match '[ \t]+$') {
            Add-Finding $Display ($i + 1) 'HYG001' 'Information' 'trailing whitespace'
        }
        if ($lines[$i] -match "`t") {
            Add-Finding $Display ($i + 1) 'HYG002' 'Information' 'tab character - use spaces'
        }
    }

    # --- help ---------------------------------------------------------------- #
    if ($text -notmatch '\.SYNOPSIS') {
        Add-Finding $Display 1 'DOC001' 'Warning' 'no comment-based help (.SYNOPSIS)'
    }
}

# --------------------------------------------------------------------------- #

if (-not $Path -or $Path.Count -eq 0) {
    $repo = Split-Path -Parent $PSScriptRoot
    $Path = @(
        (Join-Path $repo '.apm\scripts\powershell'),
        $PSScriptRoot
    )
}

$files = New-Object System.Collections.ArrayList
foreach ($p in $Path) {
    if (-not (Test-Path $p)) { continue }
    if ((Get-Item $p).PSIsContainer) {
        foreach ($f in (Get-ChildItem -Path $p -Filter '*.ps1' -Recurse -File)) { [void]$files.Add($f.FullName) }
    } else {
        [void]$files.Add((Resolve-Path $p).Path)
    }
}

Write-Host ''
Write-Host 'Static analysis' -ForegroundColor White
Write-Host ("{0} file(s)" -f $files.Count) -ForegroundColor DarkGray

foreach ($f in $files) {
    $display = Split-Path -Leaf $f
    # A test harness may legitimately write to the console, and this analyser holds its
    # own rule patterns as string literals. Neither should be judged as shipped code.
    $isShipped = $f -notmatch '\\tests\\'
    Test-OneFile $f $display $isShipped
}

$errors = @($script:Findings | Where-Object { $_.Severity -eq 'Error' })
$warnings = @($script:Findings | Where-Object { $_.Severity -eq 'Warning' })
$info = @($script:Findings | Where-Object { $_.Severity -eq 'Information' })

foreach ($group in ($script:Findings | Group-Object File)) {
    Write-Host ''
    Write-Host ("  {0}" -f $group.Name) -ForegroundColor Cyan
    foreach ($f in ($group.Group | Sort-Object Line)) {
        $colour = switch ($f.Severity) { 'Error' { 'Red' } 'Warning' { 'Yellow' } default { 'DarkGray' } }
        Write-Host ("    {0,-5} line {1,-5} {2}  {3}" -f $f.Severity.Substring(0, 4), $f.Line, $f.Rule, $f.Message) -ForegroundColor $colour
    }
}

Write-Host ''
Write-Host ('-' * 60)
Write-Host ("errors {0}   warnings {1}   info {2}" -f $errors.Count, $warnings.Count, $info.Count) `
    -ForegroundColor $(if ($errors.Count -gt 0) { 'Red' } elseif ($warnings.Count -gt 0) { 'Yellow' } else { 'Green' })

$exit = 0
if ($FailOn -eq 'Error' -and $errors.Count -gt 0) { $exit = 1 }
if ($FailOn -eq 'Warning' -and ($errors.Count + $warnings.Count) -gt 0) { $exit = 1 }
exit $exit
