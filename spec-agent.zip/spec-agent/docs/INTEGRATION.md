# Integrating an existing agent with the spec layer

This is the whole contract. If your agent honours it, it is compliant. Nothing else
in this package needs to change for you to adopt it.

## One command in

```powershell
Spec.ps1 -Root <migration-root> -Command resolve -View <view> -MinStatus approved -Format json
```

| `-View` | Contains | For |
|---|---|---|
| `devops-spec` | build/deploy, environments, infra dependencies, config and secrets handling, health checks, rollback, monitoring | IaC and pipeline agents |
| `development-spec` | functional behaviour, component contracts, API requirements, data models, acceptance criteria | application agents |
| `refactoring-spec` | current architecture, technical debt, behaviour that must not change, dependency impact | modernisation agents |

## Five exit codes out

| Exit | Meaning | Required behaviour |
|---|---|---|
| **0** | every statement in the view meets `-MinStatus` | proceed |
| **2** | the view is empty, or a required argument is missing | stop, report it |
| **3** | not approved, or a section is blocked by a conflict | **stop and write nothing** |
| **4** | no spec store, or unknown view | stop, report the path |
| **5** | already exists (`init` only) | not seen by consumers |

**Exit 3 is not an error to route around.** It means a human has not agreed to this
yet. Do not retry at a lower `-MinStatus`, do not generate a partial artifact, do not
summarise what you would have produced. The refusal is the useful output.

## The payload

```json
{
  "view": "devops-spec",
  "min_status": "approved",
  "resolved_at": "2026-08-27T09:14:02Z",
  "count": 6,
  "plan_hash": "feb53229d53c683665d4e22b0686f92f9509e2b020fc6f4961f1137acdaa5ed9",
  "statements": [
    {
      "id": "stmt-7472c831",
      "fact_key": "azure.target.queue",
      "value": "servicebus-premium",
      "tier": "C",
      "confidence": "medium",
      "section": "infrastructure",
      "status": "approved"
    }
  ]
}
```

### Fields your agent should actually use

- **`fact_key`** - dispatch on this, not on free text. It is stable across runs.
- **`value`** - the shortest true thing. Map it through a table you control.
- **`plan_hash`** - write this next to whatever you generate. It covers the resolved
  statements, so if any of them changes the hash changes, and an approval that named
  the old hash no longer describes what is about to be applied.
- **`tier`** and **`confidence`** - a tier D or E fact is approved but weak. Surface
  that in your output rather than treating it as settled.

## Four rules for a compliant consumer

**1. Resolve, never read files.** Do not open `out/specifications/*.json`. Those hold
statements at every status including drafts; `resolve` is the thing that filters them.
Do not read `out/statements.json` - that is the writer's format, not a contract.

**2. Never re-read the source documents.** They were interpreted once, under review.
Re-reading them produces a second opinion nobody approved.

**3. An unmapped value is a hard stop.** If an approved statement names something your
mapping table does not know, exit non-zero and name the `fact_key`. Adding a plausible
resource type is the exact failure this layer exists to prevent.

**4. Absence is a hard stop too.** If a fact you need is not in the payload, it does not
exist. Do not supply a default. A sensible default is the hardest kind of wrong answer
to find later.

## Minimal compliant consumer

`tests/mock-consumer.ps1` in this package is about 40 lines and does exactly the above.
It is used by the contract test suite, and is the shortest useful reference for wiring
up a real one.

```powershell
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'          # or a child's stderr becomes terminating
$out  = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SpecScript `
            -Root $Root -Command resolve -View devops-spec -MinStatus approved -Format json 2>&1
$code = $LASTEXITCODE
$ErrorActionPreference = $prevEap

if ($code -eq 3) { Write-Error 'REFUSED: spec not approved'; exit 3 }
if ($code -ne 0) { exit $code }

$plan = (($out | Where-Object { $_ -is [string] }) -join "`n") | ConvertFrom-Json
```

> The `ErrorActionPreference` dance is not decoration. With `2>&1` under `Stop`, a
> child process writing to stderr raises a terminating error in the parent, so your
> agent crashes with exit 1 instead of propagating the refusal. This bug shipped in
> our own build agent and was only caught by a test.

## Verifying compliance in your environment

```powershell
# 1. Does the spec layer work here at all?
.\tests\Invoke-Tests.ps1

# 2. Does the gate actually refuse for your agent?
Spec.ps1 -Root <root> -Command resolve -View devops-spec -MinStatus approved
# expect exit 3 and a list of blocking statements while anything is unapproved

# 3. Approve one statement and confirm your agent's behaviour changes
Spec.ps1 -Root <root> -Command review -Target <id> -Action approve -Actor <you>
```

## What this package never does to you

It does not call your agent, does not schedule anything, does not require a state
file, and does not write outside `out/`. It is a store with a gate on the front.
Sequencing, if you need it, is yours to own.
