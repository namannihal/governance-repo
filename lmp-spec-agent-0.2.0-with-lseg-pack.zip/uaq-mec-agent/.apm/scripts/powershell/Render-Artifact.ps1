<#
.SYNOPSIS
    Render a final artifact by joining a versioned catalogue with an approved spec.

.DESCRIPTION
    This is the delivery half of the pipeline. It answers nothing and decides
    nothing; it joins two inputs that were each produced elsewhere:

      catalogue  lseg-artifact-views\<view>.view.json
                 the questions / control criteria. Versioned, identical for every
                 application. Owns the row set, the order and the column headers.

      payload    Spec.ps1 -Command resolve -View <view> -Format json
                 the answers for one application. Approved, gated, plan-hashed.

    The join is fact_key. A catalogue row with no matching approved fact is emitted
    BLANK - never filled, never dropped. The output therefore always has exactly as
    many rows as the catalogue, which is what makes it safe to hand to a reviewer:
    a gap looks like a gap rather than like a shorter document.

    Windows PowerShell 5.1. No modules. ASCII only.

.EXAMPLE
    Spec.ps1 -Root <root> -Command resolve -View uaq-spec -Format json > uaq.json
    .\Render-Artifact.ps1 -Artifact uaq -Catalogue ..\lseg-artifact-views\uaq-spec.view.json `
                          -Payload uaq.json -Out out\UAQ-payments-gateway.csv
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('uaq', 'mec')][string]$Artifact,
    [Parameter(Mandatory = $true)][string]$Catalogue,
    [Parameter(Mandatory = $true)][string]$Payload,
    [Parameter(Mandatory = $true)][string]$Out,
    [ValidateSet('csv')][string]$Format = 'csv',
    [switch]$AllowUnapproved
)

$ErrorActionPreference = 'Stop'

function Fail([string]$Message, [int]$Code) {
    [Console]::Error.WriteLine("ERROR: $Message")
    exit $Code
}

function Read-Json([string]$Path, [string]$Label, [int]$MissingCode) {
    if ($Path -eq '-') {
        $raw = [Console]::In.ReadToEnd()
    }
    else {
        if (-not (Test-Path -LiteralPath $Path)) { Fail "$Label not found: $Path" $MissingCode }
        $raw = Get-Content -LiteralPath $Path -Raw
    }
    if (-not $raw.Trim()) { Fail "$Label is empty" $MissingCode }
    try { $raw | ConvertFrom-Json }
    catch { Fail "$Label is not valid JSON: $($_.Exception.Message)" $MissingCode }
}

function Get-Prop($Obj, [string]$Name) {
    if ($null -eq $Obj) { return $null }
    $p = $Obj.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    $p.Value
}

$expectedView = if ($Artifact -eq 'uaq') { 'uaq-spec' } else { 'mec-spec' }

# ------------------------------------------------------------------ inputs

$cat = Read-Json $Catalogue 'catalogue' 2
$pay = Read-Json $Payload 'payload' 2

if ((Get-Prop $cat 'view') -ne $expectedView) {
    Fail ("catalogue is for view '{0}', expected '{1}'" -f (Get-Prop $cat 'view'), $expectedView) 4
}
if ((Get-Prop $pay 'view') -ne $expectedView) {
    Fail ("payload is for view '{0}', expected '{1}'. Resolve the right view." -f (Get-Prop $pay 'view'), $expectedView) 4
}

# resolve already refuses unless the gate passed, so a payload that reached this
# script is approved. The check is here because a hand-edited payload would not be.
$minStatus = [string](Get-Prop $pay 'min_status')
if ($minStatus -ne 'approved' -and -not $AllowUnapproved) {
    Fail ("payload was resolved at -MinStatus '$minStatus', not 'approved'. Rendering a draft as a deliverable is how an unreviewed value reaches a customer. Pass -AllowUnapproved to override deliberately." ) 3
}
$standardsChecked = [bool](Get-Prop $pay 'standards_checked')
$planHash = [string](Get-Prop $pay 'plan_hash')

# ------------------------------------------------------------------ index the answers

$answers = @{}
foreach ($s in @(Get-Prop $pay 'statements')) {
    $k = [string](Get-Prop $s 'fact_key')
    if (-not $k) { continue }
    $answers[$k] = $s
}

# ------------------------------------------------------------------ flatten the catalogue

$rows = New-Object System.Collections.ArrayList
foreach ($sec in @(Get-Prop $cat 'sections')) {
    foreach ($f in @(Get-Prop $sec 'facts')) {
        [void]$rows.Add([pscustomobject]@{
                Section = $sec; Fact = $f; Ordinal = [int](Get-Prop $f 'ordinal')
            })
    }
}
# The catalogue owns row order; ordinal is the source file's own order so the
# rendered artifact round-trips against the original export.
$ordered = @($rows | Sort-Object Ordinal)
if ($ordered.Count -eq 0) { Fail 'catalogue contains no facts' 2 }

# ------------------------------------------------------------------ provenance

function New-Provenance($Stmt) {
    if ($null -eq $Stmt) { return '' }
    ('stmt={0} | tier={1} | confidence={2} | status={3}' -f `
        (Get-Prop $Stmt 'id'), (Get-Prop $Stmt 'tier'), (Get-Prop $Stmt 'confidence'), (Get-Prop $Stmt 'status'))
}

# ------------------------------------------------------------------ render

$outRows = New-Object System.Collections.ArrayList
$filled = 0
$blank = 0
$blankKeys = New-Object System.Collections.ArrayList
$weak = New-Object System.Collections.ArrayList

if ($Artifact -eq 'uaq') {
    foreach ($r in $ordered) {
        $key = [string](Get-Prop $r.Fact 'fact_key')
        $stmt = $answers[$key]
        $ans = if ($null -ne $stmt) { [string](Get-Prop $stmt 'value') } else { '' }
        if ($ans) { $filled++ } else { $blank++; [void]$blankKeys.Add($key) }
        if ($null -ne $stmt -and @('D', 'E') -contains [string](Get-Prop $stmt 'tier')) { [void]$weak.Add($key) }

        [void]$outRows.Add([pscustomobject][ordered]@{
                Category = [string](Get-Prop $r.Fact 'category')
                Question = [string](Get-Prop $r.Fact 'question')
                Answer   = $ans
                Details  = (New-Provenance $stmt)
            })
    }
}
else {
    $schema = @(Get-Prop $cat 'output_schema')
    $answerCol = [string](Get-Prop $cat 'answer_column')
    $detailCol = [string](Get-Prop $cat 'detail_column')
    if ($schema.Count -eq 0) { Fail 'catalogue has no output_schema' 2 }
    if (-not $answerCol) { Fail 'catalogue does not name its answer_column' 2 }

    foreach ($r in $ordered) {
        $key = [string](Get-Prop $r.Fact 'fact_key')
        $stmt = $answers[$key]
        $ans = if ($null -ne $stmt) { [string](Get-Prop $stmt 'value') } else { '' }
        if ($ans) { $filled++ } else { $blank++; [void]$blankKeys.Add($key) }
        if ($null -ne $stmt -and @('D', 'E') -contains [string](Get-Prop $stmt 'tier')) { [void]$weak.Add($key) }

        $catalogueCells = Get-Prop $r.Fact 'catalogue'
        $row = [ordered]@{}
        foreach ($col in $schema) {
            if ($col -eq $answerCol) { $row[$col] = $ans }
            elseif ($col -eq $detailCol) { $row[$col] = (New-Provenance $stmt) }
            else { $row[$col] = [string](Get-Prop $catalogueCells $col) }
        }
        [void]$outRows.Add([pscustomobject]$row)
    }
}

# A row count that differs from the catalogue means a question or control was
# invented or lost. Neither is recoverable downstream, so it stops here.
if ($outRows.Count -ne $ordered.Count) {
    Fail ("rendered {0} row(s) from a catalogue of {1} - refusing to write" -f $outRows.Count, $ordered.Count) 3
}

$outDir = Split-Path -Parent $Out
if ($outDir -and -not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
$outRows | Export-Csv -LiteralPath $Out -NoTypeInformation -Encoding UTF8

# ------------------------------------------------------------------ sidecar report

$pct = if ($ordered.Count -gt 0) { [Math]::Round(100.0 * $filled / $ordered.Count, 1) } else { 0 }
$reportPath = [System.IO.Path]::ChangeExtension($Out, '.report.md')
$rep = New-Object System.Text.StringBuilder
[void]$rep.AppendLine("# $($cat.title) - render report")
[void]$rep.AppendLine("")
[void]$rep.AppendLine("| | |")
[void]$rep.AppendLine("|---|---|")
[void]$rep.AppendLine("| artifact | $Artifact |")
[void]$rep.AppendLine("| catalogue | $([System.IO.Path]::GetFileName($Catalogue)) |")
[void]$rep.AppendLine("| rows | $($ordered.Count) |")
[void]$rep.AppendLine("| answered | $filled ($pct%) |")
[void]$rep.AppendLine("| blank | $blank |")
[void]$rep.AppendLine("| weak (tier D/E) | $($weak.Count) |")
[void]$rep.AppendLine("| standards_checked | $standardsChecked |")
[void]$rep.AppendLine("| plan_hash | ``$planHash`` |")
[void]$rep.AppendLine("")
[void]$rep.AppendLine("The plan_hash fingerprints exactly the approved values this artifact was built")
[void]$rep.AppendLine("from. Keep it with the document: re-running resolve later and comparing the hash")
[void]$rep.AppendLine("is what tells you whether this file still reflects the approved spec.")
if ($blank -gt 0) {
    [void]$rep.AppendLine("")
    [void]$rep.AppendLine("## Unanswered ($blank)")
    [void]$rep.AppendLine("")
    [void]$rep.AppendLine("Left blank because the spec holds no approved fact for them. They are not gaps")
    [void]$rep.AppendLine("in this renderer - they are gaps in the spec, and they belong to the spec layer.")
    [void]$rep.AppendLine("")
    foreach ($k in ($blankKeys | Select-Object -First 40)) { [void]$rep.AppendLine("- ``$k``") }
    if ($blankKeys.Count -gt 40) { [void]$rep.AppendLine("- ... and $($blankKeys.Count - 40) more") }
}
if ($weak.Count -gt 0) {
    [void]$rep.AppendLine("")
    [void]$rep.AppendLine("## Weak evidence ($($weak.Count))")
    [void]$rep.AppendLine("")
    [void]$rep.AppendLine("Answered, but from a tier D or E statement. Approval set the review status, not")
    [void]$rep.AppendLine("the strength of the evidence - these carry into the deliverable as-is.")
    [void]$rep.AppendLine("")
    foreach ($k in $weak) { [void]$rep.AppendLine("- ``$k``") }
}
[System.IO.File]::WriteAllText($reportPath, $rep.ToString(), (New-Object System.Text.UTF8Encoding($false)))

# ------------------------------------------------------------------ summary

Write-Output ("{0}  {1} row(s)  {2} answered ({3}%)  {4} blank  {5} weak" -f `
        $expectedView, $ordered.Count, $filled, $pct, $blank, $weak.Count)
Write-Output ("  plan_hash {0}" -f $planHash)
Write-Output ("  wrote {0}" -f $Out)
Write-Output ("  wrote {0}" -f $reportPath)
if (-not $standardsChecked) {
    Write-Output "  NOTE: the payload records standards_checked=false - the constitution was not evaluated"
}
exit 0
