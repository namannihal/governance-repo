---
mode: agent
description: "Produce the final Unified Assessment Questionnaire by joining the UAQ catalogue with the approved uaq-spec payload from the spec layer."
---

# /create-uaq

Agent: [artifact-renderer](../agents/artifact-renderer.agent.md) |
Schemas: [artifact-schemas](../instructions/artifact-schemas.instructions.md)

Produces `Category, Question, Answer, Details` — one row per catalogue question, in
the catalogue's own order.

## Inputs

| Input | Default |
|---|---|
| Spec workspace root | ask |
| Catalogue | `lseg-artifact-views\uaq-spec.view.json` |
| Output path | `<root>\out\artifacts\UAQ-<app>.csv` |

## Steps

1. **Resolve the view.** This is the gate; if it refuses, stop and report why.

   ```
   Spec.ps1 -Root <root> -Command resolve -View uaq-spec -MinStatus approved -Format json > uaq-payload.json
   ```

   | Exit | Meaning | What to do |
   |---|---|---|
   | 0 | approved facts returned | continue |
   | 2 | nothing in the view | stop — the spec holds no UAQ facts yet |
   | 3 | refused | stop — **do not** retry at a lower `-MinStatus` |

2. **Render.**

   ```
   Render-Artifact.ps1 -Artifact uaq -Catalogue <catalogue> -Payload uaq-payload.json -Out <out.csv>
   ```

3. **Read the sidecar report** written next to the artifact and summarise it.

4. **If coverage is low, name the fix.** The remedy is in the spec layer, not here.
   This prints the exact catalogue keys the spec is missing, with the question text
   for each, which is what `/spec-ingest` should be answering against:

   ```
   Get-CatalogueCoverage.ps1 -Catalogue <catalogue> -Root <root> -MissingOnly -Format json
   ```

   A fact answered under a different key is invisible to the renderer, and the cell
   renders blank exactly as though no evidence existed.

## Report

- rows / answered / blank
- answers resting on tier D or E evidence
- the `plan_hash`, with: *keep this with the file; re-run resolve and compare it to
  know whether the document still reflects the approved spec*
- if coverage is low, say plainly that the remedy is in the spec layer — more
  evidence or another review round — not in this command

## Never

- Fill a blank cell yourself.
- Reword or reorder a question.
- Re-run `resolve` at a lower `-MinStatus` to raise the coverage number.
- Present a percentage without the blank count beside it.
