---
mode: agent
description: "Produce the final Minimum Entry Criteria assessment by joining the MEC catalogue with the approved mec-spec payload from the spec layer."
---

# /create-mec

Agent: [artifact-renderer](../agents/artifact-renderer.agent.md) |
Schemas: [artifact-schemas](../instructions/artifact-schemas.instructions.md)

Produces the full MEC workbook schema — 18 columns, one row per control. Seventeen
columns come from the catalogue verbatim; the compliance status comes from the spec.

## Inputs

| Input | Default |
|---|---|
| Spec workspace root | ask |
| Catalogue | `lseg-artifact-views\mec-spec.view.json` |
| Output path | `<root>\out\artifacts\MEC-<app>.csv` |

## Steps

1. **Resolve the view.**

   ```
   Spec.ps1 -Root <root> -Command resolve -View mec-spec -MinStatus approved -Format json > mec-payload.json
   ```

2. **Render.**

   ```
   Render-Artifact.ps1 -Artifact mec -Catalogue <catalogue> -Payload mec-payload.json -Out <out.csv>
   ```

3. **Score from the rendered file**, using the catalogue's own scale:

   | Status | Score |
   |---|---|
   | Compliant | 100 |
   | Full Coverage \| No Concerns | 100 |
   | Partially Compliant | 50 |
   | Non-Compliant | 0 |
   | Not Applicable | 100 |
   | *(blank)* | **not scored — unassessed** |

   Compute the percentage over **scored controls only**, and report the unassessed
   count in the same breath. A blank control is not a zero and it is not a pass; it
   is a control nobody has looked at, and averaging it away is how a workbook comes
   to look finished when a third of it is empty.

## Report

- controls / scored / **unassessed**
- score as a percentage of the maximum for the scored controls
- every Non-Compliant and Partially Compliant
- every Not Applicable — these score full marks, so each one deserves a reviewer's
  challenge
- the `plan_hash`

For the unassessed controls, print the keys the spec is missing so the gap is
actionable rather than just counted:

```
Get-CatalogueCoverage.ps1 -Catalogue <catalogue> -Root <root> -MissingOnly
```

## Never

- Score a blank control.
- Report a percentage without the unassessed count.
- Alter any catalogue column: MEC ID, type, theme, criteria text, anti-patterns,
  control mappings and NIST references are the versioned enterprise standard.
- Fill a status yourself. If a control is unassessed, the spec layer has no approved
  fact for it, and that is where it gets fixed.
