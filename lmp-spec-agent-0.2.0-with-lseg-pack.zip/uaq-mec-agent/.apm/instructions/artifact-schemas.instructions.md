---
description: "The catalogue-plus-payload contract: what each input owns, how they join, and the output schemas for the UAQ and MEC artifacts."
applyTo: "**/other-apm-agents/uaq-mec-agent/**"
---

# Artifact schemas

This package renders **existing enterprise files**. It does not design a format; it
fills columns in someone else's, and copies the rest through untouched.

## The contract

```
lseg-artifact-views\<view>.view.json          Spec.ps1 resolve -View <view> -Format json
        the CATALOGUE                                     the PAYLOAD
  questions / control criteria                    approved facts for one app
  row set, order, column headers                  values, tier, confidence, status
                    \                            /
                     \        join on fact_key  /
                      v                        v
                    Render-Artifact.ps1  ->  final .csv + .report.md
```

Each half owns something the other cannot supply:

- The **catalogue** is versioned and identical for every application. It decides
  which rows exist and what they are called.
- The **payload** is specific to one application and has already been through
  review and the constitution gate. It decides what the answers are.

A catalogue row with no matching approved fact renders **blank**. It is never
filled and never dropped, so the output row count always equals the catalogue row
count. That property is what makes the file safe to hand to a reviewer: a gap looks
like a gap, rather than like a shorter document.

---

## UAQ

CSV, four columns, in this order:

```
Category,Question,Answer,Details
```

- `Category`, `Question` — from the catalogue, verbatim
- `Answer` — the approved value, or blank
- `Details` — provenance: `stmt=<id> | tier=<A-E> | confidence=<high|medium|low> | status=<approved>`

415 questions across 18 categories in the current catalogue. Row order follows the
catalogue's `ordinal`, which is the original export's own order, so the rendered
file round-trips against it.

---

## MEC

Eighteen columns, taken from the catalogue's `output_schema`. Only two are facts
about the application; the workbook's own usage notes say so:

> *"Track your application's compliance to the MEC by using the drop down entries in
> Column I. Where there are MEC which are not applicable - record that reason in
> Column J."*

| Column | Source |
|---|---|
| `This Application's MEC Compliance Status` | the payload |
| `Applicability Notes` | provenance for that status |
| everything else — MEC ID, type, theme, criteria title, applicability, security principle, criteria text, evidence source, anti-patterns, SCF controls, vendor standards, links, patterns, NIST mapping, notes | the catalogue, verbatim |

### Scoring

| Status | Score |
|---|---|
| Compliant | 100 |
| Full Coverage \| No Concerns | 100 |
| Partially Compliant | 50 |
| Non-Compliant | 0 |
| Not Applicable | 100 |
| *(blank)* | not scored — unassessed |

`Not Applicable` scores full marks, which is exactly why an unassessed control must
never be reported as one. Percentages are computed over scored controls only, and
the unassessed count is reported alongside.

---

## plan_hash

Every payload carries one. It fingerprints the exact set of approved values the
artifact was built from, so:

- store it with the delivered file
- re-run `resolve` later and compare — if the hash matches, the document still
  reflects the approved spec; if not, something changed after approval and the
  artifact is stale

It is written into the sidecar `.report.md` for this reason.

---

## Adding an artifact

`/create-sad` and any others follow the same shape, and adding one should touch
data, not code:

1. add a catalogue at `lseg-artifact-views\<view>.view.json` with `output_schema`,
   `answer_column` and per-fact `ordinal`
2. add the matching view to the spec layer so `resolve -View <view>` works
3. add a prompt

The renderer already handles a catalogue-driven column set; only artifact-specific
row shaping needs code.
