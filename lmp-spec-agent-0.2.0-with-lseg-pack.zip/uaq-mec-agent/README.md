# uaq-mec-agent

The **delivery** half of the pipeline. It consumes the specification the spec layer
produced and emits the final documents.

It collects no evidence and answers no questions. Data collection and document
delivery are separate concerns on purpose: a schema change never touches evidence,
and a new fact never requires a new renderer.

## Where it sits

```
evidence  ->  spec-agent  ->  approved spec  ->  uaq-mec-agent  ->  UAQ.csv
                                                                    MEC.csv
                                                                    SAD  (later)
```

## How it works

Two inputs, joined on `fact_key`:

| Input | From | Owns |
|---|---|---|
| **Catalogue** | `lseg-artifact-views\<view>.view.json` | the row set, the order, the column headers |
| **Payload** | `Spec.ps1 resolve -View <view> -Format json` | the answers — already approved and gated |

A catalogue row with no matching approved fact renders **blank**. Never filled,
never dropped. So the output always has exactly as many rows as the catalogue, which
is what makes it safe to hand to a reviewer: **a gap looks like a gap, rather than
like a shorter document.**

## Commands

| Command | Output |
|---|---|
| `/create-uaq` | `Category, Question, Answer, Details` — 415 questions, 18 categories |
| `/create-mec` | the 18-column MEC workbook schema — 30 controls |

`/create-sad` joins these once the SAD catalogue and `sad-spec` view are settled.

Each run writes two files: the artifact, and a `.report.md` beside it carrying
coverage, weak-evidence count and the `plan_hash`.

## Running it

```powershell
Spec.ps1 -Root <root> -Command resolve -View mec-spec -MinStatus approved -Format json > mec-payload.json

.\.apm\scripts\powershell\Render-Artifact.ps1 -Artifact mec `
  -Catalogue ..\..\lseg-artifact-views\mec-spec.view.json `
  -Payload mec-payload.json `
  -Out out\MEC-payments-gateway.csv
```

| Exit | Meaning |
|---|---|
| 0 | rendered |
| 2 | could not assess — catalogue or payload missing, empty or unparseable |
| 3 | refused — payload not approved, or the row count did not match the catalogue |
| 4 | wrong view |

## What it refuses to do

- **Answer anything.** No evidence, no source documents, no authority.
- **Add or drop a row.** A mismatch against the catalogue stops the write.
- **Edit catalogue text.** Questions and control criteria are versioned enterprise
  content; rewording one forks the standard for this application alone.
- **Render a draft as a deliverable.** A payload resolved below `approved` is
  refused; `-AllowUnapproved` exists for deliberate drafts and shows up in the report.
- **Promote weak evidence.** A tier D answer renders as tier D.

The first four are enforced in `Render-Artifact.ps1`, not in prose.

## Acceptance

`Test-Acceptance.ps1` runs against the real `payments-gateway` spec workspace and
the real catalogues derived from `poc\mock-clean` — 12 checks, all passing:

```
===== uaq-spec =====
PASS  renders from an approved payload            PASS  row count matches the catalogue (415)
PASS  column count matches the catalogue schema   PASS  wrong view is refused
PASS  missing payload is cannot-assess            PASS  unapproved payload is refused
PASS  unapproved renders only with the explicit override

===== mec-spec =====   (same seven, row count 30, 18 columns)
```

Real output, MEC:

```
MEC-v3_3-1  Web Application Firewall  status="Compliant"  stmt=stmt-f7d3c821 | tier=A | confidence=high | status=approved
MEC-v3_3-2  Segmentation              status="Compliant"  stmt=stmt-481f9271 | tier=A | confidence=high | status=approved
MEC-v3_3-3  Anti-malware Deployment   status=""
MEC-v3_3-4  Vulnerability Mgmt Tooling status=""
```

`6 answered (20%), 24 blank` — reported together, always. A workbook that showed
100% because it silently skipped 24 controls would be the dangerous artifact.
