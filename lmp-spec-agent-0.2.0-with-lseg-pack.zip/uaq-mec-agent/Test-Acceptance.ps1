# End-to-end acceptance for uaq-mec-agent, using the real payments-gateway spec
# workspace and the real catalogues derived from poc\mock-clean.
[CmdletBinding()]
param(
    [string]$Repo,
    [string]$Views
)
Set-ExecutionPolicy -Scope Process Bypass -Force
$ErrorActionPreference = 'Continue'

if (-not $Repo) {
    # Released layout puts spec-agent beside this folder; the dev tree nests it one deeper.
    $near = Split-Path $PSScriptRoot -Parent
    $Repo = if (Test-Path (Join-Path $near 'spec-agent')) { $near } else { Split-Path $near -Parent }
}
$R      = Join-Path $Repo 'spec-agent\spec-test\payments-gateway'
$Spec   = Join-Path $Repo 'spec-agent\.apm\scripts\powershell\Spec.ps1'
$Render = Join-Path $PSScriptRoot '.apm\scripts\powershell\Render-Artifact.ps1'
if (-not $Views) { $Views = Join-Path $Repo 'lseg-artifact-views' }
$work   = Join-Path $env:TEMP 'uaq-mec-render'

# The catalogues carry customer questionnaire text and are distributed separately, so
# say that plainly rather than failing later on a missing file nobody can place.
if (-not (Test-Path -LiteralPath $Views)) {
    Write-Output "SKIP  catalogues not found at: $Views"
    Write-Output '      They are not bundled with this package. Re-run with -Views <folder>'
    Write-Output '      containing uaq-spec.view.json and mec-spec.view.json.'
    exit 2
}
if (-not (Test-Path -LiteralPath $R)) {
    Write-Output "SKIP  spec workspace not found at: $R"
    Write-Output '      Re-run with -Repo <folder> holding spec-agent and its spec-test workspace.'
    exit 2
}

if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null

function Case($name, $expected, $block) {
    $code = & $block
    $verdict = if ($code -eq $expected) { 'PASS' } else { 'FAIL' }
    '{0}  {1,-50} expected={2} actual={3}' -f $verdict, $name, $expected, $code
}

foreach ($a in @(@('uaq', 'uaq-spec'), @('mec', 'mec-spec'))) {
    $artifact = $a[0]; $view = $a[1]
    Write-Output ""
    Write-Output "===== $view ====="

    $payload = Join-Path $work "$view-payload.json"
    (& $Spec -Root $R -Command resolve -View $view -MinStatus approved -RequireStandards -Format json 2>$null) |
        Set-Content -LiteralPath $payload -Encoding UTF8
    Write-Output ("resolve exit={0}" -f $LASTEXITCODE)

    $cat = Join-Path $views "$view.view.json"
    $out = Join-Path $work ("{0}-payments-gateway.csv" -f $artifact.ToUpper())

    Case 'renders from an approved payload' 0 {
        & $Render -Artifact $artifact -Catalogue $cat -Payload $payload -Out $out | Out-Null
        $LASTEXITCODE
    }

    # The row set belongs to the catalogue: no question invented, none lost.
    $catJson = Get-Content $cat -Raw | ConvertFrom-Json
    $expectRows = [int]$catJson.fact_count
    $rows = @(Import-Csv $out)
    Case "row count matches the catalogue ($expectRows)" $expectRows { @($rows).Count }

    $cols = @(($rows[0] | Get-Member -MemberType NoteProperty).Name)
    Case 'column count matches the catalogue schema' @($catJson.output_schema).Count { $cols.Count }

    Case 'wrong view is refused' 4 {
        $other = if ($artifact -eq 'uaq') { Join-Path $views 'mec-spec.view.json' } else { Join-Path $views 'uaq-spec.view.json' }
        & $Render -Artifact $artifact -Catalogue $other -Payload $payload -Out (Join-Path $work 'nope.csv') 2>$null | Out-Null
        $LASTEXITCODE
    }

    Case 'missing payload is cannot-assess' 2 {
        & $Render -Artifact $artifact -Catalogue $cat -Payload (Join-Path $work 'missing.json') -Out (Join-Path $work 'nope.csv') 2>$null | Out-Null
        $LASTEXITCODE
    }

    # A draft must not be renderable as a deliverable by accident.
    $draft = Join-Path $work "$view-draft.json"
    (Get-Content $payload -Raw) -replace '"min_status":\s*"approved"', '"min_status": "needs-review"' |
        Set-Content -LiteralPath $draft -Encoding UTF8
    Case 'unapproved payload is refused' 3 {
        & $Render -Artifact $artifact -Catalogue $cat -Payload $draft -Out (Join-Path $work 'nope.csv') 2>$null | Out-Null
        $LASTEXITCODE
    }
    Case 'unapproved renders only with the explicit override' 0 {
        & $Render -Artifact $artifact -Catalogue $cat -Payload $draft -Out (Join-Path $work 'draft.csv') -AllowUnapproved 2>$null | Out-Null
        $LASTEXITCODE
    }
}

Write-Output ""
Write-Output "===== what was produced ====="
Get-ChildItem $work -Filter '*.csv' | ForEach-Object { '{0,-34} {1,8} bytes' -f $_.Name, $_.Length }
Write-Output ""
Get-Content (Join-Path $work 'MEC-payments-gateway.report.md') -ErrorAction SilentlyContinue | Select-Object -First 16
