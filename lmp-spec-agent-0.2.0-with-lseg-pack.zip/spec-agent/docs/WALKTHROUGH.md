# Walkthrough — what each step does and why

A knowledge-transfer record of running the spec layer and its constraint layer end to end
against a real application, written for someone who did not build it.

Each step says what you run, what it does, what it proves, and which LSEG rule it serves.
Design decisions taken along the way are in `DECISIONS.md`.

Environment used: Windows PowerShell 5.1, no modules. Package `lmp-spec-agent` 0.1.1
alongside `lseg-constitution-pack`, both siblings in the same folder.

---

## The shape of it

```
documents  ->  facts with evidence  ->  checked against LSEG rules  ->  human approval  ->  IaC
              (spec layer)              (constraint layer)              (review gate)
```

Nothing moves right until the stage on its left is satisfied. The whole point is that a
downstream tool cannot get a spec that is unapproved, incomplete, or against the rules.

---

## Step 1 — Prove the package works here

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\spec-agent\tests\Invoke-Tests.ps1
```

**Does:** runs 163 self-contained checks. All fixtures are created in `%TEMP%`; nothing is
written into the repository.

**Expect:** `passed 163   failed 0`. Also one yellow line saying the CPF catalogue is not
reachable — expected until Step 3 sets the path.

**Proves:** the copy arrived intact and the engine runs on this machine, *before* anything
real is pointed at it. Run this first in any new environment.

**What the 163 amount to:**

| Guarantee | Consequence if it were false |
|---|---|
| Confidence is computed from *how* a fact was found, never claimed by the caller | Anything could declare itself trustworthy |
| Every refusal path returns the right exit code and writes nothing | A gate that half-opens is worse than no gate |
| A stand-in consumer genuinely stops when refused | Downstream tools could build from an unapproved spec |
| Editing a source document voids the approval bound to it | Approvals would outlive the evidence behind them |
| Two sources disagreeing blocks that section | The tool would silently pick a winner |
| A required fact nobody stated returns "cannot assess", never "passed" | Silence would read as compliance |
| Rules bite individually *and* in combination | The interesting failures are combinations |
| Exceptions need a named approver and expire | Waivers would become permanent by accident |

---

## Step 2 — Find the CPF catalogue

```powershell
Get-ChildItem -Recurse -File -Filter "_catalog.json"
```

**Does:** locates the live list of approved CPF modules that the IaC agent ships with.

**Why it matters.** Rule `LMP-II-01` encodes *"Only CPF clear-listed Azure services may be
provisioned in LMP Landing Zones (SMCF-GOV-06)"*. The engine reads that list **live** at
check time rather than keeping a copy.

The reason is measured, not theoretical: the snapshot bundled for development held 226
modules; the customer's live catalogue held 283. A copied list would have been 57 modules
stale on arrival, rejecting services that are in fact approved. A clearlist that cries
wolf gets ignored. See `DECISIONS.md` DEC-001.

**Pick:** the catalogue the IaC agent actually reads at runtime, so the spec layer and the
IaC agent are checking against the same list.

---

## Step 3 — Point at the catalogue, create the workspace

```powershell
$env:LMP_CPF_CATALOG = "<...>\cpf-schemas\_catalog.json"
$spec  = "<...>\spec-agent\.apm\scripts\powershell\Spec.ps1"
$check = "<...>\spec-agent\.apm\scripts\powershell\Check-Standards.ps1"
$root  = "<...>\.lmp-migrate\payments-gateway"

... -File $spec -Root $root -Command init
```

**Does:** creates the evidence store for one application, and the four intake folders.

```
out\statements.json                    the claim store            PERMANENT
out\sources\source-register.json       every file, hashed, read or not-read and why
out\conflicts\unresolved-conflicts.json
out\decisions\decision-log.jsonl       append-only                PERMANENT
src\comigrate-assessment\
src\aimigrate-assessment\
src\existing-sad\
src\application-docs\
```

**Why four intake folders.** Where a document came from is itself evidence. A CoMigrate
export is machine-generated fact; a Word SAD is a person's stated intent. The folder name
determines the recorded adapter, so a reviewer can weight them differently.

The names are exact and load-bearing — `existing_sad` instead of `existing-sad` silently
falls through to the generic `appdocs`. In 0.1.1 `init` creates them and prints them, and
the same table drives both creation and adapter inference so the two cannot drift apart.
See `DECISIONS.md` DEC-004.

**Second `init` exits 5, not 0.** It refuses to overwrite an existing evidence store. Use
`-Force` only when you genuinely intend to discard it — that store is not regenerable.

**Standards angle:** nothing is enforced yet. But `decision-log.jsonl` starts here and is
append-only. Every approval, rejection, voided approval and granted exception lands in it
and is never rewritten. It is what you produce when someone asks, months later, why a
design was allowed through.

**Keep the terminal.** `$env:LMP_CPF_CATALOG`, `$spec`, `$check` and `$root` are session
variables. A new terminal means setting them again.

---

## Step 4 — Put a document in the intake

Drop the Solution Architecture Document into `src\existing-sad\`.

**Does:** nothing automated. This is the human handing the tool its raw material.

**The document used here** is a deliberately imperfect one. It states, in ordinary prose,
that the application is Tier 1, that the treatment is Replatform, that it is not
containerised today, and that the target is AKS. It never mentions RTO, RPO, a recovery
pattern, a secondary region, a cutover approach, a rollback plan, validation, or
monitoring.

That is not a strawman. It is what a competent, busy architect produces, and a reviewer
would very likely sign it off. It contains one combination that cannot be built and nine
absent facts the constitution requires — and finding those without reading three tables
in parallel is the thing being demonstrated.

**Note for real use:** `.pdf` is extractable, including owner-restricted files and
scans (which fall back to Windows OCR and are labelled OCR-derived). `.pptx` and
`.vsdx` are not. Anything unreadable — and a rights-protected PDF, whose readable
pages are only a "use a different reader" notice — is recorded as not-read *with the
reason and the remedy* rather than skipped, so an unreadable document is a visible
gap and not a silent one.

---

## Step 5 — Register the sources

```powershell
... -File $spec -Root $root -Command register-sources
```

**Does:** walks `src\`, and for every file records a SHA-256, the adapter inferred from
the folder, and whether the extractor could actually read it.

**The principle: read or refuse.** Every file lands in one of exactly two states — `read`
with a hash, or `not-read` with a reason and where possible a remedy. There is no third
state and nothing is quietly skipped. If nothing at all is readable the command exits 2
and writes no evidence, because a spec built from no sources is worse than no spec.

**Why the hash matters later.** Approvals are bound to it. Approve a fact in Step 9, edit
the source document afterwards, run `verify`, and the approval is voided with reason
`source-changed`. Approval attaches to the evidence, not to the claim.

**Output to check:** `adapter` is `existing_sad` rather than `appdocs` (the folder name
was right), and `path` begins cleanly at `src\` (the DEC-005 path fix).

Record the source `id` — statements are attached to it.

---

## Step 6 — Turn prose into statements

```powershell
... -Command add-statement -FactKey app.tier -Value 1 -SourceId src-xxxxxxxx `
    -Locator payments-gateway-sad.md -Quote "The Payments Gateway is a Tier 1 application." `
    -Method explicit-statement
```

**Does:** records one atomic claim with the evidence behind it.

**A statement has five parts,** and the claim is the least important:

| Part | Example |
|---|---|
| fact key | `app.tier` |
| value | `1` |
| source | `src-210548f2` |
| locator | `payments-gateway-sad.md` |
| quote | *"The Payments Gateway is a Tier 1 application."* |

Strip the last three and you have a guess wearing a fact's clothes.

**Tier is computed, never claimed.** `-Method` says *how* the fact was obtained and the
tier follows from it — `explicit-statement` and `table-cell` give tier A, `inferred` gives
C, `guess` gives E. There is no `-Tier` argument. Anything permitted to rate its own
confidence rates it too high.

**Routing** happens automatically from the fact-key prefix: `app.` reaches devops and
development, `migration.` reaches devops and refactoring, and so on. A prefix with no
routing rule lands in `unrouted` and is surfaced in the review summary rather than
silently dropped.

**Two honest limitations:**

- *The quote is not verified against the file.* Nothing checks that the sentence really
  appears. It is evidence for the human reviewer, who can open the locator and look. The
  hash proves the file has not changed since; it does not prove the quote is real.
- *In production an agent produces these commands* via `/spec-ingest`. That agent path has
  not been exercised in a live session — it is the largest untested surface in the
  package. Doing it by hand here shows precisely what the agent has to produce.

---

## Step 7 — Build

```powershell
... -Command build
```

**Does:** collapses the loose statements into one canonical answer per fact, projects the
three views, detects conflicts, and renders the review Markdown.

**Result here:** `9 statement(s), 9 fact(s), 0 conflict(s), 3 view(s)`.

- *9 into 9* means no duplicates. Two sources stating the same value collapse to one
  canonical fact, both kept as supporting evidence.
- *0 conflicts* means nothing contested. Two sources **disagreeing** raises a conflict and
  freezes that section — the tool does not pick a winner.
- *Views hold statement ids, not copies*, so a fact corrected once is corrected everywhere
  it appears.

Everything under `specifications/` and `review/` is regenerable. `statements.json` and the
decision log are not.

---

## Step 8 — Check against the constitution

```powershell
... -File $check -Root $root -Command check          # exit 3
... -File $spec  -Root $root -Command resolve -View devops-spec -RequireStandards   # exit 3
```

**Does:** evaluates the canonical spec against all 74 rules, writes
`out/compliance/violations.json` and a readable report, then `resolve` reads that file and
shuts the gate.

**Result here: 18 findings — 2 violations, 16 gaps, exit 3.**

### Read the header before the findings

```
9 fact(s) stated, 6 derived
CPF clearlist: 282 module(s) from ...\cpf-schemas\_catalog.json
not_assessed 0
```

- **6 derived** — from `app.tier = 1` alone the engine inferred multi-region, multi-AZ,
  zone-redundancy, a cutover pattern, source-parallel rollback and multi-geography.
- **`not_assessed 0`** is the proof the catalogue binding worked. Had the path been wrong,
  the CPF rules would sit at `not-assessed` — reported but **not blocking**. Zero means the
  target module was genuinely checked against the live list and found.
- The catalogue holds 283 entries but yielded 282 ids: one entry has no `cpf_id`. Harmless
  here, but a real data-quality gap for whoever maintains it.

### The finding that justifies the layer

```
[VIOLATION] LMP-MIG-CUT-3
      app.tier = 1 (stated, stmt-1c471772)
      app.tier -> LMP-MIG-CUT-2 requires migration.cutover_pattern = cdc
      migration.r_type = Replatform (stated, stmt-83eb4652)
```

Tier 1 forces near-zero RPO, which forces a CDC cutover, which requires application-side
replay awareness — which is outside Replatform scope. **The document never mentions a
cutover pattern.** The fact that exposes the contradiction did not exist until the rules
derived it. Catching this by eye needs the tier table, the cutover table and the R-Type
table held open at once.

### Gaps are consequences, not just blanks

Several gaps — secondary region, recovery pattern, RPO — are not written anywhere in the
constitution as "Tier 1 needs a secondary region". They are downstream of the derived
`deploy.multi_region = true`. The engine reached them by chaining.

### The gate

`resolve` exits 3 and prints *"These cannot be cleared by approval. Fix the design, or
record an exception."* A delivery team cannot sign off past a MUST. Only fixing the design
or a recorded exception — named governance approver, mandatory expiry — clears it.

**A consumer needs no code change to inherit this.** `resolve` already returned 3 for
"not approved"; it now also returns 3 for "against the rules".

---

## Step 9 — Fix the design

Two problems: one contradiction, sixteen blanks.

**The correction is an addition, not an edit.**

```powershell
... -Command add-statement -FactKey migration.r_type -Value Rearchitect -Method human-assertion
... -Command review -Target <old-stmt-id> -Action request-changes -Actor n.nihal `
    -Rationale "Superseded: Tier 1 forces CDC, outside Replatform scope (LMP-MIG-CUT-3)"
```

The `Replatform` statement is never deleted. It stays, marked rejected, with a name and a
reason in the append-only log. Canonical selection ranks rejected statements last, so
`Rearchitect` wins. In six months the question is rarely "what does the spec say" — it is
"why did this change", and only the rejected statement answers that.

**`human-assertion` is tier A, and that is not a loophole.** A named person taking
responsibility for a fact is evidence of the same class as a sentence in a document. What
is *not* evidence is a tool guessing and labelling it explicit.

**State the derived facts explicitly.** `multi_region`, `multi_az`, `zone_redundant` and
`rollback.source_parallel` had already been derived from Tier 1. Writing them down moves
them from silent assumption to something a human reviews. The report lists them under
*"facts the constitution implies but nobody stated"* precisely so they can be.

**Result:** 18 findings to 1. Exit 3 to exit 2. Derived facts 6 to 1.

### The defect this step exposed

The build reported `1 conflict(s)` — `migration.r_type` holding two values. Rejecting the
loser had no effect, because conflict detection counted every statement regardless of
review status. Since the store is append-only, rejection is the *only* move a human has,
so conflicts were permanently unclearable: the constitution check was green and `resolve`
would still refuse, for a reason nobody could act on. Fixed in `Spec.ps1`; see
`DECISIONS.md` DEC-006.

**Never hand-edit anything under `out/`.** The conflicts, specifications, review and
compliance folders are regenerated on every `build` — editing them achieves nothing and
the next build overwrites it. Editing `statements.json` or the decision log forges the
audit trail. If output looks stale, rebuild.

---

## Step 10 — The judgement call

One finding survived, and it is the right one to be left with:

```
[GAP] LMP-RT-CONTAINER-2  only 0 of the required 2 evidence facts are stated
```

The constitution requires the container business case to be evidenced in *at least two of
three* dimensions. The engine verified whether those facts exist. It did not, and will
not, judge whether the case is any good.

**Exit 2, not 3** — "nothing is broken, but I cannot fully assess this". Different from a
violation, and deliberately so.

Two legitimate routes:

| Route | When |
|---|---|
| **State the evidence** — quantified TCO reduction, measurable reliability gain, or a scaling need beyond VMSS | The case can be made |
| **Record an exception** — named governance approver, mandatory expiry | The deviation is accepted but unevidenced |

The exception route refuses without an approver, refuses without an expiry, refuses a
backdated expiry, and re-opens the finding the day it lapses.

**Result of Route A:** `total 0`, exit 0. Fully compliant against 74 rules.


## Step 11 — The approval gate

```powershell
powershell -File $spec -Root $root -Command build
powershell -File $spec -Root $root -Command resolve -View devops-spec -MinStatus approved -RequireStandards
```

**Result:** exit 0, 31 statements, `plan_hash b922149f0a614a75...`

This is the handoff. Nothing downstream reads the store directly — everything goes through
`resolve`, which refuses unless *both* gates are clear:

| Gate | Question | Cleared by |
|---|---|---|
| Constitution | does the design obey the standards? | fixing the design, or an expiring exception |
| Approval | has a human signed off every statement? | `review -Action approve` with a name |

The two are independent, and `-RequireStandards` matters more than it looks. Without it, a
missing rule pack produces no findings, and "no findings" is indistinguishable from
"passed". The flag turns an unrun check into a refusal.

The `plan_hash` fingerprints exactly what was approved. Change any value and the hash
moves, so a generated artefact can be traced back to a specific approved state rather than
to "the spec, at some point".

### What this step actually exposed

The first run of Step 11 failed with exit 3:

```
BLOCKED: 1 statement(s) below -MinStatus 'approved':
  stmt-83eb4652  migration.r_type  [changes-requested]
```

That is the statement corrected back in Step 9 — the wrong `r_type`, rejected and replaced.
It had been superseded, and it was still blocking.

**This was a real defect, and a bad one:** once any fact was corrected, that spec could
never resolve again. The store is append-only, so there was no move available to clear it.

The fix is DEC-007. A superseded statement leaves the view — but only where a live
statement for the same fact replaces it. Rejecting the *only* statement for a fact still
blocks, because otherwise rejection would be a way to walk past anything inconvenient.

Worth noting how it was found. 164 tests passed. The existing test asserted that rejecting
a statement cleared the conflict, then stopped — it never went on to call `resolve`, so it
confirmed the mechanism and missed the consequence. It took a real correction on real
documents to surface it. Both halves of the rule now have a test that ends at `resolve`.




