# spec-agent

`lmp-spec-agent` is the **specification layer** for migration programmes. It reads the
assessment output a programme already produces, turns it into sourced facts, and hands
downstream agents a spec they can build from — instead of every agent re-reading the same
documents and quietly guessing at the gaps.

It is written in Windows PowerShell 5.1 and runs directly on an LMP developer VDI. No
runtime to install, no service to stand up, no network dependency — three scripts and a
folder of JSON on the machine the engineer already has.

---

## Architecture

![spec-agent architecture](spec-agent-architecture.png)

Read down the blue spine — that is the whole pipeline. Inputs enter from the left,
artifacts are written to the right.

---

## Overview

### What it solves

A migration programme already generates assessment material: CoMigrate exports, AI Migrate
intake reports, existing SADs, application documentation. Today every downstream agent
starts by re-reading that material and forming its own view of the application. That is
duplicated effort, and worse, it is *divergent* effort — two agents can read the same
document and reach different conclusions, and nobody notices until the infrastructure is
wrong.

spec-agent does that analysis **once**. It produces a specification that downstream agents
consume directly, so the IaC agent does not need its own discovery phase. The assessment
becomes a shared, reviewed, versioned artifact rather than something each agent re-derives.

The second problem is quieter. A requirement discovered in week one gets buried in a Word
file. By the time an agent needs it, someone fills the blank with a plausible default. The
generated Terraform passes review because it *looks* exactly how it should look. The
wrongness is only visible to someone who already knew what was intended — and that person
is not in the review. So every fact here carries its receipt: source document, locator,
exact quote.

### Caveat

A spec describes intent, not implementation. The **refactoring agent needs the actual
source code in addition to the spec** — it cannot modernise from a specification alone.
The IaC and DevOps consumers work from the spec by itself; refactoring does not.

---

## Concepts

| Term | What it means | Example |
| --- | --- | --- |
| **Statement** | One claim plus proof of where it came from | *"`app.tier` is `1`, because the SAD says 'The Payments Gateway is a Tier 1 application.'"* |
| **fact_key** | The dotted name of the question a statement answers | `app.tier`, `nfr.rto`, `migration.r_type` |
| **Tier** | How strong the evidence is, `A` (quoted directly) down to `E` (guess) | A quote from the document is `A`; a guess is `E` |
| **Stated vs derived** | A fact either comes from a document, or a rule works it out | The SAD *states* `app.tier = 1`; a rule *derives* that a CDC cutover is therefore required |
| **Canonical spec** | The single agreed answer for each `fact_key`, once competing statements are settled | Five documents mention the RTO; the canonical spec holds one value |
| **View** | The slice of the spec one audience needs | `devops-spec.json` carries deployment facts; app teams never see them |
| **Conflict** | Two live statements giving *different* answers to the same `fact_key` | Section 4.2 says the RTO is `15m`; the page 7 table says `1h` |

---

## How you use it

You do not normally call the scripts. The package registers six **slash commands** in
Copilot chat, and those run the PowerShell underneath. From the README: *"You never call
these directly at first — you type a `/slash-command` in Copilot chat and it runs them for
you."*

| Slash command | What you get | What runs underneath |
| --- | --- | --- |
| `/spec-init` | Creates the store and the four intake folders | `init` |
| `/spec-ingest` | Reads the documents, writes statements, builds the spec and views | `register-sources` → `add-statement` (many) → `build` |
| `/spec-check` | Checks the spec against the LSEG constitution, explaining each finding in the constitution's own words | `Check-Standards.ps1 check` |
| `/spec-extract-required` | Goes hunting for the specific facts the constitution needs and the spec is missing | `Check-Standards.ps1 required` → `add-statement` |
| `/spec-review` | Walks you through review in triage order and records each decision | `verify` → `status` → `review` → `build` |
| `/spec-status` | Says plainly whether a downstream consumer would be allowed to run | `verify` → `status` → `resolve` |

Behind the commands sit three agents, each with a narrow job:

- **`spec.agent.md`** — the orchestrator. Sequences the work and owns none of it. Refuses
  when preconditions are not met: no store, no statements, nothing approved.
- **`spec-builder.agent.md`** — the discovery specialist. Turns document text into
  statements, and *never asserts anything it cannot quote*.
- **`spec-reviewer.agent.md`** — drives human review in triage order and records every
  decision through the CLI.

### A typical session

```text
/spec-init                →  store created, four intake folders ready
   drop the documents in  →  CoMigrate export, AI Migrate report, SAD, app docs
/spec-ingest              →  documents read, statements written, spec built
/spec-check               →  standards findings, in the constitution's own words
   fix the design         →  conflicts resolved, missing facts supplied
/spec-review              →  approve statement by statement, with your name on each
/spec-status              →  "the gate would open for devops-spec"
```

As the FAQ puts it: *you type six things, and the system spends the whole time telling you
what it needs next and refusing to move until it has it.*

### The scripts underneath

| Script | Role |
| --- | --- |
| `Spec.ps1` | The pipeline — `init`, `register-sources`, `add-statement`, `build`, `review`, `verify`, `status`, `resolve` |
| `Check-Standards.ps1` | The constraint layer. Evaluates the spec against the LSEG constitution and guidelines |
| `Extract-Text.ps1` | Document text extraction, called by `register-sources` |

---

## What it produces

### On screen

`/spec-check` reports what it found, and whether it could even assess:

```text
constitution v1.6.0  74 rule(s)  31 fact(s) stated, 6 derived
18 finding(s): 2 violation(s), 16 gap(s)                        EXIT: 3
```

Once the design is fixed and the statements approved, the gate opens:

```text
view devops-spec  31 statement(s)  plan_hash b922149f0a614a75...  EXIT: 0
```

### The payload a downstream agent receives

This is the actual output contract — what the IaC agent reads instead of re-reading
documents:

```json
{
  "view": "devops-spec",
  "min_status": "approved",
  "resolved_at": "2026-08-27T09:14:02Z",
  "count": 6,
  "standards_checked": true,
  "standards_skipped": false,
  "plan_hash": "feb53229d53c683665d4e22b0686f92f9509e2b020fc6f4961f1137acdaa5ed9",
  "statements": [
    {
      "id": "stmt-7472c831",
      "fact_key": "azure.target.queue",
      "value": "servicebus-premium",
      "tier": "C",
      "confidence": "medium",
      "section": "infrastructure",
      "status": "approved"
    }
  ]
}
```

Every fact arrives with its strength attached. `tier: "C"` and `confidence: "medium"` tell
the consumer this was inferred rather than quoted — approving it did not make it stronger.

### The files on disk

One folder you write into, one folder the tool owns:

```text
payments-gateway\
│
├── src\                                    <- YOU put documents here
│   ├── comigrate-assessment\
│   ├── aimigrate-assessment\
│   ├── existing-sad\
│   │   └── payments-gateway-sad.md
│   └── application-docs\
│
└── out\                                    <- the tool owns all of this
    ├── statements.json                     the claim store, append-only
    ├── evidence-map.json                   source -> statements, for impact analysis
    ├── sources\
    │   └── source-register.json            every file + sha256; unread ones carry the
    │                                       fix, e.g. "PDF - export to .docx and re-run"
    ├── specifications\
    │   ├── system-spec.json                canonical, one answer per fact_key
    │   ├── development-spec.json       ┐
    │   ├── devops-spec.json            ├─ the 3 views shipped today
    │   ├── refactoring-spec.json       ┘
    │   ├── sad-spec.json               ┐
    │   ├── mec-spec.json               ├─ further views, one per downstream
    │   └── uaq-spec.json               ┘  consumer that needs its own slice
    ├── conflicts\
    │   └── unresolved-conflicts.json       same fact_key, competing values
    ├── decisions\
    │   └── decision-log.jsonl              append-only, never regenerated
    ├── compliance\                         written by Check-Standards.ps1 only
    │   ├── constitution-report.json        every finding, with its derivation chain
    │   └── violations.json                 the gate file that resolve reads
    └── review\*.md                         for humans, read-only
```

**Four specification files ship today**: one canonical `system-spec.json`, plus three views
projected from it. The views hold statement *ids*, never copies — so there is exactly one
place a value lives.

| Spec file | `-View` value | Contains | For |
| --- | --- | --- | --- |
| `system-spec.json` | *(not resolvable)* | The canonical answer per `fact_key` | internal |
| `devops-spec.json` | `devops-spec` | Build/deploy, environments, infra dependencies, config and secrets, health checks, rollback, monitoring | IaC and pipeline agents |
| `development-spec.json` | `development-spec` | Functional behaviour, component contracts, API requirements, data models, acceptance criteria | application agents |
| `refactoring-spec.json` | `refactoring-spec` | Current architecture, technical debt, behaviour that must not change, dependency impact | modernisation agents |

### More views, for more consumers

A view is just a projection of the canonical spec for one audience, so the set is not meant
to stop at three. Each new downstream consumer gets its own slice rather than being handed
the whole spec and left to work out which parts apply to it:

| Planned view | Stands for | Would carry |
| --- | --- | --- |
| `sad-spec` | Solution Architecture Document | The facts needed to assemble or refresh the SAD |
| `mec-spec` | Minimum Entry Criteria | Compliance status per cyber control — around 30 controls |
| `uaq-spec` | Unified Assessment Questionnaire | The questionnaire answers — around 415 facts across 13 sections |

The fact vocabularies for MEC and UAQ already exist as draft manifests
(`lseg-artifact-views/mec-spec.view.json`, `uaq-spec.view.json`), derived from real customer
exports. Their purpose is stated plainly in the generator: *"An artifact view says which
facts a downstream agent needs, in what order, under what headings. It is data, not code, so
adding an artifact touches one file and an architect can review the question-to-fact mapping
without reading PowerShell."*

The goal is that agents **ask for facts by name** — if each agent invents its own names, no
two agents ask for the same thing the same way, and no rule can bind to them. Where a
questionnaire duplicates something the spec already holds, the answer is to alias it to the
canonical key (`uaq.performance.rto` → `nfr.rto`) rather than create a second fact.

> **Status.** The three shipped views are hardcoded in `Spec.ps1` as
> `$script:VIEWS = @('development-spec', 'devops-spec', 'refactoring-spec')`, so adding a
> fourth is a code change today, not configuration. The MEC and UAQ manifests are still
> marked draft — their `fact_key`s are slugged mechanically and need a human pass.

Each spec file carries an `artifact_id`, a `version`, a `status`, and its `sections` — and
each section is either `needs-review` or `blocked`. Statements are routed to views by
`fact_key` prefix: `api.` and `contract.` go to development, `nfr.` goes to both devops and
development, and so on.

Everything under `out\` except the two append-only files is **regenerated on every `build`**.
Edit it by hand and your edit is gone; the only way to change anything is a command.

### Version control

The whole of `out/` is committed to the repository — it is deliberately *not* git-ignored as
build output. Two of its files cannot be regenerated at all: `statements.json`, because
rebuilding it means re-reading every document and re-deciding every extraction, which will
not reproduce the same result; and `decision-log.jsonl`, which is the answer to "who allowed
this, and when".

The regenerable files are committed anyway, because being diffable is the point. As
`DECISIONS.md` puts it: *a merge request then shows exactly which facts moved, which findings
opened or closed, and which approvals were voided* — without anyone running the tool.

> **Not yet defined.** How a downstream agent or CI pipeline obtains the spec from GitLab is
> outside the current contract. The package specifies *what* to call — `resolve` — but not
> *where* the store lives for a remote consumer, and nothing in the repo describes cloning,
> a pipeline job, or a published artifact. Today the assumption is that the consumer runs
> against a local `-Root`. Anyone wiring this into GitLab CI is designing that step, not
> following a documented one.

---

## A worked example

Follow one application through the pipeline: the Payments Gateway.

### Step 1 — The document says something

`payments-gateway-sad.md`, section 1:

> "The Payments Gateway is a Tier 1 application."

`/spec-ingest` records that sentence as a statement:

```text
fact_key:  app.tier
value:     1
source:    payments-gateway-sad.md
locator:   section 1
quote:     "The Payments Gateway is a Tier 1 application."
method:    explicit-statement
tier:      A          <- follows from the method; nobody chose it
status:    needs-review
```

Tier `A` was not a judgement call. The value was quoted verbatim, and quoting verbatim is
always `A`. And nothing enters the store already approved.

### Step 2 — Where documents disagree, nobody picks a winner

Two places in the SAD answer the same question differently:

| Where | What it says | Value |
| --- | --- | --- |
| Section 4.2 | *"The service must be restored within fifteen minutes of any regional failure."* | `nfr.rto = 15m` |
| Page 7 table | *"RTO: 1 hour"* | `nfr.rto = 1h` |

That is a **conflict**. The section is blocked, both statements drop to low confidence, and
any existing approval on them is voided with reason `conflict-opened`. The tool does not
prefer the higher tier and move on — a human decides which document is right.

### Step 3 — The constitution works out what the document never said

The SAD states the application tier. It says nothing about how to cut over. `/spec-check`
derives that, because the rules chain:

```text
app.tier = 1                                    STATED   (SAD, section 1)
  └─ LMP-MIG-CUT-2: tier 1 requires
       migration.cutover_pattern = cdc          DERIVED  (never in any document)
       └─ LMP-MIG-CUT-3: cdc requires r_type
            in [Refactor, Rearchitect]
```

Now the last link matters, and this is where the treatment comes from:

```text
migration.r_type = Replatform                   STATED   (the SAD asserts the
                                                          treatment is Replatform)
```

The document *itself* says Replatform. The constitution has just derived that a Tier 1
application needs a CDC cutover, and CDC forbids Replatform. So:

```text
LMP-MIG-CUT-3   ->   VIOLATION   ->   exit 3
```

Nobody typed that contradiction in. It fell out of one stated fact and two rules.

### Step 4 — A missing fact is a different failure

```text
LMP-RT-CONTAINER-2: Rearchitect must be justified on at least 2 of
                    [cost_reduction_pct, reliability_gain, scalability_need]
                    the document justifies on 0   ->   GAP   ->   exit 2
```

Step 3 was assessed and failed. Step 4 could not be assessed at all, because the facts
needed to judge it are absent. **Absence is never compliance.**

### Step 5 — The human decides, on the record

The reviewer agrees the treatment is wrong, rejects the Replatform claim, and asserts the
correct one:

```powershell
Spec.ps1 -Command review -Target stmt-83eb4652 -Action request-changes `
         -Actor n.nihal -Rationale "tier 1 forbids Replatform"

Spec.ps1 -Command add-statement -FactKey migration.r_type -Value Rearchitect `
         -Method human-assertion -Quote "Agreed in design review 27 Aug"

Spec.ps1 -Command review -Target stmt-1c471772 -Action approve -Actor n.nihal
```

`-Actor` is mandatory; omit it and the error reads *"an approval without a name is not an
approval."* Every one of these lands in `decision-log.jsonl`, which is only appended to. Six
months later, *"why is this a Rearchitect?"* has an answer with a name and a date on it.

### Step 6 — The gate opens

```powershell
Spec.ps1 -Command resolve -View devops-spec -MinStatus approved -Format json
```

Standards are clean and every statement in the view is approved, so the payload is emitted.
Had either been untrue, it would exit 3 — and refusal is not negotiable. The consumption
instructions are explicit that exit 3 *must never be worked around*: no retrying at a lower
`-MinStatus`, no generating a subset, no describing what would have been produced.

---

## What the system guarantees

Four properties hold no matter what an agent or prompt says, because the CLI's shape
enforces them rather than its documentation.

### 1. Nothing can grade its own confidence

Tier comes from *how* a fact was obtained. There is deliberately no `-Tier` parameter, so
there is no code path to set one:

```powershell
$script:METHOD_TIER = @{
    'explicit-statement' = 'A'   # quoted verbatim from the document
    'table-cell'         = 'A'
    'config-value'       = 'A'
    'human-assertion'    = 'A'
    'structure-derived'  = 'B'   # implied by how the document is organised
    'cross-reference'    = 'B'
    'inferred'           = 'C'
    'weak-inference'     = 'D'
    'guess'              = 'E'
}
```

The code comment says why: *a caller that can name its own confidence will always name it too
high.* The same reasoning removes `-SkipReview`, which does not exist either.

### 2. Rejecting a fact does not open the gate

The store is append-only, so rejecting a claim is the only correction available. If rejected
statements simply vanished, a reviewer could clear a blocking fact by rejecting it. So a
rejected statement leaves the view **only when a live replacement exists** — exactly what
happened in Step 5, where Replatform was rejected *and* Rearchitect was added. Reject the
only statement for a fact and it stays, still blocking.

### 3. An approval expires when its evidence changes

Approval is granted against one version of a document. If that document is edited, the
approval is withdrawn automatically and the statement returns to `needs-review` with reason
`source-changed`. Nobody has to remember to re-check.

### 4. Approval is not confidence

Approving a tier `D` statement records that a human accepted it. It stays tier `D`, and it
still arrives downstream marked weak. Review changes status, never strength.

---

## The three hashes

Hashes appear in three places and do three different jobs. They are easiest to keep straight
by the question each one answers.

| Hash | Lives in | Answers |
| --- | --- | --- |
| **File SHA-256** | `source-register.json` | *Has this document changed since we read it?* |
| **`binding_hash`** | a statement's review block | *Is this approval still about the same evidence?* |
| **`plan_hash`** | the `resolve` payload | *Which exact approved spec was this artifact built from?* |

**File SHA-256** is the simple one: a fingerprint of each source document taken at
`register-sources`.

**`binding_hash`** is recorded at the moment a human approves. It covers the statement's
value *and every piece of evidence it rests on, including the SHA-256 of each source
document*. `verify` recomputes it; if it has moved, the approval is revoked automatically.
This is the mechanism behind guarantee 3 — someone editing the SAD silently invalidates the
approvals that rested on it.

**`plan_hash`** solves a different problem, downstream. When the IaC agent generates
Terraform, you need to be able to say later *which* version of the spec produced it — not
"the spec, at some point". So `resolve` fingerprints exactly the set of values it handed
over:

```powershell
plan_hash = (Get-StringSha256 (($resolved | ForEach-Object { $_.id + '=' + $_.value }) -join '|'))
```

Change any resolved value and the hash changes. The integration guide tells consumers what to
do with it: *"write this next to whatever you generate. It covers the resolved statements, so
if any of them changes the hash changes, and an approval that named the old hash no longer
describes what is about to be applied."*

In practice: store the `plan_hash` beside the generated Terraform. Months later, re-run
`resolve` — if the hash still matches, the infrastructure reflects the approved spec. If it
does not, something changed after approval and the artifact is stale.

---

## Exit codes

Exit codes are the protocol between the spec layer and everything downstream.

| Code | Meaning | Correct response |
| --- | --- | --- |
| `0` | Proceed. Payload and `plan_hash` on stdout | Build from the payload |
| `2` | **Cannot assess.** Nothing readable, or a required fact is missing | Supply the missing fact |
| `3` | **Refused.** Not approved, open conflict, or a standards violation | Fix the cause — never retry lower |
| `4` | **Misconfigured.** No store, or an unknown view | Fix the invocation |

Exit 2 and exit 3 are kept apart on purpose. Exit 2 means the check could not run; exit 3
means it ran and said no. Collapsing them would let an unrun check hide behind a passing one —
Step 3 and Step 4 of the walkthrough above are the two cases side by side.

---

## Consuming the output

The contract is one command and its exit code:

```powershell
Spec.ps1 -Root <root> -Command resolve -View <view> -MinStatus approved -Format json
```

A consumer reads the payload and **never re-reads a source document**, never opens the spec
files directly, and never writes statements or edits decisions. That is the whole point: it
is what removes the discovery phase from downstream agents.

`tests/mock-consumer.ps1` is the reference implementation and the fixture the contract suite
runs against. `tests/Invoke-Tests.ps1` covers unit, integration, contract and standards
suites; the standards suite uses synthetic rule packs, so the engine is proven independently
of organisation content.

---

## Limits

- The `.apm/` agent and prompt files are prose wrappers over this CLI. They are written but
  not exercised in a live session — the largest untested surface in the package. The scripts
  beneath them are tested; the guidance above them is not.
- Extraction is not verified against the source text. The file hash proves the document has
  not changed; nothing proves the quoted sentence actually appears in it.
- Only text-extractable documents are read. Anything unreadable is recorded as unread with a
  reason rather than skipped silently.
- PDFs are read directly, including owner-restricted ones and, with `-Password`, ones the
  user holds the password for. Scans and undecodable text layers fall back to Windows OCR.
  A page whose text layer holds fewer than 25 words per page is treated as a scan with a
  header printed over it: OCR runs and replaces it only if it recovers substantially more,
  so a genuinely short document keeps its own characters. OCR output is labelled
  OCR-derived because it is a machine reading of a picture of the words: its errors are
  silent and plausible, so quotes taken from it need human confirmation. AES-256 (`/V 5`)
  PDFs and rights-protected (Purview/AIP) PDFs are refused, the latter because their
  readable pages carry only a "use a different reader" notice.
- The refactoring view is not self-sufficient — it needs the application source code
  alongside it.
