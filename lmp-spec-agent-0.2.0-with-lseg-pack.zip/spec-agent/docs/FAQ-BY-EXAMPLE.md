# The same FAQ, told as one story

> **Want it as one picture?** `the-story.drawio` has all of this on three pages: the whole
> journey, how the LLM is wired, and the ten blanks. Open it in VS Code with the Draw.io
> Integration extension, or at diagrams.net.

---

# START HERE — the five-minute version

If you read nothing else, read this. Everything after it is detail.

## What is a "spec"?

Forget the word. **A spec here is just a list of questions and answers, where every answer
has a receipt.**

Like this:

| Question | Answer | Receipt |
|---|---|---|
| How fast must it recover? | 15 minutes | SAD, section 4.2: *"restored within fifteen minutes"* |
| What tier is it? | 1 | SAD, section 1: *"tier 1 payment authorisation"* |
| Which region? | uksouth | SAD, section 6: *"primary region UK South"* |

That's it. Thirty-one rows like that, in a file. **The receipt is the important column** —
it's what separates this from a spreadsheet somebody filled in from memory.

In the software each row is called a **statement**, and each question is called a
**fact_key**. Same thing, just the names the code uses.

## What are we trying to prevent?

One thing:

> **Somebody fills in a blank, quietly, and nobody notices.**

Your document doesn't mention a rollback plan. A tool generates Terraform anyway. It all
looks fine. Then something fails at 3am and there's no rollback — because nobody ever asked
the question.

Every rule, gate and refusal in this system exists to stop a blank being filled silently.

## There are only three programs

Everything is one of these three. There is nothing else.

| Program | What it does | Think of it as |
|---|---|---|
| **`Extract-Text.ps1`** | turns documents into plain text | the reader |
| **`Spec.ps1`** | stores facts, checks them, guards the exit | **the librarian and the bouncer** |
| **`Check-Standards.ps1`** | tests facts against LSEG's rules | the auditor |

`Spec.ps1` does most of the work, and it's really two jobs in one: it **files** your facts
(librarian), and it **refuses to let anything through the door** until they're clean and
signed off (bouncer).

## The commands, and what each one produces

You never call these directly at first — you type a `/slash-command` in Copilot chat and it
runs them for you. But this is what's actually happening:

| Command | Plain English | What appears on disk |
|---|---|---|
| `init` | make me an empty filing cabinet | the `out\` folder and 4 empty intake folders |
| `register-sources` | what documents do I have, and can I read them? | `source-register.json` — one row per file, with a fingerprint |
| `add-statement` | file one fact | one more row in `statements.json` |
| `build` | tidy up and produce the readable versions | canonical spec, 3 views, conflicts, Markdown for humans |
| `review` | record that a human approved (or rejected) one fact | updates the row, appends to `decision-log.jsonl` |
| `resolve` | **the bouncer.** may this leave the building? | nothing — it either prints the facts, or refuses |
| `verify` | has any document changed since we approved it? | revokes any approval that's gone stale |
| `status` | how many facts, how many approved? | nothing — just a report |

**The one to understand is `resolve`.** It's the door. Nothing downstream reads your facts
directly — it all goes through `resolve`, and `resolve` says no unless everything is clean
and signed.

## What it all looks like on disk

After a full run:

```
payments-gateway\
│
├── src\                            <- YOU put documents here
│   └── existing-sad\
│       └── payments-gateway-sad.md
│
└── out\                            <- the software owns everything below here
    │
    ├── statements.json             <- THE MASTER RECORD. 31 facts + receipts.
    │                                  Nothing is ever deleted from this file.
    │
    ├── sources\
    │   └── source-register.json    <- which documents, their fingerprints,
    │                                  and whether each could actually be read
    │
    ├── specifications\             <- the tidied-up versions, rebuilt every time
    │   ├── system-spec.json        <- one agreed answer per question
    │   ├── devops-spec.json        <- the subset the infra team approves
    │   ├── development-spec.json   <- the subset the dev team approves
    │   └── refactoring-spec.json
    │
    ├── review\                     <- FOR HUMANS. Markdown tables you can read.
    │   ├── review-summary.md       <- start here: counts, weak facts, conflicts
    │   └── devops-spec.md
    │
    ├── conflicts\                  <- questions with two different answers
    ├── decisions\
    │   └── decision-log.jsonl      <- every approval ever, with a name and a time
    └── compliance\
        └── violations.json         <- what the LSEG auditor found
```

**Two folders matter to you:** `src\` (you put things in) and `out\review\` (you read things
out). Everything else is plumbing.

**One warning:** everything under `out\` is **regenerated on every `build`**. Edit a file in
there and your edit disappears. The only way to change anything is a command.

## The whole thing in eight lines

```
1. /spec-init      →  empty filing cabinet
2. [you drop the SAD into src\existing-sad\]
3. /spec-ingest    →  Copilot reads it, files 31 facts with receipts
4. /spec-check     →  auditor finds 18 problems
5. [you fix the design, you make the business case]
6. /spec-review    →  you approve all 31, by name
7. resolve         →  the bouncer says yes, hands over a fingerprint
8. generator       →  Terraform, or a hard stop if anything is unmapped
```

**You type six things.** The system spends the whole time telling you what it needs next and
refusing to move until it has it.

---

Everything below is the same journey, slowly, with the reasoning.

---

# The story, in full

No jargon unless it is explained first. Every section says **what we did**, **why**, and —
the important one — **what would have happened if we hadn't**.

---

## The application

**Payments Gateway.** A tier 1 payment authorisation service. If it stops, the business
stops taking money.

Today it runs on virtual machines in a data centre. We want it on Azure. Someone has
written a 4-page architecture document about it. That document is all we have.

**The job:** turn that document into Terraform that builds the right thing on Azure,
without anybody quietly making up the parts the document didn't say.

That last clause is the entire point of the system. Everything below exists to stop one
specific bad outcome:

> Terraform that looks completely reasonable, deploys without error, and is wrong —
> because somewhere along the way, something filled in a blank.

---

## Contents

**Part 0 — before any of it works**

- [0a. Installing it](#0a-installing-it)
- [0b. How the LLM is actually wired in](#0b-how-the-llm-is-actually-wired-in)
- [0c. Your first command, click by click](#0c-your-first-command-click-by-click)

**Part 1 — the story**

1. [Reading the document](#1-reading-the-document)
2. [Turning prose into facts](#2-turning-prose-into-facts)
3. [Where the intelligence is](#3-where-the-intelligence-is)
4. [Grading how well we know each fact](#4-grading-how-well-we-know-each-fact)
5. [When the document contradicts itself](#5-when-the-document-contradicts-itself)
6. [Checking it against LSEG's rules](#6-checking-it-against-lsegs-rules)
7. [The rules that fill in your blanks](#7-the-rules-that-fill-in-your-blanks)
8. [Fixing what's broken](#8-fixing-whats-broken)
9. [The dead end we hit](#9-the-dead-end-we-hit)
10. [The judgement call](#10-the-judgement-call)
11. [A human signs off](#11-a-human-signs-off)
12. [The gate opens](#12-the-gate-opens)
13. [Generation refuses](#13-generation-refuses)
14. [Someone edits the document](#14-someone-edits-the-document)
15. [The whole story on one page](#15-the-whole-story-on-one-page)

---

# Part 0 — before any of it works

## 0a. Installing it

You get a zip. Unzip it next to your work. That's the install.

```
spec-agent\
  apm.yml                      <- the package manifest
  .apm\agents\                 <- 3 agent personas
  .apm\prompts\                <- 6 slash commands
  .apm\skills\                 <- reference material the model reads
  .apm\scripts\powershell\     <- the 3 scripts that do the actual work
  docs\  tests\
```

No installer, no modules, no service. Windows PowerShell 5.1 and nothing else — because
asking a regulated bank to approve a new runtime is a six-month conversation, and this had
to work on day one.

**`apm.yml` is what makes it a package.** It lists the agents, the slash commands and the
instructions. Your Copilot setup reads that file and registers `/spec-init`, `/spec-ingest`,
`/spec-review` and the rest as commands you can type in chat.

One environment variable, pointing at the LSEG module catalogue:

```powershell
$env:LMP_CPF_CATALOG = "...\iac-tf\r\cpf-schemas\_catalog.json"
```

**Why an env var and not a bundled copy:** our copy had 226 modules. Your live catalogue
has 283. A vendored copy is a list that is *already out of date* on the day you ship it.

---

## 0b. How the LLM is actually wired in

This is the part that's easiest to get wrong, so here it is concretely.

**There is no API key. No SDK. No model call anywhere in the PowerShell.** Search all three
scripts for "openai", "gpt" or "completion" and you get nothing.

So how is a model involved at all?

### The model IS Copilot, and the scripts are its hands

```mermaid
flowchart TB
    U([you, in VS Code]) -->|types /spec-ingest| C[Copilot Chat]
    C -->|reads| P["spec-ingest.prompt.md<br/><i>the recipe</i>"]
    P -->|points to| AG["spec-builder.agent.md<br/><i>who to be</i>"]
    P -->|points to| SK["spec-layer SKILL.md<br/><i>reference material</i>"]
    C -->|reads your documents| D[(the SAD)]
    C -->|runs, one per fact| S["Spec.ps1 add-statement"]
    S --> ST[(statements.json)]

    style C fill:#2d3f5f,color:#fff
    style S fill:#1f4d2e,color:#fff
```

Four kinds of file, four different jobs:

| File | What it is | Plain English |
|---|---|---|
| `*.prompt.md` | a slash command | **the recipe** — numbered steps to follow |
| `*.agent.md` | a persona | **who to be** — what this role may and may not do |
| `SKILL.md` | reference | **the manual** — looked up when needed |
| `*.ps1` | the tool | **the hands** — does the work, enforces the rules |

When you type `/spec-ingest`, Copilot loads `spec-ingest.prompt.md` into its context. That
file is not documentation for you — **it is instructions to the model**. Real lines from it:

> *"**One fact per statement.** If your `-Value` contains "and", split it."*
>
> *"**`-Quote` is the document's words**, not your paraphrase."*
>
> *"**A fact no document states gets no statement.** Absence is a finding. Do not invent an
> RTO because a plan will need one later."*

And the agent file ends with a list headed **"What you never do"**:

> *"Approve anything. Approval requires `-Actor`, and that actor is a person."*

### The crucial bit: instructions alone are not the control

The model is *told* not to approve anything. **It also cannot.** `Spec.ps1` has no command
that approves without `-Actor`, and there is no `-SkipReview`. Ask Copilot to approve
everything and the most it can do is run the same command you would, with a name on it,
recorded in the log.

```mermaid
flowchart LR
    A[prompt says<br/>'do not approve'] -->|persuasion| B[model complies]
    C[script has no way<br/>to approve without<br/>a name] -->|physics| D[model cannot]

    style B fill:#4a3b2a,color:#fff
    style D fill:#1f4d2e,color:#fff
```

**The prompt is guidance. The script is the guarantee.** Every rule that actually matters is
enforced by code, and the prompt just tells the model what the code is about to do to it
anyway.

So *"the model proposes, the code disposes"* isn't a slogan — it's the literal file layout.
The model's entire power is **choosing which commands to run, and what to put in `-Value`
and `-Quote`.** Everything after that is PowerShell.

---

## 0c. Your first command, click by click

### You type

```
/spec-init payments-gateway
```

### Copilot replies

> Creating the spec store for `payments-gateway`.

and runs:

```powershell
Spec.ps1 -Root .lmp-migrate\payments-gateway -Command init
```
```
spec initialised at .lmp-migrate\payments-gateway\out
intake folders ready: comigrate-assessment, aimigrate-assessment, existing-sad, application-docs
```

> Drop your documents into whichever of these four folders fits, then run `/spec-ingest`.

### What just appeared on disk

```
.lmp-migrate\payments-gateway\
  src\                          <- YOU put documents here
    comigrate-assessment\
    aimigrate-assessment\
    existing-sad\               <- our SAD goes here
    application-docs\
  out\                          <- the system owns everything below
    statements.json             <- empty store, ready
    sources\  conflicts\  decisions\  specifications\  review\
```

### The folder names are load-bearing

Drop the SAD in `existing-sad\` and it's tagged with the `existing_sad` adapter. Drop it in
a folder you typed yourself — `existing_SAD\`, say — and it silently falls back to the
generic `appdocs` adapter. **No error. Just slightly worse extraction, forever.**

That's why `init` creates the folders *for* you rather than documenting them. In the script,
one table drives both the folders created **and** the adapter matching, so the two can never
drift apart:

```powershell
$script:INTAKE_ADAPTERS = [ordered]@{
    # folder name              ->  how to read what's inside it
    'comigrate-assessment' = 'comigrate'
    'aimigrate-assessment' = 'aimigrate'
    'existing-sad'         = 'existing_sad'
    'application-docs'     = 'appdocs'
}
```

That same table is used **twice**: once to create the folders, once to work out how to read
a file based on which folder it's in. One table, so they physically cannot disagree.

We learned this the hard way — it's DEC-004 in the decisions log. Two separate lists had
drifted, and the failure was completely silent.

### The six commands, and when you'd use each

| You type | What it's for | When |
|---|---|---|
| `/spec-init` | create the store | once per application |
| `/spec-ingest` | documents → facts | after you drop documents in |
| `/spec-check` | test against LSEG rules | after ingest |
| `/spec-extract-required` | hunt for missing required facts | when check reports gaps |
| `/spec-review` | walk a human through sign-off | when you're ready to approve |
| `/spec-status` | where are we? | any time |

### There is no wizard, and that's deliberate

Run them out of order and nothing breaks — **each command refuses on its own**:

| You skipped | What happens |
|---|---|
| `init` | exit 4 — *"no spec store, run init first"* |
| putting documents in | exit 2 — *"no readable intake documents"* |
| `ingest` | `build` exits 2 — *"no statements"* |
| `review` | `resolve` exits 3 — *"not approved"* |

The orchestrator agent says so outright:

> *"There is no scheduler here and no state file... That is the whole control flow. Do not
> add your own sequencing on top of it."*

**Why this matters:** a wizard that tracks "which step you're on" has a memory, and memories
go stale. Someone edits a file by hand, or runs a script outside the tool, and the wizard's
idea of reality quietly diverges from the disk. Here **every command re-reads the disk and
decides for itself.** There's no state to get out of sync, because there's no state.

---

# Part 1 — the story

## 1. Reading the document

### In chat, you type

```
/spec-ingest
```

### What Copilot does first

Step 1 of its recipe is to register the sources:

```powershell
Spec.ps1 -Root .lmp-migrate\payments-gateway -Command register-sources
```
```
registered 1 source(s): 1 read, 0 not-read
```

It found `payments-gateway-sad.md`, took a **fingerprint** of it (a SHA-256 hash — a short
code that changes if even one character of the file changes), and recorded that it could
genuinely be read.

### What the script actually does

For every file, it does something most tools don't: **it asks the extractor to really read
the file, and believes the answer.**

```powershell
# Actually run the text extractor against this file and see if it succeeds.
$null = & powershell.exe -File $extractor -Command file -Path $f.FullName 2>&1

# Exit code 0 means it genuinely got text out. Anything else means it didn't.
if ($LASTEXITCODE -eq 0) { $status = 'read'; $readable++ }
else { $reason = 'extractor could not read this file type or content' }
```

**In plain English:** *don't assume — try it, and record the honest answer.*

The comment above it explains why:

> *"The extractor is the authority on readability. Asking it here means the register can
> never claim a file is readable that extraction then skips."*

Then, if **nothing** was readable:

```powershell
# Not one single file produced text? Stop. Do not proceed to build a spec.
if ($readable -eq 0) { Fail 'no readable intake documents - every file failed extraction' 2 }
```

Exit 2. Hard stop. It will not build a spec out of nothing.

### And the prompt makes Copilot tell you

> *"If any file came back not-read, **name those files to the user now**. Do not wait for
> the review summary. A scanned PDF or a cloud placeholder that nobody notices is how a
> whole subsystem goes missing from a spec."*

So in chat you'd see, immediately:

> ⚠ 1 of 4 files could not be read: `network-topology.pdf` — no extractable text layer
> (likely a scan). I have written no statements from it.

### If we hadn't

Imagine the document was a scanned PDF — just pictures of text. A naive tool opens it,
gets nothing, and carries on. It produces a spec with three facts in it instead of thirty.

Nobody notices, because **nothing failed**. There's no error. There's just a very short
spec, and everyone assumes the application must be simple.

The system instead says *"I could not read this file, and here is why"*. **An empty answer
and an unreadable document must never look the same.**

---

## 2. Turning prose into facts

### What you see in chat

Copilot now reads the extracted text and starts proposing facts. In chat it looks like this:

> Reading `payments-gateway-sad.md` (4.4 KB, `src-210548f2`).
>
> Section 4.2 says *"The service must be restored within fifteen minutes of any regional
> failure."* → recording `nfr.rto = 15m`.

then it runs:

```powershell
Spec.ps1 -Command add-statement -FactKey nfr.rto -Value 15m `
  -SourceId src-210548f2 -Locator "section 4.2" `
  -Quote "restored within fifteen minutes" -Method explicit-statement
```
```
added stmt-a00bc8c1  tier A  -> devops, development
```

**31 times, once per fact.** Then:

```powershell
Spec.ps1 -Command build
```
```
built: 31 statement(s), 31 fact(s), 0 conflict(s), 3 view(s)
```

### The statement it stored

```
fact_key:  nfr.rto
value:     15m
evidence:  payments-gateway-sad.md, section 4.2,
           quote: "restored within fifteen minutes"
method:    explicit-statement
```

### Why the four parts

| Part | Plain meaning | Why it's there |
|---|---|---|
| `fact_key` | the question | so rules can find it later |
| `value` | the answer | what actually goes into Terraform |
| `evidence` | where it says so | so a human can check it in 10 seconds |
| `method` | how we know | decides how much to trust it |

**The `quote` is the part people underestimate.** It means a reviewer never has to go
hunting. The claim and its receipt travel together.

### What the script does with it

Two things worth knowing.

**1. The statement id is a hash of its own content:**

```powershell
function New-StatementId($FactKey, $Value, $SourceId, $Locator) {
    # Glue the four identifying parts of the claim together into one string...
    $seed = "$FactKey|$Value|$SourceId|$Locator"

    # ...and use its fingerprint as the id. Same claim in = same id out, always.
    'stmt-' + (Get-StringSha256 $seed).Substring(0, 8)
}
```

**In plain English:** *the name of a fact is made out of the fact itself, so identical facts
cannot help but collide.*

Add the identical claim twice — from a retry, or two people ingesting the same document —
and you get the identical id, so it's recognised and skipped:

```
statement stmt-a00bc8c1 already present (identical evidence) - no change
```

**Why it matters:** without this, running ingest twice would double every fact, and a fact
appearing "twice" is evidence a naive tool might weigh more heavily. Duplication would
quietly become a vote.

**2. `-Value` is checked for *supplied*, not for *truthy*:**

```powershell
# Was -Value typed at all? (Not: is it non-empty?)
if (-not $script:BoundParams.ContainsKey('Value')) { Fail '-Value is required' 2 }
```

Not `if (-not $Value)`. The difference matters:

| Typed | Means | Ordinary check would say |
|---|---|---|
| `-Value "15m"` | a real answer | fine |
| `-Value ""` | *deliberately* empty | "missing" ❌ wrong |
| *nothing* | somebody forgot | "missing" ✅ right |

Ordinary truthiness treats the middle row as missing and **silently discards a real fact**.

### If we hadn't recorded evidence

Suppose we stored `nfr.rto = 15m` with no quote and no page reference.

Six weeks later somebody asks *"why is this configured for 15 minutes? That's expensive."*
Now someone re-reads a 4-page document to find out — and if they can't find it, they're left
guessing whether it was a real requirement or somebody's assumption.

Multiply by 31 facts and the spec becomes **unauditable**. It might be right, but nobody can
prove it, so nobody can safely change anything.

---

## 3. Where the intelligence is

This is the question everyone asks: *"if it's all scripts, where's the AI?"*

### The split

Read that sentence again:

> *"The service must be restored within fifteen minutes of any regional failure."*

Getting `nfr.rto = 15m` out of that needs **real intelligence**. It needs to know "fifteen
minutes" is a duration, that "restored" means recovery time, and that RTO is the standard
term. No pattern-matching gets you there. **A language model does this.**

But now look at what happens next:

| Decision | Who makes it |
|---|---|
| "This sentence means `nfr.rto = 15m`" | **the model** |
| "Is 15m allowed for a tier 1 app?" | **code** |
| "Does this contradict another fact?" | **code** |
| "Has a human approved it?" | **code** |
| "May we build Terraform now?" | **code** |

```mermaid
flowchart LR
    A[messy human prose] -->|MODEL<br/>reads and proposes| B[a clean fact<br/>with a quote]
    B -->|CODE<br/>checks and decides| C[allowed / refused]

    style A fill:#4a3b2a,color:#fff
    style B fill:#2d3f5f,color:#fff
    style C fill:#1f4d2e,color:#fff
```

**The model proposes. The code disposes.**

### If we hadn't split it

Suppose we just asked a model: *"here's the architecture document, is this design
compliant with LSEG standards?"*

You'd get an answer. It would be well-written, confident, and structured. It would cite
plausible-sounding rules. **And you would have no way to tell whether it was right.**

Worse — ask it twice and you might get two different answers, both convincing.

There's a sharper problem still. A model that has just written you a lovely migration plan
is not a neutral judge of whether that plan is compliant. It's marking its own homework.

So compliance was made a **decision in code**: 74 rules, each quoting the actual policy
document, evaluated the same way every time. Run it a thousand times, get the same answer a
thousand times. **You can disagree with it and go read the rule.**

---

## 4. Grading how well we know each fact

### What we did

Every statement gets a grade, **A** to **E**, based on *how* we found it:

| Grade | Meaning | Example from our document |
|---|---|---|
| **A** | it says so, in writing | "restored within fifteen minutes" → `nfr.rto = 15m` |
| **B** | implied by the structure | a diagram box labelled "UK South" |
| **C** | reasoned from context | "it's a payments service, so it's probably tier 1" |
| **D** | a stretch | "most services like this use Key Vault" |
| **E** | an admitted guess | — |

All 31 of our facts came out **tier A**, because the document was unusually explicit.

### The rule that matters

**Whoever supplies the fact does not get to choose its grade.** You declare *how* you found
it, and the grade follows automatically.

### How the script enforces that

There is simply **no `-Tier` parameter**. You can't pass one. The grade is looked up from
the method you declared:

```powershell
# A lookup table: how you found it  ->  what grade it gets.
# You declare the left column. The code decides the right column.
$script:METHOD_TIER = @{
    'explicit-statement' = 'A'   # the document says it outright
    'table-cell'         = 'A'   # it was in a table
    'structure-derived'  = 'B'   # implied by how the document is organised
    'inferred'           = 'C'   # reasoned from context
    'weak-inference'     = 'D'   # a stretch
    'guess'              = 'E'   # admitted guess
}
```

with a one-line comment stating the reasoning:

> *"Tier is never supplied by a caller: a caller that can name its own confidence will
> always name it too high."*

And an unknown method doesn't get the benefit of the doubt:

```powershell
function Get-Tier($ExtractionMethod) {
    # Recognised method? Use its grade.
    if ($script:METHOD_TIER.ContainsKey($ExtractionMethod)) { return $script:METHOD_TIER[$ExtractionMethod] }

    # Never seen it before? Treat it as a guess.
    return 'E'
}
```

**Unrecognised means E — the worst grade, not the best.** Every unknown gets treated as a
guess until someone proves otherwise.

The tier is also **recomputed on every build**, never trusted from the stored file. Edit
`statements.json` by hand to upgrade a D to an A and the next `build` puts it straight back.

### If we hadn't

Let anything self-report its own confidence, and everything is high confidence. Not out of
malice — it's just what happens. A model asked "how sure are you?" tends to say "very".
A contractor under time pressure will too.

Then a reviewer sees 31 facts all marked "high confidence" and reasonably concludes there's
nothing much to check. **The grades stop carrying information, so people stop reading
them.**

By deriving the grade from the method, a **D** appears whenever someone declares a weak
inference — whether they wanted it to or not. That D is a flag saying *"look here first"*.

---

## 5. When the document contradicts itself

### What could happen

Suppose page 2 says *"recovery within fifteen minutes"* and page 7's table says
*"RTO: 1 hour"*.

Both are tier A. Both are quoted. Both are genuinely in the document.

```
nfr.rto = 15m   (page 2)
nfr.rto = 1h    (page 7, table)
```

The system raises a **conflict**, marks that whole section **blocked**, and refuses to hand
anything downstream. It also drops the confidence to *low* — a fact people disagree about is
not a confident fact, however plainly it's written.

### In chat you'd see

> ⚠ **1 open conflict.** `nfr.rto` has two competing values:
> - `15m` — stmt-a00bc8c1, section 4.2, *"restored within fifteen minutes"*
> - `1h` — stmt-3f9d2e71, page 7 table, *"RTO: 1 hour"*
>
> The `nfr` section of `devops-spec` is **blocked**. I cannot resolve this — both are
> tier A and both are genuinely in your document. A human needs to decide which is right.
> Run `/spec-review` to record the decision.

Notice what it does *not* do: pick one, suggest one, or guess which page is newer.

### What the script does

Group every statement by `fact_key`, then count the distinct values:

```powershell
# Take every answer given for this one question, and remove duplicates.
$values = @($live | ForEach-Object { $_.value } | Sort-Object -Unique)

# More than one distinct answer left? Then people disagree.
if ($values.Count -gt 1) {
    # ...record a conflict, and mark every statement in the group as contested
}
```

**In plain English:** *if the same question has two different answers, say so — don't pick.*

Two consequences follow automatically. **Confidence is forced down regardless of tier:**

```powershell
function Get-Confidence($Tier, $InConflict) {
    # Contested? Then it's low confidence, full stop - grade is irrelevant.
    if ($InConflict) { return 'low' }
    ...
}
```

And — this is the sharp one — **an existing approval is torn up**:

```powershell
# This fact is now contested, but somebody had already approved it...
if ($inConflict -and $s.review.status -eq 'approved') {
    $s.review.status = 'needs-review'          # tear the approval up
    $s.review.reason = 'conflict-opened'       # and say why
    Add-DecisionEntry $Paths @{ actor = 'system'; action = 'auto-void'; ... }   # log it
}
```

**Why:** you approved `15m` back when it was the only answer. Someone has since found a
document saying `1h`. Your approval was made without knowing that. It cannot stand, and the
system revokes it rather than hoping someone remembers to.

### If we hadn't

A tool that doesn't check for this picks one. Probably the first one it saw, or the last —
some detail of ordering nobody intended as a decision.

You get Terraform configured for a 15-minute RTO. That's active-active across two regions,
roughly double the infrastructure.

Or it picks `1h`, you deploy single-region, and you discover the difference during an
outage.

**Either way the software made a decision that nobody knew was being made.** The conflict
mechanism forces the question back to a human: *your document contradicts itself, which is
it?*

---

## 6. Checking it against LSEG's rules

### In chat, you type

```
/spec-check
```

### What Copilot runs

```powershell
Check-Standards.ps1 -Root .lmp-migrate\payments-gateway -Command check
```
```
constitution v1.6.0  74 rule(s)  31 fact(s) stated, 6 derived
18 finding(s): 2 violation(s), 16 gap(s)     EXIT: 3
```

Two things were actually **wrong**. Sixteen were **missing** — questions LSEG requires an
answer to, that our document never addressed.

### What Copilot must do with that

The prompt is explicit about the model's role here:

> *"...explain every finding in the constitution's own words, and **never adjudicate
> compliance by judgement**."*

So in chat you get the findings quoted and grouped — never *"I think this is probably fine"*.
The model is a translator here, not a judge. It has no ability to clear a finding; the only
things that clear one are a changed fact or a recorded exception.

### How the rules work

The rules aren't a summary of LSEG policy. Each one carries **the policy's own sentence**:

```json
{
  "id": "LMP-RT-CONTAINER-2",
  "quote": "<the actual sentence from the LMP Constitution v1.6.0>",
  "when":  { "migration.r_type": "Rearchitect" },
  "requires_n_of": { "n": 2, "facts": ["...cost_reduction_pct",
                                       "...reliability_gain",
                                       "...scalability_need"] }
}
```

So when it blocks you, it can show you **why, in the constitution's words** — not a
paraphrase by whoever wrote the rule.

### If we hadn't quoted the source

Say the rule just said `r_type must not be Replatform for tier 1`.

An architect reads that, thinks *"that seems arbitrary"*, and goes hunting for someone who
can waive it. Now you've got an argument based on nobody being sure what the policy says.

With the quote, the conversation is 30 seconds: here is the sentence, here is what it
requires, do you meet it or not?

### A violation blocks everything

Our violations were about infrastructure. They also blocked the *development* view.

**Why:** a tier 1 payments service with the wrong migration approach isn't "broken for the
infrastructure team and fine for the developers". It's broken. Letting one team proceed
just means the wrong thing gets built faster.

---

## 7. The rules that fill in your blanks

### The clever part

Our document said **"tier 1"**. It never mentioned cutover strategy.

But the constitution says *tier 1 implies CDC cutover*, and *CDC cutover implies a rollback
plan*, and *a rollback plan implies a rollback trigger*...

The engine follows that chain and worked out **6 facts** the constitution requires that
nobody had written down.

```mermaid
flowchart LR
    A["app.tier = 1<br/><i>stated</i>"] --> B["cutover = CDC<br/><i>implied</i>"]
    B --> C["rollback plan<br/><i>implied</i>"]
    C --> D["rollback trigger<br/><i>implied</i>"]
    D --> E["...6 facts nobody<br/>wrote down"]

    style A fill:#1f4d2e,color:#fff
    style E fill:#5f3d2d,color:#fff
```

It reports them under a deliberately blunt heading:

> **"facts the constitution implies but nobody stated"**

### How the script does it

It keeps applying rules until nothing new appears — a **fixpoint loop**:

```powershell
# Chains implication rules to a fixpoint. Only `must_be` derives a value - `must_be_in`
# and `must_exist` constrain without pinning one, so they validate but never derive.
```

One pass would only find facts implied *directly* by what you stated. Looping means it also
finds facts implied by facts implied by what you stated — the full chain, however deep.

It also tracks **which rule produced each derived fact**, so it can catch the rulebook
contradicting itself:

```powershell
if ($existing.origin -eq 'derived' -and [string]$existing.value -ne [string]$mustBe) {
    # two rules derived two different values for the same fact
    ... kind = 'inconsistency'; rule_a = $derivedBy[$targetKey] ...
}
```

**Why bother:** without it you'd be blocked by an unwinnable rule — satisfy one and you
break the other — with no way to see that the *constitution* is at fault, not you. It names
both rule ids so someone can go and fix the policy.

### The chat follow-up

When gaps come back, there's a second command:

```
/spec-extract-required
```

Its description states the division of labour exactly:

> *"Rule-guided extraction: **the checker decides what to look for, the model only finds
> it**."*

The rule engine produces the shopping list — *"the constitution needs
`migration.cutover_pattern` and it's missing"* — and Copilot goes hunting through the
documents for that specific fact. It never decides whether what it finds is acceptable.

**Why this ordering matters:** a model asked to "find anything missing" will find whatever
it finds. A model handed a list of 16 specific required facts is doing a search, not
exercising judgement — and a search you can check.

### If we hadn't

The document is silent on rollback. A tool that only checks what's written finds nothing
wrong — the document doesn't *violate* anything.

You migrate. Something goes wrong at 3am during cutover. **There is no rollback plan**,
because nobody ever asked the question, because the document never raised it, because
nobody noticed the document should have.

The chain turns *"you didn't mention this"* into *"your own tier 1 declaration requires
this"*. **It finds the questions you didn't know to ask.**

### It also checks the rulebook against itself

If one rule concludes `cutover = CDC` and another concludes `cutover = big-bang`, that's a
**collision** — the constitution contradicts itself. It says so, rather than quietly
picking one.

Otherwise you'd be blocked by an unwinnable rule and have no idea why.

---

## 8. Fixing what's broken

### What we did

The worst finding:

```
[VIOLATION] migration.r_type = Replatform is not permitted for a tier 1 application
```

We'd said we'd lift-and-shift a tier 1 payments service. The constitution forbids it.

So we corrected it. Not by editing anything — **you cannot edit or delete a statement**.
You add the right one and reject the wrong one:

```powershell
Spec.ps1 -Command add-statement -FactKey migration.r_type -Value Rearchitect ...
Spec.ps1 -Command review -Target stmt-83eb4652 -Action request-changes `
         -Actor n.nihal -Rationale "tier 1 forbids Replatform"
```

18 findings → 1.

### Why nothing is ever deleted

Six months from now, someone will ask *"why is this a rearchitect? That was expensive."*

The record has the answer: the original Replatform decision, who rejected it, when, and why.
**The wrong answer and the reason it's wrong are both part of the design history.**

### If we could delete

The store would only ever show the current answer. Every reversed decision would vanish,
and with it the reason. The most valuable thing in a migration — *why we ruled things out* —
would be exactly the thing that got erased.

---

## 9. The dead end we hit

**This is a real bug we hit on this exact application. It's here because it explains the
design better than anything that worked first time.**

### What happened

Having rejected the Replatform statement and approved Rearchitect, we asked for the gate:

```
BLOCKED: 1 statement(s) below -MinStatus 'approved':
  stmt-83eb4652  migration.r_type  [changes-requested]
```

The **rejected** statement was blocking. The one we'd deliberately thrown away.

And because nothing can be deleted, **there was no way out**. Correct any fact and that
spec could never be approved again, ever.

### The tempting fix, and why it's dangerous

Obvious answer: *rejected statements shouldn't count. Remove them.*

Now consider what that hands you.

A statement is blocking your migration. You don't want to deal with it. So you reject it —
and it disappears. Gate opens.

**Rejection becomes the escape hatch.** The gate now only checks the statements nobody
objected to, which means it isn't a gate at all. It's a formality.

### The actual fix

A rejected statement is removed **only when another live statement replaces it**.

```mermaid
flowchart TB
    A[you reject a statement] --> B{is there another<br/>answer for this fact?}
    B -->|yes| C["means: 'this one was superseded'<br/>removed - the new answer stands"]
    B -->|no| D["means: 'this fact is wrong'<br/>stays, and still BLOCKS"]

    style C fill:#1f4d2e,color:#fff
    style D fill:#5f2d2d,color:#fff
```

Same command, two meanings, and the difference is whether you supplied a replacement:

- **"This is superseded"** — here's the right answer, drop the old one. → *proceed*
- **"This is wrong"** — and I have nothing to put in its place. → *still blocked*

Reject the only answer to a question and you haven't answered it. You've just admitted you
don't know. That should block, and it does.

### Why this is in the FAQ

164 automated tests passed while this bug was live. The test checked that rejecting a
statement cleared the conflict — and stopped there. It never went on to ask *"and can you
now actually proceed?"*

**It tested the mechanism and missed the outcome.** It took running the thing on a real
document to find it. Both halves of the rule now have a test that runs all the way to the
gate.

---

## 10. The judgement call

### What we did

One finding survived:

```
[GAP] LMP-RT-CONTAINER-2  only 0 of the required 2 evidence facts are stated
                          EXIT: 2
```

LSEG requires a rearchitect to be justified on at least **two of three** grounds: cost,
reliability, or scale. Our document justified it on none.

### Note the exit code: 2, not 3

- **3** means *"I checked. The answer is no."*
- **2** means *"I couldn't check."*

Nothing here is broken. The engine simply **cannot assess** a business case that hasn't been
made.

### If we collapsed 2 and 3 into "failure"

You'd lose the ability to distinguish these two situations:

| | |
|---|---|
| *"This design violates a standard"* | someone made a wrong decision |
| *"This design was never assessed"* | nobody made a decision at all |

The second is more dangerous, because it's invisible. Everything looks fine. There's just
nothing there.

This is also why there's a `-RequireStandards` switch. Without it, forgetting to run the
compliance check produces **zero findings** — which looks exactly like passing. The switch
turns *"never checked"* into an outright refusal.

**A check that didn't run must never look like a check that passed.**

### What we did about it

Two legitimate routes:

| Route | When | We chose |
|---|---|---|
| **State the evidence** | you can make the case | ✅ 22% cost reduction, plus a measured VMSS scaling limit |
| **Record an exception** | accepted, but unevidenced | — |

Route A took us to **0 findings**.

### About that exception route

An exception is not a waiver. It requires:

- a named **governance approver** (not the person who wants it)
- a mandatory **expiry date**
- a rationale

It refuses a backdated expiry, and the finding **re-opens by itself** the day it lapses.

**If exceptions didn't expire:** the first migration under pressure gets one. So does the
second. Three years later there are 200 permanent exceptions, nobody knows who approved
them or why, and the constitution is decoration.

Expiry means every deviation gets re-argued. Most quietly disappear, because the pressure
that justified them is gone.

---

## 11. A human signs off

### In chat, you type

```
/spec-review
```

### What Copilot does

It does **not** dump 31 statements at you. The reviewer agent works a **triage order**:
conflicts first, then tier E, then tier D, then unrouted, then a spot-check of the rest.

> **31 statements to review.** No conflicts. All tier A, so nothing is flagged as weak.
>
> Starting with the 3 facts that drive the most Terraform:
>
> **1 of 31** — `azure.target.compute` = `cpf-azure-prdsvcpat-aks-private`
> Evidence: `payments-gateway-sad.md`, section 3.1
> Quote: *"private AKS cluster, no public API endpoint"*
> Tier A · explicit statement
>
> Approve, request changes, or skip?

You say approve. It runs:

```powershell
Spec.ps1 -Command review -Target stmt-271704ac -Action approve -Actor n.nihal
```
```
stmt-271704ac -> approved by n.nihal
```

**Where does `n.nihal` come from?** You. Copilot asks once at the start of the session and
uses it for the rest. It cannot make one up — the script rejects the command without it.

### The script's guard

```powershell
# No name supplied? Then this is not an approval. Refuse before doing anything.
if (-not $Actor) { Fail '-Actor is required - an approval without a name is not an approval' 2 }
```

And on approval it captures the fingerprint that makes the approval revocable later:

```powershell
'approve' {
    $found.review.status = 'approved'

    # Record a fingerprint of the value AND of every document it rests on.
    # This is what `verify` re-checks later to see if the approval is still honest.
    $found.review.binding_hash = Get-BindingHash $found $srcIndex
}
```

Every decision is then appended — never overwritten — to `decision-log.jsonl`:

```powershell
# Append one line to decision-log.jsonl. Append only - never edited, never removed.
Add-DecisionEntry $Paths @{ ts = (Now); actor = $Actor; action = $Action; target = $Target
                            fact_key = $found.fact_key; rationale = $Rationale }
```

### If approvals were anonymous

Something goes wrong. You ask *"who signed off on single-region deployment?"*

Answer: "the system approved it". Or: "it was approved on the 14th".

**Nobody actually took responsibility.** And a sign-off nobody is accountable for isn't a
control — it's a checkbox. The value of the approval is exactly the fact that a specific
person's name is against it.

### What is deliberately NOT a human decision

Grading, conflict detection, rule evaluation, whether the gate opens.

**Why keep humans out of those?** Because they're mechanical, and humans are inconsistent
about mechanical things — especially at 6pm on a Friday before a go-live. Code isn't.

Humans should spend their judgement on *"is this business case good enough?"*, not on
*"did I remember to check all 74 rules?"*

---

## 12. The gate opens

### What we did

```powershell
Spec.ps1 -Command resolve -View devops-spec -MinStatus approved -RequireStandards
```
```
view devops-spec  31 statement(s)  plan_hash b922149f0a614a75...     EXIT: 0
```

### The two locks

```mermaid
flowchart LR
    A[want to generate<br/>Terraform] --> B{standards<br/>clean?}
    B -->|no| X[REFUSED]
    B -->|yes| C{every statement<br/>approved?}
    C -->|no| X
    C -->|yes| D[here is the payload<br/>+ plan_hash]

    style X fill:#5f2d2d,color:#fff
    style D fill:#1f4d2e,color:#fff
```

They're **independent**, and that's the point. Approving a design doesn't make it compliant.
Compliance doesn't mean anyone agreed to it. You need both.

**Standards are checked first** — "this breaks a rule" matters more than "nobody's signed
it yet".

### The order in the script

The constitution gate sits at the very top of `resolve`, before the approval loop:

```powershell
# Look for the auditor's findings file.
$vio = Read-JsonFile $Paths.Violations

if ($null -ne $vio) {
    $standardsChecked = $true              # remember that a check DID happen
    $blocking = AsArray $vio.violations

    if ($blocking.Count -gt 0) {           # any unresolved violations? refuse.
        [Console]::Error.WriteLine("BLOCKED: $($blocking.Count) unresolved constitution finding(s):")
        ...
        [Console]::Error.WriteLine('These cannot be cleared by approval. Fix the design, or record an exception:')
        exit 3
    }
}
```

Read that error message again: **"These cannot be cleared by approval."** The two gates
aren't just independent, the system says so when it refuses, so nobody wastes an afternoon
trying to approve their way past a violation.

The comment above it explains why one violation stops all three views:

> *"A violation blocks every view, not just the one it was routed to. A tier 1 application
> with a Replatform treatment is not broken in the devops view and fine in the development
> view — it is broken, and nothing should be built from it."*

### And the "never checked" trap

```powershell
# You demanded a standards check, but no findings file exists at all,
# which means the check was never run. Silence is not a pass. Refuse.
if ($RequireStandards -and -not $standardsChecked) {
    [Console]::Error.WriteLine('BLOCKED: -RequireStandards is set but no standards check has been run.')
    exit 3
}
```

The handover payload also carries these two facts forward, so whoever reads it later can
tell a clean run from a skipped one:

```powershell
standards_checked = $standardsChecked      # was the auditor actually run?
standards_skipped = [bool]$SkipStandards   # did someone deliberately bypass it?
```

**Why record a bypass rather than just allowing it:** if `-SkipStandards` left no trace, a
bypassed run and a clean run would be identical downstream. Recording it means the bypass is
visible to whoever reads the output later.

### That `plan_hash`

`b922149f0a614a75...` is a fingerprint of **exactly what was approved** — every fact, every
value. Change one and it changes completely.

It gets written next to the generated Terraform.

**If we didn't have it:** you'd have Terraform, and a spec, and no way to prove they match.
Six months on, the spec has moved on. Did this Terraform come from the approved version, or
from something someone was mid-way through editing? Unanswerable.

With the hash: compare, done.

---

## 13. Generation refuses

### What we did

Gate open, so we ran the generator. Result:

```
HARD STOP: approved value(s) this agent has no CPF module mapping for:
  azure.target.compute = cpf-azure-prdsvcpat-aks-private (stmt stmt-271704ac)
                                                          EXIT: 2
```

Nothing was written.

### Why this is the right answer

We asked for a private AKS cluster. The generator doesn't have a mapping for it — so it
**stopped**, and named the exact statement so we know where to look.

The comment in its own source says it plainly:

> *"A value not in this table is a hard stop: this agent will not invent a module."*

### If it had guessed

This is the single most dangerous moment in the whole pipeline. A generator with a missing
piece is *so close* to done. It would be so easy to pick something similar — a regular AKS
module instead of the private one.

You'd get Terraform. It would be valid. It would deploy.

**And you'd have a payment service on a publicly-reachable Kubernetes API.**

Nobody would spot it in review, because the Terraform looks exactly like Terraform is
supposed to look. The wrongness is invisible unless you already know what was meant.

**Refusing loudly is always better than guessing quietly.** Same reason a missing fact is a
hard stop rather than a sensible default — once a default is baked into Terraform, it's
indistinguishable from a decision someone made on purpose.

### The known weakness

That module table is **hardcoded with six entries**. The real catalogue has **283**.

This is a genuine gap, and it's in the FAQ's "what this does not do" list rather than
hidden. The fix is to read the live catalogue — the same lesson the compliance checker
already learned, which reads its catalogue at runtime rather than keeping a copy.

**A copy of a list is a list that is already out of date.**

---

## 14. Someone edits the document

### The scenario

Everything is approved. Terraform is generated. A week later, an architect updates the SAD:
the RTO changes from 15 minutes to 1 hour. Reasonable change, properly considered.

**Your approval was about the old sentence.**

### What the system does

```powershell
Spec.ps1 -Command verify
```
```
verify: 1 approval(s) voided by changed evidence
```

When you approved, it recorded a fingerprint covering the value **and the fingerprint of
the document it came from**. The document changed, so the fingerprint changed, so the
approval is **automatically revoked**. That statement is back to `needs-review`, reason:
`source-changed`.

```mermaid
flowchart LR
    A[approved:<br/>rto = 15m] --> B[fingerprint recorded]
    B --> C[SAD edited]
    C --> D[verify]
    D --> E{fingerprint<br/>still matches?}
    E -->|yes| F[approval stands]
    E -->|no| G[REVOKED<br/>back to needs-review]

    style G fill:#5f2d2d,color:#fff
```

### If we didn't do this

The approval would survive. It would still say "approved by n.nihal".

And it would be a **lie** — n.nihal approved a 15-minute RTO. The document now says an hour.
Nobody re-checked, because nobody knew there was anything to re-check.

Worse, the approval provides *false comfort*. Someone looking at that spec sees a green tick
against a fact that no longer matches its own evidence.

This is the failure mode that catches everyone eventually: **not a missing sign-off, but a
sign-off that quietly stopped being true.** The fingerprint means nobody has to remember —
it's caught mechanically.

---

## 15. The whole story on one page

```mermaid
flowchart TB
    A["4-page SAD"] --> B["read it, fingerprint it<br/><i>refuses if unreadable</i>"]
    B --> C["MODEL: 31 facts,<br/>each with a quote"]
    C --> D["grade A-E by how we know<br/><i>you don't grade yourself</i>"]
    D --> E["contradictions?<br/><i>blocks, doesn't pick</i>"]
    E --> F["74 LSEG rules<br/><i>18 findings</i>"]
    F --> G["chain rules forward<br/><i>6 facts nobody stated</i>"]
    G --> H["HUMAN: fix design<br/><i>add + reject, never delete</i>"]
    H --> I["HUMAN: make the<br/>business case"]
    I --> J["HUMAN: approve all 31,<br/>by name"]
    J --> K{"THE GATE<br/>standards + approval"}
    K -->|refused| X["nothing written"]
    K -->|open| L["payload + plan_hash"]
    L --> M{"every value<br/>mapped?"}
    M -->|no| Y["HARD STOP<br/><i>will not invent</i>"]
    M -->|yes| N["Terraform<br/>+ plan_hash"]

    style X fill:#5f2d2d,color:#fff
    style Y fill:#5f2d2d,color:#fff
    style N fill:#1f4d2e,color:#fff
```

### The entire session, as you'd actually experience it
```
you >  /spec-init payments-gateway
       spec initialised. 4 intake folders ready.
       Drop your documents in, then run /spec-ingest.

       [you copy payments-gateway-sad.md into src\existing-sad\]

you >  /spec-ingest
       registered 1 source: 1 read, 0 not-read
       ...31 statements added, all tier A...
       built: 31 statements, 31 facts, 0 conflicts, 3 views
       Nothing weak, no conflicts. Next: /spec-check

you >  /spec-check
       18 findings: 2 violations, 16 gaps.
       WORST: migration.r_type = Replatform is not permitted for tier 1.
       Constitution says: "<the actual sentence>"

you >  it should be Rearchitect
       [adds the new statement, rejects the old one - asks for your name and rationale]
       18 findings -> 1

you >  /spec-check
       1 finding: business case needs 2 of 3 grounds, 0 stated. EXIT 2

you >  cost saving is 22%, and VMSS can't scale fast enough at market close
       [adds 2 business_case statements with your words as the quote]
       0 findings. EXIT 0

you >  /spec-review
       31 statements, triage order, one at a time...
       31 approved by n.nihal

       [you run the generator]
       HARD STOP: no CPF module mapping for cpf-azure-prdsvcpat-aks-private
```

**Seven things you typed.** Two of them plain English. The rest was the system telling you
what it needed next, and refusing to move until it had it.

### The one idea underneath all of it

Every single mechanism above is a defence against **the same failure**:

> Something fills in a blank, quietly, and nobody notices.

| The blank | What would have filled it | What happens instead |
|---|---|---|
| Unreadable document | an empty spec that looks complete | refuses, says why |
| No evidence recorded | trust me | quote + location required |
| Self-declared confidence | "high", always | derived from method |
| Two contradicting values | whichever was seen first | blocks, asks a human |
| No compliance check | silence that looks like a pass | `-RequireStandards` refuses |
| Facts nobody stated | nothing — never asked | rules chain forward and demand them |
| Unevidenced business case | "it's obviously better" | 2-of-3 required, or an expiring exception |
| No approver named | "the system approved it" | `-Actor` mandatory |
| Edited document | stale approval, still green | fingerprint revokes it |
| Unmapped module | something similar | hard stop, names the statement |

Every one of those defaults is *reasonable*. Every one produces Terraform that deploys
cleanly. And every one is a decision that **nobody knew was being made**.

The system's actual job isn't generating Terraform. It's making sure that by the time
Terraform exists, **every decision in it was made deliberately, by someone whose name is
recorded, based on evidence you can go and read.**

---

## What it still can't do

Being straight about this is more useful than a longer list of features.

- **If the model misreads a fact, nothing automatic catches it.** Read "15 minutes" as
  `15h` and the system happily proceeds. That's what the quote and the human reviewer are
  for — and it's a real limitation, not a theoretical one.
- **It doesn't judge whether your business case is any good.** It checks two of three
  grounds are *stated*. Whether 22% justifies a rearchitect is a human call.
- **It can't tell you a rule is wrong.** It catches the rulebook contradicting itself, but
  not a rule that's simply bad policy.
- **It doesn't run Terraform.** It generates and traces. It doesn't plan or apply.
- **It's not a security control.** The fingerprints detect *change*, not *tampering*.
  Anyone who can write to the output folder can write whatever they like. Protect it with
  source control and permissions.
