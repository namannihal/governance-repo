# Spec Layer — in three parts

`lmp-spec-agent` 0.1.1 · Windows PowerShell 5.1, no modules
Worked example throughout: **Payments Gateway**, tier 1, one 4-page SAD.

---

# 1. What we're solving

You have a document. You want Terraform. The risk isn't that the AI writes nonsense — it's
this:

> **A blank gets filled quietly, and the result looks exactly like a decision.**

The SAD says nothing about rollback. A generator emits Terraform with a reasonable default.
It plans, it applies, it passes review — because it looks exactly like Terraform is supposed
to look. The wrongness is only visible to someone who already knew what was intended, and
that person isn't in the review.

Three properties make this worth engineering against:

| | |
|---|---|
| **Silent** | no error, no warning |
| **Plausible** | survives code review |
| **Compounding** | the default becomes the documented state, and the next decision builds on it |

**So the goal isn't "generate infrastructure faster."** It's: *by the time Terraform exists,
every value in it was stated by a document, checked against LSEG standards, and approved by a
named person — or the pipeline refused.*

Everything below is that sentence, implemented.

---

# 2. How we do it — the commands

## The flow

```
/spec-init      →  empty store + 4 intake folders
   [you drop payments-gateway-sad.md into src\existing-sad\]
/spec-ingest    →  reads it, files 31 facts, each with a quote
/spec-check     →  74 LSEG rules  →  18 findings
   [you fix the design; you make the business case]
/spec-review    →  you approve all 31, by name
resolve         →  the gate. exit 0 + plan_hash
generator       →  Terraform, or a hard stop
```

## What each command writes

| Command | Does | Writes |
|---|---|---|
| `init` | create the store, create intake folders | `out\` skeleton, empty `statements.json` |
| `register-sources` | hash every file, ask the extractor if it's genuinely readable | `sources\source-register.json` |
| `add-statement` | file one fact + its evidence | one row in `statements.json` |
| `build` | dedupe, project views, detect conflicts | `specifications\*.json`, `conflicts\`, `review\*.md` |
| `review` | record a human decision | updates the row, appends `decisions\decision-log.jsonl` |
| **`resolve`** | **the gate** | nothing — prints the payload, or refuses |
| `verify` | re-check approvals against current documents | revokes any whose evidence moved |

## The two commands that matter

**`add-statement`** — the unit of work. One fact, four parts:

```powershell
Spec.ps1 -Command add-statement -FactKey nfr.rto -Value 15m `
  -SourceId src-210548f2 -Locator "section 4.2" `
  -Quote "restored within fifteen minutes" -Method explicit-statement
```

The `-Quote` is the document's own words. The `-Method` sets the grade (A–E) — **there is no
`-Tier` parameter**, because anything that can name its own confidence names it too high.

**`resolve`** — the door. Nothing downstream reads the store directly. Two independent locks:

```
standards clean?  ──no──> exit 3  "These cannot be cleared by approval."
        │yes
every fact approved? ──no──> exit 3  (names each blocker)
        │yes
   payload + plan_hash
```

## Exit codes

| | |
|---|---|
| **0** | success |
| **2** | *couldn't assess* — nothing readable, no statements, unmapped value |
| **3** | *assessed and refused* — not approved, or a standards violation |
| 4 / 5 | setup fault / already exists |

**2 vs 3 is the important split.** "I checked and the answer is no" vs "I could not check."
Collapse them and a check that never ran looks like a check that passed.

---

# 3. Who does what — and what it produces

## The one place the LLM acts

```
                    ┌─────────── LLM (Copilot) ───────────┐
messy prose  ──────>│ propose (fact_key, value, evidence) │──────> everything
                    └─────────────────────────────────────┘        after this
                                                                   is PowerShell
```

Reading *"restored within fifteen minutes"* and producing `nfr.rto = 15m` needs real
intelligence. **That is the model's entire job.** It does not decide grades, contradictions,
compliance, approval, or whether the gate opens.

**Why compliance especially stays out of the model:** a verdict must be identical every run,
must be checkable, and must not come from the same session that just wrote the design. A model
grading its own migration plan is marking its own homework.

## LLM vs static, step by step

| Step | Who | Produces |
|---|---|---|
| read documents | **LLM** | proposed facts |
| readability check | static | `source-register.json` — read / not-read + reason |
| grade A–E | static | `tier` on each statement |
| detect contradictions | static | `conflicts\unresolved-conflicts.json` |
| **check LSEG rules** | **static** | `compliance\violations.json` + `compliance\report.md` |
| find missing required facts | **LLM**, given the list | more statements |
| approve | **human**, named | `decision-log.jsonl` |
| the gate | static | payload + `plan_hash`, or refusal |

Note row 6. When the checker reports 16 gaps, the LLM goes hunting for **those specific
facts**. The prompt states the split outright:

> *"the checker decides what to look for, the model only finds it"*

A model told "find anything missing" exercises judgement. A model handed a list of 16 named
facts performs a search — and a search you can check.

## Instructions are not controls

The package tells the model *"never approve anything."* It also **cannot**: there is no code
path that approves without `-Actor`, and no `-SkipReview` flag.

Test any claimed safeguard by assuming the model is adversarial:

| Told to the model | Actually enforced? |
|---|---|
| approve nothing | ✅ `-Actor` mandatory |
| don't set the tier | ✅ no `-Tier` parameter exists |
| don't invent facts | ✅ an unstated fact simply has no row |
| quote, don't paraphrase | ❌ **guidance only — known gap** |

## How LSEG standards get in

Not summarised. **Encoded** — 74 rules, each carrying the constitution's own sentence:

```json
{
  "id": "LMP-RT-CONTAINER-2",
  "quote": "<verbatim sentence from LMP Constitution v1.6.0>",
  "when":  { "migration.r_type": "Rearchitect" },
  "requires_n_of": { "n": 2, "facts": ["business_case.cost_reduction_pct",
                                       "business_case.reliability_gain",
                                       "business_case.scalability_need"] }
}
```

The `quote` is why an architect can't argue with the tool — only with the policy.

**The rules join to your spec through `fact_key`.** That shared vocabulary is the entire
coupling: rules are written against `migration.r_type`, statements are filed under
`migration.r_type`.

**And rules chain.** The SAD said `app.tier = 1` and never mentioned cutover. Tier 1 implies
CDC cutover, which implies a rollback plan, which implies a trigger. The engine applies rules
until nothing new appears and reported **6 facts the constitution requires that nobody wrote
down** — under the heading *"facts the constitution implies but nobody stated."*

That's the part a checker that only tests what's written would never find.

## The static checks, and the files they leave behind

| File | Written by | Contains |
|---|---|---|
| `sources\source-register.json` | `register-sources` | every file, its SHA-256, read / not-read **and why** |
| `statements.json` | `add-statement` | the master record — append-only, nothing ever deleted |
| `specifications\system-spec.json` | `build` | one agreed answer per `fact_key` |
| `specifications\devops-spec.json` *(+2)* | `build` | per-team review scopes |
| `conflicts\unresolved-conflicts.json` | `build` | facts with two competing values |
| `review\review-summary.md` | `build` | **for humans** — counts, weak facts, unreadable sources |
| **`compliance\violations.json`** | `check` | **the findings `resolve` reads before it will open** |
| `compliance\report.md` | `check` | findings + derived facts, in the constitution's words |
| `decisions\decision-log.jsonl` | `review` | every approval: who, when, why — append-only |

Two things to know about these:

- **Everything under `out\` is regenerated on every `build`.** Edit it and your edit is gone.
  The only way to change anything is a command.
- **`violations.json` is the join between the two halves.** `Check-Standards.ps1` writes it;
  `Spec.ps1 resolve` reads it and refuses. Delete the rule pack and the spec layer still
  works — it just records `standards_checked = false` so nobody mistakes silence for a pass.

## What it can't do

- **If the model misreads a fact, nothing automatic catches it.** *"fifteen minutes"* read as
  `15h` sails through. The quote and the human reviewer are the only defence. We're strong
  against *omission*, weak against *mistranscription*.
- **It doesn't judge whether a business case is good** — only that the required grounds are
  stated.
- **It isn't a security control.** Hashes detect change, not tampering.

---

**More detail:** `TECHNICAL-REVIEW` content lives in `DECISIONS.md` (why each choice),
`WALKTHROUGH.md` (the 12-step live run), `INTEGRATION.md` (consumer contract).
