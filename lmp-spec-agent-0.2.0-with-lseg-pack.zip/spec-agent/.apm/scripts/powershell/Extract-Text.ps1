<#
.SYNOPSIS
    Convert intake documents into Markdown the agent can actually read.

.DESCRIPTION
    A .docx is a ZIP of XML; a .xlsx is the same. Reading one directly returns binary,
    so without this step every Word document under src\ is invisible to the normaliser
    even though the scan report cheerfully lists it.

    Mirrors src\<folder>\... into <Out>\<folder>\....md. Knows nothing about adapters -
    it walks whatever folders exist under src\, so adding an intake source costs
    nothing here.

    Exit 2 = nothing extractable was found.

    PowerShell 5.1 compatible. No modules required. ASCII only on purpose: PS 5.1
    reads a BOM-less .ps1 as ANSI, so a stray non-ASCII character is a parse error.

.EXAMPLE
    .\Extract-Text.ps1 -Root .lmp-migrate\payments-api -Command extract
    .\Extract-Text.ps1 -Command file -Path .\design.docx
#>
[CmdletBinding()]
param(
    [string]$Root = '.',
    [ValidateSet('extract', 'file')][string]$Command = 'extract',
    [string]$Out,
    [string]$Path,
    [switch]$NoOcr,
    # For a PDF that genuinely requires a user password. Supplying your own password
    # is not the same as recovering one, which this does not do.
    [string]$Password
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:NoOcr = [bool]$NoOcr
$script:PdfUsedOcr = $false
$script:PdfPassword = $Password

$script:WNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$script:SsNs = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
$script:RNs = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
$script:PrNs = 'http://schemas.openxmlformats.org/package/2006/relationships'

# One member of a supplied ZIP may not exceed this once decompressed. A vendor
# export is untrusted input; without this a 1 MB file can expand to fill the disk.
$script:MaxMemberBytes = 64MB

$Tick = [char]96

$script:TextExt = @('.md', '.txt', '.json', '.xml', '.yaml', '.yml', '.log', '.ini', '.cfg')
$script:Extractable = $script:TextExt + @('.docx', '.xlsx', '.csv', '.tsv', '.drawio', '.pdf')

# Listed honestly rather than silently ignored: each one needs a human step first.
$script:NeedsManual = @{
    '.doc'  = 'legacy Word binary - save as .docx and re-run'
    '.xls'  = 'legacy Excel binary - save as .xlsx and re-run'
    '.ppt'  = 'legacy PowerPoint binary - save as .pptx and export the text'
    '.pptx' = 'slides - export the text to .docx or .md'
    '.vsd'  = 'Visio - export to PDF then text, or describe it in a .md'
    '.vsdx' = 'Visio - export to PDF then text, or describe it in a .md'
    '.msg'  = 'Outlook message - save the body as .txt'
    '.png'  = 'image - describe it in a .md alongside'
    '.jpg'  = 'image - describe it in a .md alongside'
    '.jpeg' = 'image - describe it in a .md alongside'
    '.gif'  = 'image - describe it in a .md alongside'
    '.bmp'  = 'image - describe it in a .md alongside'
    '.zip'  = 'archive - unpack it into the source folder'
    '.7z'   = 'archive - unpack it into the source folder'
    '.rar'  = 'archive - unpack it into the source folder'
}

$script:Ignored = @('.gitkeep', 'readme.md', '.ds_store', 'thumbs.db')

# Windows cloud-storage placeholder bits: OFFLINE, RECALL_ON_OPEN,
# RECALL_ON_DATA_ACCESS. A OneDrive/SharePoint file that was never downloaded has
# a real size on disk but no content.
$script:PlaceholderBits = 0x1000 -bor 0x40000 -bor 0x400000

function Test-FileProblem([string]$FilePath) {
    # Name the common reasons an Office file is unreadable. Without this, ZIP parsing
    # reports 'Central Directory corrupt' and hides which of them it actually was.
    # Attributes first: reading a placeholder throws before we learn anything.
    $item = Get-Item -LiteralPath $FilePath -Force
    if (([int]$item.Attributes -band $script:PlaceholderBits) -ne 0) {
        return "cloud placeholder - not downloaded to this machine. Right-click it, 'Always keep on this device' (or just open it once), then re-run."
    }
    $buf = New-Object byte[] 8
    try {
        $fs = [System.IO.File]::OpenRead($FilePath)
        try { $n = $fs.Read($buf, 0, 8) } finally { $fs.Dispose() }
    }
    catch { return ('cannot be read from disk - ' + $_.Exception.Message.Trim()) }
    if ($n -lt 8) { return 'file is too small to be a .docx/.xlsx' }
    $ole = @(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1)
    $isOle = $true
    for ($i = 0; $i -lt 8; $i++) { if ($buf[$i] -ne $ole[$i]) { $isOle = $false; break } }
    if ($isOle) {
        return 'legacy Office binary inside a modern extension - open it and use Save As to write a real .docx/.xlsx, then re-run'
    }
    if ($buf[0] -ne 0x50 -or $buf[1] -ne 0x4B) {
        return 'not a ZIP archive - this is not a real .docx/.xlsx'
    }
    return $null
}

function Get-Stamp { (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }

function Format-Cell([string]$Text) {
    if ($null -eq $Text) { return '' }
    $Text.Replace('|', '\|').Replace("`n", ' ').Replace("`r", ' ').Trim()
}

function Compress-Blanks($Lines) {
    $out = New-Object System.Collections.ArrayList
    foreach ($line in $Lines) {
        $s = if ($null -eq $line) { '' } else { [string]$line }
        if (-not $s.Trim()) {
            if ($out.Count -gt 0 -and -not ([string]$out[$out.Count - 1]).Trim()) { continue }
            [void]$out.Add('')
        }
        else { [void]$out.Add($s.TrimEnd()) }
    }
    while ($out.Count -gt 0 -and -not ([string]$out[0]).Trim()) { $out.RemoveAt(0) }
    while ($out.Count -gt 0 -and -not ([string]$out[$out.Count - 1]).Trim()) { $out.RemoveAt($out.Count - 1) }
    $out.ToArray()
}

function Convert-RowsToMarkdown($Rows) {
    $keep = @()
    foreach ($r in $Rows) {
        $has = $false
        foreach ($c in $r) { if ($c -and ([string]$c).Trim()) { $has = $true; break } }
        if ($has) { $keep += , @($r) }
    }
    if ($keep.Count -eq 0) { return @() }
    $width = 0
    foreach ($r in $keep) { if ($r.Count -gt $width) { $width = $r.Count } }
    $out = @()
    $sep = @()
    for ($i = 0; $i -lt $width; $i++) { $sep += ' --- ' }
    for ($i = 0; $i -lt $keep.Count; $i++) {
        $a = @($keep[$i])
        while ($a.Count -lt $width) { $a += '' }
        $out += ('| ' + ($a -join ' | ') + ' |')
        if ($i -eq 0) { $out += ('|' + ($sep -join '|') + '|') }
    }
    $out
}

function Read-ZipEntry($Zip, [string]$Name) {
    $entry = $Zip.GetEntry($Name)
    if ($null -eq $entry) { return $null }
    if ($entry.Length -gt $script:MaxMemberBytes) {
        throw ("$Name expands to $($entry.Length) bytes; limit is $($script:MaxMemberBytes)")
    }
    $stream = $entry.Open()
    try {
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
    }
    finally { $stream.Dispose() }
}

function ConvertTo-SafeXml([string]$Xml) {
    # XmlResolver = $null blocks external entity resolution (XXE); intake documents
    # are untrusted third-party exports.
    $doc = New-Object System.Xml.XmlDocument
    $doc.XmlResolver = $null
    $doc.LoadXml($Xml)
    $doc
}

function New-NsManager($Doc, [hashtable]$Map) {
    $ns = New-Object System.Xml.XmlNamespaceManager($Doc.NameTable)
    foreach ($k in $Map.Keys) { $ns.AddNamespace($k, $Map[$k]) }
    # XmlNamespaceManager is IEnumerable, so a bare `$ns` returns its prefixes as an
    # array instead of the manager itself.
    Write-Output -NoEnumerate $ns
}

# --------------------------------------------------------------- .docx

function Get-ParaText($Node) {
    # w:instrText and w:delText are absent by omission - field codes and tracked
    # deletions are not document content.
    $sb = New-Object System.Text.StringBuilder
    foreach ($n in $Node.SelectNodes('.//w:t | .//w:tab | .//w:br | .//w:cr', $script:Ns)) {
        switch ($n.LocalName) {
            't' { [void]$sb.Append($n.InnerText) }
            'tab' { [void]$sb.Append("`t") }
            default { [void]$sb.Append("`n") }
        }
    }
    $sb.ToString()
}

function Get-ParaStyle($P) {
    $st = $P.SelectSingleNode('w:pPr/w:pStyle', $script:Ns)
    if ($null -eq $st) { return '' }
    $st.GetAttribute('val', $script:WNs)
}

function Get-HeadingLevel([string]$Style) {
    # Word's Heading1 sits under the document Title, so it maps to '##'.
    $s = ($Style -replace '\s', '').ToLowerInvariant()
    if ($s -eq 'title') { return 1 }
    if ($s -eq 'subtitle') { return 2 }
    if ($s -match '^heading(\d)$') { return [Math]::Min([int]$Matches[1] + 1, 6) }
    return 0
}

function Get-ListLevel($P) {
    $num = $P.SelectSingleNode('w:pPr/w:numPr', $script:Ns)
    if ($null -eq $num) { return -1 }
    $ilvl = $num.SelectSingleNode('w:ilvl', $script:Ns)
    if ($null -eq $ilvl) { return 0 }
    $n = 0
    if ([int]::TryParse($ilvl.GetAttribute('val', $script:WNs), [ref]$n)) {
        return [Math]::Max(0, [Math]::Min($n, 6))
    }
    return 0
}

function Convert-WordTable($Tbl) {
    $rows = @()
    foreach ($tr in $Tbl.SelectNodes('w:tr', $script:Ns)) {
        $cells = @()
        foreach ($tc in $tr.SelectNodes('w:tc', $script:Ns)) {
            $parts = @()
            foreach ($p in $tc.SelectNodes('w:p', $script:Ns)) {
                $t = (Get-ParaText $p).Trim()
                if ($t) { $parts += $t }
            }
            $cells += (Format-Cell ($parts -join ' '))
        }
        if ($cells.Count -gt 0) { $rows += , $cells }
    }
    Convert-RowsToMarkdown $rows
}

function Get-BodyChild($Node) {
    # Flatten content controls; a title page is often wrapped in w:sdt.
    $out = @()
    foreach ($child in $Node.ChildNodes) {
        if ($child.LocalName -eq 'sdt') {
            $content = $child.SelectSingleNode('w:sdtContent', $script:Ns)
            if ($null -ne $content) { $out += @(Get-BodyChild $content) }
        }
        else { $out += $child }
    }
    $out
}

function Convert-DocxToMarkdown([string]$FilePath) {
    $problem = Test-FileProblem $FilePath
    if ($problem) { throw $problem }
    $zip = [System.IO.Compression.ZipFile]::OpenRead($FilePath)
    try { $raw = Read-ZipEntry $zip 'word/document.xml' } finally { $zip.Dispose() }
    if ($null -eq $raw) { throw 'no word/document.xml - not a Word file' }

    $doc = ConvertTo-SafeXml $raw
    $script:Ns = New-NsManager $doc @{ 'w' = $script:WNs }
    $body = $doc.DocumentElement.SelectSingleNode('w:body', $script:Ns)
    if ($null -eq $body) { return @() }

    $lines = @()
    foreach ($child in @(Get-BodyChild $body)) {
        if ($child.LocalName -eq 'p') {
            $text = (Get-ParaText $child).Replace("`t", '  ').Trim()
            if (-not $text) { continue }
            $level = Get-HeadingLevel (Get-ParaStyle $child)
            $lvl = Get-ListLevel $child
            if ($level -gt 0) { $lines += @('', ('#' * $level + ' ' + $text), '') }
            elseif ($lvl -ge 0) { $lines += (('  ' * $lvl) + '- ' + $text) }
            else { $lines += @($text, '') }
        }
        elseif ($child.LocalName -eq 'tbl') {
            $table = @(Convert-WordTable $child)
            if ($table.Count -gt 0) { $lines += @('') + $table + @('') }
        }
    }
    Compress-Blanks $lines
}

# --------------------------------------------------------------- .xlsx

function Get-ColumnIndex([string]$Ref) {
    if ($Ref -notmatch '^([A-Za-z]+)(\d+)$') { return -1 }
    $n = 0
    foreach ($ch in $Matches[1].ToUpperInvariant().ToCharArray()) {
        $n = $n * 26 + ([int][char]$ch - 64)
    }
    $n - 1
}

function Convert-XlsxToMarkdown([string]$FilePath) {
    $problem = Test-FileProblem $FilePath
    if ($problem) { throw $problem }
    $zip = [System.IO.Compression.ZipFile]::OpenRead($FilePath)
    try {
        $sstRaw = Read-ZipEntry $zip 'xl/sharedStrings.xml'
        $wbRaw = Read-ZipEntry $zip 'xl/workbook.xml'
        $relRaw = Read-ZipEntry $zip 'xl/_rels/workbook.xml.rels'
        if ($null -eq $wbRaw -or $null -eq $relRaw) { throw 'no workbook - not an Excel file' }

        $shared = @()
        if ($null -ne $sstRaw) {
            $sst = ConvertTo-SafeXml $sstRaw
            $sns = New-NsManager $sst @{ 'x' = $script:SsNs }
            foreach ($si in $sst.DocumentElement.SelectNodes('x:si', $sns)) {
                $sb = New-Object System.Text.StringBuilder
                foreach ($t in $si.SelectNodes('.//x:t', $sns)) { [void]$sb.Append($t.InnerText) }
                $shared += $sb.ToString()
            }
        }

        $rels = ConvertTo-SafeXml $relRaw
        $rns = New-NsManager $rels @{ 'p' = $script:PrNs }
        $rid = @{}
        foreach ($rel in $rels.DocumentElement.SelectNodes('p:Relationship', $rns)) {
            $target = $rel.GetAttribute('Target').Replace('\', '/')
            if ($target.StartsWith('/')) { $target = $target.Substring(1) }
            elseif (-not $target.StartsWith('xl/')) { $target = 'xl/' + $target }
            $rid[$rel.GetAttribute('Id')] = $target
        }

        $wb = ConvertTo-SafeXml $wbRaw
        $wns = New-NsManager $wb @{ 'x' = $script:SsNs; 'r' = $script:RNs }
        $sheets = @()
        foreach ($sh in $wb.DocumentElement.SelectNodes('x:sheets/x:sheet', $wns)) {
            $member = $rid[$sh.GetAttribute('id', $script:RNs)]
            if ($member) {
                $name = $sh.GetAttribute('name')
                if (-not $name) { $name = 'sheet' }
                $sheets += , @($name, $member)
            }
        }
        if ($sheets.Count -eq 0) { throw 'no sheets found - not an Excel file' }

        $lines = @()
        foreach ($pair in $sheets) {
            $raw = Read-ZipEntry $zip $pair[1]
            $rows = @()
            if ($null -ne $raw) {
                $ws = ConvertTo-SafeXml $raw
                $xns = New-NsManager $ws @{ 'x' = $script:SsNs }
                foreach ($row in $ws.DocumentElement.SelectNodes('x:sheetData/x:row', $xns)) {
                    $cells = @{}
                    $i = 0
                    foreach ($c in $row.SelectNodes('x:c', $xns)) {
                        $idx = Get-ColumnIndex $c.GetAttribute('r')
                        if ($idx -lt 0) { $idx = $i }
                        $t = $c.GetAttribute('t')
                        $val = ''
                        if ($t -eq 'inlineStr') {
                            foreach ($n in $c.SelectNodes('x:is//x:t', $xns)) { $val += $n.InnerText }
                        }
                        else {
                            $v = $c.SelectSingleNode('x:v', $xns)
                            if ($null -ne $v) { $val = $v.InnerText }
                            if ($t -eq 's') {
                                $si = 0
                                if ([int]::TryParse($val, [ref]$si) -and $si -ge 0 -and $si -lt $shared.Count) {
                                    $val = $shared[$si]
                                }
                                else { $val = '' }
                            }
                        }
                        $cells[$idx] = Format-Cell $val
                        $i++
                    }
                    if ($cells.Count -gt 0) {
                        $max = ($cells.Keys | Measure-Object -Maximum).Maximum
                        $arr = @()
                        for ($k = 0; $k -le $max; $k++) {
                            $arr += $(if ($cells.ContainsKey($k)) { $cells[$k] } else { '' })
                        }
                        $rows += , $arr
                    }
                    else { $rows += , @() }
                }
            }
            $table = @(Convert-RowsToMarkdown $rows)
            $lines += @('', ('## Sheet: ' + $pair[0]), '')
            $lines += $(if ($table.Count -gt 0) { $table } else { @('_empty sheet_') })
        }
        Compress-Blanks $lines
    }
    finally { $zip.Dispose() }
}

# --------------------------------------------------------------- .drawio

function Convert-DrawioLabel([string]$Text) {
    if (-not $Text) { return '' }
    $t = [regex]::Replace($Text, '<br\s*/?>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<[^>]+>', '')
    [System.Net.WebUtility]::HtmlDecode($t).Replace("`n", ' ').Trim()
}

function Get-DrawioModel($Dia) {
    # A page is either inline <mxGraphModel> or draw.io's base64 + raw-deflate form.
    $model = $Dia.SelectSingleNode('mxGraphModel')
    if ($null -ne $model) { return $model }
    $payload = $Dia.InnerText.Trim()
    if (-not $payload) { return $null }
    try { $raw = [System.Convert]::FromBase64String($payload) } catch { return $null }
    foreach ($skip in @(0, 2)) {
        try {
            $bytes = if ($skip -eq 0) { $raw } else { [byte[]]($raw[$skip..($raw.Length - 1)]) }
            $ms = New-Object System.IO.MemoryStream(, $bytes)
            $ds = New-Object System.IO.Compression.DeflateStream($ms, [System.IO.Compression.CompressionMode]::Decompress)
            $sr = New-Object System.IO.StreamReader($ds, [System.Text.Encoding]::UTF8)
            try { $xml = $sr.ReadToEnd() } finally { $sr.Dispose() }
            return (ConvertTo-SafeXml ([System.Uri]::UnescapeDataString($xml))).DocumentElement
        }
        catch { continue }
    }
    return $null
}

function Get-DrawioCells($Model) {
    $nodes = New-Object System.Collections.Specialized.OrderedDictionary
    $edges = @()
    foreach ($el in $Model.SelectNodes('.//object | .//mxCell')) {
        if ($el.LocalName -eq 'object') {
            $cell = $el.SelectSingleNode('mxCell')
            $cid = $el.GetAttribute('id')
            $label = Convert-DrawioLabel $el.GetAttribute('label')
        }
        else {
            # An mxCell wrapped in <object> carries no id; it is handled above.
            $cell = $el
            $cid = $el.GetAttribute('id')
            $label = Convert-DrawioLabel $el.GetAttribute('value')
        }
        if ($null -eq $cell -or -not $cid -or $nodes.Contains($cid)) { continue }
        if ($cell.GetAttribute('edge') -eq '1') {
            $edges += , @($cell.GetAttribute('source'), $cell.GetAttribute('target'), $label)
        }
        elseif ($cell.GetAttribute('vertex') -eq '1') {
            $nodes[$cid] = $label
        }
    }
    @{ nodes = $nodes; edges = $edges }
}

function Convert-DrawioToMarkdown([string]$FilePath) {
    $doc = ConvertTo-SafeXml (Read-TextFile $FilePath)
    $root = $doc.DocumentElement
    $pages = @()
    if ($root.LocalName -eq 'mxfile') {
        $i = 0
        foreach ($d in $root.SelectNodes('diagram')) {
            $i++
            $name = $d.GetAttribute('name')
            if (-not $name) { $name = "Page-$i" }
            $pages += , @($name, (Get-DrawioModel $d))
        }
    }
    elseif ($root.LocalName -eq 'mxGraphModel') { $pages += , @('Page-1', $root) }
    else { throw ("not a draw.io file (root element is <" + $root.LocalName + ">)") }
    if ($pages.Count -eq 0) { throw 'no diagram pages found' }

    $lines = @(
        '> Deterministic graph extraction. Shapes, labels and connections are read from',
        '> the file. Protocol, data-flow direction and component roles are **not** inferred',
        '> here -- a connection means the diagram joins two shapes, nothing more.'
    )
    foreach ($page in $pages) {
        $lines += @('', ('## Page: ' + $page[0]), '')
        $model = $page[1]
        if ($null -eq $model) { $lines += '_Page content could not be decoded._'; continue }

        $g = Get-DrawioCells $model
        $nodes = $g.nodes
        $labelled = @($nodes.Keys | Where-Object { $nodes[$_] })
        $lines += @(('### Shapes ({0} labelled, {1} unlabelled)' -f $labelled.Count, ($nodes.Count - $labelled.Count)), '')
        if ($labelled.Count -gt 0) {
            $rows = @(, @('id', 'label'))
            foreach ($k in ($labelled | Sort-Object)) { $rows += , @($k, (Format-Cell $nodes[$k])) }
            $lines += @(Convert-RowsToMarkdown $rows)
        }
        else { $lines += '_No labelled shapes._' }

        $dangling = 0
        $erows = @(, @('from', 'to', 'label'))
        foreach ($e in $g.edges) {
            $a = if ($nodes.Contains($e[0])) { $nodes[$e[0]] } else { $null }
            $b = if ($nodes.Contains($e[1])) { $nodes[$e[1]] } else { $null }
            if ($null -eq $a -or $null -eq $b) { $dangling++ }
            $erows += , @((Format-Cell $(if ($null -ne $a) { $a } else { '(unconnected)' })),
                (Format-Cell $(if ($null -ne $b) { $b } else { '(unconnected)' })),
                (Format-Cell $e[2]))
        }
        $lines += @('', ('### Connections ({0})' -f $g.edges.Count), '')
        if ($g.edges.Count -gt 0) { $lines += @(Convert-RowsToMarkdown $erows) }
        else { $lines += '_No connections._' }
        if ($dangling -gt 0) {
            $lines += @('', ('**{0} connection(s) have a loose end** in the source diagram.' -f $dangling))
        }
    }
    Compress-Blanks $lines
}

# --------------------------------------------------------------- .pdf encryption

# Most "encrypted" business PDFs carry an OWNER password only: the user password is
# empty, the file opens in any viewer without a prompt, and the encryption exists to
# restrict copying and printing. The standard empty-password key derivation below is
# what every reader does to open them.
#
# A PDF that genuinely requires a user password is NOT opened here. Recovering that
# would be password cracking, which is out of scope; such a file is refused.

$script:PdfPad = [byte[]](0x28, 0xBF, 0x4E, 0x5E, 0x4E, 0x75, 0x8A, 0x41, 0x64, 0x00, 0x4E, 0x56,
    0xFF, 0xFA, 0x01, 0x08, 0x2E, 0x2E, 0x00, 0xB6, 0xD0, 0x68, 0x3E, 0x80,
    0x2F, 0x0C, 0xA9, 0xFE, 0x64, 0x53, 0x69, 0x7A)

function ConvertFrom-PdfHex([string]$Hex) {
    $h = ($Hex -replace '[^0-9A-Fa-f]', '')
    if ($h.Length % 2 -eq 1) { $h += '0' }
    $out = New-Object byte[] ($h.Length / 2)
    for ($i = 0; $i -lt $out.Length; $i++) { $out[$i] = [Convert]::ToByte($h.Substring($i * 2, 2), 16) }
    $out
}

# /O and /U are byte strings: either ( ... ) with escapes, or < hex >.
function Get-PdfDictBytes([string]$Dict, [string]$Name) {
    $m = [regex]::Match($Dict, [regex]::Escape($Name) + '\s*(?:\((?<lit>(?>(?:\\.|[^\\()])*))\)|<(?<hex>[0-9A-Fa-f\s]+)>)')
    if (-not $m.Success) { return $null }
    if ($m.Groups['hex'].Success) { return (ConvertFrom-PdfHex $m.Groups['hex'].Value) }
    $s = ConvertFrom-PdfString $m.Groups['lit'].Value
    $b = New-Object byte[] $s.Length
    for ($i = 0; $i -lt $s.Length; $i++) { $b[$i] = [byte]([int][char]$s[$i] -band 0xFF) }
    $b
}

function Invoke-Rc4([byte[]]$Key, [byte[]]$Data) {
    $s = New-Object byte[] 256
    for ($i = 0; $i -lt 256; $i++) { $s[$i] = [byte]$i }
    $j = 0
    for ($i = 0; $i -lt 256; $i++) {
        $j = ($j + $s[$i] + $Key[$i % $Key.Length]) -band 0xFF
        $t = $s[$i]; $s[$i] = $s[$j]; $s[$j] = $t
    }
    $out = New-Object byte[] $Data.Length
    $i = 0; $j = 0
    for ($k = 0; $k -lt $Data.Length; $k++) {
        $i = ($i + 1) -band 0xFF
        $j = ($j + $s[$i]) -band 0xFF
        $t = $s[$i]; $s[$i] = $s[$j]; $s[$j] = $t
        $out[$k] = $Data[$k] -bxor $s[($s[$i] + $s[$j]) -band 0xFF]
    }
    $out
}

# Algorithm 2 step 1: the password is padded to 32 bytes with a fixed string. An
# empty password is therefore just the pad, which is why the same code opens both
# owner-restricted files and ones the user has the password for.
function Get-PdfPaddedPassword([string]$Password) {
    $out = New-Object byte[] 32
    $n = 0
    if ($Password) {
        $pw = [System.Text.Encoding]::GetEncoding(28591).GetBytes($Password)
        $n = [Math]::Min(32, $pw.Length)
        [Array]::Copy($pw, 0, $out, 0, $n)
    }
    if ($n -lt 32) { [Array]::Copy($script:PdfPad, 0, $out, $n, 32 - $n) }
    $out
}

function Get-PdfFileKey($Info) {
    # PDF 32000-1 Algorithm 2, with the empty user password.
    $md5 = [System.Security.Cryptography.MD5]::Create()
    try {
        $buf = New-Object System.IO.MemoryStream
        $padded = Get-PdfPaddedPassword $script:PdfPassword
        $buf.Write($padded, 0, 32)
        $buf.Write($Info.O, 0, [Math]::Min(32, $Info.O.Length))
        $p = [BitConverter]::GetBytes([int]$Info.P)          # little-endian, signed
        $buf.Write($p, 0, 4)
        if ($Info.ID) { $buf.Write($Info.ID, 0, $Info.ID.Length) }
        if ($Info.R -ge 4 -and -not $Info.EncryptMetadata) {
            $ff = [byte[]](0xFF, 0xFF, 0xFF, 0xFF); $buf.Write($ff, 0, 4)
        }
        $key = $md5.ComputeHash($buf.ToArray())
        $n = [Math]::Max(5, [int]($Info.LengthBits / 8))
        if ($Info.R -ge 3) {
            for ($i = 0; $i -lt 50; $i++) {
                $slice = New-Object byte[] $n
                [Array]::Copy($key, 0, $slice, 0, $n)
                $key = $md5.ComputeHash($slice)
            }
        }
        $final = New-Object byte[] $n
        [Array]::Copy($key, 0, $final, 0, $n)
        $final
    }
    finally { $md5.Dispose() }
}

function Get-PdfObjectKey($FileKey, [int]$ObjNum, [int]$Gen, [bool]$IsAes) {
    $md5 = [System.Security.Cryptography.MD5]::Create()
    try {
        $ms = New-Object System.IO.MemoryStream
        $ms.Write($FileKey, 0, $FileKey.Length)
        $ms.WriteByte([byte]($ObjNum -band 0xFF))
        $ms.WriteByte([byte](($ObjNum -shr 8) -band 0xFF))
        $ms.WriteByte([byte](($ObjNum -shr 16) -band 0xFF))
        $ms.WriteByte([byte]($Gen -band 0xFF))
        $ms.WriteByte([byte](($Gen -shr 8) -band 0xFF))
        if ($IsAes) { $salt = [byte[]](0x73, 0x41, 0x6C, 0x54); $ms.Write($salt, 0, 4) }
        $h = $md5.ComputeHash($ms.ToArray())
        $n = [Math]::Min($FileKey.Length + 5, 16)
        $out = New-Object byte[] $n
        [Array]::Copy($h, 0, $out, 0, $n)
        $out
    }
    finally { $md5.Dispose() }
}

function Invoke-PdfAesDecrypt([byte[]]$Key, [byte[]]$Data) {
    # First 16 bytes of the stream are the CBC initialisation vector.
    if ($Data.Length -le 16) { return $null }
    $aes = [System.Security.Cryptography.Aes]::Create()
    try {
        $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
        $aes.Padding = [System.Security.Cryptography.PaddingMode]::None
        $aes.KeySize = $Key.Length * 8
        $aes.Key = $Key
        $iv = New-Object byte[] 16
        [Array]::Copy($Data, 0, $iv, 0, 16)
        $aes.IV = $iv
        $body = New-Object byte[] ($Data.Length - 16 - (($Data.Length - 16) % 16))
        if ($body.Length -le 0) { return $null }
        [Array]::Copy($Data, 16, $body, 0, $body.Length)
        $dec = $aes.CreateDecryptor()
        try { $plain = $dec.TransformFinalBlock($body, 0, $body.Length) } finally { $dec.Dispose() }
        # Strip PKCS#7 padding when it is well formed.
        if ($plain.Length -gt 0) {
            $pad = $plain[$plain.Length - 1]
            if ($pad -ge 1 -and $pad -le 16 -and $pad -le $plain.Length) {
                $trimmed = New-Object byte[] ($plain.Length - $pad)
                [Array]::Copy($plain, 0, $trimmed, 0, $trimmed.Length)
                return $trimmed
            }
        }
        $plain
    }
    catch { $null }
    finally { $aes.Dispose() }
}

function Get-PdfEncryptionInfo([string]$All) {
    $j = [regex]::Match($All, '/Filter\s*/Standard')
    if (-not $j.Success) { return $null }
    # Anchor on the enclosing object, not the nearest '<<': the encryption dictionary
    # nests a /CF sub-dictionary, so the nearest '<<' lands inside it and /O is missed.
    $start = $All.LastIndexOf(' obj', $j.Index)
    if ($start -lt 0) { $start = [Math]::Max(0, $j.Index - 2000) }
    $end = $All.IndexOf('endobj', $j.Index)
    if ($end -lt 0 -or ($end - $start) -gt 8000) { $end = [Math]::Min($All.Length - 1, $j.Index + 2000) }
    $dict = $All.Substring($start, $end - $start)

    $O = Get-PdfDictBytes $dict '/O'
    $U = Get-PdfDictBytes $dict '/U'
    if ($null -eq $O) { return $null }

    $R = 2; $V = 1; $len = 40; $P = -1
    if ($dict -match '/R\s+(\d+)') { $R = [int]$Matches[1] }
    if ($dict -match '/V\s+(\d+)') { $V = [int]$Matches[1] }
    # The nested /CF dictionary also carries a /Length, in BYTES (16), while the
    # top-level one is in BITS (128). Taking the first match yields a 2-byte key.
    $lengths = @([regex]::Matches($dict, '/Length\s+(\d+)') | ForEach-Object { [int]$_.Groups[1].Value })
    $bits = @($lengths | Where-Object { $_ -ge 40 })
    if ($bits.Count -gt 0) { $len = ($bits | Measure-Object -Maximum).Maximum }
    elseif ($lengths.Count -gt 0) { $len = ($lengths | Measure-Object -Maximum).Maximum * 8 }
    if ($dict -match '/P\s+(-?\d+)') { $P = [int]$Matches[1] }
    $cfm = if ($dict -match '/CFM\s*/(\w+)') { $Matches[1] } else { 'V2' }
    $encMeta = -not ($dict -match '/EncryptMetadata\s+false')

    $id = $null
    $idm = [regex]::Match($All, '/ID\s*\[\s*<(?<a>[0-9A-Fa-f\s]+)>')
    if ($idm.Success) { $id = ConvertFrom-PdfHex $idm.Groups['a'].Value }

    [pscustomobject]@{
        O = $O; U = $U; P = $P; R = $R; V = $V; LengthBits = $len
        CFM = $cfm; EncryptMetadata = $encMeta; ID = $id
    }
}

# --------------------------------------------------------------- .pdf

# Latin-1 maps every byte to the char of the same value, so offsets found by
# searching the decoded string are valid indexes into the byte array. UTF8 would
# not round-trip arbitrary binary and the stream offsets would drift.
$script:PdfEnc = [System.Text.Encoding]::GetEncoding(28591)

# Below this many words per page, assume the text layer is incidental (a header or a
# stamp over a scan) and check whether OCR recovers more. A page of prose runs to
# several hundred; even a sparse title page clears this comfortably.
$script:SparseWordsPerPage = 25

function Expand-PdfStream([byte[]]$Bytes, [int]$Start, [int]$Length) {
    if ($Length -le 2) { return $null }
    # A zlib header (low nibble 8 = deflate) sits in front of the raw deflate data
    # that DeflateStream expects, so it is skipped when present.
    $skip = if (($Bytes[$Start] -band 0x0F) -eq 8) { 2 } else { 0 }
    $len = $Length - $skip
    if ($len -le 0) { return $null }
    $chunk = New-Object byte[] $len
    [Array]::Copy($Bytes, $Start + $skip, $chunk, 0, $len)
    try {
        $ms = New-Object System.IO.MemoryStream(, $chunk)
        $ds = New-Object System.IO.Compression.DeflateStream($ms, [System.IO.Compression.CompressionMode]::Decompress)
        $sr = New-Object System.IO.StreamReader($ds, $script:PdfEnc)
        try { $sr.ReadToEnd() } finally { $sr.Dispose() }
    }
    catch { $null }
}

function ConvertFrom-PdfString([string]$Raw) {
    $sb = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $Raw.Length; $i++) {
        $ch = $Raw[$i]
        if ($ch -ne '\') { [void]$sb.Append($ch); continue }
        $i++
        if ($i -ge $Raw.Length) { break }
        $n = $Raw[$i]
        switch -CaseSensitive ($n) {
            'n' { [void]$sb.Append("`n") }
            'r' { [void]$sb.Append("`n") }
            't' { [void]$sb.Append("`t") }
            'b' { }
            'f' { }
            '(' { [void]$sb.Append('(') }
            ')' { [void]$sb.Append(')') }
            '\' { [void]$sb.Append('\') }
            default {
                if ($n -ge '0' -and $n -le '7') {
                    $oct = [string]$n
                    while ($oct.Length -lt 3 -and ($i + 1) -lt $Raw.Length -and $Raw[$i + 1] -ge '0' -and $Raw[$i + 1] -le '7') {
                        $i++; $oct += $Raw[$i]
                    }
                    [void]$sb.Append([char][Convert]::ToInt32($oct, 8))
                }
                else { [void]$sb.Append($n) }
            }
        }
    }
    $sb.ToString()
}

function Get-PdfContentText([string]$Content) {
    # Only the text-showing operators are read, but the positioning operands have to
    # be honoured: many generators place every glyph with its own Td, so treating Td
    # as a line break shreds the text into one character per line. A vertical move
    # is a new line; a purely horizontal one is a space.
    #
    # Atomic groups (?>...) plus a match timeout are not optional here: the string
    # alternation backtracks catastrophically on a content stream with unbalanced
    # parens, and a real 400 KB PDF hung the extractor indefinitely without them.
    $opts = [System.Text.RegularExpressions.RegexOptions]::None
    $timeout = [TimeSpan]::FromSeconds(10)
    $pattern = '\((?<s>(?>(?:\\.|[^\\()])*))\)\s*Tj' +
        '|\[(?<a>(?>(?:\\.|[^\]])*))\]\s*TJ' +
        '|<(?<h>[0-9A-Fa-f\s]{2,})>\s*Tj' +
        '|(?<tx>-?[0-9.]+)\s+(?<ty>-?[0-9.]+)\s+(?:Td|TD)' +
        '|(?:-?[0-9.]+\s+){5}(?<my>-?[0-9.]+)\s+Tm' +
        '|(?<star>T\*)|(?<et>ET)'
    $re = New-Object System.Text.RegularExpressions.Regex($pattern, $opts, $timeout)
    $inner = New-Object System.Text.RegularExpressions.Regex('\((?<t>(?>(?:\\.|[^\\()])*))\)|(?<k>-?[0-9.]+)', $opts, $timeout)

    $out = New-Object System.Text.StringBuilder
    $lastY = [double]::NaN
    try { $matches = $re.Matches($Content) }
    catch [System.Text.RegularExpressions.RegexMatchTimeoutException] { return '' }

    foreach ($m in $matches) {
        if ($m.Groups['s'].Success) {
            [void]$out.Append((ConvertFrom-PdfString $m.Groups['s'].Value))
        }
        elseif ($m.Groups['a'].Success) {
            try { $parts = $inner.Matches($m.Groups['a'].Value) }
            catch [System.Text.RegularExpressions.RegexMatchTimeoutException] { continue }
            foreach ($sm in $parts) {
                if ($sm.Groups['t'].Success) {
                    [void]$out.Append((ConvertFrom-PdfString $sm.Groups['t'].Value))
                }
                else {
                    # A large negative kern is how most generators encode a space.
                    $kv = 0.0
                    if ([double]::TryParse($sm.Groups['k'].Value, [ref]$kv) -and $kv -le -100) {
                        [void]$out.Append(' ')
                    }
                }
            }
        }
        elseif ($m.Groups['h'].Success) {
            $hex = ($m.Groups['h'].Value -replace '\s', '')
            if ($hex.Length % 2 -eq 1) { $hex += '0' }
            for ($k = 0; $k -lt $hex.Length - 1; $k += 2) {
                $code = [Convert]::ToInt32($hex.Substring($k, 2), 16)
                if ($code -ge 32) { [void]$out.Append([char]$code) }
            }
        }
        elseif ($m.Groups['ty'].Success) {
            $ty = 0.0
            [void][double]::TryParse($m.Groups['ty'].Value, [ref]$ty)
            if ([Math]::Abs($ty) -gt 0.01) { [void]$out.Append("`n") } else { [void]$out.Append(' ') }
        }
        elseif ($m.Groups['my'].Success) {
            $y = 0.0
            [void][double]::TryParse($m.Groups['my'].Value, [ref]$y)
            if (-not [double]::IsNaN($lastY) -and [Math]::Abs($y - $lastY) -gt 0.01) { [void]$out.Append("`n") }
            $lastY = $y
        }
        elseif ($m.Groups['star'].Success -or $m.Groups['et'].Success) {
            [void]$out.Append("`n")
        }
    }
    $out.ToString()
}

function Test-LooksLikeProse([string]$Text) {
    # Assumes English source documents, which is what the intake folders carry.
    # The point is not language detection; it is telling decoded words apart from
    # glyph indices that happen to render as letters.
    $sample = $Text
    if ($sample.Length -gt 20000) { $sample = $sample.Substring(0, 20000) }
    $letters = ([regex]'[A-Za-z]').Matches($sample).Count
    $nonWs = ($sample -replace '\s', '').Length

    # A page carrying plenty of marks but few letters has not decoded: subset fonts
    # map glyph indices onto the punctuation range, so the output arrives as
    # ! " # $ % rather than words. Checked before the short-document bail below,
    # because such a page can fall under the letter threshold while being long.
    if ($nonWs -ge 40 -and ($letters / [double]$nonWs) -lt 0.5) { return $false }

    if ($letters -lt 40) { return $true }   # genuinely too short to judge; let it through

    $common = @('the', 'and', 'of', 'to', 'is', 'in', 'for', 'with', 'that', 'this',
        'are', 'be', 'on', 'as', 'by', 'or', 'from', 'not', 'it', 'an')
    $words = @(([regex]'[A-Za-z]{2,}').Matches($sample) | ForEach-Object { $_.Value.ToLowerInvariant() })

    # Plenty of letters but almost no multi-letter words means the glyphs decoded
    # individually and never formed words - the shape undecodable subset fonts take.
    if ($words.Count -lt 10) { return ($letters -lt 60) }

    $hits = @($words | Where-Object { $common -contains $_ })
    $distinct = @($hits | Sort-Object -Unique).Count
    $rate = $hits.Count / [double]$words.Count

    # Real English prose runs well above 5% function words with several distinct
    # ones; substituted glyph text produces almost none.
    ($distinct -ge 3 -and $rate -ge 0.02)
}

function Test-PdfEmptyUserPassword($Info, [byte[]]$FileKey) {
    # Algorithm 5: recompute the /U value the file key implies and compare. The key
    # carries the password, so this validates whatever password produced it - empty
    # or supplied. Note steps (a)/(b) encrypt the padding constant, never the
    # password itself. A mismatch means the password is wrong or missing, which is a
    # different problem from one we merely failed to decrypt - and worth saying so.
    if ($null -eq $Info.U -or $Info.U.Length -lt 16) { return $false }
    $md5 = [System.Security.Cryptography.MD5]::Create()
    try {
        if ($Info.R -eq 2) {
            $x = Invoke-Rc4 $FileKey $script:PdfPad
        }
        else {
            $ms = New-Object System.IO.MemoryStream
            $ms.Write($script:PdfPad, 0, 32)
            if ($Info.ID) { $ms.Write($Info.ID, 0, $Info.ID.Length) }
            $x = $md5.ComputeHash($ms.ToArray())
            $x = Invoke-Rc4 $FileKey $x
            for ($i = 1; $i -le 19; $i++) {
                $k = New-Object byte[] $FileKey.Length
                for ($b = 0; $b -lt $FileKey.Length; $b++) { $k[$b] = $FileKey[$b] -bxor [byte]$i }
                $x = Invoke-Rc4 $k $x
            }
        }
        for ($i = 0; $i -lt 16; $i++) { if ($x[$i] -ne $Info.U[$i]) { return $false } }
        $true
    }
    finally { $md5.Dispose() }
}

function Invoke-PdfOcrText([string]$FilePath) {
    if ($script:NoOcr) { return $null }
    $ocr = Join-Path $PSScriptRoot 'Invoke-PdfOcr.ps1'
    if (-not (Test-Path -LiteralPath $ocr)) { return $null }
    $text = if ($script:PdfPassword) {
        & $ocr -Path $FilePath -Password $script:PdfPassword 2>$null
    }
    else {
        & $ocr -Path $FilePath 2>$null
    }
    if ($LASTEXITCODE -ne 0 -or -not ("$text" -replace '\s', '')) { return $null }
    "$text"
}

function Invoke-PdfOcrFallback([string]$FilePath, [string]$Reason) {
    # Reached only when the text layer is absent or undecodable. OCR reads a picture
    # of the words rather than the words, so the caller marks the result and the
    # reviewer has to confirm any quote taken from it.
    $text = Invoke-PdfOcrText $FilePath
    if ($null -eq $text) { throw $Reason }
    $script:PdfUsedOcr = $true
    Compress-Blanks (Split-TextLines $text)
}

function Get-PdfPageCount([string]$All) {
    @(([regex]'/Type\s*/Page(?!s)').Matches($All)).Count
}

function Convert-PdfToMarkdown([string]$FilePath) {
    $item = Get-Item -LiteralPath $FilePath -Force
    if (([int]$item.Attributes -band $script:PlaceholderBits) -ne 0) {
        throw "cloud placeholder - not downloaded to this machine. Right-click it, 'Always keep on this device' (or just open it once), then re-run."
    }
    $bytes = [System.IO.File]::ReadAllBytes($FilePath)
    if ($bytes.Length -lt 32) { throw 'file is too small to be a PDF' }
    $head = $script:PdfEnc.GetString($bytes, 0, [Math]::Min(1024, $bytes.Length))
    if ($head -notmatch '%PDF-') { throw 'not a PDF - the %PDF header is missing' }

    $all = $script:PdfEnc.GetString($bytes)

    # Rights-managed (Purview/AIP) PDFs carry a readable decoy page saying "This PDF
    # file is protected - you'll need a different reader", with the real content
    # encrypted in an embedded payload. That decoy extracts cleanly as plausible
    # English and passes every quality check below, so without this test the file
    # succeeds and the spec gets built from a notice rather than the document. OCR
    # is no escape either - it would read the same decoy page. Refuse outright.
    if ($all -match 'MicrosoftIRMServices') {
        throw 'PDF is rights-protected (Microsoft Purview/AIP). Its readable pages are only a "you need a different reader" notice - the actual content is encrypted and is not present in extractable form. Open it in a reader where you hold the rights and save or print an unprotected copy, then re-run'
    }

    $crypt = $null
    if ($all -match '/Encrypt[\s/<\[]') {
        $info = Get-PdfEncryptionInfo $all
        if ($null -eq $info) {
            throw 'PDF is encrypted in a form this extractor cannot read - export it to .docx or .txt and re-run'
        }
        if ($info.V -ge 5) {
            # AES-256 (R5/R6) uses a different, SHA-2 based derivation that is not
            # implemented here.
            throw 'PDF uses AES-256 encryption, which this extractor does not implement - export it to .docx or .txt and re-run'
        }
        $fileKey = Get-PdfFileKey $info
        if (-not (Test-PdfEmptyUserPassword $info $fileKey)) {
            $msg = if ($script:PdfPassword) {
                'the supplied password did not open this PDF - check it, or export the file to .docx or .txt and re-run'
            }
            else {
                'PDF needs a user password to open - pass -Password, supply an unprotected copy, or export it to .docx or .txt, and re-run'
            }
            throw $msg
        }
        $crypt = [pscustomobject]@{
            Key   = $fileKey
            IsAes = ($info.CFM -eq 'AESV2')
        }
    }

    $objRe = New-Object System.Text.RegularExpressions.Regex('(?<num>\d+)\s+(?<gen>\d+)\s+obj',
        [System.Text.RegularExpressions.RegexOptions]::RightToLeft)

    $text = New-Object System.Text.StringBuilder
    $parseTimedOut = $false
    $idx = 0
    while ($true) {
        $st = $all.IndexOf('stream', $idx)
        if ($st -lt 0) { break }
        $p = $st + 6
        if ($p -lt $all.Length -and $all[$p] -eq "`r") { $p++ }
        if ($p -lt $all.Length -and $all[$p] -eq "`n") { $p++ }
        $en = $all.IndexOf('endstream', $p)
        if ($en -lt 0) { break }
        $len = $en - $p
        if ($len -gt 0) {
            # An image's bytes are not page content, and roughly half of all JPEGs of
            # any size contain 'Tj' by chance - enough to get the stream parsed as text
            # and inject junk into an image-heavy document.
            $objStart = $all.LastIndexOf(' obj', $st)
            $dict = if ($objStart -ge 0) { $all.Substring($objStart, $st - $objStart) } else { '' }
            if ($dict -match '/Subtype\s*/Image') { $idx = $en + 9; continue }

            $raw = New-Object byte[] $len
            [Array]::Copy($bytes, $p, $raw, 0, $len)

            if ($null -ne $crypt) {
                # Each object is encrypted under a key derived from its own number.
                $om = $objRe.Match($all, $st)
                if ($om.Success) {
                    $objKey = Get-PdfObjectKey $crypt.Key ([int]$om.Groups['num'].Value) ([int]$om.Groups['gen'].Value) $crypt.IsAes
                    $raw = if ($crypt.IsAes) { Invoke-PdfAesDecrypt $objKey $raw } else { Invoke-Rc4 $objKey $raw }
                }
                else { $raw = $null }
            }

            if ($null -ne $raw -and $raw.Length -gt 0) {
                try {
                    $content = Expand-PdfStream $raw 0 $raw.Length
                    # An uncompressed content stream is legal and common in simple PDFs.
                    if (-not $content) {
                        $candidate = $script:PdfEnc.GetString($raw)
                        if ($candidate -match 'Tj|TJ') { $content = $candidate }
                    }
                    if ($content -and ($content -match 'Tj|TJ')) {
                        [void]$text.Append((Get-PdfContentText $content))
                        [void]$text.Append("`n")
                    }
                }
                catch [System.Text.RegularExpressions.RegexMatchTimeoutException] {
                    # One pathological stream should not decide the whole file. Record
                    # it and let the checks below choose OCR over a partial read.
                    $parseTimedOut = $true
                }
            }
        }
        $idx = $en + 9
    }

    $result = $text.ToString()
    if ($parseTimedOut) {
        # Whatever was read is missing at least one stream. A silently incomplete
        # document is worse than a slower one, so re-read the whole file.
        return (Invoke-PdfOcrFallback $FilePath 'the text layer could not be parsed in reasonable time, and OCR produced nothing either - export to .docx or .txt and re-run')
    }
    if (-not ($result -replace '\s', '')) {
        $reason = if ($null -ne $crypt) {
            'the file decrypted but no text layer was found, and OCR produced nothing either'
        }
        else {
            'no extractable text layer, and OCR produced nothing either - check the file opens and contains readable pages'
        }
        return (Invoke-PdfOcrFallback $FilePath $reason)
    }
    if (-not (Test-LooksLikeProse $result)) {
        # A subset font with a custom encoding decodes to plausible-looking letters
        # that are not the document's words. Handing that on would put fabricated
        # sentences into the evidence chain, so read the rendered page instead.
        return (Invoke-PdfOcrFallback $FilePath 'the text layer uses a custom font encoding that cannot be decoded, and OCR produced nothing either - export to .docx or .txt and re-run')
    }

    # A scan often carries a thin text layer - a header, a footer, a stamp - while the
    # substance of the page stays locked in the image. That extracts cleanly and reads
    # as ordinary English, so nothing above catches it. Judged per page, because one
    # readable page in a fifty-page scan is the same problem as a short document.
    $pages = Get-PdfPageCount $all
    $words = @(([regex]'[A-Za-z]{2,}').Matches($result)).Count
    if ($pages -gt 0 -and ($words / [double]$pages) -lt $script:SparseWordsPerPage) {
        $ocrText = Invoke-PdfOcrText $FilePath
        if ($null -ne $ocrText) {
            $ocrWords = @(([regex]'[A-Za-z]{2,}').Matches($ocrText)).Count
            # Only swap when OCR recovers substantially more. If it does not, the thin
            # layer was all there was, and the document's own characters beat a
            # machine reading of them.
            if ($ocrWords -ge ($words * 2) -and ($ocrWords - $words) -ge 25) {
                $script:PdfUsedOcr = $true
                return (Compress-Blanks (Split-TextLines $ocrText))
            }
        }
    }

    Compress-Blanks (Split-TextLines $result)
}

# --------------------------------------------------------------- flat files

function Read-TextFile([string]$FilePath) {
    [System.IO.File]::ReadAllText($FilePath, [System.Text.Encoding]::UTF8)
}

function Split-TextLines([string]$Text) {
    # A single trailing newline ends the last line, it does not start an empty one.
    ($Text -replace "`r?`n$", '') -split "`r?`n"
}

function Split-DelimitedText([string]$Text, [char]$Delim) {
    $rows = @()
    $row = @()
    $cur = New-Object System.Text.StringBuilder
    $inQuotes = $false
    for ($i = 0; $i -lt $Text.Length; $i++) {
        $ch = $Text[$i]
        if ($inQuotes) {
            if ($ch -eq '"') {
                if (($i + 1) -lt $Text.Length -and $Text[$i + 1] -eq '"') { [void]$cur.Append('"'); $i++ }
                else { $inQuotes = $false }
            }
            else { [void]$cur.Append($ch) }
        }
        elseif ($ch -eq '"') { $inQuotes = $true }
        elseif ($ch -eq $Delim) { $row += (Format-Cell $cur.ToString()); [void]$cur.Clear() }
        elseif ($ch -eq "`n") {
            $row += (Format-Cell $cur.ToString()); [void]$cur.Clear()
            $rows += , $row; $row = @()
        }
        elseif ($ch -ne "`r") { [void]$cur.Append($ch) }
    }
    if ($cur.Length -gt 0 -or $row.Count -gt 0) {
        $row += (Format-Cell $cur.ToString())
        $rows += , $row
    }
    $rows
}

function Convert-CsvToMarkdown([string]$FilePath) {
    $delim = if ($FilePath.ToLowerInvariant().EndsWith('.tsv')) { "`t" } else { ',' }
    Convert-RowsToMarkdown @(Split-DelimitedText (Read-TextFile $FilePath) ([char]$delim))
}

function Convert-FileToMarkdown([string]$FilePath) {
    $ext = [System.IO.Path]::GetExtension($FilePath).ToLowerInvariant()
    switch ($ext) {
        '.docx' { return @{ lines = @(Convert-DocxToMarkdown $FilePath); kind = 'docx' } }
        '.xlsx' { return @{ lines = @(Convert-XlsxToMarkdown $FilePath); kind = 'xlsx' } }
        '.csv' { return @{ lines = @(Convert-CsvToMarkdown $FilePath); kind = 'csv' } }
        '.tsv' { return @{ lines = @(Convert-CsvToMarkdown $FilePath); kind = 'csv' } }
        '.drawio' { return @{ lines = @(Convert-DrawioToMarkdown $FilePath); kind = 'drawio' } }
        '.pdf' {
            $script:PdfUsedOcr = $false
            $lines = @(Convert-PdfToMarkdown $FilePath)
            return @{ lines = $lines; kind = $(if ($script:PdfUsedOcr) { 'pdf-ocr' } else { 'pdf' }) }
        }
        '.json' {
            # Verbatim, not re-serialised: evidence cites line numbers in the original file.
            return @{ lines = @('```json') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'json' }
        }
        '.xml' { return @{ lines = @('```xml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'xml' } }
        '.yaml' { return @{ lines = @('```yaml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'yaml' } }
        '.yml' { return @{ lines = @('```yaml') + @(Split-TextLines (Read-TextFile $FilePath)) + @('```'); kind = 'yaml' } }
    }
    if ($script:TextExt -contains $ext) {
        return @{ lines = @(Compress-Blanks @(Split-TextLines (Read-TextFile $FilePath))); kind = 'text' }
    }
    throw ("no extractor for '" + $ext + "'")
}

# --------------------------------------------------------------- driver

if ($Command -eq 'file') {
    if (-not $Path) { [Console]::Error.WriteLine('extract: -Path is required with -Command file'); exit 1 }
    try { $r = Convert-FileToMarkdown (Resolve-Path -LiteralPath $Path).Path }
    catch { [Console]::Error.WriteLine('extract: ' + $_.Exception.Message); exit 1 }
    if ($r.kind -eq 'pdf-ocr') {
        # Single-file mode feeds ingestion directly, so the caveat has to travel with
        # the text here too - otherwise OCR output is indistinguishable from a real
        # text layer at the point where statements get their evidence.
        Write-Output '> **OCR-DERIVED.** Machine reading of a picture of the words, not the words themselves. Recognition errors are silent and plausible. Confirm any sentence against the original before quoting it as evidence.'
        Write-Output ''
    }
    Write-Output ($r.lines -join "`n")
    exit 0
}

$SrcRoot = Join-Path $Root 'src'
if (-not $Out) { $Out = Join-Path (Join-Path (Join-Path $Root 'out') 'intake') 'extracted' }

if (-not (Test-Path -LiteralPath $SrcRoot)) {
    [Console]::Error.WriteLine("extract: no src folder at $SrcRoot")
    [Console]::Error.WriteLine('  Run /discovery-init-migration first.')
    exit 4
}

$done = @(); $skipped = @(); $failed = @()

foreach ($folderDir in (Get-ChildItem -LiteralPath $SrcRoot -Directory | Sort-Object Name)) {
    if ($folderDir.Name.StartsWith('.')) { continue }
    $folder = $folderDir.Name
    $prefix = $folderDir.FullName.TrimEnd('\') + '\'
    foreach ($file in (Get-ChildItem -LiteralPath $folderDir.FullName -File -Recurse -Force | Sort-Object FullName)) {
        if ($file.Name.StartsWith('.') -or ($script:Ignored -contains $file.Name.ToLowerInvariant())) { continue }
        $rel = $file.FullName.Substring($prefix.Length).Replace('\', '/')
        if ($rel -like '.*' -or $rel -like '*/.*') { continue }
        $label = $folder + '/' + $rel
        $ext = $file.Extension.ToLowerInvariant()

        if ($script:NeedsManual.ContainsKey($ext)) {
            $skipped += , @($label, $script:NeedsManual[$ext]); continue
        }
        if ($script:Extractable -notcontains $ext) {
            $skipped += , @($label, ("unrecognised type '" + $ext + "' - no extractor")); continue
        }
        try { $r = Convert-FileToMarkdown $file.FullName }
        catch { $failed += , @($label, $_.Exception.Message); continue }

        $dest = Join-Path (Join-Path $Out $folder) ($rel.Replace('/', '\') + '.md')
        $destDir = Split-Path -Parent $dest
        if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }

        $body = @($r.lines)
        if ($body.Count -eq 0) { $body = @('_No text content found in this file._') }
        $header = @(
            ('# ' + [System.IO.Path]::GetFileName($rel)), '',
            ('> Extracted from ' + $Tick + 'src/' + $label + $Tick + ' by ' + $Tick + 'Extract-Text.ps1' + $Tick + ' (' + $r.kind + ') at ' + (Get-Stamp) + '.'),
            '> Mechanical text extraction: images, formatting and embedded objects are not preserved.'
        )
        if ($r.kind -eq 'pdf-ocr') {
            # OCR misreads are silent and plausible, so the warning travels with the
            # text rather than living only in a run report nobody re-reads.
            $header += @(
                '>',
                '> **OCR-DERIVED. These are a machine reading of a picture of the words, not the',
                '> words themselves.** Recognition errors are silent and look plausible. Confirm any',
                '> sentence against the original before quoting it as evidence.'
            )
        }
        $header += @('', '---', '')
        (((@($header) + $body) -join "`n") + "`n") | Set-Content -LiteralPath $dest -Encoding UTF8 -NoNewline
        $display = $dest.Replace('\', '/')
        $rootPrefix = $Root.TrimEnd('\', '/').Replace('\', '/') + '/'
        if ($display.StartsWith($rootPrefix)) { $display = $display.Substring($rootPrefix.Length) }
        $done += , @($label, $r.kind, $display, ($folder + '/' + $rel + '.md'), $body.Count)
    }
}

$lines = @('# Extracted intake', '', ('Generated ' + (Get-Stamp) + ' by ' + $Tick + 'Extract-Text.ps1' + $Tick + '.'), '',
    ('Every downstream reader uses **these** files, not the originals under ' + $Tick + 'src/' + $Tick + '. The originals are never modified.'), '',
    '| Source | Extractor | Lines | Extracted to |', '|---|---|---|---|')
foreach ($d in $done) {
    $lines += ('| ' + $Tick + 'src/' + $d[0] + $Tick + ' | ' + $d[1] + ' | ' + $d[4] + ' | [' + $Tick + $d[2] + $Tick + '](' + $d[3] + ') |')
}
if ($done.Count -eq 0) { $lines += '| _none_ | | | |' }
if ($skipped.Count -gt 0) {
    $lines += @('', '## Not extracted', '', 'These were **not read**. Do not cite them as evidence.', '', '| File | Why |', '|---|---|')
    foreach ($s in $skipped) { $lines += ('| ' + $Tick + 'src/' + $s[0] + $Tick + ' | ' + $s[1] + ' |') }
}
if ($failed.Count -gt 0) {
    $lines += @('', '## Failed', '', 'Present and of a supported type, but could not be parsed.', '', '| File | Error |', '|---|---|')
    foreach ($f in $failed) { $lines += ('| ' + $Tick + 'src/' + $f[0] + $Tick + ' | ' + $f[1].Replace('|', '\|') + ' |') }
}
if (-not (Test-Path -LiteralPath $Out)) { New-Item -ItemType Directory -Path $Out -Force | Out-Null }
$indexPath = Join-Path $Out 'INDEX.md'
(($lines -join "`n") + "`n") | Set-Content -LiteralPath $indexPath -Encoding UTF8 -NoNewline
Write-Output "index -> $indexPath"

foreach ($d in $done) {
    Write-Output ('extracted  {0} {1} {2,4} lines -> {3}' -f $d[0].PadRight(45), $d[1].PadRight(6), $d[4], $d[2])
}
foreach ($s in $skipped) { Write-Output ('SKIPPED    {0} {1}' -f $s[0].PadRight(45), $s[1]) }
foreach ($f in $failed) { [Console]::Error.WriteLine(('FAILED     {0} {1}' -f $f[0].PadRight(45), $f[1])) }

Write-Output ''
Write-Output ("{0} extracted, {1} skipped, {2} failed" -f $done.Count, $skipped.Count, $failed.Count)

if ($done.Count -eq 0) {
    [Console]::Error.WriteLine('')
    [Console]::Error.WriteLine("STOP: nothing could be extracted from $SrcRoot.")
    [Console]::Error.WriteLine('  Files were present but none is machine-readable.')
    [Console]::Error.WriteLine('  Convert at least one to .docx, .xlsx, .csv, .md or .txt and re-run.')
    exit 2
}
exit 0
