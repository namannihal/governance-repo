<#
.SYNOPSIS
    The spec layer: statement store, canonical spec, domain views, review gate.

.DESCRIPTION
    Turns extracted evidence into atomic statements, deduplicates them into a canonical
    spec, projects them into three domain views, and refuses to hand anything to a
    downstream agent until a human has approved it.

    This is the only writer of everything under out/. It has no dependency on any other
    package, and no opinion about which agent consumes it - see docs/INTEGRATION.md.

    Windows PowerShell 5.1. No modules.

.PARAMETER Command
    init             Create the out/ spec skeleton.
    register-sources Walk src/, hash every file, record read or not-read with a reason.
    add-statement    Add one atomic claim with its evidence.
    build            Canonical + views + conflicts + evidence map + rendered Markdown.
    resolve          The downstream gate. Exit 3 when the view is not approved.
    review           Append a human decision. The only way a status changes.
    verify           Recompute bindings; void approvals whose evidence moved.
    status           Triage counts.

.EXAMPLE
    .\Spec.ps1 -Root .lmp-migrate\payments-api -Command init
    .\Spec.ps1 -Root .lmp-migrate\payments-api -Command register-sources
    .\Spec.ps1 -Root .lmp-migrate\payments-api -Command build
    .\Spec.ps1 -Root .lmp-migrate\payments-api -Command resolve -View devops-spec -MinStatus approved

.NOTES
    Exit codes
      0  success
      2  hard stop - no evidence to work from
      3  prerequisite unmet - not approved, or a blocked section
      4  missing store, or unknown view
      5  already exists
#>
[CmdletBinding()]
param(
    [string]$Root = '.',

    [ValidateSet('init', 'register-sources', 'add-statement', 'build', 'resolve',
        'review', 'verify', 'status', 'review-sheet', 'apply-review')]
    [string]$Command = 'status',

    [string]$FactKey,
    [string]$Value,
    [string]$SourceId,
    [string]$Locator,
    [string]$Quote,

    [ValidateSet('explicit-statement', 'table-cell', 'diagram-label', 'config-value',
        'structure-derived', 'cross-reference', 'inferred', 'weak-inference', 'guess',
        'human-assertion')]
    [string]$Method = 'explicit-statement',

    [string[]]$Domains,
    [string]$Section,
    [string]$View,

    [ValidateSet('draft', 'needs-review', 'changes-requested', 'approved', 'superseded')]
    [string]$MinStatus = 'approved',

    [string]$Target,
    [ValidateSet('approve', 'request-changes', 'reset')][string]$Action,
    [string]$Actor,
    [string]$Rationale,

    [ValidateSet('text', 'json')][string]$Format = 'text',
    [switch]$Force,

    # Bypasses the constitution gate in resolve. Recorded in the resolve payload so a
    # bypass is visible downstream rather than indistinguishable from a clean pass.
    [switch]$SkipStandards,

    # The opposite: refuse unless a standards check has actually been run. Without it,
    # a missing rule pack degrades to "no findings", which looks exactly like "passed".
    # Pipelines that are supposed to enforce a constitution should set this.
    [switch]$RequireStandards,

    # apply-review: parse and validate the sheet, print the plan, change nothing.
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

# $PSBoundParameters inside a function describes that function, not this script.
# Commands need to distinguish "-Value was not supplied" from "-Value ''", so the
# script-level binding is captured here while it is still in scope.
$script:BoundParams = $PSBoundParameters

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

$script:SPEC_VERSION = 1

# Commands write to the output stream and signal failure through this, because
# `exit (Invoke-Something)` would capture their output as the exit expression
# instead of printing it.
$script:ExitCode = 0

# Ordered weakest to strongest. Used by resolve to compare against -MinStatus.
$script:STATUS_ORDER = @('draft', 'needs-review', 'changes-requested', 'approved', 'superseded')

# Extraction method decides tier. Tier is never supplied by a caller: a caller that
# can name its own confidence will always name it too high.
$script:METHOD_TIER = @{
    'explicit-statement' = 'A'
    'table-cell'         = 'A'
    'diagram-label'      = 'A'
    'config-value'       = 'A'
    'human-assertion'    = 'A'
    'structure-derived'  = 'B'
    'cross-reference'    = 'B'
    'inferred'           = 'C'
    'weak-inference'     = 'D'
    'guess'              = 'E'
}

$script:TIER_CONFIDENCE = @{ 'A' = 'high'; 'B' = 'high'; 'C' = 'medium'; 'D' = 'low'; 'E' = 'low' }

$script:VIEWS = @('development-spec', 'devops-spec', 'refactoring-spec', 'sad-spec', 'mec-spec', 'uaq-spec')

# A fact asserted by a reviewer rather than found in a document. It is still evidence -
# a named person, at a recorded time, with a rationale - so it is exempt from the
# source-register check that every other statement must pass.
$script:HUMAN_SOURCE = 'human-review'

# Intake folder -> adapter. One table drives both the folders `init` creates and the
# adapter `register-sources` infers, because two lists would drift and the failure is
# silent: a document in a mistyped folder is recorded as 'appdocs' with no warning.
$script:INTAKE_ADAPTERS = [ordered]@{
    'comigrate-assessment' = 'comigrate'
    'aimigrate-assessment' = 'aimigrate'
    'existing-sad'         = 'existing_sad'
    'application-docs'     = 'appdocs'
}

# Subject prefix -> default domains and section. Explicit -Domains always wins.
#
# 'sad' is an audience, not a fact family: a Solution Architecture Document is
# assembled from facts that already exist for other views, so it is added alongside
# them rather than given prefixes of its own. 'mec' and 'uaq' are the opposite -
# their facts come from a control catalogue and a questionnaire, so they carry their
# own prefixes and belong to nobody else.
$script:ROUTING = @(
    @{ Prefix = 'api.';        Domains = @('development', 'sad');               Section = 'contracts' }
    @{ Prefix = 'app.';        Domains = @('devops', 'development', 'sad');      Section = 'application' }
    @{ Prefix = 'data.';       Domains = @('development', 'sad');               Section = 'data-model' }
    @{ Prefix = 'behaviour.';  Domains = @('development', 'refactoring'); Section = 'behaviour' }
    @{ Prefix = 'contract.';   Domains = @('development', 'sad');               Section = 'contracts' }
    @{ Prefix = 'nfr.';        Domains = @('devops', 'development', 'sad');      Section = 'nfr' }
    @{ Prefix = 'infra.';      Domains = @('devops', 'sad');                    Section = 'infrastructure' }
    @{ Prefix = 'deploy.';     Domains = @('devops', 'sad');                    Section = 'deployment' }
    @{ Prefix = 'env.';        Domains = @('devops', 'sad');                    Section = 'environments' }
    @{ Prefix = 'config.';     Domains = @('devops');                    Section = 'configuration' }
    @{ Prefix = 'monitor.';    Domains = @('devops', 'sad');                    Section = 'monitoring' }
    @{ Prefix = 'rollback.';   Domains = @('devops', 'sad');                    Section = 'rollback' }
    @{ Prefix = 'aws.';        Domains = @('devops', 'refactoring', 'sad');      Section = 'infrastructure' }
    @{ Prefix = 'azure.';      Domains = @('devops', 'sad');                    Section = 'infrastructure' }
    @{ Prefix = 'arch.';       Domains = @('refactoring', 'sad');               Section = 'current-architecture' }
    @{ Prefix = 'debt.';       Domains = @('refactoring');               Section = 'technical-debt' }
    @{ Prefix = 'dependency.'; Domains = @('refactoring', 'devops', 'sad');      Section = 'dependencies' }
    @{ Prefix = 'risk.';       Domains = @('devops', 'refactoring', 'sad');      Section = 'risks' }

    # Added for the constraint layer. A constitution rule can only be evaluated
    # against a fact that reached a view, so every key in the rule pack's vocabulary
    # needs a home here or it lands in 'unrouted' and is never gated.
    @{ Prefix = 'migration.';    Domains = @('devops', 'refactoring', 'sad');   Section = 'migration' }
    @{ Prefix = 'source.';       Domains = @('refactoring', 'devops', 'sad');   Section = 'current-architecture' }
    @{ Prefix = 'security.';     Domains = @('devops', 'development', 'sad', 'mec'); Section = 'security' }
    @{ Prefix = 'observability.'; Domains = @('devops', 'sad');                 Section = 'monitoring' }
    @{ Prefix = 'pipeline.';     Domains = @('devops');                  Section = 'deployment' }
    @{ Prefix = 'naming.';       Domains = @('devops');                  Section = 'infrastructure' }
    @{ Prefix = 'business_case.'; Domains = @('devops', 'refactoring', 'sad');  Section = 'rationale' }

    # Artifact vocabularies. The section here is only a fallback - both catalogues are
    # themed (MEC by control theme, UAQ by questionnaire section), so the ingesting
    # agent should pass -Section to preserve that grouping.
    @{ Prefix = 'mec.';          Domains = @('mec');                     Section = 'controls' }
    @{ Prefix = 'uaq.';          Domains = @('uaq');                     Section = 'assessment' }
)

# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

function Fail([string]$Message, [int]$Code) {
    [Console]::Error.WriteLine("ERROR: $Message")
    exit $Code
}

function Now() { (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }

function Get-Sha256Hex([byte[]]$Bytes) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash($Bytes)
        return ([System.BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
    } finally { $sha.Dispose() }
}

function Get-StringSha256([string]$Text) {
    Get-Sha256Hex ([System.Text.Encoding]::UTF8.GetBytes($Text))
}

function Get-FileSha256([string]$Path) {
    $fs = [System.IO.File]::OpenRead($Path)
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $hash = $sha.ComputeHash($fs)
            return ([System.BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
        } finally { $sha.Dispose() }
    } finally { $fs.Dispose() }
}

# Set-Content adds its own newline; -NoNewline plus an explicit trailing newline keeps
# the file byte-stable across runs, which matters because we hash these files.
function Write-JsonFile([string]$Path, $Object) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $json = $Object | ConvertTo-Json -Depth 100
    Set-Content -Path $Path -Value ($json + "`r`n") -Encoding UTF8 -NoNewline
}

function Read-JsonFile([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $raw = Get-Content -Path $Path -Raw -Encoding UTF8
    if (-not $raw -or $raw.Trim().Length -eq 0) { return $null }
    return ($raw | ConvertFrom-Json)
}

function Write-TextFile([string]$Path, [string]$Text) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $Path -Value $Text -Encoding UTF8 -NoNewline
}

# ConvertFrom-Json collapses one-element arrays to a scalar. Every read of a JSON
# array goes through this or the code breaks on single-statement stores.
# -NoNewline is not the issue here: a bare `return @()` unrolls to $null on the way
# out, so the result must be emitted unenumerated.
function AsArray($Value) {
    if ($null -eq $Value) { $result = @() }
    elseif ($Value -is [System.Array]) { $result = $Value }
    else { $result = @($Value) }
    Write-Output -NoEnumerate $result
}

function Get-StatusRank([string]$Status) {
    $i = [Array]::IndexOf($script:STATUS_ORDER, $Status)
    if ($i -lt 0) { return 0 }
    return $i
}

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #

function Get-Paths([string]$RootPath) {
    $out = Join-Path $RootPath 'out'
    $p = [ordered]@{
        Root         = $RootPath
        Src          = Join-Path $RootPath 'src'
        Out          = $out
        Sources      = Join-Path $out 'sources\source-register.json'
        Statements   = Join-Path $out 'statements.json'
        EvidenceMap  = Join-Path $out 'evidence-map.json'
        Conflicts    = Join-Path $out 'conflicts\unresolved-conflicts.json'
        Decisions    = Join-Path $out 'decisions\decision-log.jsonl'
        SpecDir      = Join-Path $out 'specifications'
        Canonical    = Join-Path $out 'specifications\system-spec.json'
        ReviewDir    = Join-Path $out 'review'
        Summary      = Join-Path $out 'review\review-summary.md'
        Violations   = Join-Path $out 'compliance\violations.json'
        Sheet        = Join-Path $out 'review\review-sheet.md'
        AppliedDir   = Join-Path $out 'review\applied'
    }
    return $p
}

function Get-ViewPath($Paths, [string]$ViewName) {
    Join-Path $Paths.SpecDir ("{0}.json" -f $ViewName)
}

# --------------------------------------------------------------------------- #
# Routing, tiers, ids
# --------------------------------------------------------------------------- #

function Get-Routing([string]$Key) {
    foreach ($r in $script:ROUTING) {
        if ($Key.StartsWith($r.Prefix, [StringComparison]::OrdinalIgnoreCase)) {
            return [ordered]@{ Domains = $r.Domains; Section = $r.Section }
        }
    }
    # Unroutable keys are not silently dropped into a default view. They land in
    # 'unrouted' so the review summary can show them.
    return [ordered]@{ Domains = @('development'); Section = 'unrouted' }
}

function Get-Tier([string]$ExtractionMethod) {
    if ($script:METHOD_TIER.ContainsKey($ExtractionMethod)) { return $script:METHOD_TIER[$ExtractionMethod] }
    return 'E'
}

function Get-Confidence([string]$Tier, [bool]$InConflict) {
    # An open conflict forces low regardless of tier. A contested fact is not a
    # confident one, however plainly it was written down.
    if ($InConflict) { return 'low' }
    if ($script:TIER_CONFIDENCE.ContainsKey($Tier)) { return $script:TIER_CONFIDENCE[$Tier] }
    return 'low'
}

function New-StatementId([string]$FactKeyValue, [string]$ValueText, [string]$SourceIdText, [string]$LocatorText) {
    $seed = "$FactKeyValue|$ValueText|$SourceIdText|$LocatorText"
    'stmt-' + (Get-StringSha256 $seed).Substring(0, 8)
}

function New-SourceId([string]$RelPath) {
    'src-' + (Get-StringSha256 $RelPath).Substring(0, 8)
}

# Binding hash covers the value and the evidence it rests on, including the hash of
# each source file. Change the document and this moves, which voids the approval.
function Get-BindingHash($Statement, $SourceIndex) {
    $parts = New-Object System.Collections.ArrayList
    [void]$parts.Add('v=' + $Statement.value)
    foreach ($e in (AsArray $Statement.evidence)) {
        $srcSha = ''
        if ($SourceIndex.ContainsKey($e.source_id)) { $srcSha = $SourceIndex[$e.source_id].sha256 }
        [void]$parts.Add(('e=' + $e.source_id + ':' + $srcSha + ':' + $e.locator + ':' + $e.quote))
    }
    Get-StringSha256 ($parts -join '|')
}

# --------------------------------------------------------------------------- #
# Store access
# --------------------------------------------------------------------------- #

function Get-Store($Paths) {
    $doc = Read-JsonFile $Paths.Statements
    if ($null -eq $doc) {
        return [ordered]@{ version = $script:SPEC_VERSION; generated_at = (Now); statements = @() }
    }
    $list = New-Object System.Collections.ArrayList
    foreach ($s in (AsArray $doc.statements)) { [void]$list.Add((ConvertTo-Hashtable $s)) }
    return [ordered]@{ version = $doc.version; generated_at = $doc.generated_at; statements = $list }
}

# PSCustomObject from ConvertFrom-Json is awkward to mutate. Everything the store
# writes back goes through this so property adds behave predictably.
function ConvertTo-Hashtable($Object) {
    if ($null -eq $Object) { return $null }
    if ($Object -is [System.Collections.IDictionary]) {
        $h = [ordered]@{}
        foreach ($k in $Object.Keys) { $h[$k] = ConvertTo-Hashtable $Object[$k] }
        return $h
    }
    if ($Object -is [System.Management.Automation.PSCustomObject]) {
        $h = [ordered]@{}
        foreach ($p in $Object.PSObject.Properties) { $h[$p.Name] = ConvertTo-Hashtable $p.Value }
        return $h
    }
    if ($Object -is [System.Array]) {
        $a = New-Object System.Collections.ArrayList
        foreach ($item in $Object) { [void]$a.Add((ConvertTo-Hashtable $item)) }
        return $a.ToArray()
    }
    return $Object
}

function Save-Store($Paths, $Store) {
    $Store.generated_at = Now
    Write-JsonFile $Paths.Statements $Store
}

function Get-SourceIndex($Paths) {
    $idx = @{}
    $doc = Read-JsonFile $Paths.Sources
    if ($null -eq $doc) { return $idx }
    foreach ($s in (AsArray $doc.sources)) { $idx[$s.id] = $s }
    return $idx
}

function Add-DecisionEntry($Paths, $Entry) {
    $dir = Split-Path -Parent $Paths.Decisions
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $line = ($Entry | ConvertTo-Json -Depth 20 -Compress)
    Add-Content -Path $Paths.Decisions -Value $line -Encoding UTF8
}

# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #

function Invoke-Init($Paths) {
    if ((Test-Path $Paths.Statements) -and -not $Force) {
        Fail "spec store already exists at $($Paths.Statements). Use -Force to reset." 5
    }
    foreach ($d in @($Paths.Out, (Split-Path -Parent $Paths.Sources), (Split-Path -Parent $Paths.Conflicts),
            (Split-Path -Parent $Paths.Decisions), $Paths.SpecDir, $Paths.ReviewDir)) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    foreach ($folder in $script:INTAKE_ADAPTERS.Keys) {
        $p = Join-Path $Paths.Src $folder
        if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    }
    Write-JsonFile $Paths.Statements ([ordered]@{ version = $script:SPEC_VERSION; generated_at = (Now); statements = @() })
    Write-JsonFile $Paths.Sources ([ordered]@{ version = $script:SPEC_VERSION; generated_at = (Now); sources = @() })
    Write-JsonFile $Paths.Conflicts ([ordered]@{ version = $script:SPEC_VERSION; generated_at = (Now); conflicts = @() })
    if (-not (Test-Path $Paths.Decisions)) { Write-TextFile $Paths.Decisions '' }
    Write-Output "spec initialised at $($Paths.Out)"
    Write-Output ("intake folders ready: " + (($script:INTAKE_ADAPTERS.Keys) -join ', '))
}

function Invoke-RegisterSources($Paths) {
    if (-not (Test-Path $Paths.Src)) { Fail "no src/ folder at $($Paths.Src)" 4 }

    $extractor = Join-Path $PSScriptRoot 'Extract-Text.ps1'
    $files = @(Get-ChildItem -Path $Paths.Src -Recurse -File -ErrorAction SilentlyContinue)

    # Both sides go through GetFullPath before the prefix is trimmed. Resolve-Path
    # preserves an 8.3 short root (NAMANN~1) while FileInfo.FullName is always long, and
    # the length mismatch silently leaves a fragment of the folder name on every relative
    # path. That path is hashed into the source id, so the same file would get different
    # ids depending on how the root was spelled.
    $rootFull = [System.IO.Path]::GetFullPath((Resolve-Path $Paths.Root).Path).TrimEnd('\')

    $sources = New-Object System.Collections.ArrayList
    $readable = 0
    foreach ($f in $files) {
        $rel = [System.IO.Path]::GetFullPath($f.FullName).Substring($rootFull.Length).TrimStart('\')
        $adapter = 'appdocs'
        foreach ($folder in $script:INTAKE_ADAPTERS.Keys) {
            if ($rel -match [regex]::Escape($folder)) { $adapter = $script:INTAKE_ADAPTERS[$folder]; break }
        }

        $status = 'not-read'
        $reason = $null
        $sha = $null
        try {
            $sha = Get-FileSha256 $f.FullName
        } catch {
            $reason = 'could not open file: ' + $_.Exception.Message
        }

        if ($null -ne $sha) {
            if (Test-Path $extractor) {
                # The extractor is the authority on readability. Asking it here means the
                # register can never claim a file is readable that extraction then skips.
                # EAP is relaxed because a failed extraction writes to stderr, and with
                # 2>&1 under Stop that would abort the whole scan instead of recording
                # this one file as not-read.
                $prevEap = $ErrorActionPreference
                $ErrorActionPreference = 'Continue'
                $null = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $extractor -Command file -Path $f.FullName 2>&1
                $extractCode = $LASTEXITCODE
                $ErrorActionPreference = $prevEap
                if ($extractCode -eq 0) { $status = 'read'; $readable++ }
                else { $reason = 'extractor could not read this file type or content' }
            } else {
                $status = 'read'; $readable++
            }
        }

        [void]$sources.Add([ordered]@{
                id          = (New-SourceId $rel)
                path        = $rel
                adapter     = $adapter
                sha256      = $sha
                bytes       = $f.Length
                read_status = $status
                reason      = $reason
                scanned_at  = (Now)
            })
    }

    Write-JsonFile $Paths.Sources ([ordered]@{
            version      = $script:SPEC_VERSION
            generated_at = (Now)
            counts       = [ordered]@{ total = $files.Count; read = $readable; not_read = ($files.Count - $readable) }
            sources      = $sources.ToArray()
        })

    Write-Output ("registered {0} source(s): {1} read, {2} not-read" -f $files.Count, $readable, ($files.Count - $readable))
    if ($files.Count -eq 0) { Fail 'no intake documents found - nothing to build a spec from' 2 }
    if ($readable -eq 0) { Fail 'no readable intake documents - every file failed extraction' 2 }
}

# Shared by add-statement and apply-review, so a fact asserted at review time is built
# exactly like one extracted from a document - same id scheme, same routing, same tier
# rules. Returns the new id, or $null when an identical statement is already present.
function New-StatementRecord($Store, [string]$FactKeyText, [string]$ValueText, [string]$SourceIdText,
    [string]$LocatorText, [string]$QuoteText, [string]$MethodText, $DomainsList, [string]$SectionText) {

    $routing = Get-Routing $FactKeyText
    $useDomains = if ($DomainsList -and @($DomainsList).Count -gt 0) { @($DomainsList) } else { $routing.Domains }
    $useSection = if ($SectionText) { $SectionText } else { $routing.Section }
    $tier = Get-Tier $MethodText
    $id = New-StatementId $FactKeyText $ValueText $SourceIdText $LocatorText

    foreach ($existing in $Store.statements) {
        if ($existing.id -eq $id) { return $null }
    }

    $stmt = [ordered]@{
        id                = $id
        fact_key          = $FactKeyText
        value             = $ValueText
        evidence          = @(
            [ordered]@{
                source_id = $SourceIdText
                locator   = $(if ($LocatorText) { $LocatorText } else { '' })
                quote     = $(if ($QuoteText) { $QuoteText } else { '' })
            }
        )
        extraction_method = $MethodText
        tier              = $tier
        confidence        = (Get-Confidence $tier $false)
        domains           = @($useDomains)
        section           = $useSection
        review            = [ordered]@{
            status       = 'needs-review'
            reviewed_by  = $null
            reviewed_at  = $null
            binding_hash = $null
            reason       = $null
        }
        created_at        = (Now)
    }
    [void]$Store.statements.Add($stmt)
    return $id
}

# Applies one review decision in memory and appends the decision log entry. The caller
# saves the store, so apply-review can process a whole sheet as one write.
function Set-ReviewDecision($Paths, $Store, $SourceIndex, [string]$Id, [string]$ActionName,
    [string]$ActorName, [string]$RationaleText) {

    $found = $null
    foreach ($s in $Store.statements) { if ($s.id -eq $Id) { $found = $s; break } }
    if ($null -eq $found) { Fail "unknown statement '$Id'" 4 }

    switch ($ActionName) {
        'approve' {
            $found.review.status = 'approved'
            $found.review.binding_hash = Get-BindingHash $found $SourceIndex
            $found.review.reason = $null
        }
        'request-changes' {
            $found.review.status = 'changes-requested'
            $found.review.binding_hash = $null
            $found.review.reason = $RationaleText
        }
        'reset' {
            $found.review.status = 'needs-review'
            $found.review.binding_hash = $null
            $found.review.reason = $RationaleText
        }
    }
    $found.review.reviewed_by = $ActorName
    $found.review.reviewed_at = Now

    Add-DecisionEntry $Paths ([ordered]@{
            ts = (Now); actor = $ActorName; action = $ActionName; target = $Id
            fact_key = $found.fact_key; rationale = $RationaleText
            binding_hash = $found.review.binding_hash
        })
    return $found
}

function Invoke-AddStatement($Paths) {
    if (-not $FactKey) { Fail '-FactKey is required' 2 }
    if (-not $script:BoundParams.ContainsKey('Value')) { Fail '-Value is required' 2 }
    if (-not $SourceId) { Fail '-SourceId is required' 2 }

    $srcIndex = Get-SourceIndex $Paths
    if ($srcIndex.Count -gt 0 -and $SourceId -ne $script:HUMAN_SOURCE -and -not $srcIndex.ContainsKey($SourceId)) {
        Fail "unknown source id '$SourceId' - run register-sources first" 4
    }

    $store = Get-Store $Paths
    $id = New-StatementRecord $store $FactKey $Value $SourceId $Locator $Quote $Method $Domains $Section
    if ($null -eq $id) {
        $dupId = New-StatementId $FactKey $Value $SourceId $Locator
        Write-Output "statement $dupId already present (identical evidence) - no change"
        return
    }
    Save-Store $Paths $store
    $added = @($store.statements | Where-Object { $_.id -eq $id })[0]
    Write-Output ("added {0}  tier {1}  -> {2}" -f $id, $added.tier, ((AsArray $added.domains) -join ', '))
}

function Invoke-Build($Paths) {
    $store = Get-Store $Paths
    $statements = @($store.statements)
    if ($statements.Count -eq 0) { Fail 'no statements in the store - nothing to build' 2 }

    $srcIndex = Get-SourceIndex $Paths

    # --- conflicts: same fact_key, different value ------------------------- #
    $byKey = @{}
    foreach ($s in $statements) {
        if (-not $byKey.ContainsKey($s.fact_key)) { $byKey[$s.fact_key] = New-Object System.Collections.ArrayList }
        [void]$byKey[$s.fact_key].Add($s)
    }

    $conflicts = New-Object System.Collections.ArrayList
    $conflicted = @{}
    # fact_key -> $true when at least one statement for it has not been rejected.
    $hasLive = @{}
    foreach ($key in $byKey.Keys) {
        $group = @($byKey[$key])
        # A rejected statement is a recorded correction, not a competing claim. Counting
        # it would make conflicts unclearable: the store is append-only, so rejecting the
        # wrong value is the only move a human has. If every candidate has been rejected
        # the group is judged whole, so the disagreement is not hidden.
        $live = @($group | Where-Object { @('changes-requested', 'superseded') -notcontains $_.review.status })
        if ($live.Count -gt 0) { $hasLive[$key] = $true }
        if ($live.Count -eq 0) { $live = $group }
        $values = @($live | ForEach-Object { $_.value } | Sort-Object -Unique)
        if ($values.Count -gt 1) {
            $ids = @($live | ForEach-Object { $_.id })
            [void]$conflicts.Add([ordered]@{
                    id           = ('cft-' + (Get-StringSha256 $key).Substring(0, 6))
                    fact_key     = $key
                    values       = $values
                    statement_ids = $ids
                    detected_at  = (Now)
                    status       = 'open'
                })
            foreach ($i in $ids) { $conflicted[$i] = $true }
        }
    }

    # --- recompute derived fields ------------------------------------------ #
    foreach ($s in $statements) {
        $inConflict = $conflicted.ContainsKey($s.id)
        $s.tier = Get-Tier $s.extraction_method
        $s.confidence = Get-Confidence $s.tier $inConflict
        if ($inConflict -and $s.review.status -eq 'approved') {
            # A conflict opening under an approved statement voids the approval.
            $s.review.status = 'needs-review'
            $s.review.reason = 'conflict-opened'
            Add-DecisionEntry $Paths ([ordered]@{
                    ts = (Now); actor = 'system'; action = 'auto-void'
                    target = $s.id; rationale = 'conflict opened on fact_key ' + $s.fact_key
                })
        }
    }
    Save-Store $Paths $store

    Write-JsonFile $Paths.Conflicts ([ordered]@{
            version = $script:SPEC_VERSION; generated_at = (Now); conflicts = $conflicts.ToArray()
        })

    # --- canonical: one entry per fact_key --------------------------------- #
    $facts = New-Object System.Collections.ArrayList
    foreach ($key in ($byKey.Keys | Sort-Object)) {
        $group = @($byKey[$key])
        # A statement a human has rejected is never the canonical answer while any
        # other candidate exists. Without this, correcting a fact by adding the right
        # statement and rejecting the wrong one silently leaves the wrong one in the
        # canonical spec - tier and evidence count tie, and the winner is then decided
        # by id, which is a hash. Rejection is the strongest signal in the store and
        # has to outrank extraction quality.
        # Then: highest tier; ties break on evidence count, then on id for determinism.
        $best = @($group | Sort-Object `
            @{ Expression = { if (@('changes-requested', 'superseded') -contains $_.review.status) { 1 } else { 0 } } }, `
            @{ Expression = { [Array]::IndexOf(@('A', 'B', 'C', 'D', 'E'), $_.tier) } }, `
            @{ Expression = { -1 * (AsArray $_.evidence).Count } }, `
            @{ Expression = { $_.id } })[0]
        [void]$facts.Add([ordered]@{
                fact_key     = $key
                value        = $best.value
                statement_id = $best.id
                tier         = $best.tier
                confidence   = $best.confidence
                supported_by = @($group | ForEach-Object { $_.id })
                contested    = $conflicted.ContainsKey($best.id)
            })
    }
    Write-JsonFile $Paths.Canonical ([ordered]@{
            artifact_id  = 'system-spec'
            version      = ('1.' + $facts.Count)
            generated_at = (Now)
            fact_count   = $facts.Count
            facts        = $facts.ToArray()
        })

    # --- evidence map: source -> statements -------------------------------- #
    $emap = [ordered]@{}
    foreach ($s in $statements) {
        foreach ($e in (AsArray $s.evidence)) {
            if (-not $emap.Contains($e.source_id)) { $emap[$e.source_id] = New-Object System.Collections.ArrayList }
            [void]$emap[$e.source_id].Add($s.id)
        }
    }
    $emapOut = [ordered]@{}
    foreach ($k in $emap.Keys) { $emapOut[$k] = @($emap[$k]) }
    Write-JsonFile $Paths.EvidenceMap ([ordered]@{
            version = $script:SPEC_VERSION; generated_at = (Now); map = $emapOut
        })

    # --- views -------------------------------------------------------------- #
    foreach ($viewName in $script:VIEWS) {
        $domain = $viewName -replace '-spec$', ''
        # A superseded statement drops out of the view, but only where a live statement
        # for the same fact remains. Excluding every rejected statement would let a
        # reviewer clear the gate by rejecting whatever blocked them; keeping them all
        # means a corrected fact blocks resolve forever, since the rejected value sits
        # below -MinStatus. Rejecting the *only* statement for a fact removes the fact
        # from the spec, and the constraint layer then reports it as a gap.
        $mine = @($statements | Where-Object {
                (AsArray $_.domains) -contains $domain -and -not (
                    @('changes-requested', 'superseded') -contains $_.review.status -and $hasLive[$_.fact_key]
                )
            })

        $sections = [ordered]@{}
        foreach ($s in $mine) {
            if (-not $sections.Contains($s.section)) { $sections[$s.section] = New-Object System.Collections.ArrayList }
            [void]$sections[$s.section].Add($s)
        }

        $sectionList = New-Object System.Collections.ArrayList
        foreach ($secName in ($sections.Keys | Sort-Object)) {
            $secStatements = @($sections[$secName])
            $blockedBy = New-Object System.Collections.ArrayList
            foreach ($s in $secStatements) {
                if ($conflicted.ContainsKey($s.id)) {
                    foreach ($c in $conflicts) { if ($c.statement_ids -contains $s.id) { [void]$blockedBy.Add($c.id) } }
                }
            }
            $uniqueBlocked = @($blockedBy | Sort-Object -Unique)
            [void]$sectionList.Add([ordered]@{
                    id         = $secName
                    title      = (Get-Culture).TextInfo.ToTitleCase(($secName -replace '-', ' '))
                    statements = @($secStatements | ForEach-Object { $_.id })
                    status     = $(if ($uniqueBlocked.Count -gt 0) { 'blocked' } else { 'needs-review' })
                    blocked_by = $uniqueBlocked
                })
        }

        Write-JsonFile (Get-ViewPath $Paths $viewName) ([ordered]@{
                artifact_id     = $viewName
                version         = ('1.' + $sectionList.Count)
                status          = 'needs-review'
                canonical_ref   = 'system-spec'
                generated_at    = (Now)
                statement_count = $mine.Count
                sections        = $sectionList.ToArray()
            })
    }

    Invoke-Render $Paths $statements $conflicts $srcIndex | Out-Null

    Write-Output ("built: {0} statement(s), {1} fact(s), {2} conflict(s), {3} view(s)" -f `
            $statements.Count, $facts.Count, $conflicts.Count, $script:VIEWS.Count)
}

function Invoke-Render($Paths, $Statements, $Conflicts, $SourceIndex) {
    $banner = "<!-- GENERATED FILE. DO NOT EDIT.`r`n" +
    "     Rebuilt by Spec.ps1 -Command build. Anything typed here is lost.`r`n" +
    "     To approve:  Spec.ps1 -Command review -Target <stmt-id> -Action approve -Actor <you> -->`r`n"

    foreach ($viewName in $script:VIEWS) {
        $view = Read-JsonFile (Get-ViewPath $Paths $viewName)
        if ($null -eq $view) { continue }
        $sb = New-Object System.Text.StringBuilder
        [void]$sb.Append($banner)
        [void]$sb.Append("`r`n# $viewName`r`n`r`n")
        [void]$sb.Append("Status: $($view.status) | Statements: $($view.statement_count) | Generated: $($view.generated_at)`r`n")
        foreach ($sec in (AsArray $view.sections)) {
            [void]$sb.Append("`r`n## $($sec.title)`r`n`r`n")
            if ($sec.status -eq 'blocked') {
                [void]$sb.Append("> BLOCKED by: $((AsArray $sec.blocked_by) -join ', ')`r`n`r`n")
            }
            [void]$sb.Append("| id | fact | value | tier | confidence | status |`r`n")
            [void]$sb.Append("|---|---|---|---|---|---|`r`n")
            foreach ($sid in (AsArray $sec.statements)) {
                $s = @($Statements | Where-Object { $_.id -eq $sid })[0]
                if ($null -eq $s) { continue }
                [void]$sb.Append(("| {0} | {1} | {2} | {3} | {4} | {5} |`r`n" -f `
                            $s.id, $s.fact_key, $s.value, $s.tier, $s.confidence, $s.review.status))
            }
        }
        Write-TextFile (Join-Path $Paths.ReviewDir ("{0}.md" -f $viewName)) $sb.ToString()
    }

    # --- summary with triage numbers --------------------------------------- #
    $total = @($Statements).Count
    $approved = @($Statements | Where-Object { $_.review.status -eq 'approved' }).Count
    $needs = @($Statements | Where-Object { $_.review.status -eq 'needs-review' }).Count
    $tierE = @($Statements | Where-Object { $_.tier -eq 'E' }).Count
    $lowConf = @($Statements | Where-Object { $_.confidence -eq 'low' }).Count
    $unrouted = @($Statements | Where-Object { $_.section -eq 'unrouted' }).Count

    $sum = New-Object System.Text.StringBuilder
    [void]$sum.Append($banner)
    [void]$sum.Append("`r`n# Review summary`r`n`r`n")
    [void]$sum.Append("| metric | count |`r`n|---|---|`r`n")
    [void]$sum.Append("| statements | $total |`r`n")
    [void]$sum.Append("| approved | $approved |`r`n")
    [void]$sum.Append("| needs review | $needs |`r`n")
    [void]$sum.Append("| tier E (always needs a human) | $tierE |`r`n")
    [void]$sum.Append("| low confidence | $lowConf |`r`n")
    [void]$sum.Append("| unrouted (no domain matched) | $unrouted |`r`n")
    $conflictCount = if ($null -eq $Conflicts) { 0 } else { $Conflicts.Count }
    [void]$sum.Append("| open conflicts | $conflictCount |`r`n")

    $notRead = @()
    foreach ($k in $SourceIndex.Keys) { if ($SourceIndex[$k].read_status -ne 'read') { $notRead += $SourceIndex[$k] } }
    [void]$sum.Append("`r`n## Sources that could not be read`r`n`r`n")
    if ($notRead.Count -eq 0) {
        [void]$sum.Append("None. Every registered source was read.`r`n")
    } else {
        [void]$sum.Append("| file | why not |`r`n|---|---|`r`n")
        foreach ($n in $notRead) { [void]$sum.Append(("| {0} | {1} |`r`n" -f $n.path, $n.reason)) }
    }

    if ($conflictCount -gt 0) {
        [void]$sum.Append("`r`n## Open conflicts`r`n`r`n")
        [void]$sum.Append("| id | fact | competing values |`r`n|---|---|---|`r`n")
        foreach ($c in $Conflicts) {
            [void]$sum.Append(("| {0} | {1} | {2} |`r`n" -f $c.id, $c.fact_key, ((AsArray $c.values) -join ' / ')))
        }
    }

    Write-TextFile $Paths.Summary $sum.ToString()
}

function Invoke-Resolve($Paths) {
    if (-not $View) { Fail '-View is required' 4 }
    if ($script:VIEWS -notcontains $View) { Fail ("unknown view '$View'. Known: " + ($script:VIEWS -join ', ')) 4 }
    if ($SkipStandards -and $RequireStandards) {
        Fail '-SkipStandards and -RequireStandards contradict each other' 4
    }

    $viewPath = Get-ViewPath $Paths $View
    $viewDoc = Read-JsonFile $viewPath
    if ($null -eq $viewDoc) { Fail "view '$View' has not been built - run build first" 4 }

    $store = Get-Store $Paths
    $byId = @{}
    foreach ($s in $store.statements) { $byId[$s.id] = $s }

    # --- constitution gate -------------------------------------------------- #
    # Read, never written, here. Check-Standards.ps1 owns out/compliance/. Putting the
    # gate at the front of resolve means a consumer that already calls resolve inherits
    # standards enforcement without changing a line of its own code.
    #
    # A violation blocks every view, not just the one it was routed to. A tier 1
    # application with a Replatform treatment is not broken in the devops view and fine
    # in the development view - it is broken, and nothing should be built from it.
    $standardsChecked = $false
    if (-not $SkipStandards) {
        $vio = Read-JsonFile $Paths.Violations
        if ($null -ne $vio) {
            $standardsChecked = $true
            $blocking = AsArray $vio.violations
            if ($blocking.Count -gt 0) {
                [Console]::Error.WriteLine("BLOCKED: $($blocking.Count) unresolved constitution finding(s):")
                foreach ($b in $blocking) {
                    [Console]::Error.WriteLine(("  [{0}] {1}  {2}" -f $b.kind, $b.rule_id, $b.message))
                }
                [Console]::Error.WriteLine('These cannot be cleared by approval. Fix the design, or record an exception:')
                [Console]::Error.WriteLine('  Check-Standards.ps1 -Command grant-exception -Target <rule-id> -Actor <you> -Approver <governance> -Rationale <why> -Expires <date>')
                exit 3
            }
        }
    }

    if ($RequireStandards -and -not $standardsChecked) {
        [Console]::Error.WriteLine('BLOCKED: -RequireStandards is set but no standards check has been run.')
        [Console]::Error.WriteLine("Expected findings at: $($Paths.Violations)")
        [Console]::Error.WriteLine('Run Check-Standards.ps1 -Command check with your rule pack first.')
        exit 3
    }

    $minRank = Get-StatusRank $MinStatus
    $blockedSections = @()
    $failing = New-Object System.Collections.ArrayList
    $resolved = New-Object System.Collections.ArrayList

    foreach ($sec in (AsArray $viewDoc.sections)) {
        if ($sec.status -eq 'blocked') { $blockedSections += $sec.id; continue }
        foreach ($sid in (AsArray $sec.statements)) {
            if (-not $byId.ContainsKey($sid)) {
                Fail "view references unknown statement '$sid' - canonical ref unresolvable" 4
            }
            $s = $byId[$sid]
            if ((Get-StatusRank $s.review.status) -lt $minRank) {
                [void]$failing.Add(("{0}  {1}  [{2}]" -f $s.id, $s.fact_key, $s.review.status))
            } else {
                [void]$resolved.Add([ordered]@{
                        id = $s.id; fact_key = $s.fact_key; value = $s.value
                        tier = $s.tier; confidence = $s.confidence; section = $sec.id
                        status = $s.review.status
                    })
            }
        }
    }

    if ($blockedSections.Count -gt 0) {
        [Console]::Error.WriteLine("BLOCKED: section(s) blocked by an open conflict: $($blockedSections -join ', ')")
        [Console]::Error.WriteLine('Resolve the conflict in the decision log, then rebuild.')
        exit 3
    }
    if ($failing.Count -gt 0) {
        [Console]::Error.WriteLine("BLOCKED: $($failing.Count) statement(s) below -MinStatus '$MinStatus':")
        foreach ($f in $failing) { [Console]::Error.WriteLine("  $f") }
        exit 3
    }
    if ($resolved.Count -eq 0) {
        [Console]::Error.WriteLine("No statements in view '$View'. Nothing to hand downstream.")
        exit 2
    }

    $payload = [ordered]@{
        view        = $View
        min_status  = $MinStatus
        resolved_at = (Now)
        count       = $resolved.Count
        # A consumer can tell the difference between "standards passed" and "standards
        # were never checked". Silence would let a forgotten check look like a clean run.
        standards_checked = $standardsChecked
        standards_skipped = [bool]$SkipStandards
        plan_hash   = (Get-StringSha256 (($resolved | ForEach-Object { $_.id + '=' + $_.value }) -join '|'))
        statements  = $resolved.ToArray()
    }

    if ($Format -eq 'json') {
        Write-Output ($payload | ConvertTo-Json -Depth 40)
    } else {
        Write-Output ("view {0}  {1} statement(s)  plan_hash {2}" -f $View, $resolved.Count, $payload.plan_hash)
        foreach ($r in $resolved) { Write-Output ("  {0}  {1} = {2}  [{3}]" -f $r.id, $r.fact_key, $r.value, $r.tier) }
    }
}

function Invoke-Review($Paths) {
    if (-not $Target) { Fail '-Target is required' 2 }
    if (-not $Action) { Fail '-Action is required' 2 }
    if (-not $Actor) { Fail '-Actor is required - an approval without a name is not an approval' 2 }

    $store = Get-Store $Paths
    $srcIndex = Get-SourceIndex $Paths
    $found = Set-ReviewDecision $Paths $store $srcIndex $Target $Action $Actor $Rationale
    Save-Store $Paths $store
    Write-Output ("{0} -> {1} by {2}" -f $Target, $found.review.status, $Actor)
}

# --------------------------------------------------------------------------- #
# Review sheet: the editable surface
# --------------------------------------------------------------------------- #
# out/review/*.md is regenerated on every build, so it cannot be edited. This is the
# one file a human is meant to change. It is never regenerated behind your back, and
# apply-review translates it into the same add-statement and review calls you would
# have typed - so the audit trail, the append-only store and the -Actor requirement
# all still hold. Editing a value here does not mutate a statement: it records a new
# human-asserted one and rejects the old.

function Get-SheetCells([string]$Line) {
    $parts = $Line.Split('|')
    $cells = New-Object System.Collections.ArrayList
    for ($i = 1; $i -lt $parts.Count - 1; $i++) { [void]$cells.Add($parts[$i].Trim()) }
    return $cells.ToArray()
}

function Invoke-ReviewSheet($Paths) {
    $store = Get-Store $Paths
    $statements = @($store.statements)
    if ($statements.Count -eq 0) { Fail 'no statements in the store - nothing to review' 2 }

    if ((Test-Path $Paths.Sheet) -and -not $Force) {
        Fail "a review sheet already exists at $($Paths.Sheet). Apply it, or use -Force to discard it." 5
    }

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("# Review sheet`r`n`r`n")
    [void]$sb.Append("Generated $(Now)  -  $($statements.Count) statement(s)`r`n`r`n")
    [void]$sb.Append("EDIT THIS FILE. It is the only file under out/ that is safe to edit.`r`n")
    [void]$sb.Append("Then run:  Spec.ps1 -Root <root> -Command apply-review -Actor <you>`r`n`r`n")
    [void]$sb.Append("## How to fill it in`r`n`r`n")
    [void]$sb.Append("- **decision**: ``approve``, ``reject``, or leave blank to skip`r`n")
    [void]$sb.Append("- **new value**: to correct a fact, put the right value here and give a reason.`r`n")
    [void]$sb.Append("  That records a new statement (tier A, human-asserted) and rejects this one.`r`n")
    [void]$sb.Append("- **reason**: required for ``reject`` and for any new value.`r`n")
    [void]$sb.Append("- Do not edit the id, fact or current value columns - they identify the row.`r`n`r`n")

    $bySection = [ordered]@{}
    foreach ($s in ($statements | Sort-Object section, fact_key)) {
        if (-not $bySection.Contains($s.section)) { $bySection[$s.section] = New-Object System.Collections.ArrayList }
        [void]$bySection[$s.section].Add($s)
    }

    foreach ($sec in $bySection.Keys) {
        [void]$sb.Append("`r`n## $sec`r`n`r`n")
        [void]$sb.Append("| id | fact | current value | tier | status | decision | new value | reason |`r`n")
        [void]$sb.Append("|---|---|---|---|---|---|---|---|`r`n")
        foreach ($s in $bySection[$sec]) {
            [void]$sb.Append(("| {0} | {1} | {2} | {3} | {4} |  |  |  |`r`n" -f `
                        $s.id, $s.fact_key, $s.value, $s.tier, $s.review.status))
        }
    }

    Write-TextFile $Paths.Sheet $sb.ToString()
    Write-Output ("review sheet written: {0}" -f $Paths.Sheet)
    Write-Output ("{0} statement(s) listed. Edit the decision column, then run apply-review." -f $statements.Count)
}

function Invoke-ApplyReview($Paths) {
    if (-not (Test-Path $Paths.Sheet)) {
        Fail "no review sheet at $($Paths.Sheet) - run 'review-sheet' first" 4
    }
    if (-not $Actor -and -not $DryRun) {
        Fail '-Actor is required - an approval without a name is not an approval' 2
    }

    $store = Get-Store $Paths
    $byId = @{}
    foreach ($s in $store.statements) { $byId[$s.id] = $s }

    # Parse and validate the whole sheet before touching anything. A sheet that is half
    # applied is worse than one that is rejected, because the reviewer cannot tell which
    # half landed.
    $plan = New-Object System.Collections.ArrayList
    $problems = New-Object System.Collections.ArrayList
    $lineNo = 0
    foreach ($line in (Get-Content -Path $Paths.Sheet -Encoding UTF8)) {
        $lineNo++
        if ($line -notmatch '^\s*\|\s*stmt-') { continue }
        $c = Get-SheetCells $line
        if ($c.Count -lt 8) { [void]$problems.Add("line ${lineNo}: expected 8 columns, found $($c.Count)"); continue }

        $id = $c[0]; $curValue = $c[2]
        $decision = $c[5].ToLowerInvariant(); $newValue = $c[6]; $reason = $c[7]

        if (-not $byId.ContainsKey($id)) { [void]$problems.Add("line ${lineNo}: unknown statement '$id'"); continue }
        if ($decision -eq '' -and $newValue -eq '') { continue }

        if ($decision -ne '' -and @('approve', 'reject') -notcontains $decision) {
            [void]$problems.Add("line ${lineNo}: decision must be 'approve', 'reject' or blank - found '$decision'")
            continue
        }
        if ($newValue -ne '') {
            if ($reason -eq '') { [void]$problems.Add("line ${lineNo}: a new value needs a reason"); continue }
            if ($newValue -eq $curValue) { [void]$problems.Add("line ${lineNo}: new value is the same as the current value"); continue }
            if ($decision -eq 'approve') { [void]$problems.Add("line ${lineNo}: cannot approve a statement and replace its value in the same row"); continue }
            [void]$plan.Add([ordered]@{ kind = 'replace'; id = $id; fact_key = $byId[$id].fact_key
                    old = $curValue; new = $newValue; reason = $reason })
            continue
        }
        if ($decision -eq 'reject' -and $reason -eq '') {
            [void]$problems.Add("line ${lineNo}: reject needs a reason")
            continue
        }
        [void]$plan.Add([ordered]@{ kind = $decision; id = $id; fact_key = $byId[$id].fact_key; reason = $reason })
    }

    if ($problems.Count -gt 0) {
        [Console]::Error.WriteLine("REFUSED: $($problems.Count) problem(s) in the review sheet. Nothing was applied.")
        foreach ($p in $problems) { [Console]::Error.WriteLine("  $p") }
        exit 2
    }
    if ($plan.Count -eq 0) {
        Write-Output 'review sheet has no decisions filled in - nothing to apply'
        return
    }

    foreach ($p in $plan) {
        switch ($p.kind) {
            'approve' { Write-Output ("  approve  {0}  {1}" -f $p.id, $p.fact_key) }
            'reject' { Write-Output ("  reject   {0}  {1}  ({2})" -f $p.id, $p.fact_key, $p.reason) }
            'replace' { Write-Output ("  replace  {0}  {1}: '{2}' -> '{3}'" -f $p.id, $p.fact_key, $p.old, $p.new) }
        }
    }
    if ($DryRun) {
        Write-Output ("`n{0} change(s) planned. -DryRun set, nothing applied." -f $plan.Count)
        return
    }

    $srcIndex = Get-SourceIndex $Paths
    $added = 0
    foreach ($p in $plan) {
        switch ($p.kind) {
            'approve' { $null = Set-ReviewDecision $Paths $store $srcIndex $p.id 'approve' $Actor $p.reason }
            'reject' { $null = Set-ReviewDecision $Paths $store $srcIndex $p.id 'request-changes' $Actor $p.reason }
            'replace' {
                # The locator and quote record that this came from a reviewer, not a
                # document, so the provenance stays honest.
                $locator = 'review sheet ' + (Now)
                $newId = New-StatementRecord $store $p.fact_key $p.new $script:HUMAN_SOURCE `
                    $locator $p.reason 'human-assertion' $null $null
                if ($null -ne $newId) { $added++ }
                $null = Set-ReviewDecision $Paths $store $srcIndex $p.id 'request-changes' $Actor `
                ("superseded by review sheet: " + $p.reason)
            }
        }
    }
    Save-Store $Paths $store

    if (-not (Test-Path $Paths.AppliedDir)) { New-Item -ItemType Directory -Path $Paths.AppliedDir -Force | Out-Null }
    $stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
    Move-Item -Path $Paths.Sheet -Destination (Join-Path $Paths.AppliedDir "review-sheet-$stamp.md") -Force

    Write-Output ("`napplied {0} decision(s) by {1}, {2} new statement(s)" -f $plan.Count, $Actor, $added)
    Invoke-Build $Paths
}

function Invoke-Verify($Paths) {
    $store = Get-Store $Paths
    $srcIndex = Get-SourceIndex $Paths
    $voided = 0
    foreach ($s in $store.statements) {
        if ($s.review.status -ne 'approved') { continue }
        $current = Get-BindingHash $s $srcIndex
        if ($current -ne $s.review.binding_hash) {
            $s.review.status = 'needs-review'
            $s.review.reason = 'source-changed'
            $s.review.binding_hash = $null
            $voided++
            Add-DecisionEntry $Paths ([ordered]@{
                    ts = (Now); actor = 'system'; action = 'auto-void'
                    target = $s.id; rationale = 'evidence hash changed since approval'
                })
        }
    }
    Save-Store $Paths $store
    Write-Output ("verify: {0} approval(s) voided by changed evidence" -f $voided)
}

function Invoke-Status($Paths) {
    $store = Get-Store $Paths
    $statements = @($store.statements)
    if ($statements.Count -eq 0) {
        Write-Output 'spec store is empty'
        return
    }
    $conflictsDoc = Read-JsonFile $Paths.Conflicts
    $conflictCount = 0
    if ($null -ne $conflictsDoc) {
        $conflicts = AsArray $conflictsDoc.conflicts
        $conflictCount = $conflicts.Count
    }

    Write-Output ("statements     {0}" -f $statements.Count)
    foreach ($st in $script:STATUS_ORDER) {
        $n = @($statements | Where-Object { $_.review.status -eq $st }).Count
        if ($n -gt 0) { Write-Output ("  {0,-18} {1}" -f $st, $n) }
    }
    foreach ($t in @('A', 'B', 'C', 'D', 'E')) {
        $n = @($statements | Where-Object { $_.tier -eq $t }).Count
        if ($n -gt 0) { Write-Output ("  tier {0,-13} {1}" -f $t, $n) }
    }
    Write-Output ("open conflicts {0}" -f $conflictCount)
}

# --------------------------------------------------------------------------- #
# Dispatch
# --------------------------------------------------------------------------- #

# Dot-sourcing loads the functions without running a command, which is how the
# unit tests reach the pure helpers.
if ($MyInvocation.InvocationName -ne '.') {
    $paths = Get-Paths $Root
    if ($Command -ne 'init' -and $Command -ne 'register-sources') {
        if (-not (Test-Path $paths.Statements)) {
            Fail "no spec store at $($paths.Statements) - run 'init' first" 4
        }
    }
    switch ($Command) {
        'init' { Invoke-Init $paths }
        'register-sources' { Invoke-RegisterSources $paths }
        'add-statement' { Invoke-AddStatement $paths }
        'build' { Invoke-Build $paths }
        'resolve' { Invoke-Resolve $paths }
        'review' { Invoke-Review $paths }
        'review-sheet' { Invoke-ReviewSheet $paths }
        'apply-review' { Invoke-ApplyReview $paths }
        'verify' { Invoke-Verify $paths }
        'status' { Invoke-Status $paths }
        default { Fail "unknown command '$Command'" 2 }
    }
    exit $script:ExitCode
}
