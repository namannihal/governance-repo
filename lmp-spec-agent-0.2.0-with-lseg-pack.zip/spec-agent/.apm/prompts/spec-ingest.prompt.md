---
mode: agent
description: "Read the intake documents, turn them into atomic statements with evidence, and build the canonical spec and its three views."
---

# /spec-ingest

Agent: [spec-builder](../agents/spec-builder.agent.md) |
Skill: [spec-layer](../skills/spec-layer/SKILL.md)

## Steps

1. **Register the sources.** This hashes every file and decides, per file, whether it
   could actually be read.

   ```
   Spec.ps1 -Root <root> -Command register-sources
   ```

   | Exit | Meaning |
   |---|---|
   | 0 | at least one file was readable |
   | 2 | nothing readable - **hard stop** |
   | 4 | no `src/` folder |

   Read the counts it prints. **If any file came back not-read, name those files to
   the user now.** Do not wait for the review summary. A scanned PDF or a cloud
   placeholder that nobody notices is how a whole subsystem goes missing from a spec.

2. **Get the vocabulary before you write any statement.** If an artifact catalogue
   exists for this programme (`lseg-artifact-views\*.view.json`), it owns the
   `fact_key` names for everything a downstream artifact needs:

   ```
   Get-CatalogueCoverage.ps1 -Catalogue <catalogue> -Root <root> -MissingOnly -Format json
   ```

   That returns each missing `fact_key` **with the question text it answers**. Use
   those keys verbatim for anything the catalogue covers.

   This is not tidiness. A fact filed under a key the catalogue does not know is
   invisible to the renderer: the answer sits in the spec, the questionnaire cell
   comes out blank, and it reads as missing evidence rather than as a naming
   mismatch. Where the catalogue has no key for something, invent a dotted key as
   usual.

3. **Read the extracted Markdown** under `out/intake/extracted/`, and add one statement
   per atomic fact using the source ids from the register:

   ```
   Spec.ps1 -Root <root> -Command add-statement -FactKey <key> -Value <value> `
     -SourceId <src-id> -Locator <where> -Quote <exact words> -Method <how>
   ```

   Rules that decide whether this is worth anything:

   - **One fact per statement.** If your `-Value` contains "and", split it.
   - **`-Quote` is the document's words**, not your paraphrase.
   - **`-Method` is chosen honestly.** It sets the tier, and you cannot set the tier
     directly. Reaching for `explicit-statement` to make the spec look confident is
     the failure mode here.
   - **A fact no document states gets no statement.** Absence is a finding. Do not
     invent an RTO because a plan will need one later.

3. **Build:**

   ```
   Spec.ps1 -Root <root> -Command build
   ```

   Deduplicates by `fact_key`, projects the views, detects conflicts, and
   regenerates everything under `out/review/`.

4. **Re-check catalogue coverage** if a catalogue is in play, and report the number.
   It is the honest measure of how much of a downstream artifact can actually be
   produced.

## Report

State plainly, in this order:

- how many sources could not be read, and which
- how many statements, and **how many are tier D or E** - this is the number that
  decides how much review is really needed
- catalogue coverage, where a catalogue applies
- how many open conflicts, and on which fact keys
- how many statements are unrouted

Then: "review `out/review/review-summary.md`, then run `/spec-review`."

## Never

- Approve anything. That is `/spec-review`, and it requires a named human.
- Edit files under `out/review/` - regenerated on every build.
- Fill a gap the documents left.
- Report a count without saying how much of it is weak.
