from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


REPO = Path(__file__).resolve().parents[1]


class GenerateAgentAssetsTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        (self.root / "scripts").mkdir()
        shutil.copyfile(REPO / "scripts/generate_agent_assets.py", self.root / "scripts/generate_agent_assets.py")
        source = self.root / "source/release-reviewer.agent.md"
        source.parent.mkdir()
        source.write_text("---\nname: release-reviewer\ndescription: Reviews releases.\n---\n", encoding="utf-8")
        (source.parent / "README.md").write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def run_generator(self, response: dict) -> subprocess.CompletedProcess[str]:
        response_path = self.root / "response.json"
        response_path.write_text(json.dumps(response), encoding="utf-8")
        return subprocess.run(
            [
                sys.executable,
                "scripts/generate_agent_assets.py",
                "--agent-file",
                "source/release-reviewer.agent.md",
                "--readme-file",
                "source/README.md",
                "--output-dir",
                "artifacts/agents/release-reviewer/.apm",
                "--plan",
                ".generated/release-reviewer-plan.json",
                "--response-file",
                "response.json",
            ],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_generates_capability_driven_assets_and_plan(self) -> None:
        generated = self.run_generator(
            {
                "rationale": "Release review needs one reusable analysis skill and one explicit workflow.",
                "skill": {
                    "name": "release-reviewer",
                    "description": "Analyzes release changes when deployment risk must be assessed.",
                    "body": "## Workflow\n\nReview changes and report evidence, risk, and mitigations.",
                },
                "prompts": [
                    {
                        "name": "review-release",
                        "description": "Starts a structured release risk review.",
                        "body": "Review the supplied release and return risks with evidence.",
                    }
                ],
                "instructions": [],
            }
        )

        self.assertEqual(generated.returncode, 0, generated.stderr)
        self.assertTrue(
            (self.root / "artifacts/agents/release-reviewer/.apm/skills/release-reviewer/SKILL.md").is_file()
        )
        self.assertTrue(
            (self.root / "artifacts/agents/release-reviewer/.apm/prompts/review-release.prompt.md").is_file()
        )
        self.assertFalse((self.root / "artifacts/agents/release-reviewer/.apm/instructions").exists())
        plan = json.loads((self.root / ".generated/release-reviewer-plan.json").read_text(encoding="utf-8"))
        self.assertEqual(
            [(asset["kind"], asset["id"]) for asset in plan["proposedAssets"]],
            [("skill", "release-reviewer"), ("prompt", "review-release")],
        )

    def test_rejects_response_without_mandatory_skill(self) -> None:
        generated = self.run_generator(
            {"rationale": "No capability was generated even though a skill is mandatory.", "prompts": [], "instructions": []}
        )

        self.assertEqual(generated.returncode, 1)
        self.assertIn("must produce one skill", generated.stderr)

    def test_offline_mode_generates_mandatory_skill_without_credentials(self) -> None:
        generated = subprocess.run(
            [
                sys.executable,
                "scripts/generate_agent_assets.py",
                "--agent-file",
                "source/release-reviewer.agent.md",
                "--readme-file",
                "source/README.md",
                "--output-dir",
                "artifacts/agents/release-reviewer/.apm",
                "--plan",
                ".generated/release-reviewer-plan.json",
                "--offline",
            ],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )

        self.assertEqual(generated.returncode, 0, generated.stderr)
        skill = self.root / "artifacts/agents/release-reviewer/.apm/skills/release-reviewer/SKILL.md"
        self.assertTrue(skill.is_file())
        self.assertIn("Reviews releases.", skill.read_text(encoding="utf-8"))

    def test_copilot_response_accepts_json_code_fence(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        parsed = namespace["parse_copilot_response"]('```json\n{"skill": {"name": "test"}}\n```')

        self.assertEqual(parsed, {"skill": {"name": "test"}})

    def test_copilot_response_extracts_json_from_cli_prose(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        parsed = namespace["parse_copilot_response"](
            'Generated package assets:\n```json\n{"skill": {"name": "test"}}\n```\nReview before publishing.'
        )

        self.assertEqual(parsed, {"skill": {"name": "test"}})

    def test_copilot_response_accepts_literal_line_breaks_in_strings(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        parsed = namespace["parse_copilot_response"](
            '{"rationale":"first line\nsecond line","skill":{"name":"test"}}'
        )

        self.assertEqual(parsed["rationale"], "first line\nsecond line")

    def test_copilot_response_rejects_multiple_package_objects(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        with self.assertRaisesRegex(ValueError, "multiple package JSON objects"):
            namespace["parse_copilot_response"](
                'First: {"skill": {"name": "one"}} Second: {"skill": {"name": "two"}}'
            )

    def test_copilot_response_selects_unique_complete_package(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        parsed = namespace["parse_copilot_response"](
            'Example: {"skill":{"name":"example"}} Result: '
            '{"rationale":"analysis","skill":{"name":"real"},"prompts":[],"instructions":[]}'
        )

        self.assertEqual(parsed["skill"]["name"], "real")

    def test_copilot_response_collapses_identical_complete_packages(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)
        package = '{"rationale":"analysis","skill":{"name":"same"},"prompts":[],"instructions":[]}'

        parsed = namespace["parse_copilot_response"](f"{package}\n{package}")

        self.assertEqual(parsed["skill"]["name"], "same")

    def test_copilot_response_rejects_conflicting_complete_packages(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)
        first = '{"rationale":"one","skill":{"name":"one"},"prompts":[],"instructions":[]}'
        second = '{"rationale":"two","skill":{"name":"two"},"prompts":[],"instructions":[]}'

        with self.assertRaisesRegex(ValueError, "multiple package JSON objects"):
            namespace["parse_copilot_response"](f"{first}\n{second}")

    @mock.patch("subprocess.run")
    def test_copilot_invocation_selects_model_and_disables_tools(self, run: mock.Mock) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)
        run.return_value = subprocess.CompletedProcess(
            args=[], returncode=0, stdout='{"skill": {"name": "test"}}', stderr=""
        )

        namespace["call_copilot"]("copilot", "gpt-5.4", "Return JSON")

        command = run.call_args.args[0]
        self.assertIn("--model", command)
        self.assertIn("gpt-5.4", command)
        self.assertIn("--stream=off", command)
        self.assertIn("--disable-builtin-mcps", command)
        self.assertIn("--deny-tool=write", command)
        self.assertEqual(run.call_args.kwargs["encoding"], "utf-8")

    @mock.patch("subprocess.run")
    def test_copilot_invocation_uses_current_selection_when_model_is_omitted(self, run: mock.Mock) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)
        run.return_value = subprocess.CompletedProcess(
            args=[], returncode=0, stdout='{"skill": {"name": "test"}}', stderr=""
        )

        namespace["call_copilot"]("copilot", None, "Return JSON")

        command = run.call_args.args[0]
        self.assertNotIn("--model", command)

    def test_current_model_flag_ignores_environment_override(self) -> None:
        script = REPO / "scripts/generate_agent_assets.py"
        namespace: dict[str, object] = {"__file__": str(script), "__name__": "generate_agent_assets_test"}
        exec(script.read_text(encoding="utf-8"), namespace)

        with mock.patch.dict("os.environ", {"COPILOT_MODEL": "environment-model"}):
            args = namespace["parse_args"](
                [
                    "--agent-file", "agent.agent.md",
                    "--readme-file", "README.md",
                    "--output-dir", "output",
                    "--plan", "plan.json",
                    "--use-current-model",
                ]
            )

        self.assertTrue(args.use_current_model)
        self.assertEqual(args.model, "environment-model")


if __name__ == "__main__":
    unittest.main()