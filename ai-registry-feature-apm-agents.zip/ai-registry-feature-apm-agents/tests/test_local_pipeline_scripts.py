from __future__ import annotations

import unittest
from pathlib import Path


REPO = Path(__file__).resolve().parents[1]


class LocalPipelineScriptTests(unittest.TestCase):
    def test_agent_pipeline_matches_generation_and_packaging_contract(self) -> None:
        script = (REPO / "scripts/Invoke-LocalAgentPipeline.ps1").read_text(encoding="utf-8")

        self.assertIn("scripts/validate_agent_source.py", script)
        self.assertIn("--validate-content", script)
        self.assertIn("scripts/generate_agent_assets.py", script)
        self.assertIn("scripts/scaffold_agent.py", script)
        self.assertIn("scripts/validate_artifacts.py", script)
        self.assertIn('"--offline"', script)
        self.assertIn('"--response-file"', script)
        self.assertIn('"--copilot-command", $CopilotCommand', script)
        self.assertIn('"--use-current-model"', script)
        self.assertIn("copilot-cli-current-selection", script)
        self.assertIn("does not accept or set a token", script)
        self.assertNotIn("CopilotToken", script)
        self.assertNotIn("Remove-Item $artifactDirectory", script)
        self.assertIn("Fresh generation will not delete or overwrite it", script)
        self.assertIn('"--plan", $relativePlan', script)
        self.assertIn("install --target copilot --no-policy --no-audit", script)
        self.assertIn("pack --archive", script)
        self.assertIn('"apm-cli==$ApmVersion"', script)
        self.assertIn(".github/agents/$agentId.agent.md", script)
        self.assertIn("exactly one <id>.agent.md file and README.md", script)
        self.assertIn("Invoke-LocalCatalogPipeline.ps1", script)
        self.assertIn("catalog/index.json", script)

    def test_catalog_pipeline_builds_indexes_and_static_site(self) -> None:
        script = (REPO / "scripts/Invoke-LocalCatalogPipeline.ps1").read_text(encoding="utf-8")

        self.assertIn("scripts/build_catalog.py", script)
        self.assertIn("scripts/build_catalog_site.py", script)
        self.assertIn("public/catalog.json", script)


if __name__ == "__main__":
    unittest.main()