from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from scripts.validate_agent_source import validate


REPO = Path(__file__).resolve().parents[1]


class ValidateAgentSourceTests(unittest.TestCase):
    def prepare_registry(self, root: Path) -> None:
        schemas = root / "schemas"
        schemas.mkdir()
        for name in ("agent-source.schema.json", "agent-readme-source.schema.json"):
            (schemas / name).write_bytes((REPO / "schemas" / name).read_bytes())
        (root / "apm-policy.yml").write_bytes((REPO / "apm-policy.yml").read_bytes())

    def test_accepts_two_files_in_one_repository_directory(self) -> None:
        self.assertEqual(validate("agent/release-reviewer.agent.md", "agent/README.md"), "release-reviewer")

    def test_rejects_parent_traversal(self) -> None:
        with self.assertRaisesRegex(ValueError, "normalized relative"):
            validate("../release-reviewer.agent.md", "../README.md")

    def test_rejects_files_in_different_directories(self) -> None:
        with self.assertRaisesRegex(ValueError, "share a directory"):
            validate("agent/release-reviewer.agent.md", "docs/README.md")

    def test_rejects_invalid_agent_id(self) -> None:
        with self.assertRaisesRegex(ValueError, "lowercase"):
            validate("agent/Release_Reviewer.agent.md", "agent/README.md")

    def test_validates_structured_frontmatter(self) -> None:
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.prepare_registry(root)
            source = root / "agent/release-reviewer.agent.md"
            source.parent.mkdir()
            source.write_text(
                "---\n"
                "schemaVersion: '1.0'\n"
                "name: release-reviewer\n"
                "description: Reviews release changes and reports deployment risks.\n"
                "capabilities:\n  builtInTools: [read, search]\n  mcpServers: []\n  apmDependencies: []\n"
                "permissions:\n  filesystem: read\n  shell: deny\n  network: deny\n"
                "  repository:\n    read: true\n    write: false\n"
                "  productionWrite: false\n  humanConfirmation:\n    requiredForWrites: true\n"
                "dataHandling:\n  classification: internal\n  processesPII: false\n"
                "  touchesCustomerData: false\n  storesPromptContent: false\n"
                "runtime:\n  targets: [copilot]\n"
                "---\n\nReview releases.\n",
                encoding="utf-8",
            )
            (source.parent / "README.md").write_text(
                "---\nschemaVersion: '1.0'\ntitle: Release Reviewer\n"
                "description: Reviews releases before production deployment.\n"
                "intendedAudience: [release engineers]\n"
                "primaryScenarios: [Review release readiness]\n"
                "limitations: [Does not deploy releases]\n---\n\n## Purpose\n",
                encoding="utf-8",
            )
            with patch("scripts.validate_agent_source.ROOT", root):
                self.assertEqual(
                    validate("agent/release-reviewer.agent.md", "agent/README.md", validate_content=True),
                    "release-reviewer",
                )

    def test_rejects_permission_capability_conflict(self) -> None:
        with TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.prepare_registry(root)
            source = root / "agent/release-reviewer.agent.md"
            source.parent.mkdir()
            source.write_text(
                "---\nschemaVersion: '1.0'\nname: release-reviewer\n"
                "description: Reviews release changes and reports deployment risks.\n"
                "capabilities:\n  builtInTools: [shell]\n  mcpServers: []\n  apmDependencies: []\n"
                "permissions:\n  filesystem: read\n  shell: deny\n  network: deny\n"
                "  repository:\n    read: true\n    write: false\n"
                "  productionWrite: false\n  humanConfirmation:\n    requiredForWrites: true\n"
                "dataHandling:\n  classification: internal\n  processesPII: false\n"
                "  touchesCustomerData: false\n  storesPromptContent: false\n"
                "runtime:\n  targets: [copilot]\n---\n",
                encoding="utf-8",
            )
            (source.parent / "README.md").write_text(
                "---\nschemaVersion: '1.0'\ntitle: Release Reviewer\n"
                "description: Reviews releases before production deployment.\n"
                "intendedAudience: [release engineers]\nprimaryScenarios: [Review release readiness]\n"
                "limitations: [Does not deploy releases]\n---\n",
                encoding="utf-8",
            )
            with patch("scripts.validate_agent_source.ROOT", root):
                with self.assertRaisesRegex(ValueError, "shell capability conflicts"):
                    validate("agent/release-reviewer.agent.md", "agent/README.md", validate_content=True)


if __name__ == "__main__":
    unittest.main()