from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


REPO = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "deploy_agent_to_consumer", REPO / "scripts/deploy_agent_to_consumer.py"
)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class DeployAgentToConsumerTests(unittest.TestCase):
    def test_allows_only_apm_and_standard_copilot_outputs(self) -> None:
        allowed = (
            "apm.yml",
            "apm.lock.yaml",
            ".github/agents/example.agent.md",
            ".github/prompts/example.prompt.md",
            ".github/instructions/example.instructions.md",
            ".agents/skills/example/SKILL.md",
        )
        self.assertTrue(all(MODULE.is_allowed(path) for path in allowed))

    def test_rejects_unrelated_consumer_paths(self) -> None:
        rejected = (
            "src/application.py",
            ".gitlab-ci.yml",
            ".github/workflows/build.yml",
            "README.md",
            "apm_modules/example/apm.yml",
        )
        self.assertTrue(all(not MODULE.is_allowed(path) for path in rejected))


if __name__ == "__main__":
    unittest.main()
