from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


REPO = Path(__file__).resolve().parents[1]


class BuildCatalogSiteTests(unittest.TestCase):
    def test_renders_searchable_escaped_catalog(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            script = root / "scripts/build_catalog_site.py"
            script.parent.mkdir()
            shutil.copyfile(REPO / "scripts/build_catalog_site.py", script)
            catalog = root / "catalog.json"
            output = root / "public/index.html"
            catalog.write_text(json.dumps({
                "catalogVersion": "1.0",
                "artifacts": [{
                    "displayName": "Review <Azure>",
                    "summary": "Checks IaC.",
                    "type": "agent",
                    "version": "1.0.0",
                    "status": "active",
                    "riskTier": 2,
                    "owner": "@platform/ai",
                    "securityReview": "approved",
                    "tags": ["azure", "iac"],
                    "install": '{"git":"https://gitlab.example.com/platform/ai-registry.git","path":"artifacts/agents/azure-iac-reviewer","ref":"azure-iac-reviewer--v1.0.0"}',
                }],
            }), encoding="utf-8")

            completed = subprocess.run(
                [sys.executable, str(script), "--input", str(catalog), "--output", str(output)],
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)
            page = output.read_text(encoding="utf-8")
            self.assertIn("Review &lt;Azure&gt;", page)
            self.assertIn("azure-iac-reviewer--v1.0.0", page)
            self.assertIn("&quot;path&quot;:&quot;artifacts/agents/azure-iac-reviewer&quot;", page)
            self.assertIn('id="search"', page)


if __name__ == "__main__":
    unittest.main()