from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml


REPO = Path(__file__).resolve().parents[1]


class ScaffoldAgentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        for relative in (
            "scripts/scaffold_agent.py",
            "scripts/validate_artifacts.py",
            "schemas/artifact.metadata.schema.json",
            "apm-policy.yml",
        ):
            destination = self.root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(REPO / relative, destination)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def run_scaffolder(self, agent_file: str, *extra: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                "scripts/scaffold_agent.py",
                "--agent-file",
                agent_file,
                "--owner-team",
                "@example/agent-team",
                "--owner-contact",
                "agent-team@example.com",
                "--source-repo",
                "https://gitlab.example.com/example/ai-registry",
                *extra,
            ],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_generates_package_that_passes_registry_validation(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\n"
            "name: release-reviewer\n"
            "description: Reviews release changes and reports deployment risks.\n"
            "tools: []\n"
            "---\n\n"
            "Review the supplied release changes.\n",
            encoding="utf-8",
        )
        (source.parent / "README.md").write_text(
            "---\n"
            "title: Release Readiness Reviewer\n"
            "description: Review releases before production deployment.\n"
            "---\n\n"
            "## Purpose\n\nReview release readiness.\n",
            encoding="utf-8",
        )

        generated = self.run_scaffolder(source.relative_to(self.root).as_posix())
        self.assertEqual(generated.returncode, 0, generated.stderr)

        artifact = self.root / "artifacts/agents/release-reviewer"
        self.assertTrue((artifact / ".apm/agents/release-reviewer.agent.md").exists())
        metadata = yaml.safe_load((artifact / "metadata.yml").read_text(encoding="utf-8"))
        self.assertEqual(metadata["displayName"], "Release Readiness Reviewer")
        self.assertEqual(metadata["summary"], "Review releases before production deployment.")
        self.assertEqual(metadata["riskTier"], 1)
        self.assertEqual(metadata["provenance"]["sourceRepo"], "https://gitlab.example.com/example/ai-registry")
        manifest = yaml.safe_load((artifact / "apm.yml").read_text(encoding="utf-8"))
        self.assertEqual(manifest["author"], "@example/agent-team")
        self.assertEqual(manifest["includes"], [".apm/agents/release-reviewer.agent.md"])
        self.assertEqual(
            (artifact / "README.md").read_text(encoding="utf-8"),
            (source.parent / "README.md").read_text(encoding="utf-8"),
        )

        validated = subprocess.run(
            [sys.executable, "scripts/validate_artifacts.py", "artifacts/agents/release-reviewer"],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(validated.returncode, 0, validated.stdout + validated.stderr)

    def test_rejects_frontmatter_name_that_differs_from_filename(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nname: other-agent\ndescription: Reviews release changes for deployment risks.\n---\n",
            encoding="utf-8",
        )
        (source.parent / "README.md").write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )

        generated = self.run_scaffolder(source.relative_to(self.root).as_posix())

        self.assertEqual(generated.returncode, 1)
        self.assertIn("frontmatter name must be 'release-reviewer'", generated.stderr)

    def test_rejects_generated_files_in_authoring_folder(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nname: release-reviewer\ndescription: Reviews release deployment risks.\n---\n",
            encoding="utf-8",
        )
        (source.parent / "README.md").write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )
        (source.parent / "metadata.yml").write_text("generated: true\n", encoding="utf-8")

        generated = self.run_scaffolder(source.relative_to(self.root).as_posix())

        self.assertEqual(generated.returncode, 1)
        self.assertIn("may contain only release-reviewer.agent.md and README.md", generated.stderr)

    def test_rejects_missing_consumer_readme(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nname: release-reviewer\ndescription: Reviews release deployment risks.\n---\n",
            encoding="utf-8",
        )

        generated = self.run_scaffolder(source.relative_to(self.root).as_posix())

        self.assertEqual(generated.returncode, 1)
        self.assertIn("consumer README must exist", generated.stderr)

    def test_external_source_preserves_registry_composition(self) -> None:
        source = self.root / ".agent-source/agent/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nname: release-reviewer\ndescription: Reviews release deployment risks.\ntools: []\n---\n",
            encoding="utf-8",
        )
        readme = source.parent / "README.md"
        readme.write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )
        stale = self.root / "artifacts/agents/release-reviewer/.apm/prompts/stale.prompt.md"
        stale.parent.mkdir(parents=True)
        stale.write_text("stale\n", encoding="utf-8")
        (stale.parents[2] / "apm.yml").write_text(
            "# Generated by scripts/scaffold_agent.py.\n"
            "name: release-reviewer\n"
            "includes:\n"
            "  - .apm/agents/release-reviewer.agent.md\n"
            "  - .apm/prompts/stale.prompt.md\n"
            "dependencies:\n"
            "  apm: []\n"
            "  mcp:\n"
            "    - example/mcp-server\n",
            encoding="utf-8",
        )

        generated = self.run_scaffolder(
            source.relative_to(self.root).as_posix(),
            "--readme-file",
            readme.relative_to(self.root).as_posix(),
            "--source-ref",
            "a" * 40,
            "--source-path",
            "agent/release-reviewer.agent.md",
            "--registry-repo",
            "https://gitlab.example.com/platform/ai-registry",
            "--force",
        )

        self.assertEqual(generated.returncode, 0, generated.stderr)
        artifact = self.root / "artifacts/agents/release-reviewer"
        metadata = yaml.safe_load((artifact / "metadata.yml").read_text(encoding="utf-8"))
        self.assertEqual(metadata["provenance"]["sourceRef"], "a" * 40)
        self.assertEqual(metadata["provenance"]["sourcePath"], "agent/release-reviewer.agent.md")
        self.assertIn("platform/ai-registry", metadata["install"]["apmReference"])
        self.assertNotIn("example/ai-registry\"", metadata["install"]["apmReference"])
        self.assertTrue(stale.exists())
        manifest = yaml.safe_load((artifact / "apm.yml").read_text(encoding="utf-8"))
        self.assertIn(".apm/prompts/stale.prompt.md", manifest["includes"])
        self.assertEqual(manifest["dependencies"]["mcp"], ["example/mcp-server"])

    def test_records_ai_generation_provenance_from_package_plan(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nname: release-reviewer\ndescription: Reviews release deployment risks.\n---\n",
            encoding="utf-8",
        )
        (source.parent / "README.md").write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )
        skill = self.root / "artifacts/agents/release-reviewer/.apm/skills/release-reviewer/SKILL.md"
        skill.parent.mkdir(parents=True)
        skill.write_text(
            "---\nname: release-reviewer\ndescription: Reviews deployment risk when a release is proposed.\n---\n\nReview risk.\n",
            encoding="utf-8",
        )
        plan = self.root / "release-reviewer-plan.json"
        plan.write_text(
            '{"agentId":"release-reviewer","proposedAssets":['
            '{"kind":"skill","id":"release-reviewer","disposition":"bundled"}]}\n',
            encoding="utf-8",
        )

        generated = self.run_scaffolder(
            source.relative_to(self.root).as_posix(),
            "--consumer-project-id",
            "1234",
            "--consumer-target-branch",
            "main",
            "--plan",
            plan.relative_to(self.root).as_posix(),
            "--generation-model",
            "approved-model",
            "--generation-prompt-version",
            "1.0",
        )

        self.assertEqual(generated.returncode, 0, generated.stderr)
        metadata = yaml.safe_load(
            (self.root / "artifacts/agents/release-reviewer/metadata.yml").read_text(encoding="utf-8")
        )
        self.assertEqual(
            metadata["generation"],
            {
                "method": "ai",
                "provider": "github-copilot",
                "model": "approved-model",
                "promptVersion": "1.0",
                "reviewRequired": True,
            },
        )
        self.assertEqual(
            metadata["delivery"],
            {
                "projectId": "1234",
                "targetBranch": "main",
                "mode": "merge-request",
                "target": "copilot",
            },
        )
        validated = subprocess.run(
            [sys.executable, "scripts/validate_artifacts.py", "artifacts/agents/release-reviewer"],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(validated.returncode, 0, validated.stdout + validated.stderr)

    def test_derives_governance_from_structured_source(self) -> None:
        source = self.root / "agents/release-reviewer/release-reviewer.agent.md"
        source.parent.mkdir(parents=True)
        source.write_text(
            "---\nschemaVersion: '1.0'\nname: release-reviewer\n"
            "description: Reviews release changes and reports deployment risks.\n"
            "capabilities:\n  builtInTools: [read, search]\n"
            "  mcpServers: [io.github.github/github-mcp-server]\n"
            "  apmDependencies: [gitlab.example.com/platform/review-rules@1.0.0]\n"
            "permissions:\n  filesystem: read\n  shell: deny\n  network: restricted\n"
            "  repository:\n    read: true\n    write: false\n"
            "  productionWrite: false\n  humanConfirmation:\n    requiredForWrites: true\n"
            "dataHandling:\n  classification: confidential\n  processesPII: false\n"
            "  touchesCustomerData: false\n  storesPromptContent: false\n"
            "runtime:\n  targets: [copilot, cursor]\n---\n\nReview releases.\n",
            encoding="utf-8",
        )
        (source.parent / "README.md").write_text(
            "---\ntitle: Release Reviewer\ndescription: Reviews releases before deployment.\n---\n",
            encoding="utf-8",
        )

        generated = self.run_scaffolder(source.relative_to(self.root).as_posix())
        self.assertEqual(generated.returncode, 0, generated.stderr)
        artifact = self.root / "artifacts/agents/release-reviewer"
        metadata = yaml.safe_load((artifact / "metadata.yml").read_text(encoding="utf-8"))
        manifest = yaml.safe_load((artifact / "apm.yml").read_text(encoding="utf-8"))
        self.assertEqual(metadata["classification"], "confidential")
        self.assertEqual(metadata["riskTier"], 2)
        self.assertEqual(metadata["targets"], ["copilot", "cursor"])
        self.assertEqual(metadata["tools"]["allowedTools"], ["read", "search"])
        self.assertEqual(metadata["permissions"]["network"], "restricted")
        self.assertFalse(metadata["dataHandling"]["storesPromptContent"])
        self.assertEqual(manifest["dependencies"]["mcp"], ["io.github.github/github-mcp-server"])
        self.assertEqual(
            manifest["dependencies"]["apm"],
            ["gitlab.example.com/platform/review-rules@1.0.0"],
        )


if __name__ == "__main__":
    unittest.main()