from __future__ import annotations

import unittest
from pathlib import Path

import yaml


REPO = Path(__file__).resolve().parents[1]


class GitLabPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.pipeline = yaml.safe_load((REPO / ".gitlab-ci.yml").read_text(encoding="utf-8"))

    def test_pipeline_accepts_web_and_downstream_drafts(self) -> None:
        rules = self.pipeline["workflow"]["rules"]
        self.assertEqual(rules[0]["if"], '$CI_PIPELINE_SOURCE == "web" && $PIPELINE_MODE == "draft"')
        self.assertEqual(rules[1]["if"], '$CI_PIPELINE_SOURCE == "pipeline" && $PIPELINE_MODE == "draft"')
        self.assertIn("CI_DEFAULT_BRANCH", rules[2]["if"])
        self.assertEqual(rules[3], {"when": "never"})

    def test_pipeline_fetches_external_developer_repository(self) -> None:
        variables = self.pipeline["variables"]
        for name in (
            "AGENT_REPO_URL",
            "AGENT_REPO_REF",
            "AGENT_FILE",
            "AGENT_README_FILE",
            "AGENT_OWNER_TEAM",
            "AGENT_OWNER_CONTACT",
            "AGENT_CONSUMER_PROJECT_ID",
            "AGENT_CONSUMER_TARGET_BRANCH",
        ):
            self.assertIn(name, variables)
        fetch_script = "\n".join(self.pipeline["fetch-agent-source"]["script"])
        self.assertIn("scripts/validate_agent_source.py", fetch_script)
        self.assertIn('git clone --no-checkout "$AGENT_REPO_URL"', fetch_script)
        self.assertIn("gitlab-ci-token", fetch_script)
        self.assertIn("git -C .agent-repo archive HEAD", fetch_script)

    def test_pipeline_generates_ai_assets_and_opens_draft_merge_request(self) -> None:
        generate_script = "\n".join(self.pipeline["generate-agent-package"]["script"])
        generate_before_script = "\n".join(self.pipeline["generate-agent-package"]["before_script"])
        self.assertIn("--validate-content", generate_script)
        self.assertIn("python3-jsonschema", generate_before_script)
        self.assertIn("scripts/generate_agent_assets.py", generate_script)
        self.assertIn("COPILOT_GITHUB_TOKEN", generate_script)
        self.assertIn("COPILOT_MODEL", generate_script)
        self.assertIn('--plan ".generated/$AGENT_ID-plan.json"', generate_script)
        self.assertLess(
            generate_script.index('test ! -e "artifacts/agents/$AGENT_ID"'),
            generate_script.index("scripts/generate_agent_assets.py"),
        )
        self.assertNotIn('rm -rf "artifacts/agents/$AGENT_ID"', generate_script)
        self.assertIn("Fresh generation will not delete or overwrite it", generate_script)
        self.assertIn('--readme-file ".agent-source/$AGENT_README_FILE"', generate_script)
        self.assertIn('--source-path "$AGENT_FILE"', generate_script)
        self.assertIn('--registry-repo "$CI_PROJECT_URL"', generate_script)
        draft_script = "\n".join(self.pipeline["create-agent-draft"]["script"])
        self.assertIn("merge_request.create", draft_script)
        self.assertIn("Producer and required security/governance reviewers", draft_script)
        self.assertEqual(self.pipeline["generate-agent-package"]["image"], "node:22-bookworm-slim")
        generate_setup = "\n".join(self.pipeline["generate-agent-package"]["before_script"])
        self.assertIn("@github/copilot@$COPILOT_CLI_VERSION", generate_setup)

    def test_pipeline_publishes_only_merged_default_branch_packages(self) -> None:
        publish_rules = self.pipeline[".publish-rules"]["rules"]
        self.assertIn("CI_DEFAULT_BRANCH", publish_rules[0]["if"])
        publish_script = "\n".join(self.pipeline["publish-agent-package"]["script"])
        self.assertIn("CI_COMMIT_BEFORE_SHA", publish_script)
        self.assertIn("apm install --target copilot --no-policy --no-audit", publish_script)
        self.assertIn("apm pack --archive", publish_script)
        self.assertNotIn("apm pack --format apm", publish_script)
        self.assertIn("packages/generic/$AGENT_ID/$AGENT_VERSION", publish_script)
        self.assertIn("python scripts/build_catalog.py", publish_script)
        self.assertIn("dist/changed-agent-ids.txt", publish_script)
        self.assertLess(publish_script.index("Release tag already exists"), publish_script.index("python scripts/build_catalog.py"))

    def test_pipeline_deploys_approved_release_through_consumer_merge_request(self) -> None:
        deploy = self.pipeline["deploy-agent-to-consumer"]
        self.assertEqual(deploy["stage"], "deploy")
        self.assertIn("publish-agent-package", deploy["needs"][0]["job"])
        deploy_script = "\n".join(deploy["script"])
        self.assertIn("CONSUMER_DELIVERY_TOKEN", deploy_script)
        self.assertIn("scripts/deploy_agent_to_consumer.py", deploy_script)
        self.assertIn("dist/changed-agent-ids.txt", deploy_script)
        self.assertNotIn("CI_DEFAULT_BRANCH", deploy_script)

    def test_consumer_template_triggers_registry_for_agent_changes(self) -> None:
        template = yaml.safe_load(
            (REPO / "templates/gitlab/agent-producer.gitlab-ci.yml").read_text(encoding="utf-8")
        )
        job = template["produce-copilot-agent"]
        self.assertEqual(job["stage"], ".post")
        self.assertEqual(job["trigger"]["strategy"], "depend")
        self.assertEqual(job["variables"]["AGENT_REPO_REF"], "$CI_COMMIT_SHA")
        self.assertEqual(job["variables"]["AGENT_CONSUMER_PROJECT_ID"], "$CI_PROJECT_ID")
        self.assertEqual(job["variables"]["AGENT_CONSUMER_TARGET_BRANCH"], "$CI_DEFAULT_BRANCH")
        self.assertEqual(job["variables"]["AGENT_REPO_USE_CI_JOB_TOKEN"], "true")
        self.assertIn("agents/**/*", job["rules"][0]["changes"])


if __name__ == "__main__":
    unittest.main()