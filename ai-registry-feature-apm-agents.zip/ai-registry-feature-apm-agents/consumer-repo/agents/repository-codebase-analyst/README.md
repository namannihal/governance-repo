---
schemaVersion: "1.0"
title: Repository Codebase Analyst
description: Explains local repository architecture, dependencies, execution paths, and change impact using read-only analysis.
intendedAudience:
  - Software engineers
  - Technical leads
primaryScenarios:
  - Trace repository execution paths
  - Assess change impact
  - Explain architecture and dependencies
limitations:
  - Does not modify repository files
  - Does not execute commands or access external services
---

## Repository Codebase Analyst

Analyze an unfamiliar or complex repository without changing files. The agent follows
concrete code paths, connects implementation to tests and configuration, and separates
verified behavior from assumptions.

## When to use it

Use this agent to:

* Explain how a feature or subsystem works
* Trace an API, event, command, or user flow through the codebase
* Identify module boundaries and dependency relationships
* Find the code that controls a reported behavior
* Assess the impact of a proposed repository-scoped change
* Locate relevant tests, configuration, and integration points
* Prepare evidence-backed implementation steps

## Expected output

The agent returns a focused explanation of the controlling execution path, important
modules, repository evidence, dependencies, constraints, risks, and unknowns. Material
conclusions include repository-relative file or symbol references.

## Tools and limitations

The agent requests only the host-provided `read` and `search` tools. It does not require
an MCP server, execute commands, modify files, call external services, or publish changes.
The consuming Copilot environment must provide compatible read and search capabilities.

## Risk and review

The generated package is expected to derive risk tier 2 because runtime tools are present,
even though the agent is read-only. Registry generation adds the mandatory skill and may
add focused prompts or instructions when the capability analysis finds distinct workflows
or broadly applicable rules. Human review remains required before publication.

## Producer contract

The developer-owned source consists only of this README and
`repository-codebase-analyst.agent.md`. The registry pipeline generates the APM manifest,
governance metadata, changelog, mandatory skill, and any capability-driven prompts or
instructions.
