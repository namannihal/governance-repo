---
schemaVersion: "1.0"
title: Azure IaC Reviewer
description: Reviews Azure Bicep and Terraform changes for security, cost, and policy issues.
intendedAudience:
  - Cloud engineers
  - Infrastructure reviewers
primaryScenarios:
  - Review Bicep pull request changes
  - Review Terraform pull request changes
  - Identify Azure security cost and policy risks
limitations:
  - Does not apply or merge infrastructure changes
  - Requires an approved GitHub MCP server for pull request context
---

## Azure IaC Reviewer

> Reviews Azure Bicep/Terraform IaC changes for security, cost and policy issues in a PR.

## What it does

A read-only reviewer persona that inspects infrastructure-as-code diffs and comments with
severity-ranked, actionable findings. It never applies changes.

## When to use it

Select this agent when asked to review Bicep or Terraform changes in a pull request.

## Install

```bash
apm install contoso/ai-artifact-registry/artifacts/agents/azure-iac-reviewer#v1.0.0
```

## Tools / MCP

* `read`, `search`
* `io.github.github/github-mcp-server` (to read PR diffs)

All allow-listed in [`apm-policy.yml`](../../../apm-policy.yml).

## Risk & ownership

* Risk tier 2 (uses MCP tools; read-only, no production writes)
* Owned by `@contoso/platform-ai` ([platform-ai@contoso.com](mailto:platform-ai@contoso.com))
* Adapted from `github/awesome-copilot/agents/azure-iac-generator.agent.md`
