---
schemaVersion: "1.0"
title: GitHub Actions Pipeline Creator
description: Creates secure GitHub Actions workflows for continuous integration, release, and deployment.
intendedAudience:
  - Software engineers
  - DevOps engineers
primaryScenarios:
  - Create GitHub Actions workflows
  - Review workflow security and reliability
  - Design protected release and deployment automation
limitations:
  - Does not dispatch workflows or deploy software without confirmation
  - Requires an approved GitHub MCP server for remote repository context
---

## GitHub Actions Pipeline Creator

Build and review GitHub Actions workflows with explicit permissions, immutable dependencies,
repeatable artifacts, protected deployments, and repository-specific validation steps.

## When to use it

Use this agent to create or improve workflows under `.github/workflows/`, including:

* Pull-request validation
* Build and test automation
* Security and dependency scanning
* Release packaging and provenance
* Environment-based deployment pipelines
* Reusable workflows and workflow-call contracts

## Producer contract

The developer repository contains only this README and
`devops-pipeline-creator.agent.md`. The registry pipeline generates governance metadata and
combines the agent with approved prompts, instructions, and skills.

## Tools and MCP

* `read` and `search` for repository inspection
* `io.github.github/github-mcp-server` for GitHub repository and pull-request context

The agent generates workflow definitions and guidance. It does not dispatch workflows or
deploy software without explicit confirmation.
