<!-- Thanks for contributing an AI artifact! Complete this checklist before requesting review. -->

## What does this PR do?
<!-- New artifact / change / deprecation. Which artifact(s)? -->

## Artifact details
- **Type:** agent / skill / prompt / instruction / chatmode
- **ID:** `artifacts/<type>/<id>`
- **Version:** `x.y.z`
- **Risk tier:** 1 / 2 / 3
- **Change kind (SemVer):** MAJOR / MINOR / PATCH

## Author checklist
- [ ] Folder name == `metadata.yml:id` == `apm.yml:name` (lowercase-hyphen)
- [ ] `metadata.yml` complete and valid (`python scripts/validate_artifacts.py <path>`)
- [ ] `version` matches across `apm.yml`, `metadata.yml`, and top of `CHANGELOG.md`
- [ ] Primitive under `.apm/` has valid frontmatter (`name`/`description`)
- [ ] `README.md` explains what it does and when to use it
- [ ] `CHANGELOG.md` updated
- [ ] Dependencies pinned to tags; all tools/MCP allow-listed in `apm-policy.yml`
- [ ] No secrets or customer data in content, examples or scripts
- [ ] `owner.team` matches `.github/CODEOWNERS`

## Security (required for risk tier 3 or any `shell`/`bash` tool)
- [ ] Security review completed and recorded in `metadata.yml:compliance` (`securityReview: approved`, `reviewedBy` set)
- [ ] Every referenced script reviewed line-by-line

## Reviewer notes
<!-- Anything reviewers should pay special attention to. -->
