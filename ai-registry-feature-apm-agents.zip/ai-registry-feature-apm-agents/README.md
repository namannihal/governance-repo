---
title: AI Artifact Registry
description: Governed GitLab registry for APM agent packages and reusable AI artifacts
---

A governed registry of AI artifacts for GitHub Copilot and other supported runtimes,
hosted and released through GitLab and distributed with
**[APM (Agent Package Manager)](https://microsoft.github.io/apm/)**.

An agent developer authors one `*.agent.md` file and one `README.md` in a developer
repository. The developer pipeline sends the exact source commit and both paths to the
downstream registry pipeline. GitHub Copilot CLI uses the selected Copilot model to
generate a capability-driven package draft and opens a registry merge request. After
approval, CI publishes an immutable package and opens a developer merge request with the
standard Copilot runtime files.

---

## Why this registry exists

Teams have been hand-crafting Copilot instructions, prompts, skills and agents and copying them between repos, where they silently drift. This registry gives AI agent configuration the same treatment we give code: **a manifest, a lockfile, metadata, review, and CI**.

- **One source of truth** for approved Copilot artifacts across the org.
- **Reproducible** — consumers pin to a tag or commit SHA; APM records a content hash in `apm.lock.yaml`.
- **Governed** — every artifact carries owner, lifecycle, security classification and review metadata (`metadata.yml`), enforced by CI against a JSON Schema.
- **Portable** — artifacts are authored once under `.apm/` and compile to Copilot (`.github/`) and, where relevant, Claude, Cursor, Codex, Gemini and more.

## What lives here

The registry currently publishes one agent package under `artifacts/agents/`. An agent
package can bundle its own prompts, instructions, and skills under `.apm/`; those
assets are versioned and released with the owning agent rather than published as
duplicate top-level packages.

Each artifact is a **self-contained APM package**: an `apm.yml` distribution manifest, a `metadata.yml` governance sidecar, a `README.md`, a `CHANGELOG.md`, and the primitive source under `.apm/`.

## Repository layout

```text
ai-artifact-registry/
├── README.md                     # You are here
├── CONTRIBUTING.md               # PR-based contribution workflow
├── CHANGELOG.md                  # Registry-level changelog
├── LICENSE
├── apm-policy.yml                # Enterprise APM policy (allow-listed sources, MCP, primitives)
├── .gitignore                    # ignores apm_modules/ (build cache)
│
├── schemas/                      # JSON Schemas that CI enforces
│   └── artifact.metadata.schema.json
│
├── templates/                    # Copy-paste starting points, one per artifact type
│   ├── agent/  skill/  prompt/  instruction/  chatmode/
│
├── artifacts/                    # Generated packages, one folder per published artifact
│   ├── agents/<id>/
│   └── agents/<id>/.apm/         # Bundled prompts, instructions, and skills
│
├── catalog/                      # Generated index of everything (do not hand-edit)
│   ├── index.json
│   └── index.md
│
├── docs/                         # Getting started, authoring guides, governance
├── scripts/                      # validate_artifacts.py, build_catalog.py
└── .github/                      # CODEOWNERS, PR/issue templates, CI workflows
```

## Consuming an artifact

Install the [APM CLI](https://microsoft.github.io/apm/), then pull any artifact by its path, **pinned to a tag**:

```bash
# Install a single agent from this GitLab registry
apm install '{"git":"https://gitlab.example.com/platform/ai-registry.git","path":"artifacts/agents/azure-iac-reviewer","ref":"azure-iac-reviewer--v1.0.0"}'

apm install            # resolve everything in your repo's apm.yml
```

APM clones the GitLab registry, verifies the content hash, and compiles the primitive
into the configured runtime directories. See
**[docs/consuming-artifacts.md](docs/consuming-artifacts.md)**.

## Contributing an artifact

In the developer repository, create one folder containing `<your-id>.agent.md` and
`README.md` according to the
**[Agent Producer Contract](docs/agent-producer-contract.md)**. Include the reusable
consumer bridge job in the developer project's GitLab configuration. A normal developer
pipeline passes the exact commit to the protected registry pipeline, which generates
and validates the package and opens a draft merge request under
`artifacts/agents/<your-id>/`. After approval, CI creates an immutable release, refreshes
the catalog, installs the pinned package into a developer branch, and opens a developer
merge request containing the standard Copilot runtime files. See
**[docs/gitlab-agent-onboarding.md](docs/gitlab-agent-onboarding.md)**.

The default-branch pipeline also publishes the generated catalog through GitLab Pages.
The JSON and Markdown indexes remain source-controlled release records; the Pages site
adds search and copyable pinned install references.

Full workflow and quality bar: **[CONTRIBUTING.md](CONTRIBUTING.md)**.

## Governance at a glance

- **Ownership** — every artifact names an accountable team in `metadata.yml` and CODEOWNERS.
- **Lifecycle** — `experimental → beta → active → deprecated → retired`.
- **Risk tiers** — tier 1 (read-only) to tier 3 (shell / prod / customer data). Tier drives required approvals and review cadence.
- **Security** — APM scans every install for hidden Unicode and prompt-injection payloads (`apm audit`); the enterprise `apm-policy.yml` allow-lists sources, primitives and MCP servers.

See **[docs/governance.md](docs/governance.md)**, **[docs/security.md](docs/security.md)** and **[docs/versioning.md](docs/versioning.md)**.
