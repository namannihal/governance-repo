[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$SourceDirectory,

    [Parameter(Mandatory)]
    [string]$OwnerTeam,

    [Parameter(Mandatory)]
    [string]$OwnerContact,

    [string]$Version = "1.0.0",
    [string]$SourceRepo = "https://example.invalid/developer/agent-source.git",
    [string]$RegistryRepo = "https://example.invalid/platform/ai-registry.git",
    [string]$SourceRef = "local-smoke-test",
    [string]$PythonCommand = "python",
    [string]$ApmCommand = "apm",
    [string]$ApmVersion = "0.22.0",
    [string]$AiResponseFile = "",
    [string]$CopilotCommand = "copilot",
    [switch]$Offline
)

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$source = (Resolve-Path $SourceDirectory).Path
$relativeSource = [IO.Path]::GetRelativePath($repoRoot, $source)

if ($Offline -and $AiResponseFile) {
    throw "Use either -Offline or -AiResponseFile, not both. Omit both to use the current GitHub Copilot CLI model selection."
}

if (-not $Offline -and -not $AiResponseFile -and -not (Get-Command $CopilotCommand -ErrorAction SilentlyContinue)) {
    throw "GitHub Copilot CLI '$CopilotCommand' was not found. Install and authenticate it, or use -Offline."
}

if (-not (Get-Command $ApmCommand -ErrorAction SilentlyContinue)) {
    $apmEnvironment = Join-Path $repoRoot ".local-test/tools/apm-cli-$ApmVersion"
    $apmExecutable = Join-Path $apmEnvironment "Scripts/apm.exe"
    if (-not (Test-Path $apmExecutable -PathType Leaf)) {
        Write-Host "[setup] Installing pinned APM CLI $ApmVersion"
        & $PythonCommand -m venv $apmEnvironment
        if ($LASTEXITCODE -ne 0) { throw "Unable to create the local APM Python environment." }
        & (Join-Path $apmEnvironment "Scripts/python.exe") -m pip install --quiet "apm-cli==$ApmVersion"
        if ($LASTEXITCODE -ne 0) { throw "Unable to install apm-cli==$ApmVersion." }
    }
    $ApmCommand = $apmExecutable
}

if ([IO.Path]::IsPathRooted($relativeSource) -or $relativeSource -eq ".." -or $relativeSource.StartsWith("..$([IO.Path]::DirectorySeparatorChar)")) {
    throw "SourceDirectory must be inside the registry checkout for this local rehearsal."
}

$agentFiles = @(Get-ChildItem -Path $source -Filter "*.agent.md" -File)
$allFiles = @(Get-ChildItem -Path $source -File)
$readme = Join-Path $source "README.md"
if ($agentFiles.Count -ne 1 -or -not (Test-Path $readme -PathType Leaf) -or $allFiles.Count -ne 2) {
    throw "SourceDirectory must contain exactly one <id>.agent.md file and README.md."
}

$agentFile = $agentFiles[0]
$agentId = $agentFile.Name -replace "\.agent\.md$", ""
$relativeAgent = [IO.Path]::GetRelativePath($repoRoot, $agentFile.FullName).Replace("\", "/")
$relativeReadme = [IO.Path]::GetRelativePath($repoRoot, $readme).Replace("\", "/")

Write-Host "[1/6] Validating the two-file producer contract"
& $PythonCommand (Join-Path $repoRoot "scripts/validate_agent_source.py") $relativeAgent $relativeReadme --validate-content
if ($LASTEXITCODE -ne 0) { throw "Source validation failed." }

Write-Host "[2/6] Generating AI package plan, assets, metadata, and APM sources"
$artifactDirectory = Join-Path $repoRoot "artifacts/agents/$agentId"
$relativeArtifactApm = "artifacts/agents/$agentId/.apm"
$relativePlan = ".generated/$agentId-plan.json"
if (Test-Path $artifactDirectory) {
    throw "Artifact already exists: $artifactDirectory. Fresh generation will not delete or overwrite it."
}

$generatorArgs = @(
    (Join-Path $repoRoot "scripts/generate_agent_assets.py"),
    "--agent-file", $relativeAgent,
    "--readme-file", $relativeReadme,
    "--output-dir", $relativeArtifactApm,
    "--plan", $relativePlan
)
$generationModel = "copilot-cli-current-selection"
if ($AiResponseFile) {
    $resolvedResponse = (Resolve-Path $AiResponseFile).Path
    $relativeResponse = [IO.Path]::GetRelativePath($repoRoot, $resolvedResponse).Replace("\", "/")
    if ([IO.Path]::IsPathRooted($relativeResponse) -or $relativeResponse -eq ".." -or $relativeResponse.StartsWith("../")) {
        throw "AiResponseFile must be inside the registry checkout."
    }
    $generatorArgs += @("--response-file", $relativeResponse)
    $generationModel = "local-saved-response"
}
elseif ($Offline) {
    $generatorArgs += "--offline"
    $generationModel = "local-deterministic-simulator"
}
else {
    $generatorArgs += @("--copilot-command", $CopilotCommand, "--use-current-model")
    Write-Host "      Using the authenticated Copilot CLI and its current model selection; this script does not accept or set a token."
}
& $PythonCommand @generatorArgs
if ($LASTEXITCODE -ne 0) { throw "AI asset generation failed." }

$scaffoldArgs = @(
    (Join-Path $repoRoot "scripts/scaffold_agent.py"),
    "--agent-file", $relativeAgent,
    "--readme-file", $relativeReadme,
    "--owner-team", $OwnerTeam,
    "--owner-contact", $OwnerContact,
    "--version", $Version,
    "--source-repo", $SourceRepo,
    "--source-ref", $SourceRef,
    "--source-path", $relativeAgent,
    "--registry-repo", $RegistryRepo,
    "--created-by", "local-smoke-test",
    "--plan", $relativePlan,
    "--generation-model", $generationModel,
    "--generation-prompt-version", "1.0",
    "--force"
)
& $PythonCommand @scaffoldArgs
if ($LASTEXITCODE -ne 0) { throw "Package generation failed." }

& $PythonCommand (Join-Path $repoRoot "scripts/validate_artifacts.py") $artifactDirectory
if ($LASTEXITCODE -ne 0) { throw "Generated artifact validation failed." }

Write-Host "[3/6] Resolving and packing the generated APM package"
$testRoot = Join-Path $repoRoot ".local-test/$agentId"
$packSource = Join-Path $testRoot "pack-source"
$packageOutput = Join-Path $testRoot "package"
$consumer = Join-Path $testRoot "consumer"
Remove-Item $testRoot -Recurse -Force -ErrorAction SilentlyContinue
New-Item $packSource -ItemType Directory -Force | Out-Null
New-Item $packageOutput -ItemType Directory -Force | Out-Null
Copy-Item (Join-Path $artifactDirectory "*") $packSource -Recurse -Force

Push-Location $packSource
try {
    & $ApmCommand install --target copilot --no-policy --no-audit
    if ($LASTEXITCODE -ne 0) { throw "APM dependency resolution failed." }
    & $ApmCommand pack --archive -o $packageOutput
    if ($LASTEXITCODE -ne 0) { throw "APM archive creation failed." }
}
finally {
    Pop-Location
}

$archive = Get-ChildItem $packageOutput -Filter "*.zip" -File | Select-Object -First 1
if (-not $archive) { throw "APM did not create a ZIP archive." }

Write-Host "[4/6] Installing the ZIP as a clean consumer"
New-Item $consumer -ItemType Directory -Force | Out-Null
Push-Location $consumer
try {
    & $ApmCommand install $archive.FullName --target copilot
    if ($LASTEXITCODE -ne 0) { throw "Consumer installation failed." }
}
finally {
    Pop-Location
}

$installedAgent = Join-Path $consumer ".github/agents/$agentId.agent.md"
if (-not (Test-Path $installedAgent -PathType Leaf)) {
    throw "Consumer verification failed: $installedAgent was not installed."
}

Write-Host "[5/6] Rebuilding the metadata-driven catalog"
& (Join-Path $PSScriptRoot "Invoke-LocalCatalogPipeline.ps1") -PythonCommand $PythonCommand
if ($LASTEXITCODE -ne 0) { throw "Catalog generation failed." }

Write-Host "[6/6] Local agent publication rehearsal passed" -ForegroundColor Green
Write-Host "Metadata: $artifactDirectory\metadata.yml"
Write-Host "Manifest: $artifactDirectory\apm.yml"
Write-Host "Plan:     $(Join-Path $repoRoot $relativePlan)"
Write-Host "Archive:  $($archive.FullName)"
Write-Host "Consumer: $consumer"
Write-Host "Catalog:  $(Join-Path $repoRoot 'catalog/index.json')"
