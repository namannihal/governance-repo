#!/usr/bin/env python3
"""Render a self-contained static registry catalog from catalog/index.json."""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "catalog" / "index.json"
DEFAULT_OUTPUT = ROOT / "public" / "index.html"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build the static AI Registry catalog page.")
    parser.add_argument("--input", default=str(DEFAULT_INPUT))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    return parser.parse_args()


def escaped(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


def render_card(artifact: dict) -> str:
    tags = "".join(f'<span class="tag">{escaped(tag)}</span>' for tag in artifact.get("tags") or [])
    install = escaped(artifact.get("install"))
    search = escaped(" ".join(str(value) for value in (
        artifact.get("displayName"), artifact.get("summary"), artifact.get("type"),
        artifact.get("owner"), " ".join(artifact.get("tags") or []),
    )))
    return f"""
      <article class="artifact" data-search="{search.lower()}">
        <header>
          <div>
            <p class="kind">{escaped(artifact.get('type'))}</p>
            <h2>{escaped(artifact.get('displayName'))}</h2>
          </div>
          <span class="version">v{escaped(artifact.get('version'))}</span>
        </header>
        <p class="summary">{escaped(artifact.get('summary'))}</p>
        <div class="tags">{tags}</div>
        <dl>
          <div><dt>Status</dt><dd>{escaped(artifact.get('status'))}</dd></div>
          <div><dt>Risk tier</dt><dd>{escaped(artifact.get('riskTier'))}</dd></div>
          <div><dt>Owner</dt><dd>{escaped(artifact.get('owner'))}</dd></div>
          <div><dt>Security</dt><dd>{escaped(artifact.get('securityReview'))}</dd></div>
        </dl>
        <label>APM install reference</label>
        <div class="install-row">
          <code>{install}</code>
          <button type="button" data-copy="{install}" aria-label="Copy install reference" title="Copy install reference">Copy</button>
        </div>
      </article>"""


def render(index: dict) -> str:
    artifacts = index.get("artifacts") or []
    cards = "\n".join(render_card(artifact) for artifact in artifacts)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Governed APM agent packages available from the AI Registry.">
  <title>AI Registry</title>
  <style>
    :root {{ --ink:#17211b; --muted:#5b665f; --paper:#f4f7f2; --surface:#fff; --line:#cbd5cd; --accent:#096b4b; --accent-soft:#dcefe6; --focus:#d15420; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; color:var(--ink); background:linear-gradient(135deg,#edf3ee 0,#f8faf6 48%,#eef2e9 100%); font-family:Aptos,"Segoe UI",sans-serif; min-height:100vh; }}
    .masthead {{ border-bottom:1px solid var(--line); background:rgba(255,255,255,.82); }}
    .masthead-inner, main {{ width:min(1120px,calc(100% - 32px)); margin:auto; }}
    .masthead-inner {{ min-height:108px; display:flex; align-items:center; justify-content:space-between; gap:24px; }}
    .eyebrow, .kind {{ margin:0 0 6px; color:var(--accent); font-size:.75rem; font-weight:700; text-transform:uppercase; }}
    h1, h2 {{ margin:0; font-family:Georgia,"Times New Roman",serif; font-weight:600; letter-spacing:0; }}
    h1 {{ font-size:clamp(2rem,6vw,3.4rem); }}
    .count {{ color:var(--muted); white-space:nowrap; }}
    main {{ padding:32px 0 64px; }}
    .toolbar {{ display:grid; grid-template-columns:minmax(0,1fr) auto; align-items:center; gap:16px; margin-bottom:24px; }}
    input {{ width:100%; min-height:44px; border:1px solid var(--line); border-radius:6px; padding:10px 14px; color:var(--ink); background:var(--surface); font:inherit; }}
    input:focus {{ outline:3px solid rgba(209,84,32,.25); border-color:var(--focus); }}
    .grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr)); gap:18px; }}
    .artifact {{ border:1px solid var(--line); border-radius:8px; background:var(--surface); padding:22px; box-shadow:0 12px 28px rgba(35,57,43,.07); }}
    .artifact header {{ display:flex; justify-content:space-between; align-items:flex-start; gap:18px; }}
    h2 {{ font-size:1.45rem; }}
    .version {{ border:1px solid var(--line); border-radius:999px; padding:4px 8px; color:var(--muted); font-size:.8rem; }}
    .summary {{ min-height:48px; color:var(--muted); line-height:1.5; }}
    .tags {{ min-height:28px; display:flex; flex-wrap:wrap; gap:6px; }}
    .tag {{ border-radius:4px; padding:4px 7px; background:var(--accent-soft); color:#07553d; font-size:.75rem; }}
    dl {{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin:20px 0; }}
    dl div {{ border-top:1px solid var(--line); padding-top:8px; }}
    dt, label {{ color:var(--muted); font-size:.74rem; text-transform:uppercase; font-weight:700; }}
    dd {{ margin:3px 0 0; }}
    .install-row {{ display:grid; grid-template-columns:minmax(0,1fr) auto; gap:8px; margin-top:7px; }}
    code {{ overflow:auto; padding:10px; border-radius:5px; background:#18231d; color:#e8f4eb; white-space:nowrap; }}
    button {{ border:0; border-radius:5px; padding:0 14px; background:var(--accent); color:#fff; font:inherit; font-weight:700; cursor:pointer; }}
    button:focus-visible {{ outline:3px solid var(--focus); outline-offset:2px; }}
    .empty {{ display:none; padding:36px 0; color:var(--muted); }}
    @media (max-width:620px) {{ .masthead-inner,.toolbar {{ align-items:stretch; grid-template-columns:1fr; }} .masthead-inner {{ padding:24px 0; flex-direction:column; }} dl {{ grid-template-columns:1fr; }} .install-row {{ grid-template-columns:1fr; }} button {{ min-height:42px; }} }}
  </style>
</head>
<body>
  <header class="masthead"><div class="masthead-inner"><div><p class="eyebrow">Governed APM packages</p><h1>AI Registry</h1></div><p class="count"><strong id="visible-count">{len(artifacts)}</strong> of {len(artifacts)} artifacts</p></div></header>
  <main>
    <div class="toolbar"><input id="search" type="search" placeholder="Search agents, owners, or tags" aria-label="Search catalog"><span>Catalog v{escaped(index.get('catalogVersion'))}</span></div>
    <section class="grid" id="catalog" aria-live="polite">{cards}</section>
    <p class="empty" id="empty">No artifacts match your search.</p>
  </main>
  <script>
    const search = document.querySelector('#search');
    const cards = [...document.querySelectorAll('.artifact')];
    const count = document.querySelector('#visible-count');
    const empty = document.querySelector('#empty');
    search.addEventListener('input', () => {{
      const query = search.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {{ const show = card.dataset.search.includes(query); card.hidden = !show; visible += show ? 1 : 0; }});
      count.textContent = visible; empty.style.display = visible ? 'none' : 'block';
    }});
    document.addEventListener('click', async event => {{
      const button = event.target.closest('[data-copy]'); if (!button) return;
      await navigator.clipboard.writeText(button.dataset.copy); button.textContent = 'Copied';
      window.setTimeout(() => button.textContent = 'Copy', 1200);
    }});
  </script>
</body>
</html>
"""


def main() -> int:
    args = parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)
    index = json.loads(input_path.read_text(encoding="utf-8"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render(index), encoding="utf-8", newline="\n")
    print(f"Wrote {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())