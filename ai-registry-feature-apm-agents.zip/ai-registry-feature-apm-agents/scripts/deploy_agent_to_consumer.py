#!/usr/bin/env python3
"""Install one approved registry agent into its consumer project and open a merge request."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.parse
import urllib.request
from pathlib import Path

import yaml


ALLOWED_OUTPUTS = (
    "apm.yml",
    "apm.lock.yaml",
    ".github/agents",
    ".github/prompts",
    ".github/instructions",
    ".agents/skills",
)


def run(*args: str, cwd: Path | None = None, extra_config: tuple[str, str] | None = None) -> str:
    command = ["git"]
    if extra_config:
        command.extend(["-c", f"{extra_config[0]}={extra_config[1]}"])
    command.extend(args)
    completed = subprocess.run(command, cwd=cwd, check=True, text=True, capture_output=True)
    return completed.stdout.strip()


def api_post(url: str, token: str, fields: dict[str, str]) -> None:
    request = urllib.request.Request(
        url,
        data=urllib.parse.urlencode(fields).encode("utf-8"),
        headers={"PRIVATE-TOKEN": token},
        method="POST",
    )
    with urllib.request.urlopen(request) as response:
        if response.status not in (200, 201):
            raise RuntimeError(f"GitLab merge request API returned HTTP {response.status}")


def api_get(url: str, token: str) -> dict:
    request = urllib.request.Request(url, headers={"PRIVATE-TOKEN": token})
    with urllib.request.urlopen(request) as response:
        return json.load(response)


def changed_paths(checkout: Path) -> list[str]:
    output = run("status", "--porcelain=v1", "-z", cwd=checkout)
    paths: list[str] = []
    entries = output.split("\0") if output else []
    index = 0
    while index < len(entries):
        entry = entries[index]
        if not entry:
            index += 1
            continue
        status = entry[:2]
        paths.append(entry[3:])
        if "R" in status or "C" in status:
            if index + 1 < len(entries) and entries[index + 1]:
                paths.append(entries[index + 1])
            index += 2
        else:
            index += 1
    return paths


def is_allowed(path: str) -> bool:
    normalized = path.replace("\\", "/")
    return any(normalized == allowed or normalized.startswith(f"{allowed}/") for allowed in ALLOWED_OUTPUTS)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("package_dir", type=Path)
    parser.add_argument("--workspace", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    package_dir = args.package_dir.resolve()
    metadata = yaml.safe_load((package_dir / "metadata.yml").read_text(encoding="utf-8"))
    apm = yaml.safe_load((package_dir / "apm.yml").read_text(encoding="utf-8"))
    delivery = metadata.get("delivery") or {}
    token = os.environ.get("CONSUMER_DELIVERY_TOKEN", "")
    api_url = os.environ.get("CI_API_V4_URL", "")
    pipeline_iid = os.environ.get("CI_PIPELINE_IID", "local")
    if not token or not api_url:
        raise ValueError("CONSUMER_DELIVERY_TOKEN and CI_API_V4_URL are required")

    project_id = str(delivery["projectId"])
    target_branch = delivery["targetBranch"]
    agent_id = metadata["id"]
    version = apm["version"]
    branch = f"apm-deploy/{agent_id}-v{version}-{pipeline_iid}"
    package_reference = metadata["install"]["apmReference"]
    project = api_get(f"{api_url}/projects/{urllib.parse.quote(project_id, safe='')}", token)
    source_repo = project["http_url_to_repo"]
    run("check-ref-format", "--branch", target_branch)

    checkout = args.workspace.resolve()
    if checkout.exists():
        shutil.rmtree(checkout)
    checkout.parent.mkdir(parents=True, exist_ok=True)
    auth_header = ("http.extraHeader", f"PRIVATE-TOKEN: {token}")
    run("clone", "--branch", target_branch, "--single-branch", source_repo, str(checkout), extra_config=auth_header)

    subprocess.run(
        ["apm", "install", package_reference, "--target", "copilot", "--no-policy", "--no-audit"],
        cwd=checkout,
        check=True,
    )
    shutil.rmtree(checkout / "apm_modules", ignore_errors=True)

    paths = changed_paths(checkout)
    unexpected = sorted(path for path in paths if not is_allowed(path))
    if unexpected:
        raise RuntimeError(f"APM changed files outside the approved deployment paths: {unexpected}")
    if not paths:
        print(f"Consumer project already contains {agent_id} {version}; no merge request needed.")
        return 0

    run("config", "user.name", "AI Registry Pipeline", cwd=checkout)
    run("config", "user.email", f"ai-registry-pipeline@{urllib.parse.urlsplit(api_url).hostname}", cwd=checkout)
    run("checkout", "-b", branch, cwd=checkout)
    run("add", "--all", cwd=checkout)
    run("commit", "-m", f"chore(copilot): install {agent_id} {version}", cwd=checkout)
    run("push", "origin", f"HEAD:{branch}", cwd=checkout, extra_config=auth_header)

    api_post(
        f"{api_url}/projects/{urllib.parse.quote(project_id, safe='')}/merge_requests",
        token,
        {
            "source_branch": branch,
            "target_branch": target_branch,
            "title": f"Install approved Copilot agent: {agent_id} {version}",
            "description": (
                f"Installs the approved, immutable registry release `{agent_id}--v{version}` "
                "with APM into the standard Copilot runtime paths."
            ),
            "remove_source_branch": "true",
        },
    )
    print(json.dumps({"projectId": project_id, "branch": branch, "agent": agent_id, "version": version}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
