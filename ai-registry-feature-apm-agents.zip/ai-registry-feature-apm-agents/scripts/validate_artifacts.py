#!/usr/bin/env python3
"""Validate registry artifacts against structure, metadata schema and policy rules.

Runs in CI (see .github/workflows/validate.yml) and locally:

    python scripts/validate_artifacts.py                     # validate everything
    python scripts/validate_artifacts.py artifacts/agents/azure-iac-reviewer   # one artifact

Uses PyYAML (required) and jsonschema (optional — full schema validation when present;
built-in checks always run so the script works air-gapped).

Exit code 0 = all good, 1 = one or more errors.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("ERROR: PyYAML is required. `pip install pyyaml`.", file=sys.stderr)
    sys.exit(2)

try:
    import jsonschema  # type: ignore
    HAVE_JSONSCHEMA = True
except ImportError:
    HAVE_JSONSCHEMA = False

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "schemas" / "artifact.metadata.schema.json"
POLICY_PATH = ROOT / "apm-policy.yml"
ARTIFACTS_DIR = ROOT / "artifacts"

# metadata.type -> (artifacts/<folder>, .apm/<primitive_dir>, primitive filename suffix)
TYPE_MAP = {
    "agent":       ("agents",       "agents",       ".agent.md"),
    "skill":       ("skills",       "skills",       "SKILL.md"),
    "prompt":      ("prompts",      "prompts",      ".prompt.md"),
    "instruction": ("instructions", "instructions", ".instructions.md"),
    "chatmode":    ("chatmodes",    "chatmodes",    ".chatmode.md"),
}
REQUIRED_FILES = ["apm.yml", "metadata.yml", "README.md", "CHANGELOG.md"]


class Reporter:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def error(self, artifact: str, msg: str) -> None:
        self.errors.append(f"{artifact}: {msg}")

    def warn(self, artifact: str, msg: str) -> None:
        self.warnings.append(f"{artifact}: {msg}")


def load_yaml(path: Path):
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def parse_frontmatter(path: Path):
    text = path.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    if not m:
        return None
    return yaml.safe_load(m.group(1)) or {}


def changelog_top_version(path: Path):
    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^##\s*\[?(\d+\.\d+\.\d+)\]?", line.strip())
        if m:
            return m.group(1)
    return None


def load_policy_allowed_mcp():
    if not POLICY_PATH.exists():
        return None
    pol = load_yaml(POLICY_PATH) or {}
    return set((pol.get("mcp") or {}).get("allow") or [])


def validate_metadata_schema(meta: dict, artifact: str, rep: Reporter) -> None:
    """Full jsonschema validation when the lib is present."""
    if not HAVE_JSONSCHEMA:
        return
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = jsonschema.Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(meta), key=lambda e: e.path):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        rep.error(artifact, f"metadata schema: {loc}: {err.message}")


def builtin_metadata_checks(meta: dict, artifact: str, rep: Reporter) -> None:
    """Schema-independent checks so the script is useful without jsonschema."""
    required = [
        "schemaVersion", "id", "name", "displayName", "type", "version", "summary",
        "owner", "lifecycle", "classification", "riskTier", "targets", "license",
        "provenance", "compliance",
    ]
    for field in required:
        if meta.get(field) in (None, "", [], {}):
            rep.error(artifact, f"metadata missing required field '{field}'")

    if meta.get("schemaVersion") != "1.0":
        rep.error(artifact, "metadata schemaVersion must be '1.0'")
    if meta.get("type") not in TYPE_MAP and meta.get("type") != "plugin":
        rep.error(artifact, f"metadata type '{meta.get('type')}' is not a known type")
    if meta.get("riskTier") not in (1, 2, 3):
        rep.error(artifact, "metadata riskTier must be 1, 2 or 3")
    if meta.get("classification") not in ("public", "internal", "confidential", "highly-confidential"):
        rep.error(artifact, "metadata classification is invalid")
    status = (meta.get("lifecycle") or {}).get("status")
    if status not in ("experimental", "beta", "active", "deprecated", "retired"):
        rep.error(artifact, "metadata lifecycle.status is invalid")
    if status in ("deprecated", "retired") and not (meta.get("lifecycle") or {}).get("supersededBy"):
        rep.warn(artifact, "deprecated/retired artifact should set lifecycle.supersededBy")
    if not re.match(r"^\d+\.\d+\.\d+$", str(meta.get("version", ""))):
        rep.error(artifact, "metadata version must be SemVer x.y.z")


def policy_checks(meta: dict, artifact: str, allowed_mcp, rep: Reporter) -> None:
    tools = meta.get("tools") or {}
    compliance = meta.get("compliance") or {}
    review = compliance.get("securityReview")

    # shell/bash pre-approval requires an approved security review
    allowed_tools = [str(t).lower() for t in (tools.get("allowedTools") or [])]
    if any(t in ("shell", "bash") for t in allowed_tools):
        if review != "approved":
            rep.error(artifact, "allowed-tools includes shell/bash but compliance.securityReview != approved")
        if meta.get("riskTier", 1) < 2:
            rep.error(artifact, "allowed-tools includes shell/bash but riskTier < 2")

    # tier 3 requires an approved security review
    if meta.get("riskTier") == 3 and review != "approved":
        rep.error(artifact, "riskTier 3 requires compliance.securityReview == approved")

    # every required MCP server must be allow-listed in apm-policy.yml
    if allowed_mcp is not None:
        declared = set(tools.get("requiredMcpServers") or []) | set(
            (meta.get("dependencies") or {}).get("mcp") or []
        )
        for srv in declared:
            if srv not in allowed_mcp:
                rep.error(artifact, f"MCP server '{srv}' is not allow-listed in apm-policy.yml")


def review_date_check(meta: dict, artifact: str, rep: Reporter) -> None:
    comp = meta.get("compliance") or {}
    last, cadence, nxt = comp.get("lastReviewed"), comp.get("reviewCadenceDays"), comp.get("nextReviewDue")
    if last and cadence and nxt:
        try:
            last_d = dt.date.fromisoformat(str(last))
            expected = last_d + dt.timedelta(days=int(cadence))
            if str(nxt) != expected.isoformat():
                rep.warn(artifact, f"nextReviewDue {nxt} != lastReviewed + cadence ({expected.isoformat()})")
        except (ValueError, TypeError):
            rep.warn(artifact, "could not parse review dates")


def validate_artifact(folder: Path, rep: Reporter) -> None:
    artifact = folder.relative_to(ROOT).as_posix()

    for fname in REQUIRED_FILES:
        if not (folder / fname).exists():
            rep.error(artifact, f"missing required file '{fname}'")

    apm_path, meta_path = folder / "apm.yml", folder / "metadata.yml"
    if not (apm_path.exists() and meta_path.exists()):
        return  # can't do deeper checks

    try:
        apm = load_yaml(apm_path) or {}
        meta = load_yaml(meta_path) or {}
    except yaml.YAMLError as exc:
        rep.error(artifact, f"YAML parse error: {exc}")
        return

    validate_metadata_schema(meta, artifact, rep)
    builtin_metadata_checks(meta, artifact, rep)

    # folder == id == name
    if meta.get("id") != folder.name:
        rep.error(artifact, f"metadata.id '{meta.get('id')}' != folder name '{folder.name}'")
    if meta.get("name") != apm.get("name"):
        rep.error(artifact, f"metadata.name '{meta.get('name')}' != apm.yml name '{apm.get('name')}'")

    # version consistency across the three files
    versions = {
        "apm.yml": str(apm.get("version", "")).strip(),
        "metadata.yml": str(meta.get("version", "")).strip(),
        "CHANGELOG.md": changelog_top_version(folder / "CHANGELOG.md") if (folder / "CHANGELOG.md").exists() else None,
    }
    distinct = {v for v in versions.values() if v}
    if len(distinct) > 1:
        rep.error(artifact, f"version mismatch across files: {versions}")

    # license consistency
    if apm.get("license") and meta.get("license") and apm["license"] != meta["license"]:
        rep.error(artifact, f"license mismatch apm.yml={apm['license']} metadata.yml={meta['license']}")

    includes = apm.get("includes") or []
    if not isinstance(includes, list) or not all(isinstance(include, str) for include in includes):
        rep.error(artifact, "apm.yml includes must be an array of paths")
        includes = []
    for include in includes:
        include_path = folder / include.rstrip("/")
        if not include.startswith(".apm/") or ".." in Path(include).parts:
            rep.error(artifact, f"invalid include path '{include}'")
        elif not include_path.exists():
            rep.error(artifact, f"included path does not exist: '{include}'")

    generation = meta.get("generation") or {}
    if generation.get("method") == "ai":
        generated_skills = list((folder / ".apm" / "skills").glob("*/SKILL.md"))
        if not generated_skills:
            rep.error(artifact, "AI-generated agent package must contain at least one skill")

    # primitive presence + frontmatter
    mtype = meta.get("type")
    if mtype in TYPE_MAP:
        expected_parent = TYPE_MAP[mtype][0]
        if folder.parent.name != expected_parent:
            rep.error(artifact, f"type '{mtype}' should live under artifacts/{expected_parent}/")
        _, prim_dir, suffix = TYPE_MAP[mtype]
        base = folder / ".apm" / prim_dir
        if mtype == "skill":
            skill_md = base / folder.name / "SKILL.md"
            prim = skill_md if skill_md.exists() else None
        else:
            matches = list(base.glob(f"*{suffix}")) if base.exists() else []
            prim = matches[0] if matches else None
        if not prim:
            rep.error(artifact, f"missing primitive file under .apm/{prim_dir}/ (expected *{suffix})")
        else:
            fm = parse_frontmatter(prim)
            if fm is None:
                rep.error(artifact, f"primitive {prim.name} has no YAML frontmatter")
            else:
                if mtype in ("agent", "skill") and not fm.get("name"):
                    rep.error(artifact, f"{prim.name} frontmatter missing 'name'")
                if not fm.get("description"):
                    rep.error(artifact, f"{prim.name} frontmatter missing 'description'")

    policy_checks(meta, artifact, load_policy_allowed_mcp(), rep)
    review_date_check(meta, artifact, rep)


def discover(target: Path | None) -> list[Path]:
    if target:
        return [target]
    found = []
    for parent in sorted(ARTIFACTS_DIR.glob("*")):
        if parent.is_dir():
            found.extend(p for p in sorted(parent.glob("*")) if p.is_dir())
    return found


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    target = (ROOT / args[0]).resolve() if args else None
    rep = Reporter()
    artifacts = discover(target)
    if not artifacts:
        print("No artifacts found to validate.")
        return 0
    for folder in artifacts:
        validate_artifact(folder, rep)

    print(f"Validated {len(artifacts)} artifact(s).")
    if not HAVE_JSONSCHEMA:
        print("(jsonschema not installed — ran built-in checks only; CI installs it for full schema validation.)")
    for w in rep.warnings:
        print(f"  WARN  {w}")
    for e in rep.errors:
        print(f"  ERROR {e}")
    if rep.errors:
        print(f"\nFAILED: {len(rep.errors)} error(s), {len(rep.warnings)} warning(s).")
        return 1
    print(f"\nPASSED: 0 errors, {len(rep.warnings)} warning(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
