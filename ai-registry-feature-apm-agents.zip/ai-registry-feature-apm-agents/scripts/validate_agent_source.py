#!/usr/bin/env python3
"""Validate developer-repository paths accepted by the agent ingestion pipeline."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from pathlib import PurePosixPath

import yaml


AGENT_ID_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
ROOT = Path(__file__).resolve().parents[1]


def repository_path(value: str, label: str) -> PurePosixPath:
    if not value or "\\" in value:
        raise ValueError(f"{label} must be a non-empty POSIX repository path")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise ValueError(f"{label} must be a normalized relative repository path")
    return path


def validate_paths(agent_file: str, readme_file: str) -> str:
    agent_path = repository_path(agent_file, "AGENT_FILE")
    readme_path = repository_path(readme_file, "AGENT_README_FILE")
    if agent_path.parent != readme_path.parent:
        raise ValueError("AGENT_FILE and AGENT_README_FILE must share a directory")
    if readme_path.name != "README.md":
        raise ValueError("AGENT_README_FILE must name README.md")
    if not agent_path.name.endswith(".agent.md"):
        raise ValueError("AGENT_FILE must end with .agent.md")
    agent_id = agent_path.name.removesuffix(".agent.md")
    if not AGENT_ID_PATTERN.fullmatch(agent_id):
        raise ValueError("agent ID must contain lowercase letters, digits, and hyphens")
    return agent_id


def load_frontmatter(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\r?\n(.*?)\r?\n---(?:\r?\n|$)", text, re.DOTALL)
    if not match:
        raise ValueError(f"{path}: file must start with YAML frontmatter")
    frontmatter = yaml.safe_load(match.group(1)) or {}
    if not isinstance(frontmatter, dict):
        raise ValueError(f"{path}: frontmatter must be a YAML mapping")
    return frontmatter


def schema_error(path: Path, error: object) -> ValueError:
    absolute_path = getattr(error, "absolute_path")
    message = getattr(error, "message")
    field = ".".join(str(part) for part in absolute_path) or "frontmatter"
    return ValueError(f"{path}: {field}: {message}")


def validate_schema(path: Path, schema_name: str) -> dict:
    try:
        import jsonschema
    except ImportError as exc:
        raise ValueError("jsonschema is required for producer content validation") from exc
    frontmatter = load_frontmatter(path)
    schema_path = ROOT / "schemas" / schema_name
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = sorted(jsonschema.Draft202012Validator(schema).iter_errors(frontmatter), key=lambda item: list(item.path))
    if errors:
        raise schema_error(path, errors[0])
    return frontmatter


def validate_policy(agent_path: Path, agent: dict) -> None:
    capabilities = agent["capabilities"]
    permissions = agent["permissions"]
    tools = set(capabilities["builtInTools"])
    repository = permissions["repository"]

    if tools & {"read", "search"} and (permissions["filesystem"] == "deny" or not repository["read"]):
        raise ValueError(f"{agent_path}: read/search tools require filesystem and repository read permission")
    if "edit" in tools and (permissions["filesystem"] != "write" or not repository["write"]):
        raise ValueError(f"{agent_path}: edit requires filesystem write and repository write permission")
    if (permissions["filesystem"] == "write" or repository["write"]) and "edit" not in tools:
        raise ValueError(f"{agent_path}: write permission requires the edit capability")
    if "shell" in tools and permissions["shell"] == "deny":
        raise ValueError(f"{agent_path}: shell capability conflicts with denied shell permission")
    if permissions["shell"] != "deny" and "shell" not in tools:
        raise ValueError(f"{agent_path}: shell permission requires the shell capability")
    if permissions["productionWrite"] and not permissions["humanConfirmation"]["requiredForWrites"]:
        raise ValueError(f"{agent_path}: production writes require human confirmation")

    policy = yaml.safe_load((ROOT / "apm-policy.yml").read_text(encoding="utf-8")) or {}
    allowed_mcp = set((policy.get("mcp") or {}).get("allow") or [])
    disallowed = sorted(set(capabilities["mcpServers"]) - allowed_mcp)
    if disallowed:
        raise ValueError(f"{agent_path}: MCP servers are not allowed by policy: {', '.join(disallowed)}")
    if capabilities["mcpServers"] and permissions["network"] == "deny":
        raise ValueError(f"{agent_path}: MCP dependencies require restricted or allowed network permission")


def validate(agent_file: str, readme_file: str, *, validate_content: bool = False) -> str:
    agent_id = validate_paths(agent_file, readme_file)
    if not validate_content:
        return agent_id

    agent_path = (ROOT / agent_file).resolve()
    readme_path = (ROOT / readme_file).resolve()
    if not agent_path.is_file() or not readme_path.is_file():
        raise ValueError("AGENT_FILE and AGENT_README_FILE must exist before content validation")
    agent = validate_schema(agent_path, "agent-source.schema.json")
    validate_schema(readme_path, "agent-readme-source.schema.json")
    if agent["name"] != agent_id:
        raise ValueError(f"{agent_path}: frontmatter name must be '{agent_id}'")
    validate_policy(agent_path, agent)
    return agent_id


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("agent_file")
    parser.add_argument("readme_file")
    parser.add_argument("--validate-content", action="store_true")
    args = parser.parse_args()
    print(validate(args.agent_file, args.readme_file, validate_content=args.validate_content))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)