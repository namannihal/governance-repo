[CmdletBinding()]
param(
    [string]$PythonCommand = "python"
)

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

Write-Host "[1/3] Building catalog indexes from artifact metadata"
& $PythonCommand (Join-Path $repoRoot "scripts/build_catalog.py")
if ($LASTEXITCODE -ne 0) { throw "Catalog index generation failed." }

Write-Host "[2/3] Rendering the static catalog page"
& $PythonCommand (Join-Path $repoRoot "scripts/build_catalog_site.py")
if ($LASTEXITCODE -ne 0) { throw "Static catalog generation failed." }

$catalogJson = Join-Path $repoRoot "catalog/index.json"
$publicCatalog = Join-Path $repoRoot "public/catalog.json"
Copy-Item $catalogJson $publicCatalog -Force

if (-not (Test-Path (Join-Path $repoRoot "public/index.html") -PathType Leaf)) {
    throw "Static catalog verification failed: public/index.html was not created."
}
if (-not (Test-Path $publicCatalog -PathType Leaf)) {
    throw "Static catalog verification failed: public/catalog.json was not created."
}

Write-Host "[3/3] Local catalog pipeline passed" -ForegroundColor Green
Write-Host "Catalog data: $catalogJson"
Write-Host "Static page:  $(Join-Path $repoRoot 'public/index.html')"
