#!/usr/bin/env python3
"""Generate reviewed APM assets from an agent and its README."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
PROMPT_VERSION = "1.0"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate capability-driven assets for an APM agent package.")
    parser.add_argument("--agent-file", required=True)
    parser.add_argument("--readme-file", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--response-file", help="Use a saved model response instead of calling an API.")
    parser.add_argument("--offline", action="store_true", help="Generate a deterministic local-test skill without an API.")
    parser.add_argument("--copilot-command", default=os.getenv("COPILOT_COMMAND", "copilot"))
    parser.add_argument("--model", default=os.getenv("COPILOT_MODEL"))
    parser.add_argument(
        "--use-current-model",
        action="store_true",
        help="Use the model persisted in GitHub Copilot CLI, ignoring COPILOT_MODEL.",
    )
    return parser.parse_args(argv)


def within_root(value: str, label: str) -> Path:
    path = (ROOT / value).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as exc:
        raise ValueError(f"{label} must be inside this repository") from exc
    return path


def model_prompt(agent_text: str, readme_text: str, agent_id: str) -> str:
    return f"""You design governed APM packages. Analyze the authored agent and README, then return one JSON object only.

The response must be parseable JSON. Escape line breaks inside JSON strings as \\n. Do not insert literal
line breaks inside quoted strings. Use ASCII punctuation and do not wrap the JSON in Markdown fences or prose.

The package must have exactly one focused skill named {agent_id}. Add prompts only for distinct user-invoked
workflows. Add instructions only for concise rules that should apply broadly. Do not generate scripts, shell
commands, credentials, network calls, MCP dependencies, or capabilities absent from the source. Keep generated
content faithful to the source and suitable for human review.

Return this object shape:
{{
  "rationale": "short capability analysis",
  "skill": {{"name": "{agent_id}", "description": "what and when", "body": "Markdown instructions"}},
  "prompts": [{{"name": "lowercase-slug", "description": "purpose", "body": "Markdown prompt"}}],
  "instructions": [{{"name": "lowercase-slug", "description": "purpose", "applyTo": "**", "body": "Markdown rules"}}]
}}

Agent source:
<agent>
{agent_text}
</agent>

README source:
<readme>
{readme_text}
</readme>
"""


def offline_response(agent_text: str, agent_id: str) -> dict:
    description_match = re.search(r"^description:\s*(.+?)\s*$", agent_text, re.MULTILINE)
    source_description = (
        description_match.group(1).strip().strip("'\"")
        if description_match
        else f"Provides the capability defined by the {agent_id} agent."
    )
    return {
        "rationale": "Credential-free local rehearsal generates the mandatory skill; use a saved response to test optional assets.",
        "skill": {
            "name": agent_id,
            "description": source_description,
            "body": (
                "## Workflow\n\n"
                f"1. Follow the scope, workflow, and guardrails defined by the bundled `{agent_id}` agent.\n"
                "2. Ground the result in the repository context supplied by the user.\n"
                "3. State assumptions and return concrete verification steps."
            ),
        },
        "prompts": [],
        "instructions": [],
    }


def parse_copilot_response(content: str) -> dict:
    response = content.strip()

    def is_package(candidate: object) -> bool:
        return isinstance(candidate, dict) and isinstance(candidate.get("skill"), dict)

    def is_complete_package(candidate: dict) -> bool:
        return (
            isinstance(candidate.get("rationale"), str)
            and isinstance(candidate.get("prompts"), list)
            and isinstance(candidate.get("instructions"), list)
        )

    def parse_candidate(candidate: str) -> dict | None:
        try:
            parsed = json.loads(candidate.strip(), strict=False)
        except json.JSONDecodeError:
            return None
        return parsed if is_package(parsed) else None

    direct = parse_candidate(response)
    if direct is not None:
        return direct

    candidates: list[dict] = []
    fenced_blocks = re.findall(r"```(?:json)?\s*(.*?)\s*```", response, re.DOTALL | re.IGNORECASE)
    for block in fenced_blocks:
        parsed = parse_candidate(block)
        if parsed is not None:
            candidates.append(parsed)

    if not candidates:
        decoder = json.JSONDecoder(strict=False)
        position = 0
        while position < len(response):
            object_start = response.find("{", position)
            if object_start < 0:
                break
            try:
                parsed, object_end = decoder.raw_decode(response, object_start)
            except json.JSONDecodeError:
                position = object_start + 1
                continue
            if is_package(parsed):
                candidates.append(parsed)
            position = object_end

    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        complete_candidates = [candidate for candidate in candidates if is_complete_package(candidate)]
        if len(complete_candidates) == 1:
            return complete_candidates[0]
        if complete_candidates:
            canonical_candidates = {
                json.dumps(candidate, sort_keys=True, ensure_ascii=True) for candidate in complete_candidates
            }
            if len(canonical_candidates) == 1:
                return complete_candidates[0]
        raise ValueError("GitHub Copilot response contained multiple package JSON objects")
    try:
        parsed = json.loads(response, strict=False)
    except json.JSONDecodeError:
        parsed = None
    if isinstance(parsed, dict):
        raise ValueError("GitHub Copilot response JSON did not contain the required skill object")
    raise ValueError("GitHub Copilot response did not contain a package JSON object")


def call_copilot(copilot_command: str, model: str | None, prompt: str) -> dict:
    environment = os.environ.copy()
    command = [
        copilot_command,
        "--prompt",
        prompt,
        "--silent",
        "--output-format=text",
        "--stream=off",
        "--no-auto-update",
        "--no-custom-instructions",
        "--disable-builtin-mcps",
        "--no-ask-user",
        "--no-remote",
        "--no-remote-export",
        "--deny-tool=write",
        "--deny-tool=shell",
        "--deny-tool=read",
        "--deny-tool=url",
        "--deny-tool=task",
    ]
    if model:
        command.extend(["--model", model])
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            env=environment,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
            timeout=300,
        )
    except FileNotFoundError as exc:
        raise ValueError(f"GitHub Copilot CLI command was not found: {copilot_command}") from exc
    except subprocess.TimeoutExpired as exc:
        raise ValueError("GitHub Copilot CLI generation timed out") from exc
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise ValueError(f"GitHub Copilot CLI generation failed: {detail[:1000]}")
    return parse_copilot_response(completed.stdout)


def require_text(value: object, label: str, minimum: int = 10) -> str:
    text = str(value or "").strip()
    if len(text) < minimum:
        raise ValueError(f"{label} must contain at least {minimum} characters")
    return text


def validate_slug(value: object, label: str) -> str:
    slug = str(value or "").strip()
    if not SLUG_PATTERN.fullmatch(slug):
        raise ValueError(f"{label} must be lowercase kebab-case")
    return slug


def yaml_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)


def write_markdown(path: Path, frontmatter: list[tuple[str, str]], body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    header = "\n".join(f"{key}: {yaml_string(value)}" for key, value in frontmatter)
    path.write_text(f"---\n{header}\n---\n\n{body.rstrip()}\n", encoding="utf-8", newline="\n")


def generate_assets(response: dict, agent_id: str, output_dir: Path, plan_path: Path) -> None:
    if not isinstance(response, dict):
        raise ValueError("AI generation response must be a JSON object")
    skill = response.get("skill")
    if not isinstance(skill, dict):
        raise ValueError("AI generation must produce one skill")
    skill_name = validate_slug(skill.get("name"), "skill.name")
    if skill_name != agent_id:
        raise ValueError(f"skill.name must match agent id '{agent_id}'")
    skill_description = require_text(skill.get("description"), "skill.description")
    skill_body = require_text(skill.get("body"), "skill.body")

    proposed_assets = [{"kind": "skill", "id": skill_name, "disposition": "bundled"}]
    write_markdown(
        output_dir / "skills" / skill_name / "SKILL.md",
        [("name", skill_name), ("description", skill_description)],
        skill_body,
    )

    for kind in ("prompts", "instructions"):
        assets = response.get(kind) or []
        if not isinstance(assets, list):
            raise ValueError(f"{kind} must be an array")
        seen: set[str] = set()
        for index, asset in enumerate(assets):
            if not isinstance(asset, dict):
                raise ValueError(f"{kind}[{index}] must be an object")
            name = validate_slug(asset.get("name"), f"{kind}[{index}].name")
            if name in seen:
                raise ValueError(f"duplicate {kind} name '{name}'")
            seen.add(name)
            description = require_text(asset.get("description"), f"{kind}[{index}].description")
            body = require_text(asset.get("body"), f"{kind}[{index}].body")
            if kind == "prompts":
                write_markdown(
                    output_dir / "prompts" / f"{name}.prompt.md",
                    [("name", name), ("description", description), ("agent", agent_id)],
                    body,
                )
                proposed_assets.append({"kind": "prompt", "id": name, "disposition": "bundled"})
            else:
                apply_to = str(asset.get("applyTo") or "**").strip()
                write_markdown(
                    output_dir / "instructions" / f"{name}.instructions.md",
                    [("description", description), ("applyTo", apply_to)],
                    body,
                )
                proposed_assets.append({"kind": "instruction", "id": name, "disposition": "bundled"})

    plan = {
        "schemaVersion": "1.0",
        "generatorPromptVersion": PROMPT_VERSION,
        "agentId": agent_id,
        "rationale": require_text(response.get("rationale"), "rationale"),
        "proposedAssets": proposed_assets,
    }
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8", newline="\n")


def main(argv: list[str] | None = None) -> int:
    try:
        args = parse_args(argv)
        agent_file = within_root(args.agent_file, "agent file")
        readme_file = within_root(args.readme_file, "README file")
        output_dir = within_root(args.output_dir, "output directory")
        plan_path = within_root(args.plan, "plan")
        if not agent_file.name.endswith(".agent.md"):
            raise ValueError("agent file name must end with .agent.md")
        agent_id = agent_file.name.removesuffix(".agent.md")
        if args.response_file and args.offline:
            raise ValueError("--response-file and --offline cannot be used together")
        if args.response_file:
            response = json.loads(within_root(args.response_file, "response file").read_text(encoding="utf-8"))
        elif args.offline:
            response = offline_response(agent_file.read_text(encoding="utf-8"), agent_id)
        else:
            response = call_copilot(
                args.copilot_command,
                None if args.use_current_model else args.model,
                model_prompt(
                    agent_file.read_text(encoding="utf-8"),
                    readme_file.read_text(encoding="utf-8"),
                    agent_id,
                ),
            )
        generate_assets(response, agent_id, output_dir, plan_path)
        print(f"Generated AI package plan: {plan_path.relative_to(ROOT).as_posix()}")
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())