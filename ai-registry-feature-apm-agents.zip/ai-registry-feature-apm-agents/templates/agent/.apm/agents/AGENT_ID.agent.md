---
name: AGENT_ID
description: What this agent does and WHEN Copilot should route to it. Lead with the trigger scenario.
tools: []
model: gpt-5
---

You are <persona>. Your job is <single clear responsibility>.

When invoked:
1. <step>
2. <step>
3. <step>

Guardrails:
- <what you must never do — e.g. never write to production without a change ticket>
- Ask for clarification when <ambiguous condition>.
