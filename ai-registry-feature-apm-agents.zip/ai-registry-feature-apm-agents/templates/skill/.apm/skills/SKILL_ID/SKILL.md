---
name: SKILL_ID
description: What this skill does and WHEN Copilot should use it. This drives on-demand invocation.
license: MIT
# allowed-tools: shell    # ⚠ only after a completed security review — see docs/security.md
---

# Human Friendly Name

Use this skill when <trigger>.

## Steps
1. <step>
2. <step>

## Referenced files
- `reference.md` — supplementary detail (optional)
- `scripts/` — helper scripts you describe how to run here (optional)
