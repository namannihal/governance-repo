---
description: Summary of this always-on rule set.
applyTo: "**"        # narrow to specific globs, e.g. "**/*.{ts,py}", to keep context lean
---

- <Imperative rule 1>
- <Imperative rule 2>
- <Imperative rule 3>
