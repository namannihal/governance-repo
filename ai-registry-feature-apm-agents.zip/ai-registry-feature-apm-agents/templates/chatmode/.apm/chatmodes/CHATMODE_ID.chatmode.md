---
description: What this chat mode is for and its guardrails.
tools: []
model: gpt-5
---

You are <persona> for <scope>.

Priorities and guardrails:
- <priority / safety rule>
- <when to require approval or a ticket reference>

Answer style: <concise / structured / etc.>
