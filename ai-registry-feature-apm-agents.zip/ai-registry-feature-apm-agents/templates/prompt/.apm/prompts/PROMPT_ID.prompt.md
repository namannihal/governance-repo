---
name: PROMPT_ID
description: What this prompt produces and when to invoke it.
mode: agent          # ask | edit | agent
model: gpt-5
---

<Write the reusable prompt here. Use ${input:variableName} for user-supplied values.>

Produce the output using these sections:
- <Section 1>
- <Section 2>
