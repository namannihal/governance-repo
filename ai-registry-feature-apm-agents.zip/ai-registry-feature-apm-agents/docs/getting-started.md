---
title: Getting Started
description: Install or contribute governed APM agent packages from the AI Registry
---

This registry is a **git-hosted APM package index**. There is no separate server to run — APM resolves artifacts directly from this repository over git.

## Install the APM CLI

```bash
# Linux / macOS
curl -sSL https://aka.ms/apm-unix | sh
# Windows (PowerShell)
irm https://aka.ms/apm-windows | iex

apm --version
```

Alternatives: `brew install microsoft/apm/apm`, Scoop, or `pip install apm-cli`.

## Two audiences

### I want to *use* an artifact

Go to **[consuming-artifacts.md](consuming-artifacts.md)**. In short:

```bash
apm install '{"git":"https://gitlab.example.com/platform/ai-registry.git","path":"artifacts/agents/azure-iac-reviewer","ref":"azure-iac-reviewer--v1.0.0"}'
```

### I want to *contribute* an artifact

Go to **[../CONTRIBUTING.md](../CONTRIBUTING.md)** and the
**[agent producer contract](agent-producer-contract.md)**. In short:

```bash
# In the developer repository:
mkdir -p agent
# Author the schema-versioned agent/my-agent.agent.md and agent/README.md.
# Commit both files; the consumer bridge job triggers the registry pipeline.
```

## Key concepts (2-minute version)

| Concept | What it means here |
| --------- | -------------------- |
| **Artifact** | A published agent / skill / prompt / instruction / chatmode, one folder under `artifacts/`. |
| **APM package** | Each artifact folder *is* an APM package: `apm.yml` + `.apm/` source. |
| **`metadata.yml`** | Governance sidecar (owner, lifecycle, risk, security) unique to this registry. |
| **`apm.lock.yaml`** | Written in the *consumer's* repo; pins each artifact to a commit SHA + content hash. |
| **`apm-policy.yml`** | Install-time policy this registry enforces (sources, MCP, primitives, pinning). |
| **Catalog** | `catalog/index.json` — generated machine-readable index of every artifact. |

## The golden rules

1. **Keep agent source in the developer repository.** CI imports the agent and README,
   generates the `.apm/` package in the registry, and returns the approved Copilot files
   through a developer merge request.
2. **Pin everything.** Tags or SHAs, never `main`.
3. **Metadata is not optional.** CI generates agent metadata and rejects any artifact
   whose `metadata.yml` fails the schema.
4. **Commit deployed files in consumer repos** so Copilot on github.com and first-time cloners get the context before they run `apm install`.
