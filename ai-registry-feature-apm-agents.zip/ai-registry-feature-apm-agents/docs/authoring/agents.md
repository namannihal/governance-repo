---
title: Authoring an Agent
description: Author the two consumer-owned files used to generate a governed agent package
---

A **custom agent** is a specialised persona with its own scope, tools and system prompt.
Copilot loads it when the user selects it or when routing matches. Contributors author
exactly one agent file and one README in a developer repository. Registry CI creates
an AI-generated APM package draft and governance files. The draft always contains one
focused skill. It contains prompts and instructions only when capability analysis finds
a distinct user-invoked workflow or broadly applicable rule.

## Authoring layout

```text
agent/
|-- <id>.agent.md
`-- README.md
```

Do not add `metadata.yml`, `apm.yml`, `.registry/`, `.apm/`, or any other file to this
folder. The registry pipeline rejects any additional file in the imported folder.

## Structured declarations

Both files begin with versioned YAML frontmatter. CI validates the declarations before
any Copilot request. Unknown fields, unsupported tools, contradictory permissions, and
MCP servers outside `apm-policy.yml` fail validation. The Markdown after frontmatter
remains flexible and describes behavior or usage in natural language.

The schemas are:

* `schemas/agent-source.schema.json` for `<id>.agent.md`
* `schemas/agent-readme-source.schema.json` for `README.md`

## README frontmatter

The README begins with catalog presentation metadata, followed by the consumer-facing
package documentation:

```markdown
---
schemaVersion: "1.0"
title: Azure IaC Reviewer
description: Install and use the read-only Azure Bicep and Terraform review agent
intendedAudience:
  - Cloud engineers
primaryScenarios:
  - Review infrastructure pull request changes
limitations:
  - Does not apply infrastructure changes
---

## Purpose

Review infrastructure-as-code changes without applying them.
```

CI uses `title` as `metadata.yml:displayName`, uses `description` as the catalog summary,
and copies the complete README byte-for-byte to `artifacts/agents/<id>/README.md`.

## `<id>.agent.md` frontmatter

```markdown
---
schemaVersion: "1.0"
name: azure-iac-reviewer
description: Reviews Azure Bicep/Terraform IaC for security, cost and policy issues. Use when asked to review infrastructure-as-code changes in a PR.
model: gpt-5
capabilities:
  builtInTools:
    - read
    - search
  mcpServers:
    - io.github.github/github-mcp-server
  apmDependencies: []
permissions:
  filesystem: read
  shell: deny
  network: restricted
  repository:
    read: true
    write: false
  productionWrite: false
  humanConfirmation:
    requiredForWrites: true
dataHandling:
  classification: internal
  processesPII: false
  touchesCustomerData: false
  storesPromptContent: false
runtime:
  targets:
    - copilot
---

You are an Azure infrastructure reviewer. When reviewing IaC changes:
1. ...
2. ...
```

The producer declares facts, and the registry derives obligations:

* `capabilities.builtInTools` uses the approved `read`, `search`, `edit`, and `shell`
  vocabulary
* `capabilities.mcpServers` uses canonical policy-approved MCP identifiers
* `capabilities.apmDependencies` declares package dependencies separately from tools
* `permissions` declares filesystem, shell, network, repository, and production-write
  boundaries
* `dataHandling` declares classification and runtime data sensitivity
* `runtime.targets` declares supported agent harnesses
* `model` remains an optional runtime preference

CI derives APM dependencies, metadata tools, targets, data handling, review cadence, and
risk tier from these declarations. Repository writes, shell access, customer data, PII,
or production writes produce tier 3. Read-only tools or MCP access produce tier 2.

## Authoring tips

* Write the agent `description` for routing. Lead with the trigger scenario
* Keep the system prompt scoped to one clear job
* Request only the tools the agent needs because each tool can raise the generated risk tier
* Put usage and behavioral context in the Markdown body, not new frontmatter fields

Commit the two files in the developer repository. The reusable consumer bridge job sends
the exact commit and both paths to the protected downstream registry pipeline. The
pipeline opens a merge request for the generated package under
`artifacts/agents/<id>/`. Review the agent, skill, and any generated prompts or
instructions. After approval and publication, the registry installs the pinned package
into a developer branch and opens a developer merge request.
