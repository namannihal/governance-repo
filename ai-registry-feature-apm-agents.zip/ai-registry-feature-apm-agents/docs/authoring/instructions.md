# Authoring an Instruction

**Instructions** are always-on guardrails and standards the agent reads on (almost) every
turn — coding conventions, security baselines, house style. Use instructions for simple
rules relevant to nearly every task; use **skills** for detailed capabilities the agent
should only load when relevant.

Authored as `*.instructions.md` under `.apm/instructions/`; compiles to
`.github/instructions/` (and a repo-wide `copilot-instructions.md` when appropriate).

## Folder layout

```
artifacts/instructions/<id>/
├── apm.yml
├── metadata.yml
├── README.md
├── CHANGELOG.md
└── .apm/
    └── instructions/
        └── <id>.instructions.md
```

## `<id>.instructions.md` frontmatter

```markdown
---
description: Secure-coding baseline applied to all source files.
applyTo: "**/*.{ts,js,py,cs,go}"
---

- Validate and encode all external input.
- Never log secrets, tokens or PII.
- Use parameterised queries; never string-concatenate SQL.
```

| Frontmatter | Notes |
|-------------|-------|
| `description` | Required. Summarises the rule set. |
| `applyTo` | Glob(s) the instruction attaches to. Omit or use `**` for repo-wide. Narrow globs keep the agent's context lean. |

## Authoring tips

- **Be concise and imperative.** These load on every matching turn — keep them short and unambiguous.
- **Scope with `applyTo`.** Don't attach language-specific rules to every file.
- **Standards, not tasks.** If it's a "how to do X" procedure, it's probably a skill.

Start from `templates/instruction/`.
