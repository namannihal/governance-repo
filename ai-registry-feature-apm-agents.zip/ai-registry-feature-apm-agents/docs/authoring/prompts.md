# Authoring a Prompt

A **prompt** is a reusable, named prompt template a user invokes on demand (a saved prompt
/ slash command). Authored as `*.prompt.md` under `.apm/prompts/`; compiles to
`.github/prompts/`.

## Folder layout

```
artifacts/prompts/<id>/
├── apm.yml
├── metadata.yml
├── README.md
├── CHANGELOG.md
└── .apm/
    └── prompts/
        └── <id>.prompt.md
```

## `<id>.prompt.md` frontmatter

```markdown
---
name: incident-postmortem
description: Generates a blameless post-incident review from an incident timeline.
mode: agent          # 'ask' | 'edit' | 'agent'
model: gpt-5
---

Write a blameless post-incident review for the incident described below.
Use these sections: Summary, Impact, Timeline, Root Cause, What went well,
Action items (owner + due date).

Incident details:
${input:incidentNotes}
```

| Frontmatter | Notes |
|-------------|-------|
| `name` | Required. Lowercase-hyphen; equals the id. |
| `description` | Required. Shown in the prompt picker and catalog. |
| `mode` | Optional: `ask`, `edit`, or `agent`. |
| `model` | Optional preferred model. |

- Use `${input:variableName}` placeholders for values the user supplies at invocation.
- Prompts can be run via the harness UI or with `apm run <script>` when wired to a script in `apm.yml`.

## Authoring tips

- One prompt, one job. Compose bigger workflows from several prompts rather than one mega-prompt.
- Make the output **structured** (named sections, a checklist) so results are consistent.
- Keep prompts free of secrets and customer data.

Start from `templates/prompt/`.
