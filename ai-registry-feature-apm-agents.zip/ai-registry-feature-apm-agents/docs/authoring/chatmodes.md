# Authoring a Chat Mode

A **chat mode** is a scoped VS Code Copilot Chat persona — a preset combination of a system
prompt, an allowed tool set, and (optionally) a model. Authored as `*.chatmode.md` under
`.apm/chatmodes/`; compiles to `.github/chatmodes/`.

## Folder layout

```
artifacts/chatmodes/<id>/
├── apm.yml
├── metadata.yml
├── README.md
├── CHANGELOG.md
└── .apm/
    └── chatmodes/
        └── <id>.chatmode.md
```

## `<id>.chatmode.md` frontmatter

```markdown
---
description: Datacenter operations assistant — triage, runbooks, capacity questions.
tools: ['read', 'search', 'github-mcp-server']
model: gpt-5
---

You are a datacenter operations assistant for the Netherlands region.
Prioritise safety and change-control. When asked to act on production,
require a change ticket reference before proposing commands.
```

| Frontmatter | Notes |
|-------------|-------|
| `description` | Required. Shown in the chat-mode picker and catalog. |
| `tools` | Optional tool whitelist; each entry must be allow-listed in `apm-policy.yml` and reflected in `metadata.yml:tools`. |
| `model` | Optional preferred model. |

## Authoring tips

- **Define the persona and its guardrails**, not a one-off task — chat modes persist across a conversation.
- **Constrain tools deliberately.** A mode that can touch production is tier 3 and needs security sign-off.
- Chat modes are VS Code-specific; set `targets: [copilot]` unless you also validate other harnesses.

Start from `templates/chatmode/`.
