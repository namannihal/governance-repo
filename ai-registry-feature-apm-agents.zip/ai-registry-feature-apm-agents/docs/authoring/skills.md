# Authoring a Skill

A **skill** is a reusable, model-invoked capability packaged as a folder of instructions,
scripts and resources. Copilot loads it *on demand* when the task matches the skill's
`description`. Skills are the right choice for detailed capabilities the agent should only
pull in when relevant (use **instructions** for simple always-on rules).

Skills work with Copilot cloud agent, Copilot code review, the Copilot CLI, the Copilot app,
and agent mode in VS Code.

## Folder layout

```
artifacts/skills/<id>/
├── apm.yml
├── metadata.yml
├── README.md
├── CHANGELOG.md
└── .apm/
    └── skills/
        └── <id>/
            ├── SKILL.md          # required, MUST be named SKILL.md
            ├── reference.md      # optional supplementary docs
            └── scripts/          # optional scripts referenced from SKILL.md
```

The skill directory name must be lowercase with hyphens and match the id.

## `SKILL.md` frontmatter

```markdown
---
name: terraform-plan-review
description: Reviews a `terraform plan` for risky changes (deletes, replacements, IAM). Use when asked to review a Terraform plan or apply.
license: MIT
# allowed-tools: shell        # ⚠ only with a completed security review
---

# Terraform Plan Review

When asked to review a Terraform plan:
1. ...
```

| Frontmatter | Req | Notes |
|-------------|:---:|-------|
| `name` | ✅ | Lowercase-hyphen; unique; matches the directory. |
| `description` | ✅ | What it does **and when Copilot should use it** — this drives invocation. |
| `license` | | SPDX id. |
| `allowed-tools` | | Tools pre-approved without a per-use confirmation. **Only add `shell`/`bash` after a security review** — it removes the confirmation step and can let an injection run arbitrary commands. |

## Enabling a script

Copilot discovers every file in the skill directory when the skill loads. To ship a script:

1. Add it to the skill directory (e.g. `scripts/convert.sh`).
2. Describe **when and how** to run it in the `SKILL.md` body.
3. Only pre-approve `shell` in `allowed-tools` if you fully trust the script and it has been reviewed.

## Authoring tips

- **Description is everything** — it's both the routing signal and the catalog summary. Mirror it in `metadata.yml:description`.
- **Keep `SKILL.md` focused**; push long reference material into sibling `.md` files the body links to.
- **Deterministic scripts** for anything that must be exact (parsing, conversions) rather than asking the model to do it by hand.

Start from `templates/skill/`.
