---
title: Versioning and Releases
description: Version, tag, and release monorepo packages through GitLab
---

Artifacts are versioned with [SemVer](https://semver.org/) and released as immutable git
tags so consumers can pin and reproduce exactly.

## When to bump

| Change | Bump |
| -------- | ------ |
| Reworded system prompt / instruction that changes agent behaviour; removed a capability; added a newly-*required* tool or MCP server | **MAJOR** |
| New optional capability; expanded examples; additional target harness; backward-compatible improvement | **MINOR** |
| Typo, clarification, formatting, non-behavioural metadata fix | **PATCH** |

Because agent artifacts are *behavioural*, err toward MAJOR when in doubt: a prompt change
that surprises an existing consumer is a breaking change even if no field was removed.

## The three-way version rule

CI generates the version into all three package files. Set `AGENT_VERSION` for the
package build instead of editing generated files. The values must match, or CI fails:

1. `apm.yml` → `version`
2. `metadata.yml` → `version`
3. `CHANGELOG.md` → top entry

## Release flow

1. Set `AGENT_VERSION` in the developer project's consumer bridge configuration. The
  downstream registry pipeline generates the manifest, metadata, and changelog entry.
1. CI resolves the developer repository ref to an immutable source commit.
1. CI validates and audits the generated package.
1. The protected publication job commits the package to the registry default branch and
  creates the tag at that exact registry commit:

```bash
git tag azure-iac-reviewer--v1.2.0 "$CI_COMMIT_SHA"
git push origin azure-iac-reviewer--v1.2.0
```

Per-artifact tags let each artifact release independently in this monorepo. Duplicate
tags fail instead of moving an existing release.

1. The release uploads the APM archive to GitLab generic packages and links it from the
  GitLab Release. The default-branch pipeline rebuilds the catalog and Pages site.
1. Consumers upgrade deliberately with `apm deps update` and commit the new
  `apm.lock.yaml`.

## Consumer pinning

```yaml
dependencies:
  apm:
    - git: https://gitlab.example.com/platform/ai-registry.git
      path: artifacts/agents/azure-iac-reviewer
      ref: azure-iac-reviewer--v1.2.0
```

GitLab dependencies use explicit `git`, `path`, and `ref` fields so nested groups cannot
be mistaken for package paths. Policy requires a bounded tag, SemVer constraint, or
commit SHA; floating branches are rejected.

## Deprecation & retirement

- Set `lifecycle.status: deprecated`, fill `supersededBy` + `sunsetDate`, add a CHANGELOG entry.
- The artifact stays installable so pinned consumers don't break.
- After `sunsetDate`, move to `retired` — kept for reproducibility of old pins, removed from active catalog listings.

## CHANGELOG format (Keep a Changelog)

```markdown
## [1.2.0] - 2026-08-04
### Added
- New `--strict` guidance for module version pinning.
### Changed
- Clarified the review checklist ordering.
```
