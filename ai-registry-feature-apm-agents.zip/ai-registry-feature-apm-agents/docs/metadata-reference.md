---
title: Metadata Reference
description: Governance metadata fields generated and validated for registry artifacts
---

Every artifact carries a `metadata.yml` governance sidecar, validated in CI against
[`schemas/artifact.metadata.schema.json`](../schemas/artifact.metadata.schema.json).
This file captures the ownership,
lifecycle, security and provenance facts that the APM manifest (`apm.yml`) does not model.

> **`apm.yml` vs `metadata.yml`**: `apm.yml` is the *distribution* manifest APM reads to
> resolve and compile the artifact. `metadata.yml` is the *governance* record the registry's
> own tooling reads to validate, catalog and audit. The validator checks that `name`,
> `version` and `license` agree across both.

## Field-by-field

| Field | Req | Notes |
| ------- | :---: | ------- |
| `schemaVersion` | ✅ | Always `"1.0"` for this schema revision. |
| `id` | ✅ | Immutable slug; equals the folder name. Lowercase-hyphen. |
| `name` | ✅ | APM package name; must equal `apm.yml:name`. |
| `displayName` | ✅ | Human-friendly catalog title. |
| `type` | ✅ | `agent` \| `skill` \| `prompt` \| `instruction` \| `chatmode` \| `plugin`. |
| `version` | ✅ | SemVer; must equal `apm.yml:version` and top of `CHANGELOG.md`. |
| `summary` | ✅ | ≤160 chars, shown in listings and search. |
| `description` | | Full "what + when to use"; mirror the primitive's frontmatter `description`. |
| `owner.team` | ✅ | GitHub team slug; must exist in CODEOWNERS. |
| `owner.contact` | ✅ | Team DL / on-call alias. |
| `owner.maintainers[]` | | Named approvers (name, github, email). |
| `lifecycle.status` | ✅ | `experimental`→`beta`→`active`→`deprecated`→`retired`. |
| `lifecycle.supersededBy` | ⚠️ | Required when deprecated/retired. |
| `lifecycle.sunsetDate` | | Removal date for deprecated artifacts. |
| `classification` | ✅ | `public` \| `internal` \| `confidential` \| `highly-confidential` — of the artifact **content**. |
| `dataHandling.*` | | `touchesCustomerData`, `processesPII`, `writesToProduction`, `notes`. |
| `riskTier` | ✅ | `1` read-only · `2` uses tools/MCP · `3` shell/prod/customer data. |
| `targets[]` | ✅ | Harnesses validated against (`copilot`, `claude`, …). |
| `tags[]` / `domains[]` | | Discovery aids. |
| `tools.allowedTools[]` | | Pre-approved tools; `shell`/`bash` forces riskTier ≥ 2 + security review. |
| `tools.requiredMcpServers[]` | | Must be allow-listed in `apm-policy.yml`. |
| `dependencies.apm[]` / `.mcp[]` | | Mirror of `apm.yml`; pinned. |
| `install.apmReference` | | The `apm install` string consumers copy. |
| `license` | ✅ | SPDX id; must equal `apm.yml:license`. |
| `provenance.sourceRepo` | ✅ | Canonical developer repository URL. |
| `provenance.sourceRef` | | Immutable developer repository commit used for generation. |
| `provenance.sourcePath` | | Agent path within the developer repository. |
| `provenance.createdBy` / `createdDate` | ✅¹ | Original author + date (createdDate required). |
| `provenance.originatingSource` | | Upstream artifact you adapted — credit it. |
| `compliance.securityReview` | ✅ | `not-required` \| `pending` \| `approved` \| `rejected`. Tier-3 must be `approved` to merge. |
| `compliance.reviewedBy` | | Approver handle. |
| `compliance.lastReviewed` | ✅ | Date of last governance review. |
| `compliance.reviewCadenceDays` | ✅ | 90 (tier 3) / 180 (tier 2) / 365 (tier 1). |
| `compliance.nextReviewDue` | | `lastReviewed + reviewCadenceDays`; catalog flags overdue. |
| `evaluation.*` | | Optional test/eval pointers. |
| `links.*` | | documentation / changelog / issues URLs. |

¹ `createdDate` is required; `createdBy` is strongly recommended.

## Risk tiers → obligations

| Tier | Examples | Approvals | Cadence |
| :----: | ---------- | ----------- | :-------: |
| **1** | Instructions, static prompts, read-only guidance | 1 owning-team | 365 days |
| **2** | Skills/agents that call MCP tools, no prod writes | owning-team + registry maintainer | 180 days |
| **3** | `shell`/`bash`, writes to production, customer data | + AI Governance / Security sign-off | 90 days |

## Minimal valid example

```yaml
schemaVersion: "1.0"
id: my-skill
name: my-skill
displayName: My Skill
type: skill
version: 1.0.0
summary: One sentence describing what this does and when to use it.
owner:
  team: "@contoso/platform-ai"
  contact: platform-ai@contoso.com
lifecycle:
  status: beta
classification: internal
riskTier: 1
targets: [copilot]
license: MIT
provenance:
  sourceRepo: https://gitlab.example.com/teams/my-skill.git
  sourceRef: 4bf92f3577b5432f8d25b124f8640ce71c3f1f22
  sourcePath: agent/my-skill.agent.md
  createdBy: "@jane"
  createdDate: 2026-08-04
compliance:
  securityReview: not-required
  lastReviewed: 2026-08-04
  reviewCadenceDays: 365
  nextReviewDue: 2027-08-04
```
