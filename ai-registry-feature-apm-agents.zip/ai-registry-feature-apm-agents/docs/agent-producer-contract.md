---
title: Create an Agent Package
description: Beginner guide for writing the agent and README files that start APM package generation
---

You only need to write two files to request a new agent package. The registry creates
the APM manifest, metadata, skill, and other package files for you.

This guide starts with a read-only agent because that is the safest and most common
choice for a first package.

## Before you start

Choose a short ID for your agent. Use lowercase letters, numbers, and hyphens only.

Examples:

* `repository-analyst`
* `release-reviewer`
* `api-documentation-helper`

In this guide, the ID is `repository-analyst`.

## Step 1: Create the folder

Create one folder with exactly two files:

```text
repository-analyst/
|-- repository-analyst.agent.md
`-- README.md
```

The agent filename must start with the ID. Do not add `apm.yml`, `metadata.yml`, skills,
prompts, or any other files. The registry generates them later.

## Step 2: Create the agent file

Copy this example into `repository-analyst.agent.md`:

```markdown
---
schemaVersion: "1.0"
name: repository-analyst
description: Analyzes a repository to explain how its code works. Use when investigating a feature, bug, dependency, or proposed code change.
capabilities:
  builtInTools:
    - read
    - search
  mcpServers: []
  apmDependencies: []
permissions:
  filesystem: read
  shell: deny
  network: deny
  repository:
    read: true
    write: false
  productionWrite: false
  humanConfirmation:
    requiredForWrites: true
dataHandling:
  classification: internal
  processesPII: false
  touchesCustomerData: false
  storesPromptContent: false
runtime:
  targets:
    - copilot
---

You are a read-only repository analyst. Explain how code works using evidence from the
current repository.

## Workflow

1. Understand the user's question.
2. Find the closest source files, tests, and configuration.
3. Trace the code path that controls the behavior.
4. Explain the result with file and symbol references.
5. Clearly identify assumptions and missing information.

## Guardrails

* Do not modify files or run commands.
* Do not expose passwords, tokens, or secret values.
* Do not present assumptions as verified facts.
* Keep the analysis focused on the user's question.

## Response format

Provide a direct answer, supporting repository evidence, important constraints, risks,
and focused next steps.
```

Change these three parts:

1. Change `name` to your agent ID. It must exactly match the filename.
2. Change `description` to explain what the agent does and when someone should use it.
3. Replace the text after the second `---` with your agent's role, workflow, guardrails,
   and expected response.

For your first agent, leave the other settings unchanged unless it needs additional
access.

## Step 3: Understand the safety settings

The example agent can read and search repository files. It cannot edit files, run shell
commands, use the network, or write to production.

The important settings are:

| Setting | Plain-language meaning |
| ------- | ---------------------- |
| `builtInTools` | Tools the agent asks the host to provide |
| `mcpServers` | Approved external tool servers the agent needs |
| `apmDependencies` | Other APM packages this agent needs |
| `filesystem` | Whether the agent can read or write local files |
| `shell` | Whether the agent can run terminal commands |
| `network` | Whether the agent can access external services |
| `repository.write` | Whether the agent can change repository files |
| `productionWrite` | Whether the agent can change a production system |
| `dataHandling` | Types of information the agent may process or store |
| `runtime.targets` | Agent hosts that can run the package |

Use empty brackets when no MCP server or APM dependency is needed:

```yaml
mcpServers: []
apmDependencies: []
```

Do not request access that the agent does not need. More access results in more review
requirements.

## Step 4: Create the README

Copy this example into `README.md`:

```markdown
---
schemaVersion: "1.0"
title: Repository Analyst
description: Explains repository behavior, dependencies, and change impact using read-only analysis.
intendedAudience:
  - Software engineers
  - Technical leads
primaryScenarios:
  - Understand how a feature works
  - Investigate a code defect
  - Assess the impact of a proposed change
limitations:
  - Does not modify repository files
  - Does not execute commands or access external services
---

## Repository Analyst

Use this agent to understand an unfamiliar codebase without changing files. It traces
real code paths and separates verified behavior from assumptions.

## When to use it

Use the agent when you need to understand a feature, follow a request through the
codebase, locate dependencies, investigate a defect, or plan a change.

## What it returns

The agent provides a direct explanation, repository evidence, constraints, risks,
unknowns, and recommended next steps.

## Requirements and limitations

The agent needs the host's `read` and `search` tools. It does not need an MCP server and
cannot modify files, execute commands, or access external services.
```

Change these parts:

* `title`: A friendly name shown in the catalog
* `description`: A short catalog summary
* `intendedAudience`: The people who should use the agent
* `primaryScenarios`: The main jobs the agent supports
* `limitations`: Actions or scenarios the agent does not support
* The text after the second `---`: Instructions for people who install the package

The README describes the agent to users. The agent file tells the agent how to behave.

## Step 5: Commit the two files

Commit and push the agent file and README to your developer repository. Your normal
project pipeline starts the registry workflow when files under `agents/` change. You do
not need to open the registry project or manually start its pipeline.

### Understand the two projects

The workflow uses two GitLab projects:

| Project | Purpose |
| ------- | ------- |
| Developer project | Stores your two source files and receives the approved package through a merge request. |
| Registry project | Stores `.gitlab-ci.yml`, validation scripts, schemas, policy, generated packages, and the catalog. |

The developer pipeline passes its project ID, repository URL, exact commit SHA, source
paths, and target branch to the registry pipeline. GitLab Runner checks out the registry
project automatically. The registry pipeline then checks out the two source files from
the exact developer commit.

```mermaid
flowchart LR
   A[Developer project<br/>agent and README] -->|Project pipeline| B[Registry downstream pipeline]
   B --> C[Registry package merge request]
   C -->|Approval and merge| D[Immutable registry release]
   D -->|APM install| E[Developer deployment branch]
   E --> F[Developer merge request]
```

Your project needs this GitLab configuration. The registry team can provide the include
URL and project path used by your organization.

```yaml
include:
  - project: platform/ai-registry
    ref: main
    file: /templates/gitlab/agent-producer.gitlab-ci.yml

variables:
  REGISTRY_PROJECT_PATH: platform/ai-registry
  AGENT_FILE: agents/repository-analyst/repository-analyst.agent.md
  AGENT_README_FILE: agents/repository-analyst/README.md
  AGENT_VERSION: 1.0.0
  AGENT_OWNER_TEAM: Developer Experience
  AGENT_OWNER_CONTACT: developer-experience@example.com
  COPILOT_MODEL: auto
```

The reusable job runs on the default branch when files under `agents/` change. It pins
the request to `CI_COMMIT_SHA`, triggers the registry as a downstream pipeline, and waits
for the registry draft pipeline to finish.

### Allow private cross-project access

GitLab administrators configure two job-token allow-list directions once:

1. The registry project allows the developer project to trigger its pipeline.
2. The developer project allows the registry project to fetch the exact source commit.

The registry also owns a protected and masked `CONSUMER_DELIVERY_TOKEN`. This token can
create a branch and merge request in approved developer projects. It does not push to the
developer default branch. Organizations that cannot use job-token repository access can
configure the protected and masked `AGENT_REPO_AUTH_HEADER` fallback.

Do not put a token in the repository URL, agent file, README, or unmasked pipeline
variable. If validation fails, correct the two files and push a new commit. The next
developer pipeline sends the new commit SHA automatically.

## What happens next

The registry:

1. Checks that the folder contains exactly the two expected files.
2. Checks names, capabilities, permissions, data handling, and policy rules.
3. Uses GitHub Copilot CLI to create one skill.
4. Creates prompts or instructions only when the agent needs them.
5. Creates `apm.yml`, `metadata.yml`, `CHANGELOG.md`, and the package layout.
6. Validates and audits the generated package.
7. Opens a draft merge request for human review.
8. Publishes the package only after approval and merge.
9. Installs the pinned release into standard Copilot paths in a developer branch.
10. Opens a developer merge request for final review and merge.

The developer merge request can contain `apm.yml`, `apm.lock.yaml`, `.github/agents`,
`.github/prompts`, `.github/instructions`, and `.agents/skills`. Only the paths produced
for that package are present. The registry delivery job rejects any unexpected file
change.

The destination must not already exist. New-package generation never deletes or replaces
an existing governed package.

## When your agent needs more access

Start from the read-only example and change only what is required.

### Agent needs to edit repository files

Add `edit` and allow file and repository writes:

```yaml
capabilities:
  builtInTools:
    - read
    - search
    - edit
  mcpServers: []
  apmDependencies: []
permissions:
  filesystem: write
  shell: deny
  network: deny
  repository:
    read: true
    write: true
  productionWrite: false
  humanConfirmation:
    requiredForWrites: true
```

### Agent needs an MCP server

Use the full approved MCP server ID and allow network access:

```yaml
capabilities:
  builtInTools:
    - read
    - search
  mcpServers:
    - io.github.github/github-mcp-server
  apmDependencies: []
permissions:
  filesystem: read
  shell: deny
  network: restricted
  repository:
    read: true
    write: false
  productionWrite: false
  humanConfirmation:
    requiredForWrites: true
```

The MCP server must already be allowed in `apm-policy.yml`. If it is not allowed, request
a policy change before submitting the agent.

### Agent needs shell access

Add `shell` to `builtInTools` and set `shell` to `confirm` or `allow`. Shell access raises
the package risk tier and requires additional review. Prefer `confirm` unless unattended
execution is an approved requirement.

### Agent handles sensitive data

Set the data fields to describe what the agent actually handles:

```yaml
dataHandling:
  classification: confidential
  processesPII: true
  touchesCustomerData: true
  storesPromptContent: false
```

Do not lower these settings to avoid review. The registry uses them to protect users and
data.

## Common errors

| Error | How to fix it |
| ----- | ------------- |
| Agent name does not match filename | Make `name` match the filename without `.agent.md`. |
| Unknown frontmatter field | Remove the field. Only fields in the examples and schema are accepted. |
| Write permission requires `edit` | Add `edit` or return the permissions to read-only. |
| MCP requires network permission | Change `network` from `deny` to `restricted`. |
| MCP server is not allowed | Request approval and an `apm-policy.yml` update. |
| README is missing scenarios or limitations | Add at least one item to each list. |
| Source folder contains additional files | Keep only the agent file and `README.md`. |
| Artifact already exists | Use the controlled update process instead of new-package generation. |

## Quick field reference

Use this section when validation reports a field value problem.

| Field | Accepted value |
| ----- | -------------- |
| `schemaVersion` | `"1.0"` |
| `builtInTools` entries | `read`, `search`, `edit`, `shell` |
| `filesystem` | `deny`, `read`, `write` |
| `shell` | `deny`, `confirm`, `allow` |
| `network` | `deny`, `restricted`, `allow` |
| `classification` | `public`, `internal`, `confidential`, `highly-confidential` |
| Boolean fields | `true` or `false` without quotation marks |
| `runtime.targets` entries | `copilot`, `claude`, `cursor`, `codex`, `gemini`, `windsurf`, `opencode`, `kiro`, `antigravity` |

For the exact machine-enforced definitions, see:

* [`agent-source.schema.json`](../schemas/agent-source.schema.json)
* [`agent-readme-source.schema.json`](../schemas/agent-readme-source.schema.json)
* [`apm-policy.yml`](../apm-policy.yml)
