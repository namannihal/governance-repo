# Governance

This registry governs the **install and integrity plane** — what artifacts reach a
developer's disk and whether they conform to policy. It does **not** govern the runtime
plane (what a running agent may do); that belongs to each agent harness. The two planes
do not overlap.

## Roles

| Role | GitHub team | Responsibility |
|------|-------------|----------------|
| **Registry maintainers** | `@contoso/ai-registry-maintainers` | Own the framework (schemas, policy, tooling, CI). Second reviewer for tier-2+. |
| **AI Governance / Security** | `@contoso/ai-governance` | Own `apm-policy.yml`; sign off tier-3 and any `shell`/`bash` artifact. |
| **Artifact owning teams** | e.g. `@contoso/platform-ai` | Accountable for their own artifacts' correctness, security and lifecycle. |

Ownership is declared twice and must agree: in each artifact's `metadata.yml:owner.team`
and in `.github/CODEOWNERS`. The validator cross-checks them.

## Contribution lifecycle

```
two-file source -> AI draft branch -> MR gates -> review by tier -> merge -> tag release -> catalog rebuild
```

AI generation never grants approval. The owning team reviews behavioral fidelity and
the generated capability boundaries. Registry and security reviewers apply the risk-tier
requirements below. Protected-branch settings must prevent direct pushes and unapproved
merges to the default branch.

### CI gates (all must pass)
1. **Metadata schema** — `metadata.yml` validates against the JSON Schema.
2. **Structure & frontmatter** — required files present; primitive frontmatter valid; folder = id = name.
3. **`apm install --dry-run`** — manifest ↔ lockfile agree; dependencies resolve; policy passes.
4. **`apm audit --ci`** — hidden-Unicode / prompt-injection scan; SARIF uploaded to Code Scanning.
5. **Consistency** — `version`/`license` match across `apm.yml`, `metadata.yml`, `CHANGELOG.md`.

### Approvals by risk tier
| Tier | Required approvals |
|:----:|--------------------|
| 1 | 1 × owning team |
| 2 | 1 × owning team **+** 1 × registry maintainer |
| 3 | tier-2 approvals **+** AI Governance / Security sign-off recorded in `compliance` |

## Artifact lifecycle states

| Status | Installable? | In catalog? | Meaning |
|--------|:---:|:---:|---------|
| `experimental` | ✅ | flagged | Early, may change without notice. |
| `beta` | ✅ | flagged | Stabilising; feedback wanted. |
| `active` | ✅ | ✅ | Supported and recommended. |
| `deprecated` | ✅ | flagged | Superseded; will be removed at `sunsetDate`. |
| `retired` | ✅ (pinned only) | archived | No longer recommended; kept for reproducibility. |

Promotion (`experimental → active`) and deprecation both happen via PR that edits
`metadata.yml` and `CHANGELOG.md`.

## Policy inheritance (tighten-only)

`apm-policy.yml` flows **enterprise → org → repo**. A consuming repo may add restrictions
but can never relax what this registry sets. Every `apm install` — including transitive
MCP servers pulled in by deep dependencies — runs the policy before writing files, and
`apm audit --ci` enforces the same checks in branch protection.

## Periodic review

Each artifact's `compliance.reviewCadenceDays` sets its re-review interval (90 / 180 / 365
by tier). `build_catalog.py` computes `nextReviewDue` and flags overdue artifacts in the
catalog so owners can be nudged. Overdue tier-3 artifacts should be auto-flagged for the
Governance board.

## Auditability

- Every version is an immutable git tag; `apm.lock.yaml` in consumer repos records the exact SHA + content hash installed.
- `metadata.yml` records who created, reviewed and approved each artifact and when.
- The catalog is regenerated from source on every merge — it can always be rebuilt and diffed.
