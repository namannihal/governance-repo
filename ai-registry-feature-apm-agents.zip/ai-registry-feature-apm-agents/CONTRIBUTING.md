---
title: Contributing to the AI Artifact Registry
description: Contribution workflows and governance requirements for registry artifacts
---

Agent source remains in the developer repository. Its normal GitLab pipeline triggers a
protected downstream registry pipeline that imports and publishes the package here.
Registry framework changes still use merge requests and normal repository review.

## TL;DR

For an agent, create only `<agent-id>.agent.md` and `README.md` in one folder in the
developer repository. Both files require strict versioned frontmatter; see
[Authoring an agent](docs/authoring/agents.md). Configure the reusable consumer bridge
job with both source paths and ownership values. CI passes the exact source commit to
the registry, generates an agent package draft with one required skill and
capability-driven prompts and instructions, validates and audits it, and opens a registry
merge request. After approval and publication, CI installs the pinned package into a
developer branch and opens a developer merge request. See
[GitLab agent onboarding](docs/gitlab-agent-onboarding.md).

For other artifact types, use the existing template workflow:

```bash
# 1. Start from a template
cp -r templates/skill artifacts/skills/my-new-skill

# 2. Edit the four required files
#    apm.yml · metadata.yml · .apm/skills/my-new-skill/SKILL.md · README.md
#    ...and add a CHANGELOG.md entry

# 3. Validate locally (same checks CI runs)
python scripts/validate_artifacts.py artifacts/skills/my-new-skill

# 4. Commit, push, open a merge request
```

---

## 1. Pick the right artifact type

| Use a… | When you want to… | Primitive file |
| -------- | ------------------- | ---------------- |
| **Instruction** | Add always-on guardrails/standards the agent reads every turn | `*.instructions.md` |
| **Prompt** | Save a reusable, named prompt users invoke on demand | `*.prompt.md` |
| **Skill** | Package a multi-file, model-invoked capability (with scripts/assets) | `SKILL.md` + assets |
| **Agent** | Define a specialised persona with its own model, tools and system prompt | `*.agent.md` |
| **Chat mode** | Ship a scoped VS Code chat mode | `*.chatmode.md` |

Not sure? See **[docs/authoring/](docs/authoring/)**. Prefer an **instruction** for simple, universal rules and a **skill** for detailed capabilities the agent should only load when relevant.

## 2. Required files in every artifact

Agent contributors do not author files under `artifacts/agents/`. The pipeline creates
the following AI-generated package draft from the two files in the developer repository.
The owning team reviews every generated asset before merge. Other artifact types continue
to use their template workflow.

Every folder under `artifacts/<type>/<id>/` MUST contain:

| File | Purpose | Enforced by |
| ------ | --------- | ------------- |
| `apm.yml` | APM distribution manifest (name, version, targets, dependencies) | validator + `apm install --dry-run` |
| `metadata.yml` | Governance metadata sidecar | validator against `schemas/artifact.metadata.schema.json` |
| `.apm/<type>/…` | The primitive source (SKILL.md / .agent.md / etc.) | validator (frontmatter + naming) |
| `README.md` | What it does, when to use it, how to install | validator (must be non-empty) |
| `CHANGELOG.md` | Keep-a-Changelog format; top version must match `version` | validator |

**Naming:** the folder name = `metadata.yml:id` = `apm.yml:name`. Lowercase, hyphen-separated.

## 3. Metadata is mandatory

`metadata.yml` is generated for agent packages and authored through the template
workflow for other artifact types. The validator rejects anything the schema flags.
The most important fields are:

- **`owner.team` / `owner.contact`** — must identify the accountable GitLab group.
- **`lifecycle.status`** — new artifacts start at `experimental` or `beta`.
- **`classification`** — data classification of the artifact content.
- **`riskTier`** — 1 (read-only) / 2 (uses tools/MCP) / 3 (shell, prod writes, or customer data).
- **`compliance.securityReview`** — must be `approved` before a tier-3 artifact (or any artifact requesting `shell`/`bash`) can merge.
- **`provenance`** — where it came from; credit upstream sources you adapted.

See **[docs/metadata-reference.md](docs/metadata-reference.md)** for a field-by-field walkthrough.

## 4. Pin your dependencies

- Reference other artifacts and MCP servers with **tags**, not `main`: `…#v1.0.0`.
- Every tool in `metadata.yml:tools` and every dependency in `apm.yml` MUST be allow-listed in [`apm-policy.yml`](apm-policy.yml). If you need a new source or MCP server, add it in the same PR and flag it for the Governance board.
- Do **not** pre-approve `shell`/`bash` in an artifact's `allowed-tools` unless the security review is complete. This removes Copilot's confirmation step and can let a prompt injection run arbitrary commands.

## 5. Versioning (SemVer)

- **MAJOR** — behaviour change that could surprise existing consumers (reworded system prompt, removed capability, new required tool).
- **MINOR** — additive, backward-compatible improvement.
- **PATCH** — typos, clarifications, non-behavioural fixes.

The `version` in `apm.yml`, `metadata.yml`, and the top of `CHANGELOG.md` must all agree.
After approval, the protected release job creates `<id>--vX.Y.Z`. See
**[docs/versioning.md](docs/versioning.md)**.

## 6. Review & merge

1. GitLab approval rules request the owning team.
2. **CI** must be green: schema validation, frontmatter checks, `apm install --dry-run` (lockfile integrity), and `apm audit --ci` (hidden-Unicode / prompt-injection scan, uploaded as SARIF).
3. **Approvals** by risk tier:
   - Tier 1 — 1 owning-team approval.
   - Tier 2 — 1 owning-team + 1 registry-maintainer approval.
   - Tier 3 — the above **plus** AI Governance / Security sign-off recorded in `metadata.yml:compliance`.
4. Start the protected registry pipeline manually from the default branch.
5. CI resolves the supplied source ref to an immutable commit and records it in metadata.
6. CI validates and audits the generated package before committing it to the registry.
7. CI tags the exact registry commit, publishes the APM archive, and rebuilds the
   catalog and GitLab Pages site. Do not hand-edit `catalog/`.

## 7. Deprecating an artifact

Open a merge request that sets `lifecycle.status: deprecated`, fills `supersededBy` and
`sunsetDate`, and adds a `CHANGELOG.md` entry. The artifact stays installable so pinned
consumers do not break, but it is flagged in the catalog.

## Local checks before you push

Run the complete agent pipeline from PowerShell after signing in to GitHub Copilot CLI.
Use `/model` in an interactive `copilot` session to select the model first. The local
pipeline omits `--model`, so Copilot CLI uses that persisted selection. The script does
not accept, read, or set a token. Authentication remains owned by Copilot CLI, using its
existing local login or its documented environment-based authentication.

```powershell
.\scripts\Invoke-LocalAgentPipeline.ps1 `
   -SourceDirectory .\agents\my-agent `
   -OwnerTeam "My Team" `
   -OwnerContact "my-team@example.com"
```

The source directory must be inside this checkout and contain exactly one `*.agent.md`
file and one `README.md`. The command validates both files against the producer schemas
and policy before invoking Copilot. The destination under `artifacts/agents/` must not already
exist. The command creates the artifact from scratch, validates and packs it, installs
the archive into a clean consumer, and rebuilds the catalog. It fails rather than
deleting or overwriting an existing artifact. Generated outputs modify the working tree.

Use deterministic generation when Copilot CLI is unavailable or you do not want to make
a model request:

```powershell
.\scripts\Invoke-LocalAgentPipeline.ps1 `
   -SourceDirectory .\agents\my-agent `
   -OwnerTeam "My Team" `
   -OwnerContact "my-team@example.com" `
   -Offline
```

Pass `-AiResponseFile` instead of `-Offline` to replay a saved JSON response. The two
options are mutually exclusive.

Run individual validation checks when a full package rehearsal is unnecessary:

```bash
python scripts/validate_artifacts.py            # validate every artifact
python scripts/validate_artifacts.py artifacts/agents/my-agent   # or just one
python scripts/validate_agent_source.py agents/my-agent/my-agent.agent.md agents/my-agent/README.md --validate-content
python scripts/build_catalog.py --check         # ensure catalog is up to date
```

Questions? Open a GitLab issue or contact the registry maintainers configured in the
project approval rules.
