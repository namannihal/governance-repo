# Changelog — AI Artifact Registry (framework)

All notable changes to the **registry framework** (schemas, policy, tooling, docs) are recorded here. Individual artifacts keep their own `CHANGELOG.md`. Format follows [Keep a Changelog](https://keepachangelog.com/); the registry uses [SemVer](https://semver.org/).

## [1.0.0] - 2026-08-04

### Added
- Initial enterprise-ready registry structure for GitHub Copilot AI artifacts.
- Artifact types: agents, skills, prompts, instructions, chat modes.
- `schemas/artifact.metadata.schema.json` — mandatory governance metadata sidecar (v1.0).
- `apm-policy.yml` — enterprise APM install-time policy (source/MCP/primitive allow-lists, pinning, audit).
- Copy-paste `templates/` for every artifact type.
- Worked example artifacts (one per type).
- `scripts/validate_artifacts.py` and `scripts/build_catalog.py`.
- CI workflows: metadata validation, `apm install --dry-run`, `apm audit --ci` (SARIF), catalog publish.
- PR and issue templates; CODEOWNERS routing.
- Authoring, governance, security, versioning and consumption docs.
