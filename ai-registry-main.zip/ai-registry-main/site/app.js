const state = {
  artifacts: [],
  packages: [],
  search: "",
  type: "",
  phase: "",
  workload: "",
  status: "",
  risk: "",
  sort: "name"
};

const elements = {
  form: document.querySelector("#filters"),
  search: document.querySelector("#search"),
  type: document.querySelector("#type-filter"),
  phase: document.querySelector("#phase-filter"),
  workload: document.querySelector("#workload-filter"),
  status: document.querySelector("#status-filter"),
  risk: document.querySelector("#risk-filter"),
  sort: document.querySelector("#sort"),
  grid: document.querySelector("#artifact-grid"),
  count: document.querySelector("#result-count"),
  chips: document.querySelector("#active-filters"),
  template: document.querySelector("#artifact-card-template"),
  dialog: document.querySelector("#artifact-dialog"),
  dialogContent: document.querySelector("#dialog-content")
};

const labels = {
  type: "Type",
  phase: "Phase",
  workload: "Workload",
  status: "Status",
  risk: "Risk"
};

function humanize(value) {
  return value.replaceAll("-", " ").replace(/\b\w/g, letter => letter.toUpperCase());
}

function uniqueValues(items, field) {
  return [...new Set(items.flatMap(item => item[field] || []))].sort();
}

function populateSelect(select, values) {
  const options = values.map(value => new Option(humanize(value), value));
  select.append(...options);
}

function searchableText(artifact) {
  return [
    artifact.displayName,
    artifact.summary,
    artifact.type,
    artifact.owner,
    ...(artifact.tags || []),
    ...(artifact.capabilities || []),
    ...(artifact.deliveryRoles || []),
    ...(artifact.deliverables || [])
  ].join(" ").toLowerCase();
}

function matchesFilters(artifact) {
  const searchMatches = !state.search || searchableText(artifact).includes(state.search);
  return searchMatches
    && (!state.type || artifact.type === state.type)
    && (!state.phase || artifact.migrationPhases.includes(state.phase))
    && (!state.workload || artifact.workloadTypes.includes(state.workload))
    && (!state.status || artifact.status === state.status)
    && (!state.risk || artifact.riskLevel === state.risk);
}

function sortArtifacts(artifacts) {
  const riskOrder = { high: 0, medium: 1, low: 2 };
  const statusOrder = { active: 0, beta: 1, experimental: 2, deprecated: 3 };
  return artifacts.sort((left, right) => {
    if (state.sort === "risk") {
      return (riskOrder[left.riskLevel] ?? 9) - (riskOrder[right.riskLevel] ?? 9);
    }
    if (state.sort === "status") {
      return (statusOrder[left.status] ?? 9) - (statusOrder[right.status] ?? 9);
    }
    return left.displayName.localeCompare(right.displayName);
  });
}

function packageFor(artifact) {
  return state.packages.find(item => item.artifacts.includes(artifact.id));
}

function installCommand(artifact) {
  const itemPackage = packageFor(artifact);
  return itemPackage ? `apm install ${itemPackage.install}` : "Not currently packaged";
}

function renderTags(container, tags, limit = tags.length) {
  tags.slice(0, limit).forEach(tag => {
    const element = document.createElement("span");
    element.className = "tag";
    element.textContent = humanize(tag);
    container.append(element);
  });
}

function createCard(artifact) {
  const card = elements.template.content.cloneNode(true);
  card.querySelector(".type-badge").textContent = artifact.type;
  card.querySelector(".status-badge").textContent = artifact.status;
  card.querySelector(".card-title").textContent = artifact.displayName;
  card.querySelector(".card-summary").textContent = artifact.summary;
  card.querySelector(".card-phase").textContent = humanize(artifact.migrationPhases[0] || "Not specified");
  card.querySelector(".card-workload").textContent = humanize(artifact.workloadTypes[0] || "Not specified");
  renderTags(card.querySelector(".tag-list"), artifact.tags, 3);
  card.querySelector(".card-action").addEventListener("click", () => showDetails(artifact));
  return card;
}

function listText(values) {
  return values.length ? values.map(humanize).join(", ") : "Not specified";
}

function showDetails(artifact) {
  const command = installCommand(artifact);
  elements.dialogContent.replaceChildren();

  const type = document.createElement("span");
  type.className = "type-badge";
  type.textContent = artifact.type;

  const title = document.createElement("h2");
  title.className = "dialog-title";
  title.id = "dialog-title";
  title.textContent = artifact.displayName;

  const summary = document.createElement("p");
  summary.className = "dialog-summary";
  summary.textContent = artifact.summary;

  const details = document.createElement("div");
  details.className = "detail-grid";
  [
    ["Migration phases", listText(artifact.migrationPhases)],
    ["Capabilities", listText(artifact.capabilities)],
    ["Workloads", listText(artifact.workloadTypes)],
    ["Delivery roles", listText(artifact.deliveryRoles)],
    ["Owner", artifact.owner || "Not specified"],
    ["Risk level", humanize(artifact.riskLevel)]
  ].forEach(([heading, text]) => {
    const section = document.createElement("section");
    const sectionHeading = document.createElement("h3");
    const sectionText = document.createElement("p");
    sectionHeading.textContent = heading;
    sectionText.textContent = text;
    section.append(sectionHeading, sectionText);
    details.append(section);
  });

  const install = document.createElement("section");
  install.className = "install-block";
  const installHeading = document.createElement("h3");
  installHeading.textContent = "Install with APM";
  const commandRow = document.createElement("div");
  commandRow.className = "command-row";
  const code = document.createElement("code");
  code.textContent = command;
  commandRow.append(code);

  if (command.startsWith("apm install")) {
    const copy = document.createElement("button");
    copy.className = "copy-button";
    copy.type = "button";
    copy.textContent = "Copy";
    copy.addEventListener("click", async () => {
      await navigator.clipboard.writeText(command);
      copy.textContent = "Copied";
      window.setTimeout(() => { copy.textContent = "Copy"; }, 1500);
    });
    commandRow.append(copy);
  }

  install.append(installHeading, commandRow);
  elements.dialogContent.append(type, title, summary, details, install);
  elements.dialog.showModal();
}

function renderActiveFilters() {
  elements.chips.replaceChildren();
  Object.keys(labels).forEach(key => {
    if (!state[key]) return;
    const chip = document.createElement("button");
    chip.className = "filter-chip";
    chip.type = "button";
    chip.textContent = `${labels[key]}: ${humanize(state[key])} ×`;
    chip.addEventListener("click", () => {
      state[key] = "";
      elements[key].value = "";
      render();
    });
    elements.chips.append(chip);
  });
}

function render() {
  const artifacts = sortArtifacts(state.artifacts.filter(matchesFilters));
  elements.grid.replaceChildren();
  elements.grid.setAttribute("aria-busy", "false");
  elements.count.textContent = artifacts.length;
  renderActiveFilters();

  if (!artifacts.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "No artifacts match these filters. Clear a filter or try another search.";
    elements.grid.append(empty);
    return;
  }

  artifacts.forEach(artifact => elements.grid.append(createCard(artifact)));
}

function bindEvents() {
  elements.search.addEventListener("input", event => {
    state.search = event.target.value.trim().toLowerCase();
    render();
  });
  Object.keys(labels).forEach(key => {
    elements[key].addEventListener("change", event => {
      state[key] = event.target.value;
      render();
    });
  });
  elements.sort.addEventListener("change", event => {
    state.sort = event.target.value;
    render();
  });
  elements.form.addEventListener("reset", () => {
    window.setTimeout(() => {
      Object.assign(state, { search: "", type: "", phase: "", workload: "", status: "", risk: "" });
      render();
    });
  });
  document.querySelector("#close-dialog").addEventListener("click", () => elements.dialog.close());
  elements.dialog.addEventListener("click", event => {
    if (event.target === elements.dialog) elements.dialog.close();
  });
}

async function loadCatalog() {
  try {
    const response = await fetch("./catalog/index.json");
    if (!response.ok) throw new Error(`Catalog request failed with status ${response.status}`);
    const catalog = await response.json();
    state.artifacts = catalog.artifacts;
    state.packages = catalog.packages;

    document.querySelector("#artifact-total").textContent = catalog.counts.totalArtifacts;
    document.querySelector("#package-total").textContent = catalog.counts.totalPackages;
    document.querySelector("#active-total").textContent = catalog.facets.statuses.active || 0;
    populateSelect(elements.type, uniqueValues(state.artifacts, "type"));
    populateSelect(elements.phase, uniqueValues(state.artifacts, "migrationPhases"));
    populateSelect(elements.workload, uniqueValues(state.artifacts, "workloadTypes"));
    populateSelect(elements.status, uniqueValues(state.artifacts, "status"));
    populateSelect(elements.risk, uniqueValues(state.artifacts, "riskLevel"));
    render();
  } catch (error) {
    elements.grid.innerHTML = `<p class="error">Unable to load the catalog. ${error.message}</p>`;
    elements.grid.setAttribute("aria-busy", "false");
  }
}

bindEvents();
loadCatalog();