---
title: Skill Changelog Template
description: Release history template for a registry skill
---

Format: [Keep a Changelog](https://keepachangelog.com/) · [SemVer](https://semver.org/).
The top version MUST match `apm.yml:version`.

## [1.0.0] - 2026-01-01
### Added
- Initial release.
