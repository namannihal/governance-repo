---
title: Instruction Template
description: Documentation template for a registry instruction
---

> One-line summary (mirror `metadata.yml:summary`).

## What it does
Describe the agent's purpose and behaviour.

## When to use it
Describe the trigger scenarios Copilot should route on.

## Install
```bash
apm install praro_microsoft/ai-registry/packages/INSTRUCTION_ID#v1.0.0
```

## Tools / MCP
List any tools or MCP servers this agent requires (must be allow-listed in `apm-policy.yml`).

## Owner
`@contoso/your-team` · your-team@contoso.com
