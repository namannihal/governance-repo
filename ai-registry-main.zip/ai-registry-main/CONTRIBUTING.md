---
title: Contributing to the AI Artifact Registry
description: Contribution workflow and quality requirements for governed AI artifacts
---

Contribute migration AI artifacts through pull requests. The owning team reviews artifact behavior, migration classification, packaging, and security implications.

## TL;DR

```bash
# 1. Scaffold the governed asset and package
python scripts/scaffold_artifact.py --type skill --id my-new-skill \
   --display-name "My New Skill" \
   --summary "Describe when contributors and agents should use this skill." \
   --phase engineering \
   --capability remediation \
   --workload-type applications

# 2. Complete metadata, primitive content, README, and changelog

# 3. Validate locally (same checks CI runs)
python scripts/validate_artifacts.py artifacts/skills/my-new-skill
python scripts/build_packages.py
python scripts/build_catalog.py

# 4. Commit, push, open a PR
```

---

## 1. Pick the right artifact type

| Use a… | When you want to… | Primitive file |
|--------|-------------------|----------------|
| **Instruction** | Add always-on guardrails/standards the agent reads every turn | `*.instructions.md` |
| **Prompt** | Save a reusable, named prompt users invoke on demand | `*.prompt.md` |
| **Skill** | Package a multi-file, model-invoked capability (with scripts/assets) | `SKILL.md` + assets |
| **Agent** | Define a specialised persona with its own model, tools and system prompt | `*.agent.md` |
| **Chat mode** | Ship a scoped VS Code chat mode | `*.chatmode.md` |

Not sure? See **[docs/authoring/](docs/authoring/)**. Prefer an **instruction** for simple, universal rules and a **skill** for detailed capabilities the agent should only load when relevant.

## 2. Required files in every artifact

Every folder under `artifacts/<type>/<id>/` MUST contain:

| File | Purpose | Enforced by |
|------|---------|-------------|
| `metadata.yml` | Migration discovery metadata sidecar | validator against `schemas/artifact.metadata.schema.json` |
| Primitive source | `SKILL.md`, `*.agent.md`, `*.prompt.md`, `*.instructions.md`, or `*.chatmode.md` | validator (frontmatter + naming) |
| `README.md` | What it does, when to use it, how to install | validator (must be non-empty) |
| `CHANGELOG.md` | Release history; top version must match the local APM manifest when present | validator |

Every source-only asset must be listed in a `packages/<name>/package.yml` composition sidecar. A package can publish one asset or compose several assets that must be installed together. Run `python scripts/build_packages.py` to materialize deterministic `.apm/` package sources. Self-contained assets with a local `apm.yml` and `.apm/` source remain supported.

**Naming:** the artifact folder name must equal `metadata.yml:id`. Package folder names must equal `apm.yml:name`. Use lowercase, hyphen-separated names.

## 3. Metadata is mandatory

`metadata.yml` powers migration catalog discovery. Fill every required field:

* Use `owner.team` for accountability and `owner.maintainers` for individual contacts
* Start new artifacts with `lifecycle.status: experimental` or `beta`
* Classify the artifact with migration phases, capabilities, and workload types
* Add strategies, delivery roles, and deliverables when they improve discovery
* Set `riskLevel` to `low`, `medium`, or `high`

See **[docs/metadata-reference.md](docs/metadata-reference.md)** for a field-by-field walkthrough.

## 4. Pin your dependencies

- Reference other artifacts and MCP servers with **tags**, not `main`: `…#v1.0.0`.
- Every package dependency must resolve to an existing registry asset and include a tag or full SHA.
- Every package dependency and MCP server in `apm.yml` must comply with [`apm-policy.yml`](apm-policy.yml). Add required policy changes in the same PR.
- Do **not** pre-approve `shell`/`bash` in an artifact's `allowed-tools` unless the security review is complete. This removes Copilot's confirmation step and can let a prompt injection run arbitrary commands.

## 5. Versioning (SemVer)

- **MAJOR** — behaviour change that could surprise existing consumers (reworded system prompt, removed capability, new required tool).
- **MINOR** — additive, backward-compatible improvement.
- **PATCH** — typos, clarifications, non-behavioural fixes.

The `version` in `apm.yml` and the top of `CHANGELOG.md` must agree. Metadata has no release version. After merge, a maintainer tags the release. See **[docs/versioning.md](docs/versioning.md)**.

## 6. Review & merge

1. **CODEOWNERS** auto-requests the owning team.
2. **CI** must be green: schema validation, frontmatter checks, `apm install --dry-run` (lockfile integrity), and `apm audit --ci` (hidden-Unicode / prompt-injection scan, uploaded as SARIF).
3. Required owners review the migration classification, artifact behavior, and package security.
4. On merge, the catalog is rebuilt automatically. Do not hand-edit `catalog/`.

## 7. Deprecating an artifact

Open a PR that sets `lifecycle.status: deprecated`, fills `supersededBy`, and adds a `CHANGELOG.md` entry. The artifact stays installable for pinned consumers but is flagged in the catalog.

## Local checks before you push

```bash
python scripts/validate_artifacts.py            # validate every artifact
python scripts/validate_artifacts.py artifacts/agents/my-agent   # or just one
python scripts/build_packages.py                # materialize package .apm sources
python scripts/build_packages.py --check        # ensure package sources are current
python scripts/build_catalog.py                 # rebuild generated catalog files
python scripts/build_catalog.py --check         # ensure catalog is deterministic and current
```

Questions? Open a **Change request** issue or reach the registry maintainers listed in [`.github/CODEOWNERS`](.github/CODEOWNERS).
