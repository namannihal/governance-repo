---
title: Migration AI Artifact Registry
description: Registry of migration-team AI assets and publishable APM packages
---

A registry of **migration-team AI artifacts for GitHub Copilot**: agents, skills, prompts, instructions, and chat modes distributed with **[APM (Agent Package Manager)](https://microsoft.github.io/apm/)**.

Teams contribute artifacts through pull requests and consume published packages with `apm install`. Migration metadata makes artifacts discoverable by phase, capability, workload, strategy, delivery role, and deliverable.

---

## Why this registry exists

Teams have been hand-crafting Copilot instructions, prompts, skills and agents and copying them between repos, where they silently drift. This registry gives AI agent configuration the same treatment we give code: **a manifest, a lockfile, metadata, review, and CI**.

- **One source of truth** for approved Copilot artifacts across the org.
- **Reproducible** — consumers pin to a tag or commit SHA; APM records a content hash in `apm.lock.yaml`.
- **Discoverable** — every artifact carries controlled migration facets, ownership, lifecycle, and risk metadata enforced by CI against a JSON Schema.
- **Portable** — artifacts are authored once under `.apm/` and compile to Copilot (`.github/`) and, where relevant, Claude, Cursor, Codex, Gemini and more.

## What lives here

| Type | Folder | Source primitive | Copilot compile target |
|------|--------|---------------|------------------------|
| **Agents** | `artifacts/agents/` | `agents/*.agent.md` | `.github/agents/` |
| **Skills** | `artifacts/skills/` | `skills/<name>/SKILL.md` | `.github/skills/` |
| **Prompts** | `artifacts/prompts/` | `prompts/*.prompt.md` | `.github/prompts/` |
| **Instructions** | `artifacts/instructions/` | `instructions/*.instructions.md` | `.github/instructions/` |
| **Chat modes** | `artifacts/chatmodes/` | `chatmodes/*.chatmode.md` | `.github/chatmodes/` |

Each asset has a `metadata.yml` discovery sidecar, a `README.md`, a `CHANGELOG.md`, and a primitive source. Existing self-contained `.apm/` assets remain supported. Publishable manifests live under `packages/`, where one package can compose one or more assets.

## Repository layout

```
ai-artifact-registry/
├── README.md                     # You are here
├── CONTRIBUTING.md               # PR-based contribution workflow
├── CHANGELOG.md                  # Registry-level changelog
├── LICENSE
├── apm-policy.yml                # Enterprise APM policy (allow-listed sources, MCP, primitives)
├── registry.yml                  # Repository identity and scaffolding defaults
├── .gitignore                    # ignores apm_modules/ (build cache)
│
├── schemas/                      # JSON Schemas that CI enforces
│   └── artifact.metadata.schema.json
│
├── templates/                    # Copy-paste starting points, one per artifact type
│   ├── agent/  skill/  prompt/  instruction/  chatmode/
│
├── artifacts/                    # THE REGISTRY — one folder per published artifact
│   ├── agents/<id>/
│   ├── skills/<id>/
│   ├── prompts/<id>/
│   ├── instructions/<id>/
│   └── chatmodes/<id>/
│
├── catalog/                      # Generated index of everything (do not hand-edit)
│   ├── index.json
│   └── index.md
│
├── docs/                         # Getting started, authoring guides, governance
├── packages/                     # APM manifests, composition sidecars, and generated sources
├── scripts/                      # scaffold, package build, validation, and catalog automation
└── .github/                      # CODEOWNERS, PR/issue templates, CI workflows
```

## Consuming an artifact

Install the [APM CLI](https://microsoft.github.io/apm/), then pull any artifact by its path, **pinned to a tag**:

```bash
# Install a single agent from this registry
apm install praro_microsoft/ai-registry/packages/azure-iac-reviewer#v1.0.0

# Install a skill
apm install praro_microsoft/ai-registry/packages/terraform-plan-review#v1.0.0

apm install            # resolve everything in your repo's apm.yml
```

APM clones the registry, verifies the content hash, and compiles the primitive into `.github/` (and any other harness you target). Commit `apm.yml`, `apm.lock.yaml`, and the deployed `.github/` files so Copilot on github.com sees them too. See **[docs/consuming-artifacts.md](docs/consuming-artifacts.md)**.

## Contributing an artifact

1. Run `python scripts/scaffold_artifact.py` with the artifact type, ID, display name, and summary.
2. Replace scaffold placeholders and complete the primitive, metadata, README, and changelog.
3. Run `python scripts/build_packages.py`, `python scripts/validate_artifacts.py`, and `python scripts/build_catalog.py` locally.
4. Open a PR. CODEOWNERS routes it to the right reviewers; CI validates metadata and package references, runs the APM security audit, and checks the generated catalog.

Full workflow and quality bar: **[CONTRIBUTING.md](CONTRIBUTING.md)**.

## Governance at a glance

* **Migration discovery**: controlled facets power catalog and future UI filters
* **Ownership**: every artifact names an accountable team and may list maintainers
* **Lifecycle**: `experimental`, `beta`, `active`, `deprecated`, or `retired`
* **Risk**: a simple `low`, `medium`, or `high` discovery signal
* **Security**: APM scans installs and enforces source, primitive, dependency, and MCP policy

See **[docs/governance.md](docs/governance.md)**, **[docs/security.md](docs/security.md)** and **[docs/versioning.md](docs/versioning.md)**.
