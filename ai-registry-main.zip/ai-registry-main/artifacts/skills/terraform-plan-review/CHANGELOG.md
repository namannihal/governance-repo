# Changelog — terraform-plan-review

## [1.0.0] - 2026-08-04
### Added
- Initial release: risk-ranked review of `terraform plan` output with an apply/don't-apply verdict.
- Blocker handling for destructive actions on stateful resources.
