---
name: terraform-plan-review
description: Reviews a `terraform plan` output for risky changes — deletes, replacements, IAM/permission changes and provider drift. Use when asked to review a Terraform plan or apply before it runs.
license: MIT
---

# Terraform Plan Review

Use this skill when asked to review a `terraform plan` (or an apply that is about to run).
You are read-only: analyse the plan, never run `terraform apply`.

## Input
The user provides plan output as text, or the JSON form from:

```
terraform plan -out plan.tfplan && terraform show -json plan.tfplan > plan.json
```

Prefer the `-json` form when available — it is unambiguous about action types.

## Review procedure
1. **Summarise the change counts** — to add / change / destroy / replace.
2. **Destructive actions first.** List every `delete` and `replace`. For stateful resources
   (databases, storage accounts, key vaults, disks, DNS zones) mark them **Blocker** and
   require explicit confirmation.
3. **Permission changes.** Flag any change to IAM roles, role assignments, policies, service
   principals or key/secret access.
4. **Drift & versions.** Note provider or module version changes and any resource being
   replaced due to a forced new attribute; name the attribute that forces replacement.
5. **Blast radius.** Estimate how many resources and which environments are affected.

## Output format
```
## Terraform Plan Review
Change summary: +A ~C -D (R replacements)

### Blockers
- <resource> — <why> — <action>

### Major
- ...

### Minor
- ...

Verdict: <safe to apply / apply with confirmations / do not apply>
```

Always end with a one-line verdict. If the plan is empty or unparseable, say so instead of guessing.
