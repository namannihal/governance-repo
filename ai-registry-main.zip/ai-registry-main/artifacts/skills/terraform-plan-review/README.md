---
title: Terraform Plan Review
description: Read-only review skill for Terraform plan output
---

> Reviews a `terraform plan` output for risky changes — deletes, replacements, IAM and drift.

## What it does
A model-invoked skill that turns raw `terraform plan` output into a risk-ranked review with
a clear apply / don't-apply verdict. Read-only.

## When to use it
Ask Copilot to "review this terraform plan" and paste the plan text or `terraform show -json` output.

## Install
```bash
apm install praro_microsoft/ai-registry/packages/terraform-plan-review#v1.0.0
```

## Risk & ownership
- **Risk level:** medium (analysis only; no `apply`, no production writes)
- **Owner:** `@contoso/platform-ai` · platform-ai@contoso.com
