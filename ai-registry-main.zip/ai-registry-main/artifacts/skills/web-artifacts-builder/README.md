---
title: Web Artifacts Builder Skill
description: Skill for creating responsive and shareable interactive web artifacts
---

## Purpose

The skill provides the design system, implementation workflow, bundling scripts, and
validation rules used to produce interactive HTML artifacts and web applications.

## Install

```bash
apm install praro_microsoft/ai-registry/packages/web-artifact-builder#v1.0.0
```

See `SKILL.md` for the complete workflow and `references/` for sharing guidance.