---
title: Web Artifacts Builder Skill Changelog
description: Release history for the web artifacts builder skill
---

## [1.0.0] - 2026-08-05

### Added

* Initial responsive artifact workflow, Clawpilot theme, bundling scripts, and sharing guidance