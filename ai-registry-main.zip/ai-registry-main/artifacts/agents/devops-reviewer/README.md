---
title: Azure IaC Reviewer
description: Read-only review agent for Azure infrastructure-as-code changes
---

> Reviews Azure Bicep/Terraform IaC changes for security, cost and policy issues in a PR.

## What it does
A read-only reviewer persona that inspects infrastructure-as-code diffs and comments with
severity-ranked, actionable findings. It never applies changes.

## When to use it
Select this agent when asked to review Bicep or Terraform changes in a pull request.

## Install
```bash
apm install praro_microsoft/ai-registry/packages/devops-reviewer#v1.0.0
```

## Tools / MCP
- `read`, `search`
- `io.github.github/github-mcp-server` (to read PR diffs)

All allow-listed in [`apm-policy.yml`](../../../apm-policy.yml).

## Risk & ownership
- **Risk level:** medium (uses MCP tools; read-only, no production writes)
- **Owner:** `@contoso/platform-ai` · platform-ai@contoso.com
- **Adapted from:** `github/awesome-copilot/agents/azure-iac-generator.agent.md`
