# Changelog — azure-iac-reviewer

## [1.0.0] - 2026-08-04
### Added
- Initial release: security, Azure Policy, standards and cost review for Bicep/Terraform diffs.
- Requires a change-ticket reference before approving production-facing changes.
