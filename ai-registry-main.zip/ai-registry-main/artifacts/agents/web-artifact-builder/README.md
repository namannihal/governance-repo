---
title: Web Artifact Builder Agent
description: Agent wrapper for creating and validating interactive web artifacts
---

## Purpose

The agent coordinates interactive web artifact work and loads the companion
`web-artifacts-builder` skill for implementation, styling, validation, and sharing rules.

## Install

```bash
apm install praro_microsoft/ai-registry/packages/web-artifact-builder#v1.0.0
```

The package installs both the agent and its required skill.