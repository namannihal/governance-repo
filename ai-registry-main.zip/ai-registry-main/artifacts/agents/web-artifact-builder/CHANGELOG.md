---
title: Web Artifact Builder Agent Changelog
description: Release history for the web artifact builder agent
---

## [1.0.0] - 2026-08-05

### Added

* Initial agent wrapper for requirement discovery, implementation coordination, and validation