---
name: security-reviewer
description: Reviews code changes for security risks.
---

# Security Reviewer

TODO: Define the artifact's behavior, workflow, constraints, and expected output.
