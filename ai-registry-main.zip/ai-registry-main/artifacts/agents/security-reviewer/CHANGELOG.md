---
title: Security Reviewer Changelog
description: Release history for Security Reviewer
---

## [1.0.0] - 2026-08-05

### Added

* Initial scaffold
