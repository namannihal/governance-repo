---
title: Security Reviewer
description: Reviews code changes for security risks.
---

## Purpose

TODO: Explain when to use this artifact and what users should expect.

## Install

```bash
apm install praro_microsoft/ai-registry/packages/security-reviewer#v1.0.0
```
