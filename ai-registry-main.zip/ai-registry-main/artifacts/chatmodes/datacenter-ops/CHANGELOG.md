# Changelog — datacenter-ops

## [1.0.0] - 2026-08-04
### Added
- Initial beta release: triage, runbook lookup and capacity guidance with mandatory change-ticket gating on production actions.
