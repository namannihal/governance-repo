---
title: Datacenter Ops
description: Change-controlled assistant for datacenter operations
---

> Datacenter operations assistant — triage, runbooks and capacity questions (change-controlled).

## What it does
A VS Code chat-mode persona for datacenter operations. It helps with incident triage, runbook
lookup and capacity questions, and enforces change control before proposing any production action.

## When to use it
Select the **Datacenter Ops** chat mode when working on datacenter operational tasks.

## Install
```bash
apm install praro_microsoft/ai-registry/artifacts/chatmodes/datacenter-ops#v1.0.0
```

## Tools / MCP
- `read`, `search`
- `io.github.github/github-mcp-server`

## Risk & ownership
- **Risk level:** high (can propose production actions)
- **Owner:** `@contoso/datacenter-delivery` · dc-delivery-nl@contoso.com
