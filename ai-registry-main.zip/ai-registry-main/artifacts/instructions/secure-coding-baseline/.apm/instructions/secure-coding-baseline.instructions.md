---
description: Secure-coding baseline applied to all source files.
applyTo: "**/*.{ts,tsx,js,jsx,py,cs,go,java,rb}"
---

# Secure Coding Baseline

- Validate, sanitise and encode all external input at trust boundaries.
- Never hard-code or log secrets, tokens, connection strings or PII. Read secrets from a vault/secret store.
- Use parameterised queries or an ORM; never build SQL/NoSQL queries by string concatenation.
- Enforce authentication and authorization on every entry point; deny by default.
- Use vetted crypto libraries; never roll your own. Use TLS for data in transit.
- Pin and scan dependencies; do not add packages from untrusted sources.
- Handle errors without leaking stack traces, internal paths or secrets to callers.
- Prefer least-privilege for every identity, token and resource the code touches.
