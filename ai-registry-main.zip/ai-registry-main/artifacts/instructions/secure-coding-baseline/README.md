---
title: Secure Coding Baseline
description: Always-on secure coding guardrails for source files
---

> Always-on secure-coding guardrails applied across source files.

## What it does
Repository-scoped instructions Copilot reads on every matching turn — input validation,
secret hygiene, safe data access, dependency and logging rules.

## When to use it
Install in any repo to enforce a consistent secure-coding baseline. Scoped via `applyTo`
to common source languages.

## Install
```bash
apm install praro_microsoft/ai-registry/artifacts/instructions/secure-coding-baseline#v1.0.0
```

## Risk & ownership
- **Risk level:** low (guidance only)
- **Owner:** `@contoso/security-engineering` · security-engineering@contoso.com
- **Security review:** approved (2026-08-04)
