# Changelog — secure-coding-baseline

## [1.0.0] - 2026-08-04
### Added
- Initial release: input validation, secret hygiene, safe data access, crypto, dependency and logging rules.
