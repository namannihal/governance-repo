# Changelog — incident-postmortem

## [1.0.0] - 2026-08-04
### Added
- Initial release: blameless post-incident review with fixed sections and owner/due-date action items.
