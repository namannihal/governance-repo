---
title: Incident Post-Mortem
description: Prompt for generating a blameless post-incident review
---

> Generates a blameless post-incident review from an incident timeline.

## What it does
Turns incident notes into a structured, blameless review with owners and due dates on every action item.

## When to use it
After an incident is resolved. Invoke the prompt and pass the timeline/notes via `${input:incidentNotes}`.

## Install
```bash
apm install praro_microsoft/ai-registry/artifacts/prompts/incident-postmortem#v1.0.0
```

## Risk & ownership
- **Risk level:** low (read-only text generation)
- **Owner:** `@contoso/sre-oncall` · sre-oncall@contoso.com
