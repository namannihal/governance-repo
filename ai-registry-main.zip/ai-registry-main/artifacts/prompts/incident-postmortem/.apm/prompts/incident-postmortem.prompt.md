---
name: incident-postmortem
description: Generates a blameless post-incident review from an incident timeline or notes.
mode: agent
model: gpt-5
---

Write a **blameless** post-incident review from the incident details below. Focus on
systems and processes, never on individual blame. Keep it factual and specific.

Use exactly these sections:

1. **Summary** — 2-3 sentences: what happened and the outcome.
2. **Impact** — who/what was affected, duration, and severity.
3. **Timeline** — detection → escalation → mitigation → resolution, with timestamps.
4. **Root cause** — the contributing factors and the primary root cause.
5. **What went well** — controls and actions that helped.
6. **Action items** — a table of concrete follow-ups, each with an **owner** and a **due date**.

Incident details:
${input:incidentNotes}
