#!/usr/bin/env python3
"""Materialize publishable APM packages from governed registry assets.

Usage:
    python scripts/build_packages.py
    python scripts/build_packages.py --check
"""
from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = ROOT / "artifacts"
PACKAGES_DIR = ROOT / "packages"
TYPE_DIRS = {
    "agent": "agents",
    "skill": "skills",
    "prompt": "prompts",
    "instruction": "instructions",
    "chatmode": "chatmodes",
}
SUFFIXES = {
    "agent": ".agent.md",
    "prompt": ".prompt.md",
    "instruction": ".instructions.md",
    "chatmode": ".chatmode.md",
}
SKILL_CONTENT = {"SKILL.md", "LICENSE.txt", "scripts", "references", "assets"}


def load_yaml(path: Path) -> dict:
    """Load a YAML mapping."""
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream) or {}


def discover_artifacts() -> dict[str, tuple[Path, dict]]:
    """Index governed artifact folders by immutable metadata ID."""
    artifacts = {}
    for metadata_path in ARTIFACTS_DIR.glob("*/*/metadata.yml"):
        metadata = load_yaml(metadata_path)
        artifacts[str(metadata.get("id"))] = (metadata_path.parent, metadata)
    return artifacts


def direct_primitive(folder: Path, artifact_type: str) -> Path:
    """Locate a primitive in supported source layouts."""
    if artifact_type == "skill":
        candidates = [folder / "SKILL.md", folder / "skills" / "SKILL.md"]
        candidates.extend(folder.glob("skills/*/SKILL.md"))
    else:
        candidates = list(folder.glob(f"*{SUFFIXES[artifact_type]}"))
    primitive = next((path for path in candidates if path.is_file()), None)
    if primitive is None:
        raise ValueError(f"No {artifact_type} primitive found in {folder.relative_to(ROOT)}")
    return primitive


def copy_artifact(folder: Path, metadata: dict, destination: Path) -> None:
    """Copy one governed artifact into an APM package source tree."""
    artifact_type = metadata["type"]
    artifact_id = metadata["id"]
    packaged = folder / ".apm" / TYPE_DIRS[artifact_type]
    if artifact_type == "skill":
        packaged_skill = packaged / artifact_id
        if packaged_skill.is_dir():
            shutil.copytree(packaged_skill, destination / "skills" / artifact_id)
            return
        primitive = direct_primitive(folder, artifact_type)
        target = destination / "skills" / artifact_id
        target.mkdir(parents=True, exist_ok=True)
        source_root = primitive.parent if primitive.parent != folder / "skills" else folder
        shutil.copy2(primitive, target / "SKILL.md")
        for name in SKILL_CONTENT - {"SKILL.md"}:
            source = source_root / name
            if source.is_dir():
                shutil.copytree(source, target / name)
            elif source.is_file():
                shutil.copy2(source, target / name)
        return

    packaged_files = list(packaged.glob(f"*{SUFFIXES[artifact_type]}")) if packaged.is_dir() else []
    primitive = packaged_files[0] if packaged_files else direct_primitive(folder, artifact_type)
    target = destination / TYPE_DIRS[artifact_type]
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(primitive, target / primitive.name)


def build_package(folder: Path, artifacts: dict[str, tuple[Path, dict]], destination: Path) -> None:
    """Build one package source tree from its composition sidecar."""
    composition = load_yaml(folder / "package.yml")
    for artifact_id in composition.get("artifacts") or []:
        if artifact_id not in artifacts:
            raise ValueError(f"Unknown artifact '{artifact_id}' in {folder.relative_to(ROOT)}/package.yml")
        copy_artifact(*artifacts[artifact_id], destination)


def directories_equal(left: Path, right: Path) -> bool:
    """Recursively compare two package source directories."""
    left_files = {path.relative_to(left) for path in left.rglob("*") if path.is_file()}
    right_files = {path.relative_to(right) for path in right.rglob("*") if path.is_file()}
    if left_files != right_files:
        return False
    return all(
        (left / relative).read_bytes() == (right / relative).read_bytes()
        for relative in left_files
    )


def main() -> int:
    """Build package sources or fail if checked-in output is stale."""
    check = "--check" in sys.argv[1:]
    artifacts = discover_artifacts()
    stale = []
    for folder in sorted(path for path in PACKAGES_DIR.glob("*") if path.is_dir()):
        if not (folder / "package.yml").is_file():
            continue
        with tempfile.TemporaryDirectory() as temporary:
            expected = Path(temporary) / ".apm"
            expected.mkdir()
            build_package(folder, artifacts, expected)
            actual = folder / ".apm"
            if check:
                if not actual.is_dir() or not directories_equal(actual, expected):
                    stale.append(folder.relative_to(ROOT).as_posix())
            else:
                if actual.exists():
                    shutil.rmtree(actual)
                shutil.copytree(expected, actual)
    if stale:
        print("Stale package sources: " + ", ".join(stale))
        print("Run: python scripts/build_packages.py")
        return 1
    print(f"{'Checked' if check else 'Built'} {len(list(PACKAGES_DIR.glob('*/package.yml')))} package(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())