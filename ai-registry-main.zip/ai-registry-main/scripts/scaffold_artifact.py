#!/usr/bin/env python3
"""Scaffold a governed registry artifact and its APM publication package.

Example:
    python scripts/scaffold_artifact.py --type skill --id cost-review \
        --display-name "Cost Review" --summary "Reviews cloud changes for avoidable cost."
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "registry.yml"
TYPE_CONFIG = {
    "agent": ("agents", "{id}.agent.md"),
    "skill": ("skills", "SKILL.md"),
    "prompt": ("prompts", "{id}.prompt.md"),
    "instruction": ("instructions", "{id}.instructions.md"),
    "chatmode": ("chatmodes", "{id}.chatmode.md"),
}
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
MIGRATION_PHASES = (
    "discovery-assessment", "planning-design", "mobilization", "engineering",
    "validation", "cutover", "hypercare", "optimization",
)
MIGRATION_CAPABILITIES = (
    "portfolio-discovery", "dependency-mapping", "readiness-assessment", "business-case",
    "wave-planning", "architecture-design", "landing-zone", "remediation",
    "migration-execution", "data-migration", "testing-validation", "cutover-orchestration",
    "rollback-planning", "hypercare-operations", "security-compliance", "cost-optimization",
    "program-governance", "reporting",
)
WORKLOAD_TYPES = (
    "applications", "infrastructure", "databases", "data-platforms", "integration",
    "virtual-desktops", "security", "cross-workload",
)


def create_parser() -> argparse.ArgumentParser:
    """Create the command-line parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--type", required=True, choices=TYPE_CONFIG)
    parser.add_argument("--id", required=True, help="Immutable lowercase kebab-case ID")
    parser.add_argument("--display-name", required=True)
    parser.add_argument("--summary", required=True, help="Catalog summary, 10 to 160 characters")
    parser.add_argument("--description", help="Detailed routing description; defaults to summary")
    parser.add_argument("--owner-team")
    parser.add_argument("--owner-contact")
    parser.add_argument("--maintainer-name")
    parser.add_argument("--maintainer-github", default="@your-handle")
    parser.add_argument("--maintainer-email")
    parser.add_argument("--phase", action="append", required=True, choices=MIGRATION_PHASES)
    parser.add_argument("--capability", action="append", required=True, choices=MIGRATION_CAPABILITIES)
    parser.add_argument("--workload-type", action="append", required=True, choices=WORKLOAD_TYPES)
    parser.add_argument("--strategy", action="append", default=[])
    parser.add_argument("--delivery-role", action="append", default=[])
    parser.add_argument("--deliverable", action="append", default=[])
    parser.add_argument("--risk-level", choices=("low", "medium", "high"))
    parser.add_argument("--license")
    parser.add_argument("--package-name", help="Defaults to the artifact ID")
    parser.add_argument("--no-package", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def load_config() -> dict:
    """Load registry-wide scaffolding defaults."""
    if not CONFIG_PATH.is_file():
        raise ValueError(f"Missing registry configuration: {CONFIG_PATH.relative_to(ROOT)}")
    with CONFIG_PATH.open(encoding="utf-8") as stream:
        config = yaml.safe_load(stream) or {}
    if not (config.get("repository") or {}).get("slug"):
        raise ValueError("registry.yml must define repository.slug")
    return config


def primitive_content(artifact_type: str, artifact_id: str, display_name: str, description: str) -> str:
    """Render a minimal valid primitive for the selected type."""
    if artifact_type == "instruction":
        frontmatter = {"description": description, "applyTo": "**"}
    else:
        frontmatter = {"name": artifact_id, "description": description}
    if artifact_type == "skill":
        frontmatter["license"] = "See package apm.yml"

    rendered = yaml.safe_dump(frontmatter, sort_keys=False, allow_unicode=False).strip()
    return (
        f"---\n{rendered}\n---\n\n"
        f"# {display_name}\n\n"
        "TODO: Define the artifact's behavior, workflow, constraints, and expected output.\n"
    )


def artifact_files(args: argparse.Namespace, config: dict) -> dict[Path, str]:
    """Build the artifact files without writing them."""
    defaults = config.get("defaults") or {}
    package_defaults = config.get("packageDefaults") or {}
    owner_defaults = defaults.get("owner") or {}
    repository = config["repository"]
    artifact_id = args.id
    artifact_type = args.type
    parent, primitive_pattern = TYPE_CONFIG[artifact_type]
    folder = ROOT / "artifacts" / parent / artifact_id
    description = args.description or args.summary
    risk_level = args.risk_level or defaults.get("riskLevel", "low")
    today = dt.date.today()
    package_name = args.package_name or artifact_id

    owner = {
        "team": args.owner_team or owner_defaults.get("team"),
        "maintainers": [{"github": args.maintainer_github}],
    }
    if args.owner_contact or owner_defaults.get("contact"):
        owner["contact"] = args.owner_contact or owner_defaults.get("contact")
    if args.maintainer_name:
        owner["maintainers"][0]["name"] = args.maintainer_name
    if args.maintainer_email:
        owner["maintainers"][0]["email"] = args.maintainer_email

    metadata = {
        "schemaVersion": "2.0",
        "id": artifact_id,
        "displayName": args.display_name,
        "type": artifact_type,
        "summary": args.summary,
        "owner": owner,
        "lifecycle": {"status": defaults.get("lifecycleStatus", "experimental")},
        "migration": {
            "phases": args.phase,
            "capabilities": args.capability,
            "workloadTypes": args.workload_type,
            "strategies": args.strategy,
            "deliveryRoles": args.delivery_role,
            "deliverables": args.deliverable,
        },
        "riskLevel": risk_level,
        "tags": [],
    }
    install_reference = (
        f"{repository['slug']}/packages/{package_name}#v1.0.0" if not args.no_package else ""
    )
    primitive_name = primitive_pattern.format(id=artifact_id)
    install_section = (
        f"```bash\napm install {install_reference}\n```"
        if install_reference
        else "Add this asset to a package manifest before publishing it."
    )
    readme = (
        f"---\ntitle: {args.display_name}\ndescription: {args.summary}\n---\n\n"
        "## Purpose\n\nTODO: Explain when to use this artifact and what users should expect.\n\n"
        f"## Install\n\n{install_section}\n"
    )
    changelog = (
        f"---\ntitle: {args.display_name} Changelog\n"
        f"description: Release history for {args.display_name}\n---\n\n"
        f"## [1.0.0] - {today.isoformat()}\n\n### Added\n\n* Initial scaffold\n"
    )
    files = {
        folder / "metadata.yml": yaml.safe_dump(metadata, sort_keys=False, allow_unicode=False),
        folder / "README.md": readme,
        folder / "CHANGELOG.md": changelog,
        folder / primitive_name: primitive_content(artifact_type, artifact_id, args.display_name, description),
    }

    if not args.no_package:
        package = {
            "name": package_name,
            "version": "1.0.0",
            "description": args.summary,
            "type": "hybrid",
            "author": {
                "name": metadata["owner"]["team"],
                "email": metadata["owner"].get("contact"),
            },
            "license": args.license or package_defaults.get("license", "MIT"),
            "repository": repository.get("url"),
            "keywords": [artifact_type, "migration"],
            "targets": package_defaults.get("targets", ["copilot"]),
            "compilation": {"source_attribution": True},
            "dependencies": {"apm": []},
        }
        files[ROOT / "packages" / package_name / "apm.yml"] = yaml.safe_dump(
            package, sort_keys=False, allow_unicode=False
        )
        composition = {"schemaVersion": "1.0", "artifacts": [artifact_id]}
        files[ROOT / "packages" / package_name / "package.yml"] = yaml.safe_dump(
            composition, sort_keys=False, allow_unicode=False
        )
    return files


def run(args: argparse.Namespace) -> int:
    """Validate inputs and create scaffold files."""
    if not SLUG_PATTERN.fullmatch(args.id):
        raise ValueError("--id must be lowercase kebab-case")
    if args.package_name and not SLUG_PATTERN.fullmatch(args.package_name):
        raise ValueError("--package-name must be lowercase kebab-case")
    if not 10 <= len(args.summary) <= 160:
        raise ValueError("--summary must contain 10 to 160 characters")

    files = artifact_files(args, load_config())
    existing = [path for path in files if path.exists()]
    if existing:
        paths = ", ".join(path.relative_to(ROOT).as_posix() for path in existing)
        raise ValueError(f"Refusing to overwrite existing files: {paths}")

    for path in files:
        print(path.relative_to(ROOT).as_posix())
    if args.dry_run:
        return 0
    for path, content in files.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    print(f"Created {len(files)} files. Complete the TODO sections before submitting.")
    return 0


def main() -> int:
    """Run the scaffolding command."""
    try:
        return run(create_parser().parse_args())
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())