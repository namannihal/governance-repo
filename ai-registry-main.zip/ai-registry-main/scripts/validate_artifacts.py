#!/usr/bin/env python3
"""Validate registry artifacts against structure, metadata schema and policy rules.

Runs in CI (see .github/workflows/validate.yml) and locally:

    python scripts/validate_artifacts.py                     # validate everything
    python scripts/validate_artifacts.py artifacts/agents/azure-iac-reviewer   # one artifact

Uses PyYAML (required) and jsonschema (optional — full schema validation when present;
built-in checks always run so the script works air-gapped).

Exit code 0 = all good, 1 = one or more errors.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("ERROR: PyYAML is required. `pip install pyyaml`.", file=sys.stderr)
    sys.exit(2)

try:
    import jsonschema  # type: ignore
    HAVE_JSONSCHEMA = True
except ImportError:
    HAVE_JSONSCHEMA = False

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "schemas" / "artifact.metadata.schema.json"
ARTIFACTS_DIR = ROOT / "artifacts"
PACKAGES_DIR = ROOT / "packages"
REGISTRY_CONFIG_PATH = ROOT / "registry.yml"

# metadata.type -> (artifacts/<folder>, .apm/<primitive_dir>, primitive filename suffix)
TYPE_MAP = {
    "agent":       ("agents",       "agents",       ".agent.md"),
    "skill":       ("skills",       "skills",       "SKILL.md"),
    "prompt":      ("prompts",      "prompts",      ".prompt.md"),
    "instruction": ("instructions", "instructions", ".instructions.md"),
    "chatmode":    ("chatmodes",    "chatmodes",    ".chatmode.md"),
}
REQUIRED_FILES = ["metadata.yml", "README.md", "CHANGELOG.md"]


class RegistryLoader(yaml.SafeLoader):
    """Load YAML scalars without converting ISO dates to Python date objects."""


RegistryLoader.yaml_implicit_resolvers = {
    key: [
        resolver
        for resolver in resolvers
        if resolver[0] != "tag:yaml.org,2002:timestamp"
    ]
    for key, resolvers in yaml.SafeLoader.yaml_implicit_resolvers.items()
}


class Reporter:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def error(self, artifact: str, msg: str) -> None:
        self.errors.append(f"{artifact}: {msg}")

    def warn(self, artifact: str, msg: str) -> None:
        self.warnings.append(f"{artifact}: {msg}")


def load_yaml(path: Path):
    with path.open(encoding="utf-8") as fh:
        return yaml.load(fh, Loader=RegistryLoader)


def parse_frontmatter(path: Path):
    text = path.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    if not m:
        return None
    return yaml.safe_load(m.group(1)) or {}


def changelog_top_version(path: Path):
    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^##\s*\[?(\d+\.\d+\.\d+)\]?", line.strip())
        if m:
            return m.group(1)
    return None


def validate_metadata_schema(meta: dict, artifact: str, rep: Reporter) -> None:
    """Full jsonschema validation when the lib is present."""
    if not HAVE_JSONSCHEMA:
        return
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = jsonschema.Draft202012Validator(
        schema,
        format_checker=jsonschema.FormatChecker(),
    )
    for err in sorted(validator.iter_errors(meta), key=lambda e: e.path):
        loc = "/".join(str(p) for p in err.path) or "(root)"
        rep.error(artifact, f"metadata schema: {loc}: {err.message}")


def builtin_metadata_checks(meta: dict, artifact: str, rep: Reporter) -> None:
    """Schema-independent checks so the script is useful without jsonschema."""
    required = [
        "schemaVersion", "id", "displayName", "type", "summary", "owner",
        "lifecycle", "migration", "riskLevel",
    ]
    for field in required:
        if meta.get(field) in (None, "", [], {}):
            rep.error(artifact, f"metadata missing required field '{field}'")

    if meta.get("schemaVersion") != "2.0":
        rep.error(artifact, "metadata schemaVersion must be '2.0'")
    if meta.get("type") not in TYPE_MAP and meta.get("type") != "plugin":
        rep.error(artifact, f"metadata type '{meta.get('type')}' is not a known type")
    risk_level = meta.get("riskLevel")
    if risk_level not in ("low", "medium", "high"):
        rep.error(artifact, "metadata riskLevel must be low, medium or high")
    status = (meta.get("lifecycle") or {}).get("status")
    if status not in ("experimental", "beta", "active", "deprecated", "retired"):
        rep.error(artifact, "metadata lifecycle.status is invalid")
    if status in ("deprecated", "retired") and not (meta.get("lifecycle") or {}).get("supersededBy"):
        rep.warn(artifact, "deprecated/retired artifact should set lifecycle.supersededBy")
    migration = meta.get("migration") or {}
    for field in ("phases", "capabilities", "workloadTypes"):
        if not migration.get(field):
            rep.error(artifact, f"metadata migration.{field} must contain at least one value")
    placeholders = {"replace-me", "replace_me", "todo"}
    for field in ("tags",):
        values = {str(value).lower() for value in (meta.get(field) or [])}
        if values & placeholders:
            rep.error(artifact, f"metadata {field} contains scaffold placeholders")


def find_primitive(folder: Path, artifact_type: str) -> Path | None:
    """Find a primitive in either source-first or self-contained APM layout."""
    _, primitive_dir, suffix = TYPE_MAP[artifact_type]
    packaged_base = folder / ".apm" / primitive_dir

    if artifact_type == "skill":
        candidates = [
            packaged_base / folder.name / "SKILL.md",
            folder / "SKILL.md",
            folder / "skills" / "SKILL.md",
            folder / "skills" / folder.name / "SKILL.md",
        ]
        return next((path for path in candidates if path.is_file()), None)

    packaged = sorted(packaged_base.glob(f"*{suffix}")) if packaged_base.is_dir() else []
    direct = sorted(folder.glob(f"*{suffix}"))
    matches = packaged + direct
    return matches[0] if matches else None


def validate_package(folder: Path, rep: Reporter) -> set[str]:
    """Validate an APM composition manifest and its local artifact references."""
    package = folder.relative_to(ROOT).as_posix()
    included_artifacts: set[str] = set()
    manifest_path = folder / "apm.yml"
    if not manifest_path.is_file():
        rep.error(package, "missing required file 'apm.yml'")
        return included_artifacts

    try:
        manifest = load_yaml(manifest_path) or {}
    except yaml.YAMLError as exc:
        rep.error(package, f"YAML parse error: {exc}")
        return included_artifacts

    for field in ("name", "version", "description", "type", "license", "targets"):
        if manifest.get(field) in (None, "", [], {}):
            rep.error(package, f"apm.yml missing required field '{field}'")
    if manifest.get("name") != folder.name:
        rep.error(package, f"apm.yml name '{manifest.get('name')}' != folder name '{folder.name}'")
    if not re.match(r"^\d+\.\d+\.\d+$", str(manifest.get("version", ""))):
        rep.error(package, "apm.yml version must be SemVer x.y.z")

    dependencies = (manifest.get("dependencies") or {}).get("apm") or []
    for dependency in dependencies:
        if not isinstance(dependency, str):
            rep.error(package, "APM dependencies must use string references")
            continue
        _, separator, pinned_ref = dependency.partition("#")
        if not separator or not pinned_ref:
            rep.error(package, f"APM dependency must be pinned to a tag or SHA: {dependency}")

    composition_path = folder / "package.yml"
    if not composition_path.is_file():
        rep.error(package, "missing required file 'package.yml'")
        return included_artifacts
    try:
        composition = load_yaml(composition_path) or {}
    except yaml.YAMLError as exc:
        rep.error(package, f"package.yml parse error: {exc}")
        return included_artifacts
    if composition.get("schemaVersion") != "1.0":
        rep.error(package, "package.yml schemaVersion must be '1.0'")
    declared = composition.get("artifacts") or []
    if not declared:
        rep.error(package, "package.yml must declare at least one artifact")
    for artifact_id in declared:
        if not isinstance(artifact_id, str):
            rep.error(package, "package.yml artifact IDs must be strings")
        else:
            included_artifacts.add(artifact_id)
    if not (folder / ".apm").is_dir():
        rep.error(package, "missing generated .apm source; run scripts/build_packages.py")
    return included_artifacts


def validate_artifact(folder: Path, rep: Reporter) -> None:
    artifact = folder.relative_to(ROOT).as_posix()

    for fname in REQUIRED_FILES:
        if not (folder / fname).exists():
            rep.error(artifact, f"missing required file '{fname}'")

    apm_path, meta_path = folder / "apm.yml", folder / "metadata.yml"
    if not meta_path.exists():
        return  # can't do deeper checks

    try:
        apm = load_yaml(apm_path) or {} if apm_path.exists() else {}
        meta = load_yaml(meta_path) or {}
    except yaml.YAMLError as exc:
        rep.error(artifact, f"YAML parse error: {exc}")
        return

    validate_metadata_schema(meta, artifact, rep)
    builtin_metadata_checks(meta, artifact, rep)

    # The artifact ID is canonical across source and package manifests.
    if meta.get("id") != folder.name:
        rep.error(artifact, f"metadata.id '{meta.get('id')}' != folder name '{folder.name}'")
    if apm and meta.get("id") != apm.get("name"):
        rep.error(artifact, f"metadata.id '{meta.get('id')}' != apm.yml name '{apm.get('name')}'")

    registry = load_yaml(REGISTRY_CONFIG_PATH) or {}
    repository = registry.get("repository") or {}
    repository_url = repository.get("url")
    if apm.get("repository") and repository_url and apm["repository"] != repository_url:
        rep.error(artifact, "apm.yml repository does not match registry.yml repository.url")

    # APM owns package versioning; metadata remains focused on catalog discovery.
    versions = {
        "CHANGELOG.md": changelog_top_version(folder / "CHANGELOG.md") if (folder / "CHANGELOG.md").exists() else None,
    }
    if apm:
        versions["apm.yml"] = str(apm.get("version", "")).strip()
    distinct = {v for v in versions.values() if v}
    if len(distinct) > 1:
        rep.error(artifact, f"version mismatch across files: {versions}")

    # primitive presence + frontmatter
    mtype = meta.get("type")
    if mtype in TYPE_MAP:
        expected_parent = TYPE_MAP[mtype][0]
        if folder.parent.name != expected_parent:
            rep.error(artifact, f"type '{mtype}' should live under artifacts/{expected_parent}/")
        _, prim_dir, suffix = TYPE_MAP[mtype]
        prim = find_primitive(folder, mtype)
        if not prim:
            rep.error(artifact, f"missing {mtype} primitive (expected *{suffix})")
        else:
            fm = parse_frontmatter(prim)
            if fm is None:
                rep.error(artifact, f"primitive {prim.name} has no YAML frontmatter")
            else:
                if mtype in ("agent", "skill") and not fm.get("name"):
                    rep.error(artifact, f"{prim.name} frontmatter missing 'name'")
                if not fm.get("description"):
                    rep.error(artifact, f"{prim.name} frontmatter missing 'description'")

def discover(target: Path | None) -> list[Path]:
    if target:
        return [target]
    found = []
    for parent in sorted(ARTIFACTS_DIR.glob("*")):
        if parent.is_dir():
            found.extend(p for p in sorted(parent.glob("*")) if p.is_dir())
    return found


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    target = (ROOT / args[0]).resolve() if args else None
    rep = Reporter()
    artifacts = discover(target)
    if not artifacts:
        print("No artifacts found to validate.")
        return 0
    for folder in artifacts:
        validate_artifact(folder, rep)

    artifact_ids: dict[str, str] = {}
    for folder in artifacts:
        meta_path = folder / "metadata.yml"
        if not meta_path.is_file():
            continue
        artifact_id = str((load_yaml(meta_path) or {}).get("id", ""))
        artifact_path = folder.relative_to(ROOT).as_posix()
        if artifact_id in artifact_ids:
            rep.error(artifact_path, f"metadata.id duplicates {artifact_ids[artifact_id]}")
        else:
            artifact_ids[artifact_id] = artifact_path

    packages = [path for path in sorted(PACKAGES_DIR.glob("*")) if path.is_dir()]
    packaged_artifacts: set[str] = set()
    for folder in packages:
        packaged_artifacts.update(validate_package(folder, rep))

    for artifact_id in sorted(packaged_artifacts - artifact_ids.keys()):
        rep.error("packages", f"package.yml references unknown artifact '{artifact_id}'")

    for folder in artifacts:
        if (folder / "apm.yml").is_file():
            continue
        artifact_id = str((load_yaml(folder / "metadata.yml") or {}).get("id", ""))
        if artifact_id not in packaged_artifacts:
            artifact = folder.relative_to(ROOT).as_posix()
            rep.error(artifact, "source artifact is not referenced by any package manifest")

    print(f"Validated {len(artifacts)} artifact(s) and {len(packages)} package(s).")
    if not HAVE_JSONSCHEMA:
        print("(jsonschema not installed — ran built-in checks only; CI installs it for full schema validation.)")
    for w in rep.warnings:
        print(f"  WARN  {w}")
    for e in rep.errors:
        print(f"  ERROR {e}")
    if rep.errors:
        print(f"\nFAILED: {len(rep.errors)} error(s), {len(rep.warnings)} warning(s).")
        return 1
    print(f"\nPASSED: 0 errors, {len(rep.warnings)} warning(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
