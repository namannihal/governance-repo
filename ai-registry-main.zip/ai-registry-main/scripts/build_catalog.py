#!/usr/bin/env python3
"""Generate the registry catalog from artifact metadata.

    python scripts/build_catalog.py            # write catalog/index.json + index.md
    python scripts/build_catalog.py --check    # fail (exit 1) if the catalog is stale

The catalog is a generated index of every artifact's governance metadata. Never hand-edit
catalog/ — CI rebuilds it on merge (see .github/workflows/publish-catalog.yml).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = ROOT / "artifacts"
PACKAGES_DIR = ROOT / "packages"
REGISTRY_CONFIG = ROOT / "registry.yml"
CATALOG_DIR = ROOT / "catalog"
INDEX_JSON = CATALOG_DIR / "index.json"
INDEX_MD = CATALOG_DIR / "index.md"
CATALOG_VERSION = "2.0"


def load_yaml(path: Path):
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def collect() -> list[dict]:
    entries = []
    for parent in sorted(ARTIFACTS_DIR.glob("*")):
        if not parent.is_dir():
            continue
        for folder in sorted(parent.glob("*")):
            meta_path = folder / "metadata.yml"
            if not meta_path.is_dir() and meta_path.exists():
                meta = load_yaml(meta_path) or {}
                life = meta.get("lifecycle") or {}
                migration = meta.get("migration") or {}
                owner = meta.get("owner") or {}
                entries.append({
                    "id": meta.get("id"),
                    "displayName": meta.get("displayName"),
                    "type": meta.get("type"),
                    "summary": meta.get("summary"),
                    "status": life.get("status"),
                    "migrationPhases": migration.get("phases") or [],
                    "capabilities": migration.get("capabilities") or [],
                    "workloadTypes": migration.get("workloadTypes") or [],
                    "strategies": migration.get("strategies") or [],
                    "deliveryRoles": migration.get("deliveryRoles") or [],
                    "deliverables": migration.get("deliverables") or [],
                    "riskLevel": meta.get("riskLevel"),
                    "owner": owner.get("team"),
                    "maintainers": owner.get("maintainers") or [],
                    "tags": meta.get("tags") or [],
                    "path": folder.relative_to(ROOT).as_posix(),
                })
    entries.sort(key=lambda e: (str(e.get("type")), str(e.get("id"))))
    return entries


def collect_packages(artifacts: list[dict]) -> list[dict]:
    """Collect APM manifests and map their dependencies to catalog artifacts."""
    config = load_yaml(REGISTRY_CONFIG) or {}
    repository_slug = (config.get("repository") or {}).get("slug", "")
    artifact_ids = {entry["id"] for entry in artifacts}
    packages = []
    for folder in sorted(PACKAGES_DIR.glob("*")):
        manifest_path = folder / "apm.yml"
        if not manifest_path.is_file():
            continue
        manifest = load_yaml(manifest_path) or {}
        composition_path = folder / "package.yml"
        composition = load_yaml(composition_path) if composition_path.is_file() else {}
        included = {
            artifact_id
            for artifact_id in (composition.get("artifacts") or [])
            if artifact_id in artifact_ids
        }
        version = str(manifest.get("version"))
        packages.append({
            "name": manifest.get("name"),
            "version": version,
            "description": manifest.get("description"),
            "targets": manifest.get("targets") or [],
            "license": manifest.get("license"),
            "artifacts": sorted(included),
            "install": f"{repository_slug}/packages/{folder.name}#v{version}",
            "path": folder.relative_to(ROOT).as_posix(),
        })
    return packages


def count_values(entries: list[dict], field: str) -> dict[str, int]:
    """Count scalar or array values for a catalog discovery facet."""
    counts: dict[str, int] = {}
    for entry in entries:
        value = entry.get(field)
        values = value if isinstance(value, list) else [value]
        for item in values:
            if item:
                counts[str(item)] = counts.get(str(item), 0) + 1
    return dict(sorted(counts.items()))


def build_index(entries: list[dict], packages: list[dict]) -> dict:
    by_type: dict[str, int] = {}
    for e in entries:
        by_type[e["type"]] = by_type.get(e["type"], 0) + 1
    return {
        "catalogVersion": CATALOG_VERSION,
        # generatedAt is intentionally omitted from the persisted file so --check is stable;
        # CI stamps provenance via the commit itself.
        "counts": {
            "totalArtifacts": len(entries),
            "totalPackages": len(packages),
            "byType": dict(sorted(by_type.items())),
        },
        "facets": {
            "artifactTypes": count_values(entries, "type"),
            "statuses": count_values(entries, "status"),
            "migrationPhases": count_values(entries, "migrationPhases"),
            "capabilities": count_values(entries, "capabilities"),
            "workloadTypes": count_values(entries, "workloadTypes"),
            "strategies": count_values(entries, "strategies"),
            "deliveryRoles": count_values(entries, "deliveryRoles"),
            "deliverables": count_values(entries, "deliverables"),
            "riskLevels": count_values(entries, "riskLevel"),
        },
        "artifacts": entries,
        "packages": packages,
    }


def render_md(index: dict) -> str:
    lines = [
        "---",
        "title: Registry Catalog",
        "description: Generated catalog of governed AI artifacts and publishable APM packages",
        "---",
        "",
        "> Generated by `scripts/build_catalog.py`. Do not hand-edit.",
        "",
        "## Artifacts",
        "",
        f"**Total artifacts:** {index['counts']['totalArtifacts']}",
        "**By type:** " + ", ".join(f"{k}: {v}" for k, v in index["counts"]["byType"].items()),
        "",
        "| Artifact | Type | Migration phase | Capability | Workload | Risk |",
        "|----------|------|-----------------|------------|----------|------|",
    ]
    for e in index["artifacts"]:
        phases = ", ".join(e["migrationPhases"])
        capabilities = ", ".join(e["capabilities"])
        workloads = ", ".join(e["workloadTypes"])
        lines.append(
            f"| **{e['displayName']}** | {e['type']} | {phases} | {capabilities} | "
            f"{workloads} | {e['riskLevel']} |"
        )
    lines.extend([
        "",
        "## Packages",
        "",
        f"**Total packages:** {index['counts']['totalPackages']}",
        "",
        "| Package | Ver | Assets | Targets | Install |",
        "|---------|-----|--------|---------|---------|",
    ])
    for package in index["packages"]:
        assets = ", ".join(package["artifacts"]) or "-"
        targets = ", ".join(package["targets"]) or "-"
        lines.append(
            f"| **{package['name']}** | {package['version']} | {assets} | {targets} | "
            f"`{package['install']}` |"
        )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    check = "--check" in sys.argv[1:]
    entries = collect()
    packages = collect_packages(entries)
    index = build_index(entries, packages)
    new_json = json.dumps(index, indent=2, ensure_ascii=False, default=str) + "\n"
    new_md = render_md(index)

    if check:
        cur_json = INDEX_JSON.read_text(encoding="utf-8") if INDEX_JSON.exists() else ""
        cur_md = INDEX_MD.read_text(encoding="utf-8") if INDEX_MD.exists() else ""
        if cur_json != new_json or cur_md != new_md:
            print("Catalog is out of date. Run: python scripts/build_catalog.py")
            return 1
        print("Catalog is up to date.")
        return 0

    CATALOG_DIR.mkdir(parents=True, exist_ok=True)
    INDEX_JSON.write_text(new_json, encoding="utf-8")
    INDEX_MD.write_text(new_md, encoding="utf-8")
    print(f"Wrote {INDEX_JSON.relative_to(ROOT)} and {INDEX_MD.relative_to(ROOT)} "
            f"({index['counts']['totalArtifacts']} artifacts, "
            f"{index['counts']['totalPackages']} packages).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
