---
title: Versioning and Releases
description: Version and release APM packages independently from discovery metadata
---

Artifacts are versioned with [SemVer](https://semver.org/) and released as immutable git
tags so consumers can pin and reproduce exactly.

## When to bump

| Change | Bump |
|--------|------|
| Reworded system prompt / instruction that changes agent behaviour; removed a capability; added a newly-*required* tool or MCP server | **MAJOR** |
| New optional capability; expanded examples; additional target harness; backward-compatible improvement | **MINOR** |
| Typo, clarification, formatting, non-behavioural metadata fix | **PATCH** |

Because agent artifacts are *behavioural*, err toward MAJOR when in doubt: a prompt change
that surprises an existing consumer is a breaking change even if no field was removed.

## Version consistency

The version must match in both release files:

1. `apm.yml` → `version`
2. `CHANGELOG.md` → top entry

`metadata.yml` does not carry a package version. Git tags and APM manifests own release identity.

## Release flow

1. Bump the APM manifest version and add a matching `CHANGELOG.md` entry in your PR.
2. On merge, a maintainer tags the release:
   ```bash
   git tag artifacts/skills/terraform-plan-review@v1.2.0
   git push origin artifacts/skills/terraform-plan-review@v1.2.0
   ```
   Per-artifact tags let each artifact release independently in this monorepo.
3. Consumers upgrade deliberately with `apm deps update` and commit the new `apm.lock.yaml`.

## Consumer pinning

```yaml
dependencies:
  apm:
    - praro_microsoft/ai-registry/artifacts/skills/terraform-plan-review#v1.2.0
```

The dependency string is `<host>/<owner>/<repo>/<sub-path>#<ref>`; `<ref>` is a tag
(`#v1.2.0`), branch (discouraged), or commit SHA. Omit the host and `github.com` is assumed.

## Deprecation & retirement

- Set `lifecycle.status: deprecated`, fill `supersededBy`, and add a changelog entry.
- The artifact stays installable so pinned consumers don't break.
- Move to `retired` when support ends. Keep old pins available for reproducibility.

## CHANGELOG format (Keep a Changelog)

```markdown
## [1.2.0] - 2026-08-04
### Added
- New `--strict` guidance for module version pinning.
### Changed
- Clarified the review checklist ordering.
```
