---
title: Authoring an Agent
description: Create and package a migration-focused custom agent
---

A **custom agent** is a specialised persona with its own scope, tools and system prompt.
Copilot loads it when the user selects it (or when routing matches). Authored as a single
`*.agent.md` file under `.apm/agents/`; APM compiles it to `.github/agents/`.

## Folder layout

```
artifacts/agents/<id>/
├── apm.yml
├── metadata.yml
├── README.md
├── CHANGELOG.md
└── .apm/
    └── agents/
        └── <id>.agent.md
```

## `<id>.agent.md` frontmatter

```markdown
---
name: azure-iac-reviewer
description: Reviews Azure Bicep/Terraform IaC for security, cost and policy issues. Use when asked to review infrastructure-as-code changes in a PR.
tools: ['read', 'search', 'github-mcp-server']
model: gpt-5
---

You are an Azure infrastructure reviewer. When reviewing IaC changes:
1. ...
2. ...
```

| Frontmatter | Notes |
|-------------|-------|
| `name` | Required. Lowercase-hyphen; equals the folder id. |
| `description` | Required. Intent-rich — *what it does and when to use it*. Copilot routes on this. |
| `tools` | Optional whitelist. Every entry must comply with `apm-policy.yml`. |
| `model` | Optional preferred model. |

## Authoring tips

- **Write the `description` for routing.** Copilot decides when to invoke the agent from this line — lead with the trigger scenario.
- **Keep the system prompt scoped.** One clear job. Reference shared context or skills rather than duplicating them.
- **Least privilege on `tools`.** Include only what the job needs.
- Set `metadata.yml:riskLevel` to `high` when the agent has elevated operational implications.

Start from `templates/agent/`.
