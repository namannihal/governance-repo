---
title: Security
description: Security controls for migration AI artifact packaging and review
---

Agent context is executable: **a prompt is a program for an LLM.** This registry treats
every artifact as untrusted-until-reviewed supply-chain input.

## Threat model

| Threat | Control |
|--------|---------|
| **Prompt injection / hidden Unicode** ("Glassworm"-class) | `apm audit` scans every install for invisible characters and injection payloads; CI runs `apm audit --ci` and uploads SARIF to Code Scanning. Enforced via `apm-policy.yml:audit`. |
| **Supply-chain tampering** | `apm.lock.yaml` pins full commit SHAs + content hashes; `apm audit` re-hashes deployed files to detect hand-edits before they ship. |
| **Unpinned / drifting dependencies** | `apm-policy.yml:refs.requirePinned: true` rejects floating branches. |
| **Unexpected MCP servers** | `apm-policy.yml:mcp.trustTransitive: false` blocks MCP servers pulled in transitively unless explicitly allow-listed. |
| **Arbitrary command execution** | Review `shell` or `bash` pre-approval in primitive frontmatter and package policy before merge. |
| **Untrusted sources** | `apm-policy.yml:sources` allow-lists hosts/owners/repos; everything else is denied. |

## Rules for authors

1. **Do not pre-approve `shell` or `bash`** in an artifact's `allowed-tools` unless you have reviewed every referenced script and completed a security review. Pre-approval removes Copilot's confirmation step and can let an injection run arbitrary commands.
2. **Least privilege** — request only the tools and MCP servers the artifact truly needs. Each one must be allow-listed in `apm-policy.yml`.
3. **Pin dependencies** to tags or SHAs. Review the upstream repo before pinning.
4. **No secrets** in artifact content, examples, or scripts. Secret scanning runs on the repo; a leaked secret blocks the merge.
5. Set `riskLevel` honestly so catalog users can identify artifacts with elevated operational implications.

## Rules for reviewers

- Inspect the full diff, including `.apm/` scripts and any assets, before approving.
- Confirm `riskLevel` reflects whether the artifact calls tools, writes to production, or handles sensitive data.
- Apply the repository's required security review outside metadata for elevated runtime capabilities.
- Re-run `apm audit` locally if the SARIF report shows anything you don't understand.

## What APM does *not* do

APM governs install-time integrity, not runtime behaviour. It does not sandbox a running
agent, meter model calls, or see prompts at inference time. Runtime permissions and
sandboxing are the agent harness's responsibility.

## Reporting a vulnerability

Email **security@contoso.com** (or open a private security advisory). Do not file a public
issue for a suspected malicious artifact or injection payload.
