---
title: Governance
description: Ownership, lifecycle, validation, and policy boundaries for registry artifacts
---

This registry governs the **install and integrity plane** — what artifacts reach a
developer's disk and whether they conform to policy. It does **not** govern the runtime
plane (what a running agent may do); that belongs to each agent harness. The two planes
do not overlap.

## Roles

| Role | GitHub team | Responsibility |
|------|-------------|----------------|
| **Registry maintainers** | `@contoso/ai-registry-maintainers` | Own schemas, policy, tooling, catalog generation, and CI. |
| **AI Governance / Security** | `@contoso/ai-governance` | Own security policy and review artifacts with elevated runtime implications. |
| **Artifact owning teams** | e.g. `@contoso/platform-ai` | Accountable for their own artifacts' correctness, security and lifecycle. |

Ownership is declared twice and must agree: in each artifact's `metadata.yml:owner.team`
and in `.github/CODEOWNERS`. The validator cross-checks them.

## Contribution lifecycle

```
draft (branch) → PR → CI gates → owner review → merge → tag release → catalog rebuild
```

### CI gates (all must pass)
1. **Metadata schema** — `metadata.yml` validates against the JSON Schema.
2. **Structure & frontmatter** — required files present; primitive frontmatter valid; folder = id = name.
3. **`apm install --dry-run`** — manifest ↔ lockfile agree; dependencies resolve; policy passes.
4. **`apm audit --ci`** — hidden-Unicode / prompt-injection scan; SARIF uploaded to Code Scanning.
5. **Consistency**: APM versions agree with changelog entries and generated package sources.

## Artifact lifecycle states

| Status | Installable? | In catalog? | Meaning |
|--------|:---:|:---:|---------|
| `experimental` | yes | flagged | Early and subject to change. |
| `beta` | yes | flagged | Stabilizing and open for feedback. |
| `active` | yes | yes | Supported and recommended. |
| `deprecated` | yes | flagged | Superseded by another artifact. |
| `retired` | pinned only | archived | Retained for reproducibility. |

Promotion (`experimental → active`) and deprecation both happen via PR that edits
`metadata.yml` and `CHANGELOG.md`.

## Policy inheritance (tighten-only)

`apm-policy.yml` flows **enterprise → org → repo**. A consuming repo may add restrictions
but can never relax what this registry sets. Every `apm install` — including transitive
MCP servers pulled in by deep dependencies — runs the policy before writing files, and
`apm audit --ci` enforces the same checks in branch protection.

## Auditability

* Every version is an immutable git tag; consumer lockfiles record the installed SHA and content hash
* `metadata.yml` records the accountable team and maintainers
* The catalog is regenerated from source and can always be rebuilt and diffed
