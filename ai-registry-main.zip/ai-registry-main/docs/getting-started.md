---
title: Getting Started
description: Start consuming or contributing migration AI artifacts
---

This registry is a **git-hosted APM package index**. There is no separate server to run — APM resolves artifacts directly from this repository over git.

## Install the APM CLI

```bash
# Linux / macOS
curl -sSL https://aka.ms/apm-unix | sh
# Windows (PowerShell)
irm https://aka.ms/apm-windows | iex

apm --version
```

Alternatives: `brew install microsoft/apm/apm`, Scoop, or `pip install apm-cli`.

## Two audiences

### I want to *use* an artifact
Go to **[consuming-artifacts.md](consuming-artifacts.md)**. In short:

```bash
apm install praro_microsoft/ai-registry/packages/terraform-plan-review#v1.0.0
```

### I want to *contribute* an artifact
Go to **[../CONTRIBUTING.md](../CONTRIBUTING.md)** and the **[authoring guides](authoring/)**. In short:

```bash
cp -r templates/skill artifacts/skills/my-skill
# edit apm.yml, metadata.yml, .apm/skills/my-skill/SKILL.md, README.md, CHANGELOG.md
python scripts/validate_artifacts.py artifacts/skills/my-skill
# open a PR
```

## Key concepts (2-minute version)

| Concept | What it means here |
|---------|--------------------|
| **Artifact** | A published agent / skill / prompt / instruction / chatmode, one folder under `artifacts/`. |
| **APM package** | A publishable manifest under `packages/` that can compose one or more artifacts. |
| **`metadata.yml`** | Migration discovery sidecar containing identity, ownership, lifecycle, migration facets, and risk. |
| **`apm.lock.yaml`** | Written in the *consumer's* repo; pins each artifact to a commit SHA + content hash. |
| **`apm-policy.yml`** | Install-time policy this registry enforces (sources, MCP, primitives, pinning). |
| **Catalog** | `catalog/index.json` — generated machine-readable index of every artifact. |

## The golden rules

1. **Author under `.apm/`, never edit compiled output.** APM compiles `.apm/` into `.github/` (Copilot) and other harness dirs.
2. **Pin everything.** Tags or SHAs, never `main`.
3. **Metadata is not optional.** CI rejects any artifact whose `metadata.yml` fails the schema.
4. **Commit deployed files in consumer repos** so Copilot on github.com and first-time cloners get the context before they run `apm install`.
