---
title: Consuming Artifacts
description: Install migration AI artifacts from published APM packages
---

How a team pulls artifacts from this registry into their own repo.

## 1. Install one artifact

```bash
apm install praro_microsoft/ai-registry/packages/azure-iac-reviewer#v1.0.0
```

APM will:
1. Shallow-clone the registry into `apm_modules/` (gitignored cache).
2. Run the enterprise `apm-policy.yml` (blocks disallowed sources / MCP / unpinned refs).
3. Scan the artifact for hidden-Unicode / prompt-injection payloads (`apm audit`).
4. Compile the primitive into the harness dirs you target — `.github/agents/…` for Copilot.
5. Add the dependency to your `apm.yml` and pin the resolved SHA + content hash in `apm.lock.yaml`.

## 2. Or declare everything in your repo's `apm.yml`

```yaml
name: my-service
version: "1.0.0"
targets:
  - copilot
dependencies:
  apm:
    - praro_microsoft/ai-registry/packages/azure-iac-reviewer#v1.0.0
    - praro_microsoft/ai-registry/packages/terraform-plan-review#v1.0.0
    - praro_microsoft/ai-registry/artifacts/instructions/secure-coding-baseline#v1.0.0
  mcp:
    - io.github.github/github-mcp-server
```

Then:

```bash
apm install            # resolve + compile everything
```

## 3. Commit the right files

```gitignore
# .gitignore in the CONSUMER repo
apm_modules/
```

**Commit** `apm.yml`, `apm.lock.yaml`, and the deployed `.github/` directory. This is deliberately the opposite of `node_modules`: committing the compiled `.github/` files means Copilot on github.com — and any teammate who hasn't run `apm install` yet — still gets the correct context.

## 4. Keep dependencies fresh

```bash
apm outdated           # diff your lockfile against the registry's latest tags
apm deps update        # re-resolve and bump apm.lock.yaml (deliberate upgrade)
apm deps tree          # see transitive dependencies
```

Upgrades are always deliberate: because you pinned to a tag, nothing changes until you run `apm deps update` and commit the new lockfile.

## 5. Verify integrity anytime

```bash
apm audit              # re-hash deployed files, detect hand-edits + injection payloads
apm install --frozen   # lockfile-only install (CI equivalent of `npm ci`)
```

## Reproducibility guarantee

Because `apm.lock.yaml` pins a full commit SHA and a content hash for every artifact, a clone today and a clone in six months compile **byte-identical** agent context — as long as you don't run `apm deps update`.
