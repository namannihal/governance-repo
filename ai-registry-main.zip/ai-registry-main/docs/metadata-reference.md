---
title: Metadata Reference
description: Field reference for migration artifact discovery metadata
---

Each artifact has a `metadata.yml` sidecar validated against
`schemas/artifact.metadata.schema.json`. Metadata powers catalog discovery. APM manifests
own package versions, licenses, targets, dependencies, tools, and installation references.

## Required fields

| Field | Purpose |
|-------|---------|
| `schemaVersion` | Metadata contract version. Use `"2.0"`. |
| `id` | Immutable lowercase kebab-case ID matching the artifact folder. |
| `displayName` | Human-readable catalog name. |
| `type` | `agent`, `skill`, `prompt`, `instruction`, `chatmode`, or `plugin`. |
| `summary` | Catalog description between 10 and 160 characters. |
| `owner` | Accountable team and optional contacts. |
| `lifecycle` | Current support state. |
| `migration` | Controlled migration-program discovery facets. |
| `riskLevel` | Simple `low`, `medium`, or `high` discovery signal. |

## Owner

`owner.team` is required. `owner.contact` is an optional team email.
`owner.maintainers` is an optional list of individual maintainers. Each maintainer requires
a GitHub handle and may include a name and email.

```yaml
owner:
  team: "@contoso/migration-engineering"
  contact: migration-engineering@contoso.com
  maintainers:
    - name: Priyansh Arora
      github: "@priyansh-arora"
      email: priyansh.arora@contoso.com
```

## Lifecycle

`lifecycle.status` is required and accepts `experimental`, `beta`, `active`,
`deprecated`, or `retired`. Set `lifecycle.supersededBy` when another artifact replaces a
deprecated or retired artifact.

## Migration

The migration section supports six properties. The first three are required so every
artifact can be found by its place in a migration program.

| Property | Required | Meaning |
|----------|:--------:|---------|
| `phases` | yes | Migration lifecycle stages where the artifact is useful. |
| `capabilities` | yes | Migration activities the artifact supports. |
| `workloadTypes` | yes | Workload categories the artifact applies to. |
| `strategies` | no | Migration strategies the artifact supports. |
| `deliveryRoles` | no | Delivery roles most likely to use the artifact. |
| `deliverables` | no | Program outputs the artifact creates or improves. |

Use only values defined in the schema. Arrays reject duplicates. Required migration arrays
must contain at least one value.

```yaml
migration:
  phases: [engineering, validation]
  capabilities: [remediation, testing-validation]
  workloadTypes: [applications]
  strategies: [refactor]
  deliveryRoles: [migration-engineer]
  deliverables: [implementation, test-evidence]
```

## Optional tags

`tags` adds free-form discovery terms that are not covered by controlled migration facets.
Use lowercase kebab-case values and avoid duplicates.

## Complete example

```yaml
schemaVersion: "2.0"
id: application-remediation
displayName: Application Remediation
type: skill
summary: Guides application teams through migration remediation and validation.
owner:
  team: "@contoso/migration-engineering"
  maintainers:
    - github: "@your-handle"
lifecycle:
  status: beta
migration:
  phases: [engineering, validation]
  capabilities: [remediation, testing-validation]
  workloadTypes: [applications]
  strategies: [refactor]
  deliveryRoles: [application-owner, migration-engineer]
  deliverables: [implementation, test-evidence]
riskLevel: medium
tags: [application-modernization]
```