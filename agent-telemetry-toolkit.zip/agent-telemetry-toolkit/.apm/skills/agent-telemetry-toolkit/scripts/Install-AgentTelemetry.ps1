[CmdletBinding()]
param(
    [string]$SourcePath,
    [switch]$Configure
)

$ErrorActionPreference = 'Stop'
$AdoPat = ''
if ([string]::IsNullOrWhiteSpace($SourcePath)) {
    $SourcePath = Join-Path $PSScriptRoot 'AgentTelemetry.ps1'
}
$destinationDirectory = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.agent-telemetry\bin'
$destinationPath = Join-Path $destinationDirectory 'AgentTelemetry.ps1'
$manifestPath = Join-Path $destinationDirectory 'AgentTelemetry.manifest.json'

$settings = [ordered]@{
    AGENT_TELEMETRY_SINK        = 'ado_git'
    AGENT_TELEMETRY_ADO_ORG     = 'LSEGroup'
    AGENT_TELEMETRY_ADO_PROJECT = 'Migration'
    AGENT_TELEMETRY_ADO_REPO    = 'Sample-Infra-As-Code'
    AGENT_TELEMETRY_ADO_PATH    = 'events'
}

function Get-UserEnvironmentValue {
    param([string]$Name)

    return [Environment]::GetEnvironmentVariable($Name, 'User')
}

function Get-TelemetryClientVersion {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    $match = Select-String -LiteralPath $Path -Pattern "CLIENT_VERSION\s*=\s*\[version\]'(?<Version>[^']+)'" |
        Select-Object -First 1
    if (-not $match -or -not $match.Matches[0].Groups['Version'].Success) { return $null }
    return [version]$match.Matches[0].Groups['Version'].Value
}

function Get-TelemetryClientHash {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
    catch { return $null }
}

function Write-TelemetryManifest {
    param([string]$Version, [string]$Hash)

    $manifest = [ordered]@{
        client_version = $Version
        client_sha256  = $Hash
        installed_at   = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    }
    [System.IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Compress),
        (New-Object System.Text.UTF8Encoding($false)))
}

$telemetryConfigured = (Test-Path -LiteralPath $destinationPath -PathType Leaf) -and
    (($settings.Keys | Where-Object {
        [string]::IsNullOrWhiteSpace((Get-UserEnvironmentValue $_)) -or
        (Get-UserEnvironmentValue $_) -ne $settings[$_]
    }).Count -eq 0) -and
    -not [string]::IsNullOrWhiteSpace((Get-UserEnvironmentValue 'AGENT_TELEMETRY_ADO_PAT'))

if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
    throw "Telemetry client was not found: $SourcePath"
}

$sourceVersion = Get-TelemetryClientVersion $SourcePath
$installedVersion = Get-TelemetryClientVersion $destinationPath
$sourceHash = Get-TelemetryClientHash $SourcePath
$installedHash = Get-TelemetryClientHash $destinationPath
$clientUpdated = $false
if ($installedVersion -and $sourceVersion -and $installedVersion -gt $sourceVersion) {
    Write-Output "Telemetry client $installedVersion is newer than packaged client $sourceVersion; keeping installed client"
}
elseif ($installedHash -ne $sourceHash) {
    New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
    $temporaryPath = Join-Path $destinationDirectory 'AgentTelemetry.ps1.tmp'
    Copy-Item -LiteralPath $SourcePath -Destination $temporaryPath -Force
    Move-Item -LiteralPath $temporaryPath -Destination $destinationPath -Force
    Unblock-File -LiteralPath $destinationPath -ErrorAction SilentlyContinue
    $clientUpdated = $true
}
if (-not (Test-Path -LiteralPath $destinationPath -PathType Leaf)) {
    throw "Telemetry client was not installed: $destinationPath"
}
Write-TelemetryManifest "$((Get-TelemetryClientVersion $destinationPath))" (Get-TelemetryClientHash $destinationPath)

if ($telemetryConfigured) {
    Set-Item -Path Env:AGENT_TELEMETRY_SINK -Value $settings.AGENT_TELEMETRY_SINK
    foreach ($setting in $settings.Keys | Where-Object { $_ -ne 'AGENT_TELEMETRY_SINK' }) {
        Set-Item -Path "Env:$setting" -Value $settings[$setting]
    }
    Set-Item -Path Env:AGENT_TELEMETRY_ADO_PAT -Value (Get-UserEnvironmentValue 'AGENT_TELEMETRY_ADO_PAT')
    if ($clientUpdated) { Write-Output "Telemetry client refreshed at $destinationPath" }
    exit 0
}

if ($Configure) {
    foreach ($setting in $settings.GetEnumerator()) {
        $current = [Environment]::GetEnvironmentVariable($setting.Key, 'User')
        $value = if (-not [string]::IsNullOrWhiteSpace($current) -and $current -ne $setting.Value) { $current } else { $setting.Value }
        [Environment]::SetEnvironmentVariable($setting.Key, $value, 'User')
        Set-Item -Path "Env:$($setting.Key)" -Value $value
    }

    $pat = if (-not [string]::IsNullOrWhiteSpace($AdoPat)) { $AdoPat } else { [Environment]::GetEnvironmentVariable('AGENT_TELEMETRY_ADO_PAT', 'User') }
    if ([string]::IsNullOrWhiteSpace($pat)) {
        Write-Output 'AGENT_TELEMETRY_ADO_PAT is blank. Provide it through the VDI or enterprise secret-management process.'
    }
    else {
        [Environment]::SetEnvironmentVariable('AGENT_TELEMETRY_ADO_PAT', $pat, 'User')
        Set-Item -Path Env:AGENT_TELEMETRY_ADO_PAT -Value $pat
    }
    Remove-Variable pat -ErrorAction SilentlyContinue
}

if ($Configure) {
    & $destinationPath doctor
}
else {
    Write-Output $destinationPath
}