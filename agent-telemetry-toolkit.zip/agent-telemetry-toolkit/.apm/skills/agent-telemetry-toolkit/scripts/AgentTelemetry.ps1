<#
.SYNOPSIS
    Single-file usage telemetry client for Copilot command-based agents (ADO sink).
    PowerShell port of agent_telemetry.py. Runs on the user's VDI.

.DESCRIPTION
    No install, no modules, no third-party dependencies. Drop this file anywhere:

        .\AgentTelemetry.ps1 emit -Agent my-agent -CommandName my-command

    Non-negotiable behaviours (identical to the Python client):
      N1  never throws into the host command; always exits 0
      N2  emit path does not block: no network, no subprocess, no lock, no file read
      N3  no PII, ever
      N4  closed allow-list
      N6  the PAT is read, never written, never printed
      N7  no event loss from concurrency (atomic append + segment delete, never rewrite)
      N8  at-least-once delivery, exactly-once counting (dedupe at rollup only)
      N9  no modules; Windows PowerShell 5.1 and PowerShell 7 both work
      N10 opt-out is absolute (no collection, no disk writes)
      N11 default sink is noop
      N12 additive schema changes only

    ASCII only on purpose: PS 5.1 reads a BOM-less .ps1 as ANSI, so a stray
    non-ASCII character is a parse error rather than a display glitch.

.EXAMPLE
    .\AgentTelemetry.ps1 start -Agent my-agent -CommandName build   # prints run_id
    .\AgentTelemetry.ps1 complete -RunId <id> -Agent my-agent -CommandName build -Status success
    .\AgentTelemetry.ps1 flush
    .\AgentTelemetry.ps1 doctor
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('emit', 'start', 'complete', 'fail', 'audit', 'flush', 'status', 'doctor', 'help')]
    [string]$Command = 'help',

    [string]$Agent,
    [Alias('Cmd')][string]$CommandName,
    [string]$Version = '0.0.0',
    [string]$Team,
    [ValidateSet('pip', 'apm', 'script')][string]$Distribution = 'script',

    [string]$RunId,

    [string]$EventType,
    [string]$ToolName,
    [string]$ToolCategory,
    [string]$Decision,

    [switch]$Detached
)

# N1: nothing below may surface an error to the caller.
$ErrorActionPreference = 'Stop'
$script:ExitCode = 0

# ============================================================================
# SCHEMA
# ============================================================================

$script:SCHEMA_VERSION = '2.1'
$script:CLIENT_VERSION = [version]'2.5.0'

$script:EVENT_TYPES = @('command_started', 'command_completed', 'command_failed',
    'telemetry_health', 'tool_call_blocked', 'approval_required')
$script:DISTRIBUTIONS = @('pip', 'apm', 'script')

$script:ENVELOPE_KEYS = @('schema_version', 'event_id', 'event_type', 'timestamp', 'run_id',
    'session_id', 'install_id', 'agent_name', 'agent_version',
    'distribution', 'command', 'team', 'os', 'ci', 'consent')
$script:PAYLOAD_KEYS = @('pool_depth', 'queue_bytes', 'oldest_event_age_s', 'retry_count',
    'last_error', 'last_flush_status', 'dropped_count', 'sink',
    'tool_name', 'tool_category', 'decision')
$script:ALLOWED_KEYS = $script:ENVELOPE_KEYS + $script:PAYLOAD_KEYS

$script:MAX_STRING_LEN = 64
$script:MAX_INT = 1000000000
$script:NAME_RE = [regex]'^[a-z0-9_][a-z0-9._-]*$'

$script:UNREGISTERED = 'unregistered'
$script:HEALTH_AGENT_NAME = 'telemetry-client'
$script:HEALTH_COMMAND = 'telemetry-health'

# Rough bytes-per-event: turns a file size into an event count without reading it.
$script:APPROX_EVENT_BYTES = 420
$script:MAX_SEGMENTS_PER_RUN = 20
$script:MAX_ATTEMPTS = 5
$script:BASE_BACKOFF_S = 0.5
$script:MAX_BACKOFF_S = 30.0
$script:LOCK_STALE_S = 30.0
$script:HEALTH_INTERVAL_S = 3600
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# ============================================================================
# CONFIG
# ============================================================================

function Get-DefaultHome { Join-Path ([Environment]::GetFolderPath('UserProfile')) '.agent-telemetry' }

function Test-Truthy($v) { @('1', 'true', 'yes', 'on') -contains ("$v").Trim().ToLowerInvariant() }

function Read-DotEnvFile([string]$Path) {
    $data = @{}
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return $data }
        foreach ($raw in (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop)) {
            $line = $raw.Trim()
            if (-not $line -or $line.StartsWith('#') -or ($line -notmatch '=')) { continue }
            $i = $line.IndexOf('=')
            $k = $line.Substring(0, $i).Trim()
            $v = $line.Substring($i + 1).Trim().Trim('"').Trim("'")
            $data[$k] = $v
        }
    }
    catch { }
    return $data
}

$script:DotEnvCache = $null
function Get-DotEnv {
    if ($null -eq $script:DotEnvCache) {
        $merged = @{}
        foreach ($p in @((Join-Path (Get-Location).Path '.env'), (Join-Path (Get-DefaultHome) '.env'))) {
            foreach ($kv in (Read-DotEnvFile $p).GetEnumerator()) { $merged[$kv.Key] = $kv.Value }
        }
        $script:DotEnvCache = $merged
    }
    return $script:DotEnvCache
}

function Get-Setting([string]$Key, [string]$Default = '') {
    $v = [Environment]::GetEnvironmentVariable($Key)
    if ([string]::IsNullOrEmpty($v)) {
        $env = Get-DotEnv
        if ($env.ContainsKey($Key)) { $v = $env[$Key] }
    }
    if ([string]::IsNullOrEmpty($v)) {
        $v = [Environment]::GetEnvironmentVariable($Key, 'User')
    }
    if ([string]::IsNullOrEmpty($v)) { return $Default }
    return $v
}

function Get-SettingInt([string]$Key, [int]$Default) {
    $raw = Get-Setting $Key "$Default"
    $out = 0
    if ([int]::TryParse(("$raw").Trim(), [ref]$out)) { return $out }
    return $Default
}

function New-Config {
    param([string]$AgentName, [string]$AgentVersion, [string]$TeamName,
        [string]$Dist, [string]$CommandLabel)

    $homeRaw = Get-Setting 'AGENT_TELEMETRY_HOME' ''
    $homeDir = if ($homeRaw) { [Environment]::ExpandEnvironmentVariables($homeRaw) } else { Get-DefaultHome }

    $cfg = [ordered]@{
        agent_name        = if ($AgentName) { $AgentName } else { 'unknown-agent' }
        agent_version     = if ($AgentVersion) { $AgentVersion } else { '0.0.0' }
        distribution      = if ($Dist) { $Dist } else { 'script' }
        team              = if ($TeamName) { $TeamName } else { (Get-Setting 'AGENT_TELEMETRY_TEAM' $AgentName) }
        command           = if ($CommandLabel) { $CommandLabel } else { 'unregistered' }
        optout            = Test-Truthy (Get-Setting 'AGENT_TELEMETRY_OPTOUT' '0')
        home              = $homeDir
        sink              = (Get-Setting 'AGENT_TELEMETRY_SINK' 'noop').Trim().ToLowerInvariant()
        ado_org           = Get-Setting 'AGENT_TELEMETRY_ADO_ORG' ''
        ado_project       = Get-Setting 'AGENT_TELEMETRY_ADO_PROJECT' ''
        ado_repo          = Get-Setting 'AGENT_TELEMETRY_ADO_REPO' ''
        ado_path_prefix   = (Get-Setting 'AGENT_TELEMETRY_ADO_PATH' 'events').Trim('/')
        shard_count       = [Math]::Max(1, (Get-SettingInt 'AGENT_TELEMETRY_SHARD_COUNT' 32))
        file_dir          = Get-Setting 'AGENT_TELEMETRY_FILE_DIR' ''
        pool_max_segments = Get-SettingInt 'AGENT_TELEMETRY_POOL_MAX_SEGMENTS' 200
        pool_max_bytes    = Get-SettingInt 'AGENT_TELEMETRY_POOL_MAX_BYTES' 16777216
        segment_max_events = Get-SettingInt 'AGENT_TELEMETRY_SEGMENT_MAX_EVENTS' 500
        segment_max_age_s = Get-SettingInt 'AGENT_TELEMETRY_SEGMENT_MAX_AGE' 3600
        flush_cooldown_s  = Get-SettingInt 'AGENT_TELEMETRY_FLUSH_COOLDOWN' 60
        flush_on_terminal = Test-Truthy (Get-Setting 'AGENT_TELEMETRY_FLUSH_ON_TERMINAL' '1')
        flush_lock_wait_s = [double](Get-SettingInt 'AGENT_TELEMETRY_FLUSH_LOCK_WAIT' 5)
        max_batch         = Get-SettingInt 'AGENT_TELEMETRY_MAX_BATCH' 500
        timeout           = [double](Get-SettingInt 'AGENT_TELEMETRY_TIMEOUT' 15)
        auth_mode         = (Get-Setting 'AGENT_TELEMETRY_AUTH_MODE' 'service').Trim().ToLowerInvariant()
    }
    if (-not $cfg.team) { $cfg.team = 'unregistered' }
    if (-not $cfg.sink) { $cfg.sink = 'noop' }
    $cfg
}

function Get-PoolDir($cfg) { Join-Path $cfg.home 'pool' }
function Get-CurrentFile($cfg) { Join-Path (Get-PoolDir $cfg) 'current.jsonl' }
function Get-ReadyDir($cfg) { Join-Path (Get-PoolDir $cfg) 'ready' }
function Get-LocksDir($cfg) { Join-Path $cfg.home 'locks' }
function Get-StateFile($cfg) { Join-Path $cfg.home 'state.json' }
function Get-ManifestFile($cfg) { Join-Path (Join-Path $cfg.home 'bin') 'AgentTelemetry.manifest.json' }

function Get-ClientHash {
    try { return (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant() }
    catch { return 'unknown' }
}

# ============================================================================
# CONTEXT
# ============================================================================

$script:SessionId = [guid]::NewGuid().ToString('N')
$script:InstallIdCache = @{}

function New-EventId { [guid]::NewGuid().ToString('N') }

function Get-UtcNow {
    # Second precision is deliberate: sub-second timestamps aid correlation attacks.
    [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
}

function Get-InstallId([string]$HomeDir) {
    # RANDOM, never derived from user or machine: hashing an enumerable input is
    # brute-forceable against a directory export, so it is not anonymisation.
    if ($script:InstallIdCache.ContainsKey($HomeDir)) { return $script:InstallIdCache[$HomeDir] }
    $zero = '0' * 16
    try {
        if (-not (Test-Path -LiteralPath $HomeDir)) { New-Item -ItemType Directory -Path $HomeDir -Force | Out-Null }
        $f = Join-Path $HomeDir 'install_id'
        if (Test-Path -LiteralPath $f) {
            $existing = (Get-Content -LiteralPath $f -Raw -Encoding UTF8).Trim()
            if ($existing -match '^[0-9a-f]{16}$') { $script:InstallIdCache[$HomeDir] = $existing; return $existing }
        }
        $val = [guid]::NewGuid().ToString('N').Substring(0, 16)
        [System.IO.File]::WriteAllText($f, $val, (New-Object System.Text.UTF8Encoding($false)))
        $script:InstallIdCache[$HomeDir] = $val
        return $val
    }
    catch { return $zero }
}

function Get-OsName {
    if ($env:OS -eq 'Windows_NT') { return 'windows' }
    if ($IsLinux) { return 'linux' }
    if ($IsMacOS) { return 'macos' }
    return 'unknown'
}

function Test-IsCi {
    foreach ($k in @('CI', 'TF_BUILD', 'GITHUB_ACTIONS', 'GITLAB_CI', 'JENKINS_URL', 'BUILD_BUILDID')) {
        if ([Environment]::GetEnvironmentVariable($k)) { return $true }
    }
    return $false
}

# ============================================================================
# STATE  (cooldown, counters, last flush status - never contains a PAT)
# ============================================================================

$script:StateCache = @{ data = $null; at = 0.0; path = $null }
$script:STATE_TTL_S = 0.25

function Get-EpochSeconds { [double]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0) }

function Read-State($cfg) {
    $path = Get-StateFile $cfg
    $now = Get-EpochSeconds
    if ($script:StateCache.path -eq $path -and $null -ne $script:StateCache.data -and
        ($now - $script:StateCache.at) -lt $script:STATE_TTL_S) {
        return $script:StateCache.data.Clone()
    }
    $data = @{}
    try {
        if (Test-Path -LiteralPath $path) {
            $obj = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($p in $obj.PSObject.Properties) { $data[$p.Name] = $p.Value }
        }
    }
    catch { $data = @{} }
    $script:StateCache = @{ data = $data.Clone(); at = $now; path = $path }
    return $data
}

function Write-State($cfg, [hashtable]$Updates) {
    if ($cfg.optout) { return }
    try {
        $data = Read-State $cfg
        foreach ($kv in $Updates.GetEnumerator()) { $data[$kv.Key] = $kv.Value }
        if (-not (Test-Path -LiteralPath $cfg.home)) { New-Item -ItemType Directory -Path $cfg.home -Force | Out-Null }
        $path = Get-StateFile $cfg
        $tmp = "$path.tmp"
        $json = ($data | ConvertTo-Json -Compress -Depth 6)
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $path -Force
        $script:StateCache = @{ data = $data.Clone(); at = (Get-EpochSeconds); path = $path }
    }
    catch { return }
}

function Add-StateCount($cfg, [string]$Key, [int]$N = 1) {
    $cur = 0
    try { $cur = [int](Read-State $cfg)[$Key] } catch { $cur = 0 }
    Write-State $cfg @{ $Key = $cur + $N }
}

# ============================================================================
# LOCKFILE  (stale-safe; caller MUST honour the return value)
# ============================================================================

function Get-Lock([string]$Path, [double]$TimeoutS = 2.0) {
    # Returns a FileStream when acquired, or $null. Running the protected section
    # on $null means the lock provides no mutual exclusion at all.
    try {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }
    catch { return $null }

    $deadline = (Get-EpochSeconds) + [Math]::Max(0.0, $TimeoutS)
    while ($true) {
        try {
            return New-Object System.IO.FileStream($Path, [System.IO.FileMode]::CreateNew,
                [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        }
        catch [System.IO.IOException] {
            # A lock left by a crashed process must not wedge the system forever.
            try {
                $age = ((Get-Date).ToUniversalTime() - (Get-Item -LiteralPath $Path -Force).LastWriteTimeUtc).TotalSeconds
                if ($age -gt $script:LOCK_STALE_S) { Remove-Item -LiteralPath $Path -Force -ErrorAction Stop; continue }
            }
            catch { }
            if ((Get-EpochSeconds) -ge $deadline) { return $null }
            Start-Sleep -Milliseconds 20
        }
        catch { return $null }
    }
}

function Remove-Lock($Stream, [string]$Path) {
    if ($null -eq $Stream) { return }
    try { $Stream.Close() } catch { }
    try { Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue } catch { }
}

# ============================================================================
# REDACT  (client-side is the ONLY gate; nothing downstream re-checks)
# ============================================================================

$script:SECRET_PATTERNS = @(
    [regex]'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.',
    [regex]'\b[A-Za-z0-9+/]{40,}={0,2}\b',
    [regex]'(?i)\b(pass(word)?|pwd|secret|token|api[_-]?key|bearer)\b\s*[:=]',
    [regex]'(?i)\b(AccountKey|SharedAccessSignature|ConnectionString)\s*=',
    [regex]'(?i)\bgh[pousr]_[A-Za-z0-9]{20,}\b',
    [regex]'(?i)\bsk-[A-Za-z0-9]{20,}\b',
    [regex]'[A-Za-z]:\\|/(home|Users|mnt)/',
    [regex]'(?i)\b[\w.+-]+@[\w-]+\.[\w.]+\b',
    [regex]'\b(?:\d{1,3}\.){3}\d{1,3}\b',
    [regex]'(?i)https?://'
)

function Get-AllStrings($obj) {
    if ($null -eq $obj) { return }
    if ($obj -is [string]) { return $obj }
    $out = New-Object System.Collections.ArrayList
    if ($obj -is [System.Collections.IDictionary]) {
        foreach ($k in $obj.Keys) {
            if ($k -is [string]) { [void]$out.Add($k) }
            foreach ($s in (Get-AllStrings $obj[$k])) { if ($s) { [void]$out.Add($s) } }
        }
    }
    elseif ($obj -is [System.Collections.IEnumerable]) {
        foreach ($v in $obj) { foreach ($s in (Get-AllStrings $v)) { if ($s) { [void]$out.Add($s) } } }
    }
    return $out.ToArray()
}

function Test-SecretShape($event) {
    # Deliberately aggressive: a dropped usage event costs one count, a leaked
    # credential costs an incident.
    foreach ($s in (Get-AllStrings $event)) {
        if (-not $s) { continue }
        foreach ($pat in $script:SECRET_PATTERNS) { if ($pat.IsMatch($s)) { return $true } }
    }
    return $false
}

# ============================================================================
# NAMES  (no registration step: any well-shaped name is accepted on first use)
# ============================================================================

function ConvertTo-NormalName([string]$Value) {
    ([regex]'[\s_]+').Replace(("$Value").Trim().ToLowerInvariant(), '-')
}

function Set-NormalisedNames($cfg, $event) {
    # Returns $null for over-length values only: those are rejected rather than
    # truncated, because a truncated prefix can still be a secret.
    foreach ($key in @('agent_name', 'command', 'team')) {
        $value = $event[$key]
        if ($value -isnot [string]) { continue }
        $norm = ConvertTo-NormalName $value
        if ($norm.Length -gt $script:MAX_STRING_LEN) { return $null }
        if (-not $norm -or -not $script:NAME_RE.IsMatch($norm)) {
            $event[$key] = $script:UNREGISTERED
            Add-StateCount $cfg "invalid_$key"
        }
        else { $event[$key] = $norm }
    }
    return $event
}

# ============================================================================
# VALIDATE  (reject, never truncate)
# ============================================================================

function Test-Scalar([string]$Key, $Value) {
    if ($Value -is [bool]) { return $true }
    if ($Value -is [string]) { return $Value.Length -le $script:MAX_STRING_LEN }
    if ($Value -is [int] -or $Value -is [long]) { return ($Value -ge 0 -and $Value -le $script:MAX_INT) }
    return $false
}

function Test-Bounds($event) {
    if ($script:EVENT_TYPES -notcontains $event['event_type']) { return $false }
    if ($null -ne $event['distribution'] -and $script:DISTRIBUTIONS -notcontains $event['distribution']) { return $false }

    foreach ($key in @('agent_name', 'command', 'team')) {
        $v = $event[$key]
        if ($v -is [string] -and -not $script:NAME_RE.IsMatch($v)) { return $false }
    }

    foreach ($key in @($event.Keys)) {
        if (-not (Test-Scalar $key $event[$key])) { return $false }
    }
    return $true
}

# ============================================================================
# EVENT
# ============================================================================

function New-Envelope($cfg, [string]$EventType, [string]$RunIdValue) {
    [ordered]@{
        schema_version = $script:SCHEMA_VERSION
        event_id       = New-EventId
        event_type     = $EventType
        timestamp      = Get-UtcNow
        run_id         = $RunIdValue
        session_id     = $script:SessionId
        install_id     = Get-InstallId $cfg.home
        agent_name     = $cfg.agent_name
        agent_version  = $cfg.agent_version
        distribution   = $cfg.distribution
        command        = $cfg.command
        team           = $cfg.team
        os             = Get-OsName
        ci             = Test-IsCi
        consent        = $true
    }
}

function ConvertTo-FinalEvent($event) {
    # Last gate before the pool: drops every key outside the allow-list (N4).
    $out = [ordered]@{}
    foreach ($k in $event.Keys) {
        if ($script:ALLOWED_KEYS -contains $k -and $null -ne $event[$k]) { $out[$k] = $event[$k] }
    }
    $out
}

# ============================================================================
# POOL  (append-only current.jsonl, atomic rename to seal, delete to commit)
# ============================================================================

function Initialize-AppendDataNative {
    # The managed FileStream(path, mode, FileSystemRights, share, buffer, options) ctor
    # used below only resolves under Windows PowerShell 5.1 (.NET Framework); .NET Core
    # (pwsh, PowerShell 7+) has no such overload and PowerShell silently mis-binds a
    # different one, so this goes straight to the Win32 primitive on every host instead.
    if ('AgentTelemetryNative.Kernel32' -as [type]) { return }
    Add-Type -Namespace AgentTelemetryNative -Name Kernel32 -MemberDefinition '
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFileW(
            string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes,
            uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);
    ' -ErrorAction Stop
}

function Add-PoolLine([string]$Path, [string]$Line) {
    # AppendData ONLY (FILE_APPEND_DATA), via Win32 directly. Adding GENERIC_WRITE
    # downgrades this to seek-then-write and silently loses events under concurrency.
    Initialize-AppendDataNative
    $FILE_APPEND_DATA = 0x00000004
    $FILE_SHARE_READWRITE = 0x00000003
    $OPEN_ALWAYS = 4
    $FILE_ATTRIBUTE_NORMAL = 0x80
    $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($Line)
    $handle = [AgentTelemetryNative.Kernel32]::CreateFileW($Path, $FILE_APPEND_DATA, $FILE_SHARE_READWRITE,
        [IntPtr]::Zero, $OPEN_ALWAYS, $FILE_ATTRIBUTE_NORMAL, [IntPtr]::Zero)
    if ($handle.IsInvalid) {
        $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "CreateFileW failed for '$Path' (Win32 error $err)"
    }
    $fs = New-Object System.IO.FileStream($handle, [System.IO.FileAccess]::Write)
    try { $fs.Write($bytes, 0, $bytes.Length) } finally { $fs.Close() }
}

function Add-PoolEvent($cfg, $event) {
    # No lock, no read, no network (N2).
    $line = ($event | ConvertTo-Json -Compress -Depth 6) + "`n"
    $path = Get-CurrentFile $cfg
    try { Add-PoolLine $path $line }
    catch {
        $dir = Get-PoolDir $cfg
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Add-PoolLine $path $line
    }
}

function Test-ShouldSeal($cfg) {
    # Size-based proxy for event count. Never reads the file.
    try {
        $f = Get-Item -LiteralPath (Get-CurrentFile $cfg) -Force -ErrorAction Stop
    }
    catch { return $false }
    if ($f.Length -ge ($cfg.segment_max_events * $script:APPROX_EVENT_BYTES)) { return $true }
    if ($f.Length -gt 0) {
        $age = ((Get-Date).ToUniversalTime() - $f.LastWriteTimeUtc).TotalSeconds
        if ($age -ge $cfg.segment_max_age_s) { return $true }
    }
    return $false
}

function Invoke-PoolSeal($cfg) {
    $lockPath = Join-Path (Get-LocksDir $cfg) 'seal.lock'
    $lock = Get-Lock $lockPath 2.0
    if ($null -eq $lock) { return $null }
    try {
        $cur = Get-CurrentFile $cfg
        if (-not (Test-Path -LiteralPath $cur)) { return $null }
        if ((Get-Item -LiteralPath $cur -Force).Length -eq 0) { return $null }
        $readyDir = Get-ReadyDir $cfg
        if (-not (Test-Path -LiteralPath $readyDir)) { New-Item -ItemType Directory -Path $readyDir -Force | Out-Null }
        $ts = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
        $target = Join-Path $readyDir ("seg-$ts-" + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.jsonl')
        [System.IO.File]::Move($cur, $target)
        return $target
    }
    catch { return $null }
    finally { Remove-Lock $lock $lockPath }
}

function Get-ReadySegment($cfg) {
    try {
        $d = Get-ReadyDir $cfg
        if (-not (Test-Path -LiteralPath $d)) { return @() }
        return @(Get-ChildItem -LiteralPath $d -Filter 'seg-*.jsonl' -File | Sort-Object Name | ForEach-Object { $_.FullName })
    }
    catch { return @() }
}

function Read-Segment([string]$Path) {
    $out = New-Object System.Collections.ArrayList
    try {
        foreach ($raw in (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop)) {
            $s = $raw.Trim()
            if (-not $s) { continue }
            try { $ev = $s | ConvertFrom-Json } catch { continue }  # torn line: skip, never fatal
            if ($ev) { [void]$out.Add($ev) }
        }
    }
    catch { }
    return @($out.ToArray())
}

function Remove-Segment([string]$Path) {
    # Delete a fully-delivered segment. The ONLY removal mechanism (N7).
    for ($attempt = 0; $attempt -lt 3; $attempt++) {
        try {
            if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $true }
            [System.IO.File]::SetAttributes($Path, [System.IO.FileAttributes]::Normal)
            [System.IO.File]::Delete($Path)
            if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $true }
        }
        catch { }
        Start-Sleep -Milliseconds 50
    }
    return (-not (Test-Path -LiteralPath $Path -PathType Leaf))
}

function Rewrite-Segment([string]$Path, $Events) {
    $tempPath = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        $content = (($Events | ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 6 }) -join "`n") + "`n"
        [System.IO.File]::WriteAllText($tempPath, $content, $script:Utf8NoBom)
        Move-Item -LiteralPath $tempPath -Destination $Path -Force
        return $true
    }
    catch {
        $script:LastRewriteError = $_.Exception.Message
        try { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue } catch { }
        return $false
    }
}

function Limit-Pool($cfg) {
    # Drop OLDEST segments beyond the cap. Loss must be visible, never silent.
    $segs = [System.Collections.ArrayList]@(Get-ReadySegment $cfg)
    $dropped = 0
    while ($segs.Count -gt $cfg.pool_max_segments) {
        Remove-Segment $segs[0]; $segs.RemoveAt(0); $dropped++
    }
    $total = 0
    foreach ($s in $segs) { try { $total += (Get-Item -LiteralPath $s -Force).Length } catch { } }
    while ($segs.Count -gt 0 -and $total -gt $cfg.pool_max_bytes) {
        try { $total -= (Get-Item -LiteralPath $segs[0] -Force).Length } catch { }
        Remove-Segment $segs[0]; $segs.RemoveAt(0); $dropped++
    }
    if ($dropped) { Add-StateCount $cfg 'dropped_count' $dropped }
    return $dropped
}

function Get-PoolDepth($cfg) {
    # Approximate event count across current + ready. Not on the emit path.
    $n = 0
    try {
        $paths = @(Get-CurrentFile $cfg) + (Get-ReadySegment $cfg)
        foreach ($p in $paths) {
            if (-not (Test-Path -LiteralPath $p)) { continue }
            foreach ($line in (Get-Content -LiteralPath $p -Encoding UTF8)) { if ($line.Trim()) { $n++ } }
        }
    }
    catch { }
    return $n
}

function Get-PoolMetrics($cfg) {
    $depth = 0
    $bytes = [int64]0
    $oldest = $null
    try {
        $paths = @(Get-CurrentFile $cfg) + (Get-ReadySegment $cfg)
        foreach ($path in $paths) {
            if (-not (Test-Path -LiteralPath $path)) { continue }
            $file = Get-Item -LiteralPath $path -Force
            $bytes += [int64]$file.Length
            foreach ($line in (Get-Content -LiteralPath $path -Encoding UTF8)) {
                if (-not $line.Trim()) { continue }
                $depth++
                try {
                    $event = $line | ConvertFrom-Json
                    $timestamp = [DateTime]::ParseExact("$($event.timestamp)", 'yyyy-MM-ddTHH:mm:ssZ',
                        [Globalization.CultureInfo]::InvariantCulture,
                        [Globalization.DateTimeStyles]::AssumeUniversal)
                    if ($null -eq $oldest -or $timestamp -lt $oldest) { $oldest = $timestamp }
                }
                catch { }
            }
        }
    }
    catch { }
    $age = 0
    if ($null -ne $oldest) { $age = [int][Math]::Max(0, ((Get-Date).ToUniversalTime() - $oldest).TotalSeconds) }
    [ordered]@{ depth = $depth; bytes = $bytes; oldest_age_s = $age }
}

function Get-PendingSummary($cfg) {
    $summary = @{}
    $paths = @(Get-CurrentFile $cfg) + (Get-ReadySegment $cfg)
    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) { continue }
        foreach ($line in (Get-Content -LiteralPath $path -Encoding UTF8)) {
            if (-not $line.Trim()) { continue }
            try { $event = $line | ConvertFrom-Json } catch { continue }
            $agent = if ($event.agent_name) { "$($event.agent_name)" } else { 'unknown-agent' }
            $command = if ($event.command) { "$($event.command)" } else { 'unknown-command' }
            $key = "$agent|$command"
            if (-not $summary.ContainsKey($key)) { $summary[$key] = 0 }
            $summary[$key]++
        }
    }
    return @($summary.GetEnumerator() | Sort-Object Name | ForEach-Object {
        $parts = $_.Key -split '\|', 2
        [ordered]@{ agent = $parts[0]; command = $parts[1]; events = $_.Value }
    })
}

# ============================================================================
# AUTH  (the PAT is READ, never written, never printed)
# ============================================================================

$script:PatMemo = @{ value = $null; resolved = $false }

function Get-Pat($cfg) {
    if ($script:PatMemo.resolved) { return $script:PatMemo.value }
    $pat = $null
    foreach ($var in @('AGENT_TELEMETRY_ADO_PAT', 'AZURE_DEVOPS_EXT_PAT')) {
        $v = [Environment]::GetEnvironmentVariable($var)
        if ($v -and $v.Trim()) { $pat = $v.Trim(); break }
    }
    if (-not $pat) {
        $v = [Environment]::GetEnvironmentVariable('AGENT_TELEMETRY_ADO_PAT', 'User')
        if ($v -and $v.Trim()) { $pat = $v.Trim() }
    }
    if (-not $pat) {
        $v = (Get-DotEnv)['AGENT_TELEMETRY_ADO_PAT']
        if ($v -and $v.Trim()) { $pat = $v.Trim() }
    }
    if (-not $pat) {
        try {
            $f = Join-Path $cfg.home 'pat'
            if (Test-Path -LiteralPath $f -PathType Leaf) {
                $v = (Get-Content -LiteralPath $f -Raw -Encoding UTF8).Trim()
                if ($v) { $pat = $v }
            }
        }
        catch { $pat = $null }
    }
    $script:PatMemo = @{ value = $pat; resolved = $true }
    return $pat
}

function Get-AuthHeader([string]$Pat) {
    # ADO REST uses HTTP Basic with an EMPTY username and the PAT as password.
    $token = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(":$Pat"))
    return "Basic $token"
}

function Format-MaskedPat([string]$Pat) {
    # For status/doctor only. Never print a PAT, even partially, in logs.
    if (-not $Pat) { return '<not set>' }
    return "<set, $($Pat.Length) chars, ...$($Pat.Substring([Math]::Max(0,$Pat.Length-4)))>"
}

# ============================================================================
# SINKS
# ============================================================================

function New-SendResult([string]$Outcome, [string]$ErrClass = $null, $RetryAfterS = $null, [int]$Accepted = 0) {
    [ordered]@{ outcome = $Outcome; error_class = $ErrClass; retry_after_s = $RetryAfterS; accepted = $Accepted }
}

function Get-ShardIndex([string]$InstallIdValue, [int]$ShardCount = 32) {
    try { return [Convert]::ToInt64($InstallIdValue.Substring(0, 8), 16) % [Math]::Max(1, $ShardCount) }
    catch { return 0 }
}

function Get-ShardBranch([string]$InstallIdValue, [int]$ShardCount = 32) {
    'tel/' + ('{0:d2}' -f (Get-ShardIndex $InstallIdValue $ShardCount))
}

function Get-EventPath($cfg, $batch) {
    $first = if ($batch -and @($batch).Count) { @($batch)[0] } else { $null }
    $agent = if ($first -and $first.agent_name) { $first.agent_name } else { $cfg.agent_name }
    $inst = if ($first -and $first.install_id) { $first.install_id } else { 'unknown' }
    $day = if ($first -and $first.timestamp) { "$($first.timestamp)".Substring(0, 10) } else { (Get-UtcNow).Substring(0, 10) }
    $ts = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
    $rand = [guid]::NewGuid().ToString('N').Substring(0, 8)
    return "/$($cfg.ado_path_prefix)/$agent/date=$day/$inst-$ts-$rand.jsonl"
}

function ConvertTo-Jsonl($batch) {
    $sb = New-Object System.Text.StringBuilder
    foreach ($e in $batch) { [void]$sb.Append(($e | ConvertTo-Json -Compress -Depth 6)).Append("`n") }
    $sb.ToString()
}

# -- noop --------------------------------------------------------------------
function Test-NoopAvailable($cfg) { $true }
function Send-Noop($cfg, $batch) { New-SendResult 'ok' $null $null (@($batch).Count) }

# -- file (dev/test) ---------------------------------------------------------
function Test-FileAvailable($cfg) { [bool]$cfg.file_dir }
function Send-File($cfg, $batch) {
    try {
        $first = @($batch)[0]
        $agent = if ($first.agent_name) { $first.agent_name } else { $cfg.agent_name }
        $inst = if ($first.install_id) { $first.install_id } else { 'unknown' }
        $day = "$($first.timestamp)".Substring(0, 10)
        $d = Join-Path (Join-Path $cfg.file_dir $agent) "date=$day"
        if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        $ts = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
        $name = "$inst-$ts-" + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.jsonl'
        [System.IO.File]::WriteAllText((Join-Path $d $name), (ConvertTo-Jsonl $batch),
            (New-Object System.Text.UTF8Encoding($false)))
        return New-SendResult 'ok' $null $null (@($batch).Count)
    }
    catch { return New-SendResult 'retry' 'unknown' }
}

# -- ado_git (default production sink) ---------------------------------------
$script:ZERO_OID = '0' * 40
$script:API = 'api-version=7.1'

function Get-OrgUrl($cfg) {
    $org = ("$($cfg.ado_org)").TrimEnd('/')
    if ($org -like 'http*') { return $org }
    return "https://dev.azure.com/$org"
}
function Get-RepoUrl($cfg) { "$(Get-OrgUrl $cfg)/$($cfg.ado_project)/_apis/git/repositories/$($cfg.ado_repo)" }

function Test-AdoAvailable($cfg) {
    if (-not ($cfg.ado_org -and $cfg.ado_project -and $cfg.ado_repo)) { return $false }
    return $null -ne (Get-Pat $cfg)
}

function Get-HttpErrorResult($ErrorRecord) {
    $code = 0
    try { $code = [int]$ErrorRecord.Exception.Response.StatusCode } catch { $code = 0 }
    if ($code -eq 409) { return New-SendResult 'retry' 'sink_conflict' }
    if ($code -eq 429) {
        $ra = $null
        try { $ra = [double]$ErrorRecord.Exception.Response.Headers['Retry-After'] } catch { $ra = $null }
        return New-SendResult 'retry' 'rate_limited' $ra
    }
    # An expired/revoked PAT is a fleet-wide outage, not a poison pill.
    if ($code -eq 401 -or $code -eq 403) { return New-SendResult 'unavailable' 'auth_unavailable' }
    if ($code -ge 500 -and $code -lt 600) { return New-SendResult 'retry' 'network' }
    if (@(400, 404, 422) -contains $code) { return New-SendResult 'rejected' 'sink_rejected' }
    return New-SendResult 'retry' 'unknown'
}

function Invoke-AdoApi([string]$Url, [string]$Pat, $cfg, [string]$Method = 'GET', $Body = $null) {
    $headers = @{ Authorization = (Get-AuthHeader $Pat); Accept = 'application/json' }
    $params = @{ Uri = $Url; Method = $Method; Headers = $headers; UseBasicParsing = $true;
        TimeoutSec = [int]$cfg.timeout; ErrorAction = 'Stop'
    }
    if ($null -ne $Body) {
        $params['Body'] = ($Body | ConvertTo-Json -Depth 10 -Compress)
        $params['ContentType'] = 'application/json'
    }
    $resp = Invoke-WebRequest @params
    $data = $null
    try { $data = $resp.Content | ConvertFrom-Json } catch { $data = $null }
    return @{ status = [int]$resp.StatusCode; data = $data }
}

function Get-BranchOid($cfg, [string]$Pat, [string]$Branch) {
    $r = Invoke-AdoApi "$(Get-RepoUrl $cfg)/refs?filter=heads/$Branch&$($script:API)" $Pat $cfg 'GET'
    foreach ($ref in @($r.data.value)) {
        if ($ref.name -eq "refs/heads/$Branch") { if ($ref.objectId) { return $ref.objectId } }
    }
    return $script:ZERO_OID
}

function Get-BackoffDelay([int]$Attempt) {
    # Exponential with FULL jitter - fixed backoff re-synchronises the herd.
    $cap = [Math]::Min($script:MAX_BACKOFF_S, $script:BASE_BACKOFF_S * [Math]::Pow(2, $Attempt))
    return (Get-Random -Minimum 0.0 -Maximum $cap)
}

function Send-AdoGit($cfg, $batch) {
    $pat = Get-Pat $cfg
    if (-not $pat) { return New-SendResult 'unavailable' 'auth_unavailable' }
    $first = @($batch)[0]
    $inst = if ($first.install_id) { "$($first.install_id)" } else { '0' * 16 }
    $branch = Get-ShardBranch $inst $cfg.shard_count
    $path = Get-EventPath $cfg $batch
    $content = ConvertTo-Jsonl $batch

    $last = New-SendResult 'retry' 'unknown'
    for ($attempt = 0; $attempt -lt $script:MAX_ATTEMPTS; $attempt++) {
        try {
            $oldOid = Get-BranchOid $cfg $pat $branch
            $body = @{
                refUpdates = @(@{ name = "refs/heads/$branch"; oldObjectId = $oldOid })
                commits    = @(@{
                        comment = 'telemetry'
                        changes = @(@{
                                changeType = 'add'
                                item       = @{ path = $path }
                                newContent = @{ content = $content; contentType = 'rawtext' }
                            })
                    })
            }
            $r = Invoke-AdoApi "$(Get-RepoUrl $cfg)/pushes?$($script:API)" $pat $cfg 'POST' $body
            if ($r.status -ge 200 -and $r.status -lt 300) {
                return New-SendResult 'ok' $null $null (@($batch).Count)
            }
            $last = New-SendResult 'retry' 'unknown'
        }
        catch [System.Net.WebException] { $last = Get-HttpErrorResult $_ }
        catch {
            if ($_.Exception.Response) { $last = Get-HttpErrorResult $_ }
            elseif ($_.Exception -is [System.TimeoutException]) { $last = New-SendResult 'retry' 'timeout' }
            else { $last = New-SendResult 'retry' 'unknown' }
        }
        if ($last.outcome -ne 'retry') { return $last }
        if ($attempt -lt ($script:MAX_ATTEMPTS - 1)) {
            $delay = if ($last.retry_after_s) { [double]$last.retry_after_s } else { Get-BackoffDelay $attempt }
            Start-Sleep -Milliseconds ([int]([Math]::Min($delay, $script:MAX_BACKOFF_S) * 1000))
        }
    }
    return $last
}

function Resolve-Sink($cfg) {
    switch ($cfg.sink) {
        'file' { return @{ available = ${function:Test-FileAvailable}; send = ${function:Send-File} } }
        'ado_git' { return @{ available = ${function:Test-AdoAvailable}; send = ${function:Send-AdoGit} } }
        default { return @{ available = ${function:Test-NoopAvailable}; send = ${function:Send-Noop} } }
    }
}

# ============================================================================
# FLUSH ENGINE
# ============================================================================

function Start-DetachedFlush($cfg) {
    # Fire-and-forget. Never waits, pipes, or reads output.
    if ($cfg.optout) { return }
    $workerLock = Join-Path (Get-LocksDir $cfg) 'drain-worker.lock'
    if (Test-Path -LiteralPath $workerLock) { return }
    $last = 0.0
    try { $last = [double](Read-State $cfg)['last_spawn_at'] } catch { $last = 0.0 }
    $now = Get-EpochSeconds
    if (($now - $last) -lt $cfg.flush_cooldown_s) { return }
    Write-State $cfg @{ last_spawn_at = $now }
    try {
        $exe = if ($PSVersionTable.PSVersion.Major -ge 6) { 'pwsh' } else { 'powershell' }
        Start-Process -FilePath $exe -WindowStyle Hidden -ErrorAction Stop -ArgumentList @(
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath, 'flush', '-Detached')
    }
    catch { return }
}

function Invoke-Flush($cfg, [double]$LockWaitS = 0.0) {
    if ($cfg.optout) { return 0 }
    $lockPath = Join-Path (Get-LocksDir $cfg) 'flush.lock'
    $lock = Get-Lock $lockPath $LockWaitS
    if ($null -eq $lock) { return -1 }  # another flusher owns this machine right now
    try { return [int](Invoke-FlushLocked $cfg) }
    catch { return -1 }
    finally { Remove-Lock $lock $lockPath }
}

function Invoke-FlushLocked($cfg) {
    $sink = Resolve-Sink $cfg
    if (-not (& $sink.available $cfg)) {
        $state = Read-State $cfg
        $retryCount = 0
        try { $retryCount = [int]$state['retry_count'] } catch { $retryCount = 0 }
        $retryAt = (Get-EpochSeconds) + (Get-BackoffDelay $retryCount)
        Write-State $cfg @{ last_flush_status = 'auth_unavailable'; last_flush_at = (Get-EpochSeconds);
            next_retry_at = $retryAt; retry_count = $retryCount + 1; last_error = 'auth_unavailable' }
        return
    }

    Send-HealthEvent $cfg
    Invoke-PoolSeal $cfg | Out-Null
    Limit-Pool $cfg | Out-Null

    $delivered = 0
    $segs = @(Get-ReadySegment $cfg)
    if ($segs.Count -gt $script:MAX_SEGMENTS_PER_RUN) { $segs = $segs[0..($script:MAX_SEGMENTS_PER_RUN - 1)] }
    foreach ($seg in $segs) {
        $state = Read-State $cfg
        $nextRetry = 0.0
        try { $nextRetry = [double]$state['next_retry_at'] } catch { $nextRetry = 0.0 }
        if ($nextRetry -gt (Get-EpochSeconds)) { return $delivered }
        $batch = @(Read-Segment $seg)
        if ($batch.Count -eq 0) { Remove-Segment $seg; continue }
        $slice = if ($batch.Count -gt $cfg.max_batch) { $batch[0..($cfg.max_batch - 1)] } else { $batch }
        $result = & $sink.send $cfg $slice

        if ($result.outcome -eq 'ok') {
            $sliceCount = @($slice).Count
            $accepted = $sliceCount
            try {
                if ($null -ne $result.accepted -and [int]$result.accepted -gt 0) {
                    $accepted = [Math]::Min([int]$result.accepted, $sliceCount)
                }
            }
            catch { $accepted = $slice.Count }
            $remaining = if ($accepted -lt $batch.Count) { @($batch[$accepted..($batch.Count - 1)]) } else { @() }
            if ($remaining.Count -eq 0) {
                if (-not (Remove-Segment $seg)) {
                    Write-State $cfg @{ last_flush_status = 'segment_delete_failed'; last_flush_at = (Get-EpochSeconds);
                        last_error = 'delivered segment could not be deleted' }
                    return
                }
            }
            elseif (-not (Rewrite-Segment $seg $remaining)) {
                $rewriteError = "$script:LastRewriteError"
                if (-not $rewriteError) { $rewriteError = 'unknown rewrite exception' }
                if ($rewriteError.Length -gt 256) { $rewriteError = $rewriteError.Substring(0, 256) }
                $failedAt = Get-EpochSeconds
                Write-State $cfg @{
                    last_flush_status = 'segment_rewrite_failed'
                    last_flush_error = $rewriteError
                    last_flush_at = $failedAt
                    last_spawn_at = $failedAt
                }
                Add-StateCount $cfg 'flush_retry'
                return
            }
            $delivered += $accepted
            Write-State $cfg @{ last_flush_status = 'ok'; last_flush_at = (Get-EpochSeconds); next_retry_at = $null;
                last_error = $null; last_flush_delivered = $accepted; last_flush_deleted = $true }
            Add-StateCount $cfg 'flush_ok'
        }
        elseif ($result.outcome -eq 'rejected') {
            # Poison pill: retrying forever would block every segment behind it.
            [void](Remove-Segment $seg)
            Write-State $cfg @{ last_flush_status = $result.error_class; last_flush_at = (Get-EpochSeconds) }
            Add-StateCount $cfg 'flush_rejected'
        }
        elseif ($result.outcome -eq 'unavailable') {
            $retryCount = 0
            try { $retryCount = [int]$state['retry_count'] } catch { $retryCount = 0 }
            $retryAt = (Get-EpochSeconds) + (Get-BackoffDelay $retryCount)
            Write-State $cfg @{ last_flush_status = $result.error_class; last_flush_at = (Get-EpochSeconds);
                next_retry_at = $retryAt; retry_count = $retryCount + 1; last_error = $result.error_class }
            return
        }
        else {
            $retryCount = 0
            try { $retryCount = [int]$state['retry_count'] } catch { $retryCount = 0 }
            $retryAt = (Get-EpochSeconds) + (Get-BackoffDelay $retryCount)
            Write-State $cfg @{ last_flush_status = $result.error_class; last_flush_at = (Get-EpochSeconds);
                next_retry_at = $retryAt; retry_count = $retryCount + 1; last_error = $result.error_class }
            Add-StateCount $cfg 'flush_retry'
            return
        }
    }
    return $delivered
}

function Invoke-DrainWorker($cfg) {
    if ($cfg.optout) { return }
    $lockPath = Join-Path (Get-LocksDir $cfg) 'drain-worker.lock'
    $lock = Get-Lock $lockPath 0.0
    if ($null -eq $lock) { return }
    try {
        while ((Get-PoolMetrics $cfg).depth -gt 0) {
            $state = Read-State $cfg
            $nextRetry = 0.0
            try { $nextRetry = [double]$state['next_retry_at'] } catch { $nextRetry = 0.0 }
            $wait = $nextRetry - (Get-EpochSeconds)
            if ($wait -gt 0) {
                Start-Sleep -Milliseconds ([int]([Math]::Min($wait, $script:MAX_BACKOFF_S) * 1000))
                continue
            }
            $beforeDepth = (Get-PoolMetrics $cfg).depth
            Invoke-Flush $cfg | Out-Null
            $afterDepth = (Get-PoolMetrics $cfg).depth
            if ($afterDepth -ge $beforeDepth) {
                Write-State $cfg @{ last_flush_status = 'no_progress'; last_error = 'pool did not shrink after flush' }
                break
            }
        }
    }
    catch { }
    finally { Remove-Lock $lock $lockPath }
}

# ============================================================================
# HEALTH  (separates "nobody used it" from "nobody's events arrived")
# ============================================================================

function Send-HealthEvent($cfg) {
    if ($cfg.optout) { return }
    $last = 0.0
    try { $last = [double](Read-State $cfg)['last_health_at'] } catch { $last = 0.0 }
    $now = Get-EpochSeconds
    if (($now - $last) -lt $script:HEALTH_INTERVAL_S) { return }
    Write-State $cfg @{ last_health_at = $now }
    $st = Read-State $cfg

    # A fixed agent partition: the detached flusher has no agent context, and
    # 'unknown-agent' would create a junk folder in the events tree.
    $hcfg = New-Config $script:HEALTH_AGENT_NAME $cfg.agent_version $cfg.team $cfg.distribution $script:HEALTH_COMMAND
    $event = New-Envelope $hcfg 'telemetry_health' (New-EventId)
    $metrics = Get-PoolMetrics $cfg
    $event['pool_depth'] = $metrics.depth
    $event['queue_bytes'] = $metrics.bytes
    $event['oldest_event_age_s'] = $metrics.oldest_age_s
    $lfs = "$($st['last_flush_status'])"
    if (-not $lfs) { $lfs = 'unknown' }
    $event['last_flush_status'] = $lfs.Substring(0, [Math]::Min(32, $lfs.Length))
    $dc = 0; try { $dc = [int]$st['dropped_count'] } catch { $dc = 0 }
    $event['dropped_count'] = $dc
    $rc = 0; try { $rc = [int]$st['retry_count'] } catch { $rc = 0 }
    $event['retry_count'] = $rc
    if ($st['last_error']) { $event['last_error'] = "$($st['last_error'])".Substring(0, [Math]::Min(64, "$($st['last_error'])".Length)) }
    $event['sink'] = "$($cfg.sink)".Substring(0, [Math]::Min(32, "$($cfg.sink)".Length))
    Invoke-ProcessAndPool $hcfg $event | Out-Null
}

# ============================================================================
# CORE  (ordering is load-bearing)
# ============================================================================

function Invoke-ProcessAndPool($cfg, $event) {
    if ($cfg.optout) { return $false }
    $event = Set-NormalisedNames $cfg $event          # 2. normalise
    if ($null -eq $event -or -not (Test-Bounds $event)) {   # 3. types + lengths
        Add-StateCount $cfg 'validation_rejected'
        return $false
    }
    if (Test-SecretShape $event) {                    # 4. secret scan
        Add-StateCount $cfg 'redaction_triggered'
        return $false                                 # drop the WHOLE event
    }
    Add-PoolEvent $cfg (ConvertTo-FinalEvent $event)  # 1. allow-list (last gate)
    return $true
}

function Send-Event($cfg, [string]$EventType, [string]$RunIdValue, [hashtable]$Payload,
    [bool]$AllowDetachedFlush = $true) {
    try {
        if ($cfg.optout) { if ($RunIdValue) { return $RunIdValue } else { return (New-EventId) } }
        $rid = if ($RunIdValue) { $RunIdValue } else { New-EventId }
        $event = New-Envelope $cfg $EventType $rid
        if ($Payload) {
            foreach ($kv in $Payload.GetEnumerator()) { if ($null -ne $kv.Value) { $event[$kv.Key] = $kv.Value } }
        }
        Invoke-ProcessAndPool $cfg $event | Out-Null
        if (Test-ShouldSeal $cfg) { Invoke-PoolSeal $cfg | Out-Null }
        $isTerminalEvent = @('command_completed', 'command_failed') -contains $EventType
        if ($cfg.flush_on_terminal -and $isTerminalEvent) {
            Invoke-Flush $cfg $cfg.flush_lock_wait_s | Out-Null
            if ((Get-PoolMetrics $cfg).depth -gt 0) { Start-DetachedFlush $cfg }
        }
        elseif ($AllowDetachedFlush) {
            Start-DetachedFlush $cfg
        }
        return $rid
    }
    catch {
        if ($RunIdValue) { return $RunIdValue }
        return ('0' * 32)
    }
}

# ============================================================================
# CLI
# ============================================================================

function Show-Status($cfg) {
    $st = Read-State $cfg
    $metrics = Get-PoolMetrics $cfg
    $manifestPath = Get-ManifestFile $cfg
    Write-Output 'agent-telemetry status'
    Write-Output "  home              : $($cfg.home)"
    Write-Output "  optout            : $($cfg.optout)"
    Write-Output "  sink              : $($cfg.sink)"
    Write-Output "  client version    : $($script:CLIENT_VERSION)"
    Write-Output "  client hash       : $(Get-ClientHash)"
    Write-Output "  manifest          : $(if (Test-Path -LiteralPath $manifestPath) { $manifestPath } else { 'missing' })"
    Write-Output "  pool depth        : $($metrics.depth) event(s)"
    Write-Output "  queue bytes       : $($metrics.bytes)"
    Write-Output "  oldest event age  : $($metrics.oldest_age_s)s"
    Write-Output "  ready segments    : $(@(Get-ReadySegment $cfg).Count)"
    $pending = @(Get-PendingSummary $cfg)
    if ($pending.Count) {
        Write-Output '  pending by artifact:'
        foreach ($item in $pending) {
            Write-Output "    $($item.agent) / $($item.command): $($item.events) event(s)"
        }
    }
    Write-Output "  dropped_count     : $(if ($null -ne $st['dropped_count']) { $st['dropped_count'] } else { 0 })"
    $lfs = if ($st['last_flush_status']) { $st['last_flush_status'] } else { 'never' }
    Write-Output "  last flush status : $lfs"
    Write-Output "  retry count       : $(if ($null -ne $st['retry_count']) { $st['retry_count'] } else { 0 })"
    Write-Output "  last error        : $(if ($st['last_error']) { $st['last_error'] } else { '-' })"
    if ($st['next_retry_at']) {
        $retryIn = [int][Math]::Max(0, [double]$st['next_retry_at'] - (Get-EpochSeconds))
        Write-Output "  next retry        : in ${retryIn}s"
    }
    if ($st['last_flush_at']) {
        $age = [int][Math]::Max(0, (Get-EpochSeconds) - [double]$st['last_flush_at'])
        Write-Output "  last flush        : ${age}s ago"
    }
    Write-Output "  redactions        : $(if ($null -ne $st['redaction_triggered']) { $st['redaction_triggered'] } else { 0 })"
    $bad = 0
    try { $bad = [int]$st['invalid_command'] + [int]$st['invalid_agent_name'] } catch { $bad = 0 }
    Write-Output "  malformed names   : $bad"
}

function Show-Doctor($cfg) {
    $pat = Get-Pat $cfg
    $sink = Resolve-Sink $cfg
    $manifestPath = Get-ManifestFile $cfg
    Write-Output 'agent-telemetry doctor'
    Write-Output "  powershell        : $($PSVersionTable.PSVersion) ($(Get-OsName))"
    Write-Output "  script            : $PSCommandPath"
    Write-Output "  client version    : $($script:CLIENT_VERSION)"
    Write-Output "  client hash       : $(Get-ClientHash)"
    Write-Output "  manifest          : $(if (Test-Path -LiteralPath $manifestPath) { $manifestPath } else { 'missing' })"
    Write-Output "  home              : $($cfg.home)  (exists=$(Test-Path -LiteralPath $cfg.home))"
    Write-Output "  optout            : $($cfg.optout)"
    Write-Output "  sink              : $($cfg.sink)  (available=$([bool](& $sink.available $cfg)))"
    Write-Output "  auth mode         : $($cfg.auth_mode)"
    Write-Output "  PAT               : $(Format-MaskedPat $pat)"   # presence only, never the value
    Write-Output "  ADO org/proj/repo : $(if($cfg.ado_org){$cfg.ado_org}else{'-'}) / $(if($cfg.ado_project){$cfg.ado_project}else{'-'}) / $(if($cfg.ado_repo){$cfg.ado_repo}else{'-'})"
    Write-Output "  events prefix     : $($cfg.ado_path_prefix)"
    Write-Output "  shard count       : $($cfg.shard_count)"
    $inst = Get-InstallId $cfg.home
    Write-Output "  install_id        : $inst"
    Write-Output "  shard branch      : $(Get-ShardBranch $inst $cfg.shard_count)"
    Write-Output '  names             : shape-validated, no registration required'
    $metrics = Get-PoolMetrics $cfg
    Write-Output "  pool depth        : $($metrics.depth)"
    Write-Output "  queue bytes       : $($metrics.bytes)"
    Write-Output "  oldest event age  : $($metrics.oldest_age_s)s"
    Write-Output "  ready segments    : $(@(Get-ReadySegment $cfg).Count)"
    if ($cfg.sink -eq 'ado_git' -and -not $pat) {
        Write-Output '  ! no PAT resolved -> events will pool locally and never deliver'
    }
}

function Show-Help {
    Write-Output 'AgentTelemetry.ps1 - agent usage telemetry (single file, Azure DevOps sink)'
    Write-Output ''
    Write-Output '  emit     -Agent <a> -CommandName <c>'
    Write-Output '  start    -Agent <a> -CommandName <c> [...]            prints run_id'
    Write-Output '  complete -RunId <id> -Agent <a> -CommandName <c>'
    Write-Output '  fail     -RunId <id> -Agent <a> -CommandName <c>'
    Write-Output '  audit    -Agent <a> -CommandName <c> -EventType <t> [-ToolName <n>] [-ToolCategory <c>] [-Decision <d>]'
    Write-Output '  flush                                                deliver pooled events now'
    Write-Output '  status                                               pool + delivery health'
    Write-Output '  doctor                                               diagnose config, auth, pool'
    Write-Output ''
    Write-Output '  -Agent/-CommandName are required on complete/fail too: each call is a'
    Write-Output '  separate process, so identity does not survive from start.'
}

# Always exits 0: telemetry must never break the calling command (N1).
try {
    switch ($Command) {
        'emit' {
            $cfg = New-Config $Agent $Version $Team $Distribution $CommandName
            Send-Event $cfg 'command_started' $null @{} | Out-Null
        }
        'start' {
            $cfg = New-Config $Agent $Version $Team $Distribution $CommandName
            $rid = Send-Event $cfg 'command_started' $null @{} $false
            Write-Output $rid   # the only thing start writes to stdout
        }
        'complete' {
            $cfg = New-Config $Agent $Version $Team $Distribution $CommandName
            Send-Event $cfg 'command_completed' $RunId @{} | Out-Null
        }
        'fail' {
            $cfg = New-Config $Agent $Version $Team $Distribution $CommandName
            Send-Event $cfg 'command_failed' $RunId @{} | Out-Null
        }
        'audit' {
            $cfg = New-Config $Agent $Version $Team $Distribution $CommandName
            $payload = @{}
            if ($ToolName) { $payload['tool_name'] = $ToolName }
            if ($ToolCategory) { $payload['tool_category'] = $ToolCategory }
            if ($Decision) { $payload['decision'] = $Decision }
            Send-Event $cfg $EventType $RunId $payload | Out-Null
        }
        'flush' {
            $cfg = New-Config $null $null $null $null $null
            if ($Detached) { Invoke-DrainWorker $cfg; $delivered = 0 }
            else {
                $delivered = Invoke-Flush $cfg
                if ((Get-PoolMetrics $cfg).depth -gt 0) { Start-DetachedFlush $cfg }
            }
            $st = Read-State $cfg
            $status = if ($st['last_flush_status']) { $st['last_flush_status'] } else { 'never' }
            Write-Output "flush: delivered=$delivered status=$status pool=$(Get-PoolDepth $cfg)"
        }
        'status' { Show-Status (New-Config $null $null $null $null $null) }
        'doctor' { Show-Doctor (New-Config $null $null $null $null $null) }
        default { Show-Help }
    }
}
catch { $script:ExitCode = 0 }

exit 0
