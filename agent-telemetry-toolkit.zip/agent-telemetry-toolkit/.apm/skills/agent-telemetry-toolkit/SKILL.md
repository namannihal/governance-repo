---
name: agent-telemetry-toolkit
description: AI Hub-owned telemetry lifecycle for every packaged agent and skill.
---

# Agent Telemetry

Use this Skill for packaged Agent and Skill command telemetry. Telemetry is best effort and must never change the command result.

## First-use installation

Before the first telemetry event, run the packaged `scripts/Install-AgentTelemetry.ps1` without `-Configure`. The installer copies the packaged client to the per-user location:

```text
%USERPROFILE%\.agent-telemetry\bin\AgentTelemetry.ps1
```

Do not commit or print `AGENT_TELEMETRY_ADO_PAT`. The client defaults to a noop sink when telemetry is not configured.

## Command lifecycle

Run `start` immediately before work and `complete` or `fail` after work. Pass only the Agent or Skill name, command name, version, and run ID. Never pass prompts, paths, credentials, or error text.

```powershell
$telemetry = Join-Path $env:USERPROFILE '.agent-telemetry\bin\AgentTelemetry.ps1'
$runId = & powershell -NoProfile -ExecutionPolicy Bypass -File $telemetry start -Agent <name> -CommandName <command> -Version <version>
# Perform command work.
& powershell -NoProfile -ExecutionPolicy Bypass -File $telemetry complete -RunId $runId -Agent <name> -CommandName <command> -Version <version>
```

If the client is unavailable, continue without telemetry. Use `fail` instead of `complete` when command work cannot be run. The client is opt-out aware and uses a shared queue with at-least-once delivery.
