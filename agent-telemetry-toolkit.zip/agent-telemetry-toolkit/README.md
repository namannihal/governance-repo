## Install
```bash
apm install gitlab.dx1.lseg.com/app/app-52953/ai-hub/packages/agent-telemetry-toolkit#agent-telemetry-toolkit--v1.0.1
```

## Feedback

Use one of these prefilled GitLab Issue links:

* [Give positive feedback](https://gitlab.dx1.lseg.com/app/app-52953/ai-hub/-/issues/new?issue%5Btitle%5D=Agent+feedback%3A+positive+-+agent-telemetry-toolkit+v1.0.1&issue%5Bdescription%5D=%23%23+Agent+feedback%0A%0A-+%2A%2AAgent%3A%2A%2A+%60agent-telemetry-toolkit%60%0A-+%2A%2AVersion%3A%2A%2A+%601.0.1%60%0A-+%2A%2ARating%3A%2A%2A+%60positive%60%0A-+%2A%2ARuntime%3A%2A%2A+%0A%0A%23%23+Comment%0A&issue%5Blabels%5D=agent-feedback%2Crating%3A%3Apositive%2Cagent%3A%3Aagent-telemetry-toolkit)
* [Report a problem](https://gitlab.dx1.lseg.com/app/app-52953/ai-hub/-/issues/new?issue%5Btitle%5D=Agent+feedback%3A+negative+-+agent-telemetry-toolkit+v1.0.1&issue%5Bdescription%5D=%23%23+Agent+feedback%0A%0A-+%2A%2AAgent%3A%2A%2A+%60agent-telemetry-toolkit%60%0A-+%2A%2AVersion%3A%2A%2A+%601.0.1%60%0A-+%2A%2ARating%3A%2A%2A+%60negative%60%0A-+%2A%2ARuntime%3A%2A%2A+%0A%0A%23%23+Comment%0A&issue%5Blabels%5D=agent-feedback%2Crating%3A%3Anegative%2Cagent%3A%3Aagent-telemetry-toolkit)
* [Add a comment](https://gitlab.dx1.lseg.com/app/app-52953/ai-hub/-/issues/new?issue%5Btitle%5D=Agent+feedback%3A+comment+-+agent-telemetry-toolkit+v1.0.1&issue%5Bdescription%5D=%23%23+Agent+feedback%0A%0A-+%2A%2AAgent%3A%2A%2A+%60agent-telemetry-toolkit%60%0A-+%2A%2AVersion%3A%2A%2A+%601.0.1%60%0A-+%2A%2ARating%3A%2A%2A+%60comment%60%0A-+%2A%2ARuntime%3A%2A%2A+%0A%0A%23%23+Comment%0A&issue%5Blabels%5D=agent-feedback%2Crating%3A%3Acomment%2Cagent%3A%3Aagent-telemetry-toolkit)

## Use

Consuming agents and Skills follow `SKILL.md` for the install preflight and command-lifecycle instructions.
