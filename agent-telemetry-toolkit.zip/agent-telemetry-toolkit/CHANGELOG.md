# Changelog

## 1.0.3

- Removed contradictory multi-command setup and failure guidance from the
    packaged skill.
- Updated the blank-PAT warning to use enterprise secret management guidance.

## 1.0.2

- Added a single `record` command that records one invocation and flushes it
    synchronously, avoiding separate telemetry approvals.
- Removed obsolete failure-detail guidance that passed the unsupported
    `ErrorClass` parameter.

## 1.0.1

- Fixed installer path resolution when `SourcePath` is omitted.
- Removed the hardcoded Azure DevOps PAT from the installer.

## 1.0.0

- Restored the shared telemetry client and installer as a standalone package.
