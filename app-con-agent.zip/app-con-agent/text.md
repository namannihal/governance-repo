In LSEG, we have something called as App Con
- its basically network connectivity from one to another


APIs - 

Select a definition

All

Application Connectivity
unknown 
OAS 3.1
/sso/appconn/v3/api-docs/All
Servers

/appconn - Application Connectivity. Requires SSO session

Authorize
Application Management


GET
/applications/{id}



PUT
/applications/{id}



PATCH
/applications/{id}



GET
/tenants/{tenantId}/applications
Get applications, paged, optionally filtered



POST
/tenants/{tenantId}/applications
Create an application



GET
/applications/{appId}/hosting-environments
Get hostingEnvironments of given application, paged, optionally filtered



POST
/applications/{appId}/hosting-environments
Create a hostingEnvironment



GET
/applications


Approval Management


PUT
/approvals/{approvalId}
Edit status of an approval


Approval Rule Management


GET
/approval-rules
Get page of approval rules



POST
/approval-rules
Create approval rule



POST
/approval-rules/test-provided
Test provided approval rule



POST
/approval-rules/test-all
Test approval rules



POST
/approval-rules/import



GET
/approval-rules/{id}
Get approval rule by id



DELETE
/approval-rules/{id}
Delete approval rule



PATCH
/approval-rules/{id}
Update approval rule



GET
/approval-rules/import/{importJobId}



GET
/approval-rules/import/{importJobId}/download



GET
/approval-rules/export


Audit logs API
API for reading audit logs



POST
/audit-logs/export



GET
/audit-logs



GET
/audit-logs/{eventId}



GET
/audit-logs/{eventId}/resources



GET
/audit-logs/export/{exportId}



GET
/audit-logs/export/{exportId}/download


Base Policy Management


GET
/base-policies/{id}



PUT
/base-policies/{id}



DELETE
/base-policies/{id}



GET
/base-policies/{id}/rules/{ruleId}



PUT
/base-policies/{id}/rules/{ruleId}



DELETE
/base-policies/{id}/rules/{ruleId}



POST
/hosting-environments/{heId}/connectivity-summary/export



GET
/base-policies



POST
/base-policies



GET
/base-policies/{id}/rules



POST
/base-policies/{id}/rules



POST
/base-policies/{id}/rules/{ruleId}/change-request



GET
/hosting-environments/{heId}/connectivity-summary



GET
/hosting-environments/{heId}/connectivity-summary/export/{exportId}



GET
/hosting-environments/{heId}/connectivity-summary/export/{exportId}/download



GET
/hosting-environments/{heId}/base-policies



GET
/base-policies/{id}/hosting-environments



DELETE
/base-policies/rules/{ruleId}/pending-change


Change Request Implementation Queue


PUT
/change-requests/queue/{changeRequestId}
Updates the change request implementation status



PUT
/change-requests/queue/schedule



POST
/change-requests/operational-metrics-report
Start generating operational metrics report job



GET
/change-requests/operational-metrics-report/{jobId}
Get operational metrics report job by id



GET
/change-requests/operational-metrics-report/{jobId}/download
Download operational metrics report by id


Change Request Management


PUT
/change-requests/{id}/service-now-tickets



PUT
/change-requests/{id}/firewall-requests/{firewallRequestId}



PUT
/change-requests/queue/{changeRequestId}
Updates the change request implementation status



PUT
/change-requests/queue/schedule



PUT
/change-requests/assignments



GET
/change-requests
Get change requests



GET
/change-requests/{id}



DELETE
/change-requests/{id}
Delete a change request



GET
/change-requests/{id}/firewall-request/status



GET
/change-requests/assignments/cyber-security-approvers



DELETE
/change-requests/{id}/service-now-tickets/{ticketId}



DELETE
/change-requests/{id}/assignments


Change Request Queue


POST
/queue/export



GET
/queue



GET
/queue/{id}



GET
/queue/export/{exportId}



GET
/queue/export/{exportId}/download


Comments


GET
/comments



POST
/comments


Connection Management


GET
/connections/{connectionId}



PUT
/connections/{connectionId}
Update connection



POST
/connections/{connectionId}
[DELETE WITH REQUEST BODY] Delete connection



PATCH
/connections/{connectionId}
Patch connection



PUT
/connections/{connectionId}/verification-status/{verificationStatus}



GET
/connections
Get connections, paged, optionally filtered



POST
/connections
Create connection



POST
/connections/{connectionId}/change-request



POST
/connections/policy-overlap
Check if a connection would be covered by base policies



POST
/connections/connectivity-report
Create Connections connectivity report



POST
/connections/cloud-sre-report
Create cloud SRE report for connections



POST
/connections/backfill-implementation



POST
/connections/auto-approval-evaluation



GET
/tenants/{tenantId}/connections



GET
/providers/{providerId}/connections



GET
/hosting-environments/{hostingEnvironmentId}/connections
Get connections for given hosting environment, paged, optionally filtered



GET
/consumers/{consumerId}/connections



GET
/connections/{id}/connectivity-requirements
Get connectivity requirements for specified connection



GET
/connections/{connectionId}/firewall-rules



GET
/connections/{connectionId}/connectivity-report
Generate reports from connection connectivity requirements



GET
/connections/suricata-rules



GET
/connections/suricata-export



DELETE
/connections/{connectionId}/pending-change


Connectivity Requirements


GET
/hosting-environments/{id}/connectivity-requirements
Get connectivity requirements for specified hosting environment



GET
/connections/{id}/connectivity-requirements
Get connectivity requirements for specified connection


Consumer management


GET
/consumers/{id}
Get consumer



PUT
/consumers/{id}
Update consumer



DELETE
/consumers/{id}
Delete consumer



PATCH
/consumers/{id}
Patch consumer



POST
/hosting-environments/{hostingEnvironmentId}/consumers
Create consumer



GET
/consumers
Get consumers



POST
/consumers
Create orphaned consumer



GET
/tenant/{tenantId}/consumers



GET
/consumers/{consumerId}/connections


Dynamic configuration


GET
/dynamic-configuration/{dynamicConfigurationKey}



PUT
/dynamic-configuration/{dynamicConfigurationKey}
Update a dynamic configuration entry



PUT
/dynamic-configuration/cme-eligibility-filter
Update a CME_FIREWALL_REQUEST_ELIGIBILITY_FILTER configuration entry value



GET
/dynamic-configuration


file-storage-controller


GET
/storage
Get page of file descriptors



GET
/storage/{id}
Download file by id



GET
/storage/{id}/descriptor
Get file descriptor by id


GitLab Integration
API for testing GitLab repository file operations



POST
/gitlab/pipeline/trigger
Trigger a GitLab pipeline with payload


Global audit logs API
API for reading audit logs in global scope



POST
/global-audit-logs/export



GET
/global-audit-logs



GET
/global-audit-logs/{eventId}



GET
/global-audit-logs/{eventId}/resources



GET
/global-audit-logs/export/{exportId}



GET
/global-audit-logs/export/{exportId}/download


Hosting environments management


GET
/hosting-environments/{hostingEnvironmentId}



PUT
/hosting-environments/{hostingEnvironmentId}
Updates the chosen hostingEnvironment



DELETE
/hosting-environments/{hostingEnvironmentId}
Archives the chosen hostingEnvironment



PATCH
/hosting-environments/{hostingEnvironmentId}
Updates the chosen hostingEnvironment



POST
/hosting-environments/{heId}/connectivity-summary/export



GET
/applications/{appId}/hosting-environments
Get hostingEnvironments of given application, paged, optionally filtered



POST
/applications/{appId}/hosting-environments
Create a hostingEnvironment



GET
/tenants/{tenantId}/hosting-environments
Get hostingEnvironments of given tenant, paged, optionally filtered



GET
/hosting-environments
Get hostingEnvironments, paged, optionally filtered



GET
/hosting-environments/{id}/connectivity-requirements
Get connectivity requirements for specified hosting environment



GET
/hosting-environments/{hostingEnvironmentId}/connectivity-report
Generate reports from hosting environment connectivity requirements



GET
/hosting-environments/{hostingEnvironmentId}/connections
Get connections for given hosting environment, paged, optionally filtered



GET
/hosting-environments/{hostingEnvironmentId}/cloud-sre-report
Create cloud SRE report for hosting environment



GET
/hosting-environments/{heId}/connectivity-summary



GET
/hosting-environments/{heId}/connectivity-summary/export/{exportId}



GET
/hosting-environments/{heId}/connectivity-summary/export/{exportId}/download



GET
/hosting-environments/{heId}/base-policies


Internal API
API for different internal purposes



GET
/internal/query-resource-documentation/{type}


Jobs
API for monitoring and managing background jobs



PUT
/jobs/{jobId}/status



POST
/jobs/{jobId}/restart



GET
/jobs



GET
/jobs/{jobId}



GET
/jobs/{jobId}/steps



GET
/jobs/{jobId}/steps/{stepId}/logs


Lean IX Application Management


GET
/lean-ix-applications


Notifications


GET
/notifications



PUT
/notifications



PUT
/notifications/{id}



GET
/notifications/user-notification/config



PUT
/notifications/user-notification/config



POST
/notifications/cyber-notification
Trigger execution of notification configuration now



GET
/notifications/count


Provider Management


GET
/providers/{id}



PUT
/providers/{id}
Update provider



DELETE
/providers/{id}



PATCH
/providers/{id}
Patch provider



PUT
/providers/{id}/environment-based-auto-approval-policy



GET
/providers
Get providers



POST
/providers
Create orphaned provider



POST
/providers/validate



POST
/providers/similar



POST
/hosting-environments/{hostingEnvironmentId}/providers
Create provider



GET
/tenant/{tenantId}/providers
Get providers for tenant



GET
/providers/{providerId}/connections



GET
/providers/protocol-port-service
Get protocol, port and service information


Radar Integration


GET
/radar-integration/networks-for-hosting-environment



GET
/radar-integration/fqdns-for-provider



GET
/radar-integration/applications


Read Only Mode
API for AppConn management e.g. read-only-mode



GET
/read-only-mode
Get current state of read-only-mode



PUT
/read-only-mode
Enable or disable the read-only mode



GET
/read-only-mode/history


Resource history


GET
/object-history/{guiId}



GET
/object-history/resource


Riana Integration


GET
/riana-integration/network-by-ip


Search


GET
/search
Global search returning list



GET
/search/tree
Global search returning tree



GET
/search/tree/{parentId}



GET
/search/tree/root


Service integrations


PUT
/service-integrations/{integrationName}



POST
/service-integrations/statuses/refresh



GET
/service-integrations/statuses


Service Now Integration


GET
/service-now-integration/request-items



GET
/service-now-integration/gov-items


Tenancy


GET
/tenancy/user-tenants



DELETE
/tenancy/user-group-cache
Invalidate current user group cache



DELETE
/tenancy/user-group-cache/{userId}
Invalidate user group cache


Tenant management


GET
/tenants/{id}



PUT
/tenants/{id}
Update a tenant



DELETE
/tenants/{id}
Archive a tenant



PATCH
/tenants/{id}
Update a tenant



GET
/tenants
Get tenants, paged, optionally filtered



POST
/tenants
Create a tenant



Schemas
TenantPayloadExpand allobject
TenantStatusExpand allstring
ApiResponseErrorExpand allobject
ApiResponseErrorElementExpand allobject
ApiResponseMetadataExpand allobject
ApiResponsePagingExpand allobject
ApiResponseTenantExpand allobject
TenantExpand allobject
ServiceIntegrationNameExpand allstring
UpdateServiceIntegrationPausedRequestExpand allobject
ApiResponseServiceIntegrationStatusEntryExpand allobject
HealthCheckStatusExpand allstring
ServiceIntegrationStatusExpand allstring
ServiceIntegrationStatusEntryExpand allobject
ReadOnlyModeChangeRequestExpand allobject
ReadOnlyModeStateExpand allstring
ApiResponseUnitExpand allobject
BandwidthExpand allobject
DNATConfigurationExpand allobject
DNATProtocolExpand allstring
PeakLoadTypeExpand allstring
PortRangeExpand allobject
ProtocolExpand allstring
ProtocolPortAssociationExpand allobject
ProviderProfileExpand allstring
ProviderRecommendationTypeExpand allstring
ProviderRequestExpand allobject
TagExpand allobject
TrafficDirectionExpand allstring
TypeOfTrafficExpand allstring
UserReportedLeanIxAppTypeExpand allstring
UtilizationProfileExpand allstring
ApiResponseProviderExpand allobject
ApplicationExpand allobject
AutoApprovalEnvironmentPolicyExpand allstring
AutoApprovalPolicyExpand allobject
ConnectionStatusExpand allstring
ConsumerExpand allobject
ConsumerEmbeddedDataExpand allobject
ConsumerStateExpand allobject
DeploymentStateExpand allstring
EmbeddedDataExpand allobject
EnvironmentExpand allstring
EnvironmentSubTypeExpand allstring
HostingEnvironmentExpand allobject
HostingEnvironmentConnectionsStatusExpand allobject
HostingEnvironmentEmbeddedDataExpand allobject
HostingEnvironmentStatusExpand allstring
HostingLocationExpand allstring
HostingLocationClassExpand allstring
ProviderExpand allobject
ProviderAdditionalInfoExpand allobject
ProviderEmbeddedDataExpand allobject
ProviderStateExpand allobject
RoutingRequestStatusExpand allstring
SegmentExpand allstring
SimpleConnectionExpand allobject
SimpleConsumerExpand allobject
SimpleHEConnectionExpand allobject
SimpleProviderExpand allobject
SubnetExpand allobject
SubnetNameExpand allstring
UserReportedApplicationExpand allobject
WorkstreamExpand allstring
AutoApprovalPolicyRequestExpand allobject
ApiResponseNotificationExpand allobject
NotificationExpand allobject
RecipientTypeExpand allstring
UserNotificationConfigRequestExpand allobject
ApiResponseUserNotificationConfigExpand allobject
UserNotificationConfigExpand allobject
JobStatusExpand allstring
JobStatusUpdatePayloadExpand allobject
HostingEnvironmentRequestExpand allobject
ApiResponseHostingEnvironmentExpand allobject
DynamicConfigurationKeyExpand allstring
UpdateDynamicConfigurationRequestExpand allobject
ApiResponseDynamicConfigurationExpand allobject
DynamicConfigurationExpand allobject
DynamicConfigurationValueTypeExpand allstring
CmeRequestEligibilityFilterRequestExpand allobject
ConsumerRequestExpand allobject
ApiResponseConsumerExpand allobject
ConnectionProfileExpand allstring
ConnectionUpdateRequestExpand allobject
ApiResponseConnectionExpand allobject
ConnectionExpand allobject
ConnectionEmbeddedDataExpand allobject
ConnectionOwnerSideExpand allstring
DryRunApprovalStatusExpand allstring
VerificationStatusExpand allstring
UpdateVerificationStatusPayloadExpand allobject
ChangeRequestAddManualTicketsPayloadExpand allobject
RequestItemStateExpand allstring
TicketDataExpand allobject
ApiResponseListSnowRequestExpand allobject
AttachmentExpand allobject
SnowRequestExpand allobject
SnowRequestTypeExpand allstring
TicketCreationStatusExpand allstring
ApiResponseFirewallRequestDetailsExpand allobject
FirewallRequestDetailsExpand allobject
FirewallRequestStatusExpand allstring
FirewallRequestTypeExpand allstring
ChangeRequestImplementationPayloadExpand allobject
ImplementationStateExpand allstring
ApiResponseChangeRequestExpand allobject
ApprovalGroupTypeExpand allstring
ChangeDetailsExpand allobject
ChangeRequestExpand allobject
ChangeRequestEmbeddedDataExpand allobject
ChangeRequestJobSummaryExpand allobject
ChangeRequestTypeExpand allstring
ChangeStatusExpand allstring
ConsumerDetailsExpand allobject
FirewallRequestDataExpand allobject
FirewallRequestSummaryExpand allobject
FqdnWhitelistingAzureLmpFormStatusExpand allstring
GeneralDetailsExpand allobject
GrantedApprovalExpand allobject
JobOutcomeExpand allstring
ObjectTypeExpand allstring
OperationTypeExpand allstring
PairStringStringExpand allobject
ProviderDetailsExpand allobject
RequestFormBaseDataExpand allobject
ServiceNowSummaryExpand allobject
ChangeRequestScheduleImplementationPayloadExpand allobject
ChangeRequestAssignReviewerPayloadExpand allobject
ApiResponseListChangeRequestExpand allobject
BasePolicyPayloadExpand allobject
BasePolicyStatusExpand allstring
ApiResponseBasePolicyExpand allobject
BasePolicyExpand allobject
EndpointTemplateExpand allstring
PolicyRulePayloadExpand allobject
PolicyRuleProtocolExpand allstring
PolicyRuleProtocolPortExpand allobject
RuleEndpointExpand allobject
ApiResponsePolicyRuleExpand allobject
ChangeLifecycleStatusExpand allstring
PolicyRuleExpand allobject
PolicyRuleStateExpand allobject
PolicyRuleStatusExpand allstring
ApprovalDecisionExpand allstring
ChangeRequestApprovalPayloadExpand allobject
RejectionReasonExpand allstring
UpdateApplicationRequestExpand allobject
ApiResponseApplicationExpand allobject
CreateApplicationRequestExpand allobject
EmbedValuesExpand allstring
ApiResponseServiceIntegrationHealthcheckRefreshResultExpand allobject
ServiceIntegrationHealthcheckRefreshResultExpand allobject
ServiceIntegrationHealthcheckRefreshStatusExpand allstring
ApiResponseChangeRequestQueueExportJobExpand allobject
ChangeRequestQueueExportJobExpand allobject
ChangeRequestQueueExportStatusExpand allstring
ProviderValidationRequestExpand allobject
ApiResponseProviderValidationResponseExpand allobject
ProviderValidationMessageExpand allobject
ProviderValidationResponseExpand allobject
ProviderValidationSeverityExpand allstring
SimilarProviderRequestExpand allobject
ApiResponseSimilarProviderResponseExpand allobject
SimilarProviderResponseExpand allobject
TriggerCyberNotificationRequestExpand allobject
ApiResponseCyberNotificationConfigExpand allobject
CyberNotificationConfigExpand allobject
ApiResponseConnectivitySummaryExportJobExpand allobject
ConnectivitySummaryExportJobExpand allobject
ConnectivitySummaryExportStatusExpand allstring
AuditLogEventResultExpand allstring
ActionSourceExpand allstring
AuditLogResourceTypeExpand allstring
AuditLogResourceCategoryExpand allstring
ApiResponseAuditLogEventsExportJobExpand allobject
AuditLogEventsExportFormatExpand allstring
AuditLogEventsExportJobExpand allobject
AuditLogEventsExportStatusExpand allstring
ApiResponseGitLabPipelineResponseExpand allobject
GitLabPipelineResponseExpand allobject
ConnectionRequestExpand allobject
ConnectionRemoveOrForgetRequestExpand allobject
RemovalTypeExpand allstring
ApiResponseConnectionRemovalResponseExpand allobject
ConnectionRemovalResponseExpand allobject
SubmitApprovalForConnectionCreationOrUpdateRequestExpand allobject
ApiResponseConnectionRequestApprovalResponseExpand allobject
ConnectionRequestApprovalResponseExpand allobject
CheckConnectionCoverageRequestExpand allobject
ApiResponseConnectionCoverageCheckResultExpand allobject
ConnectionCoverageCheckResultExpand allobject
CoverageStatusExpand allstring
NotCoveredConnectionEntryExpand allobject
ConnectionsConnectivityReportRequestExpand allobject
ConnectionsCloudSREReportRequestExpand allobject
RelationSideExpand allstring
ConnectionsBulkImplementRequestExpand allobject
ApiResponseListConnectionExpand allobject
AutoApprovalEvaluationRequestExpand allobject
ApiResponseJobExpand allobject
JobExpand allobject
JobEmbeddedDataExpand allobject
JobNameExpand allstring
JobStepExpand allobject
JobStepEmbeddedDataExpand allobject
JobStepParamExpand allobject
JobStepResultExpand allobject
JobTypeExpand allstring
CommentDtoExpand allobject
ApiResponseCommentExpand allobject
CommentExpand allobject
ApiResponseReportGenerationJobExpand allobject
ReportGenerationJobExpand allobject
ReportJobStatusExpand allstring
ReportTypeExpand allstring
SubmitApprovalForPolicyRuleCreationRequestExpand allobject
ApiResponsePolicyRuleRequestApprovalResponseExpand allobject
PolicyRuleRequestApprovalResponseExpand allobject
CreateApprovalRuleRequestExpand allobject
ApiResponseApprovalRuleExpand allobject
ApprovalRuleExpand allobject
ConnectionConsumerDetailsForApprovalExpand allobject
ConnectionDetailsForApprovalExpand allobject
ConnectionPortRangeForApprovalExpand allobject
ConnectionProtocolPortAssociationForApprovalExpand allobject
ConnectionProviderDetailsForApprovalExpand allobject
TestProvidedApprovalRuleRequestExpand allobject
ApiResponseTestProvidedApprovalRuleExecutionResultExpand allobject
ApprovalRuleExecutionResultStatusExpand allstring
TestProvidedApprovalRuleExecutionResultExpand allobject
ApiResponseApprovalRulesExecutionResultExpand allobject
ApprovalRuleExecutionResultExpand allobject
ApprovalRulesExecutionResultExpand allobject
ApprovalRulesExecutionResultStatusExpand allstring
ApiResponseApprovalRulesImportJobExpand allobject
ApprovalRulesImportJobExpand allobject
ApprovalRulesImportJobStatusExpand allstring
JsonNodeobject
JsonNodeTypeExpand allstring
UpdateApprovalRuleRequestExpand allobject
ApiResponseListTenantExpand allobject
HostingEnvironmentEmbedValuesExpand allstring
ApiResponseListHostingEnvironmentExpand allobject
ConnectionEmbedValuesExpand allstring
ApiResponseListApplicationExpand allobject
ProviderEmbedValuesExpand allstring
ApiResponseListProviderExpand allobject
ConsumerEmbedValuesExpand allstring
ApiResponseListConsumerExpand allobject
ApiResponsePageStoredFileDescriptorExpand allobject
PageStoredFileDescriptorExpand allobject
PageableObjectExpand allobject
SortObjectExpand allobject
StoredFileDescriptorExpand allobject
ApiResponseStoredFileDescriptorExpand allobject
ApiResponseListRequestItemWithRequestResponseExpand allobject
RequestItemWithRequestResponseExpand allobject
ApiResponseListGovItemResponseExpand allobject
GovItemResponseExpand allobject
ApiResponseListServiceIntegrationStatusEntryExpand allobject
ApiResponseListSearchResultExpand allobject
SearchObjectTypeExpand allstring
SearchResultExpand allobject
ApiResponseTreeSearchResultExpand allobject
SearchResultWithHierarchyExpand allobject
TreeSearchResultExpand allobject
ApiResponseListSearchResultWithHierarchyExpand allobject
ApiResponseRianaNetworkExpand allobject
RianaNetworkExpand allobject
RianaNetworkMetadataExpand allobject
RianaNetworkStatusExpand allobject
RianaNotificationSettingsExpand allobject
ApiResponseReadOnlyModeChangeExpand allobject
ReadOnlyModeChangeExpand allobject
ApiResponseListReadOnlyModeChangeExpand allobject
ApiResponseListRadarNetworkForHostingEnvironmentExpand allobject
RadarNetworkForHostingEnvironmentExpand allobject
ApiResponseListRadarFqdnForProviderExpand allobject
RadarFqdnForProviderExpand allobject
ApiResponseListLeanIxApplicationExpand allobject
LeanIxApplicationExpand allobject
ChangeRequestEmbedValuesExpand allstring
ApiResponseListChangeRequestSummaryExpand allobject
ChangeRequestSummaryExpand allobject
ExternalResourceExpand allobject
ExternalResourceTypeExpand allstring
PlannedResourceExpand allobject
PlannedResourceStatusExpand allstring
PlannedResourceTypeExpand allstring
QueueStageExpand allstring
ApiResponseProviderProtocolPortServiceExpand allobject
ProviderProtocolPortServiceExpand allobject
HistoryResourceLookupDepthExpand allstring
ApiResponseListAuditLogEventExpand allobject
AuditLogEventExpand allobject
AuditLogEventEmbeddedDataExpand allobject
AuditLogResourceExpand allobject
TraceDetailsExpand allobject
ApiResponseListNotificationExpand allobject
ApiResponseLongExpand allobject
JobEmbedValuesExpand allstring
ApiResponseListJobExpand allobject
JobStepEmbedValuesExpand allstring
ApiResponseListJobStepExpand allobject
ApiResponseListJobStepLogExpand allobject
JobStepLogExpand allobject
JobStepLogLevelExpand allstring
QueryResourceTypeExpand allstring
ApiResponseQueryResourceDocumentationExpand allobject
QueryResourceDocumentationExpand allobject
ApiResponseListConnectivityRequirementDiffExpand allobject
BandwidthDiffExpand allobject
ConnectionDirectionExpand allstring
ConnectivityRequirementDiffExpand allobject
ConsumerDiffExpand allobject
DNATTargetDefinitionExpand all(any & object)
DiffCollectionProtocolPortAssociationExpand allobject
DiffCollectionStringExpand allobject
DiffPairBooleanExpand allobject
DiffPairDNATConfigurationExpand allobject
DiffPairFloatExpand allobject
DiffPairPeakLoadTypeExpand allobject
DiffPairProviderProfileExpand allobject
DiffPairStringExpand allobject
DiffPairTargetDefinitionExpand allobject
DiffPairTrafficDirectionExpand allobject
DiffPairTypeOfTrafficExpand allobject
DiffPairUtilizationProfileExpand allobject
EmptyTargetDefinitionExpand all(any & object)
FqdnTagsTargetDefinitionExpand all(any & object)
ProviderDiffExpand allobject
ServiceTagsTargetDefinitionExpand all(any & object)
StandardTargetDefinitionExpand all(any & object)
TargetDefinitionany
ApiResponseListHostingEnvironmentConnectivitySummaryRowExpand allobject
ConnectivitySummaryDirectionExpand allstring
ConnectivitySummaryEndpointExpand allobject
ConnectivitySummaryStatusExpand allstring
ConnectivitySummaryTypeExpand allstring
HostingEnvironmentConnectivitySummaryRowExpand allobject
PortRangeWithProtocolExpand allobject
ApiResponseListMatchedBasePolicyExpand allobject
MatchedBasePolicyExpand allobject
AuditLogEventEmbedValuesExpand allstring
ApiResponseAuditLogEventExpand allobject
ApiResponseListAuditLogResourceExpand allobject
ApiResponseListDynamicConfigurationExpand allobject
ApiResponseFirewallChangeInfoExpand allobject
FirewallChangeEntryExpand allobject
FirewallChangeInfoExpand allobject
ApiResponseFirewallSuricataRulesExpand allobject
FirewallSuricataRuleExpand allobject
FirewallSuricataRulesExpand allobject
ApiResponseListCommentExpand allobject
ApiResponseListFirewallRequestDetailsExpand allobject
ApiResponseListCyberSecurityApproverExpand allobject
CyberSecurityApproverExpand allobject
ApiResponseListBasePolicyExpand allobject
ApiResponseListPolicyRuleExpand allobject
ApiResponseListMatchedHostingEnvironmentExpand allobject
MatchedHostingEnvironmentExpand allobject
ApiResponseListApprovalRuleExpand allobject
AnyTypeany
PatchTenantPayloadExpand allobject
PatchEndpointRequestExpand allobject
PatchHostingEnvironmentRequestExpand allobject
PatchSubnetExpand allobject
PatchTagExpand allobject