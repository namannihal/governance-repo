# app-con-agent

Turns the connectivity requirements table in an LMP SAD into reviewed AppCon
connections.

An APM package targeting GitHub Copilot. Python 3.10+, standard library only.

---

## What AppCon is

AppCon (Application Connectivity) is LSEG's self-service front end for firewall
and network access. You describe a connection between two applications and it
routes it through cyber review and network implementation.

Its model, from the outside in:

```
Tenant
└── Application                  LeanIX id, e.g. APP-53435
    └── Hosting Environment      one per environment; has a deployment state
        ├── Consumer             the source side
        └── Provider             the destination side: FQDNs, protocol, port
            └── Connection       one consumer to one provider
                └── Change Request   what cyber actually reviews
```

Two things in that diagram cause most of the confusion:

**A hosting environment has a deployment state** - *planning* or *deployed*.
Connectivity can be requested against an environment that is still in planning,
which is the whole point: you raise the firewall requests while the
infrastructure is being built, not after. An application with no hosting
environment for a given environment is not an error, it is work that has not
started.

**A connection is one consumer to one provider.** The SAD writes one row for
what is often several connections, because a row can name several environments
and several endpoints at once.

Once submitted, a connection moves through:

```
New ──▶ Pending Approval ──▶ Approved / Pending Implementation ──▶ Scheduled ──▶ Implemented
             │
             └──▶ On Hold
```

You own the first transition. Cyber owns the second. Network engineering owns
the rest. *Implemented* is when the firewall change is actually in - which is
the state the onboarding Jira ticket is waiting for, not *Approved*.

---

## Why this is a package and not a prompt

Here is a real row from a SAD connectivity table:

| Source | Destination | Endpoints | Protocol | Environment |
|---|---|---|---|---|
| OTC CBIC (APP-52775) | Product Studio II (APP-53435) | `dev.temp.psii.lseg.com`<br>`qa.temp.psii.lseg.com`<br>`uat.temp.psii.lseg.com`<br>`ppe.temp.psii.lseg.com` | 443 / HTTPS TLS 1.2 | Dev, CI, Alpha & Pre-Prod |

Four environments. Four hostnames. They do not correspond: there is no `ci.` or
`alpha.` host, and `qa.` and `uat.` name environments this row never declares.
The cross product is sixteen connections. The intended answer is probably four.
**The document does not say which four.**

Ask a language model to expand that row and it will produce a number and sound
confident about it. The number will be wrong roughly as often as it is right,
and the output is sixteen firewall change requests on a cyber team's queue, each
one looking as reasonable as the last.

So the expansion here is a deterministic script, and it is allowed to fail:

```
Row 2: Cannot pair 4 environment(s) with 4 endpoint(s).
  No endpoint looks like: CI, ALPHA
  No environment declared for: qa.temp.psii.lseg.com, uat.temp.psii.lseg.com
  Guessing would produce 16 connections from a row that likely wants 4.
  Re-run with --pairing "2=DEV:dev.temp.psii.lseg.com,CI:..."
```

That refusal is the package. Everything else is plumbing around it.

The same rule governs the API. The Swagger inventory this was built from lists
endpoints and schema names but no request bodies, so rather than guess field
names, the client fetches the live OpenAPI document at runtime and refuses to
send a field the spec does not describe. A guessed body here creates a real
object that does not match the SAD.

---

## Install

```bash
apm install
apm compile -t copilot
```

Then set:

```bash
export APPCON_BASE_URL='https://<host>/appconn'
export APPCON_COOKIE='<SSO session cookie header>'
export APPCON_TENANT_ID='<tenant>'
export APPCON_GOV_ID='GOVI123456'      # optional, can be passed per run
```

The API requires an SSO session - the spec says so and no service-principal path
is documented. Sign in to AppCon in a browser and copy the session cookie from
the network tab. It expires; when a long run stops with a 401, that is why, and
`ledger.json` tells you where to resume.

Never put the cookie in a file under `out/`.

---

## Use

```
/appcon <path to SAD.docx>
```

runs the pipeline end to end, stopping for review before anything is created.
Or run the steps yourself, which is worth doing the first time against a new
SAD:

| Command | Does | Writes to AppCon |
|---|---|---|
| `/appcon-doctor` | check this machine can run the package at all | no (no network) |
| `/appcon-init` | probe auth, pin the API spec | no |
| `/read-sad` | docx → `sad-rows.json`, verbatim | no |
| `/create-requirements` | rows → typed requirements; refuses what it cannot pair | no |
| `/create-plan` | resolve against AppCon → `plan.json` | no |
| `/apply-plan` | create consumers, providers, connections | **yes** |
| `/request-approval` | submit change requests | **yes** |
| `/appcon-status` | poll the status machine | no |

The line between `/create-plan` and `/apply-plan` is the safety model.
Everything above it runs with a client that refuses write endpoints outright.
Both commands below it require `--confirm`, and the agents are instructed never
to pass it on your behalf.

### Output

```
out/appcon/
  spec.json          the OpenAPI document this run validated against, as fetched
  sad-rows.json      what the table says, verbatim
  requirements.json  typed requirements; every field marked VERBATIM/PARSED/INFERRED
  plan.json          what would be created, what exists, what policy covers
  ledger.json        what was created, written after every single call
```

`plan.json` is the artefact a human approves. `ledger.json` is the record of
truth about what exists. Keep both with the SAD - and `spec.json` with them,
because `apply_plan.py` refuses to run when the spec hash has moved, and at that
point the hash tells you it changed while the pinned document tells you how.

---

## Design decisions worth knowing

**Requirements are typed by derivation.** Every field records whether it was
read verbatim, parsed from another form, or inferred. Anything `INFERRED` flags
the requirement for review. The distinction between "the SAD says this" and "we
worked this out" is the only thing that lets an approver review rather than
rubber-stamp - see
[derivation-typing](.apm/instructions/derivation-typing.instructions.md).

**Applying is idempotent because it is interrupted often.** Every created object
carries `appcon-agent:<requirement_key>` in its description, and the ledger is
rewritten atomically after each individual API call rather than at the end of
the run. A run killed halfway leaves a ledger that accurately describes what
exists; re-running resumes. The requirement key is a truncated SHA-256 over
(consumer, provider, fqdn, protocol, port, environment, cutover state) and
**must never change** - `tests/test_all.py` pins it for exactly that reason.

**Plans are executed, not re-derived.** `apply_plan.py` reads only `plan.json`
and re-checks that the API spec hash still matches. If the SAD changed after the
plan was approved, it does not notice, and it must not: re-plan instead.

**Not assessed is never reported as passed.** Exit 2 means *cannot assess*
throughout - a table that could not be found, a row that could not be paired, a
status that could not be read. It is distinct from exit 3, *refused*, and both
are distinct from success. A connection whose status is unreadable is counted as
UNKNOWN and never folded into New.

**Some POSTs are reads.** `policy-overlap`, `auto-approval-evaluation`,
`providers/similar` and `providers/validate` take bodies but change nothing, so
they are on an explicit allowlist in the dry-run client rather than being
permitted by a heuristic about the verb.

---

## Tests

```bash
python tests/test_all.py
```

59 tests, stdlib `unittest`. They cover the refusal paths as carefully as the
success paths, because the refusals are the feature: a regression that turns
"cannot pair these" into a silent cross product does not look like a bug in a
passing suite, it looks like sixteen firewall requests.

Neither fixture is committed as a binary. The `.docx` is built in-test with
`zipfile`, and AppCon itself is a local server, so what the pipeline is tested
against is visible in the diff.

### Running the pipeline locally

Everything past `/create-requirements` needs a live AppCon and an SSO session,
which makes the read-only half of the pipeline hard to exercise without one.
`tests/mock_appcon_server.py` stands in:

```bash
python tests/mock_appcon_server.py --port 8765 &

export APPCON_BASE_URL='http://127.0.0.1:8765'
export APPCON_COOKIE='mock=1'
export APPCON_TENANT_ID='tenant-mock'

python tests/make_mock_sad.py --out out/appcon/MOCK-SAD.docx
python .apm/scripts/python/doctor.py
python .apm/scripts/python/extract_sad_table.py --docx out/appcon/MOCK-SAD.docx --out out/appcon/sad-rows.json
python .apm/scripts/python/expand_requirements.py --rows out/appcon/sad-rows.json --out out/appcon/requirements.json
```

That last command exits 2 and refuses two rows, which is the point of the mock
SAD - a document where every row parses tests nothing. `--revised` emits the
same SAD with the missing business justification filled in; the unpairable row
is answered with `--pairing`, because that one is not something a document
revision settles.

The mock's fixture is arranged so a single `plan_connections.py` run produces
every disposition it can produce - `EXISTS`, `COVERED_BY_POLICY`, `CREATE`,
`BLOCKED` and `NEEDS_REVIEW`. It serves the read-only surface only, and answers
write paths with a 403 that says so.

---

## Known gaps

**Auth is a session cookie.** There is no confirmed service-principal path, so
this cannot run unattended. Everything it creates is attributable to the
signed-in human, which is a reasonable property for something that raises
firewall requests, but it does mean the cookie expires mid-batch.

**Request body field names are fitted, not known.** `fit_body()` offers the spec
several plausible names per value and uses whichever it documents. This works,
but the first run against a new AppCon deployment should use `--limit 1` and be
checked in the UI before the rest of the batch.

**Cutover policy defaults to `current`.** When a SAD shows `(after cutover ...)`
twins, which set to create is a DNS scheduling decision. The default creates the
temporary hostnames only; `--cutover-policy` changes it.

**Nothing here transitions an existing connection.** No cancel, no retire, no
hold. Those endpoints exist and are deliberately not wired up.

---

## Relationship to spec-agent-new

`spec-agent-new` (lmp-council) produces the SAD. This package consumes its
connectivity table. They share exit-code conventions and the principle that
deterministic scripts enforce while agents judge, so the two compose as a
pipeline - though this package reads any SAD with a recognisable connectivity
table, not only ones the council wrote.
