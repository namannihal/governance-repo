#!/usr/bin/env python3
"""Tests for the app-con-agent engine. Stdlib unittest, no pytest, no fixtures on disk.

Run:  python tests/test_all.py

The refusal paths get as much attention here as the success paths, because the
refusals are the feature. A regression that turns "cannot pair these four
environments to these four hostnames" into a silent cross product does not look
like a bug in a passing test suite - it looks like sixteen firewall requests.
"""

from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import threading
import unittest
import zipfile
from http.server import ThreadingHTTPServer
from xml.sax.saxutils import escape

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, ".apm", "scripts", "python"))
sys.path.insert(0, HERE)

import expand_requirements as expand  # noqa: E402
import extract_sad_table as extract  # noqa: E402
import mock_appcon_server as mock_appcon  # noqa: E402
import plan_connections as planner  # noqa: E402
import validate_instance as validator  # noqa: E402
from _common import requirement_key, write_json_atomic  # noqa: E402
from appcon_client import AppConClient, AppConError  # noqa: E402

SCHEMAS = os.path.join(ROOT, "schemas")


def schema(name: str) -> dict:
    with open(os.path.join(SCHEMAS, name), encoding="utf-8") as handle:
        return json.load(handle)


class RequirementKeyTests(unittest.TestCase):
    """The identity of a requirement. Pinned, and changing it is almost never right."""

    def test_pinned_value(self):
        # If this fails, every object created by an earlier version of this package
        # has become invisible to the current one, and the next apply run will
        # duplicate the lot. Fix the code, not the expectation.
        self.assertEqual(
            requirement_key("APP-52775", "APP-53435", "dev.temp.psii.lseg.com",
                            "TCP", 443, "DEV", "CURRENT"),
            "245beaa74614f6a5",
        )

    def test_ignores_cosmetic_differences(self):
        base = requirement_key("APP-1", "APP-2", "a.example.com", "TCP", 443, "DEV", "CURRENT")
        noisy = requirement_key(" app-1 ", "app-2", "A.Example.Com.", "tcp", 443, "dev", "current")
        self.assertEqual(base, noisy)

    def test_distinguishes_cutover_state(self):
        current = requirement_key("APP-1", "APP-2", "a.example.com", "TCP", 443, "DEV", "CURRENT")
        post = requirement_key("APP-1", "APP-2", "a.example.com", "TCP", 443, "DEV", "POST_CUTOVER")
        self.assertNotEqual(current, post)


class CellParsingTests(unittest.TestCase):
    def test_party(self):
        parsed = expand.parse_party("Product Studio II (APP-53435)")
        self.assertEqual(parsed, {"lean_ix_id": "APP-53435", "name": "Product Studio II"})

    def test_party_with_trailing_dashes(self):
        # The real SAD has "Product Studio I APP--52208" with stray dashes.
        parsed = expand.parse_party("Product Studio I APP--52208")
        self.assertEqual(parsed["lean_ix_id"], "APP-52208")

    def test_party_without_id_is_refused(self):
        self.assertIsNone(expand.parse_party("Some Application"))

    def test_environments(self):
        found, problem = expand.parse_environments("Dev, CI, Alpha & Pre-Prod")
        self.assertIsNone(problem)
        self.assertEqual(found, ["DEV", "CI", "ALPHA", "PRE_PROD"])

    def test_environment_all_is_refused(self):
        found, problem = expand.parse_environments("All")
        self.assertEqual(found, [])
        self.assertIn("cannot enumerate", problem)

    def test_unknown_environment_is_reported(self):
        _, problem = expand.parse_environments("Dev, Banana")
        self.assertIn("Banana", problem)

    def test_endpoints_with_cutover(self):
        cell = (
            "https://dev.temp.psii.lseg.com (after cutover https://dev.psii.lseg.com)\n"
            "https://qa.temp.psii.lseg.com (after cutover https://qa.psii.lseg.com)"
        )
        endpoints = expand.parse_endpoints(cell)
        self.assertEqual(len(endpoints), 2)
        self.assertEqual(endpoints[0]["current"], "dev.temp.psii.lseg.com")
        self.assertEqual(endpoints[0]["post_cutover"], "dev.psii.lseg.com")

    def test_transport(self):
        transport, problem = expand.parse_transport("443 / HTTPS TLS 1.2")
        self.assertIsNone(problem)
        self.assertEqual(transport["protocol"], "TCP")
        self.assertEqual(transport["port"], 443)
        self.assertEqual(transport["encryption"], "TLS 1.2")
        self.assertEqual(transport["application_protocol"], "HTTPS")

    def test_transport_without_port_is_refused(self):
        transport, problem = expand.parse_transport("HTTPS")
        self.assertIsNone(transport)
        self.assertIn("No port", problem)

    def test_host_environment_prefix(self):
        self.assertEqual(expand.host_environment("dev.temp.psii.lseg.com"), "DEV")
        self.assertEqual(expand.host_environment("ppe.psii.lseg.com"), "PRE_PROD")
        self.assertEqual(expand.host_environment("api-01.psii.lseg.com"), None)


class PairingTests(unittest.TestCase):
    """The refusal this package exists for."""

    def test_real_sad_row_is_refused(self):
        # Dev/CI/Alpha/Pre-Prod against dev/qa/uat/ppe. Two environments have no
        # host; two hosts belong to no declared environment. A cross product would
        # make sixteen connections out of a row that wants at most four.
        environments = ["DEV", "CI", "ALPHA", "PRE_PROD"]
        endpoints = [
            {"current": "dev.temp.psii.lseg.com", "post_cutover": None},
            {"current": "qa.temp.psii.lseg.com", "post_cutover": None},
            {"current": "uat.temp.psii.lseg.com", "post_cutover": None},
            {"current": "ppe.temp.psii.lseg.com", "post_cutover": None},
        ]
        pairing, problem, _ = expand.pair(environments, endpoints)
        self.assertIsNone(pairing)
        self.assertIn("CI", problem)
        self.assertIn("ALPHA", problem)
        self.assertIn("16", problem)  # the cost of guessing, stated in the message

    def test_clean_bijection_is_accepted(self):
        environments = ["DEV", "UAT"]
        endpoints = [
            {"current": "dev.psii.lseg.com", "post_cutover": None},
            {"current": "uat.psii.lseg.com", "post_cutover": None},
        ]
        pairing, problem, inferred = expand.pair(environments, endpoints)
        self.assertIsNone(problem)
        self.assertFalse(inferred)
        self.assertEqual(pairing["DEV"]["current"], "dev.psii.lseg.com")

    def test_single_shared_host_fans_out_but_is_inferred(self):
        environments = ["DEV", "CI", "PROD"]
        endpoints = [{"current": "api.psii.lseg.com", "post_cutover": None}]
        pairing, problem, inferred = expand.pair(environments, endpoints)
        self.assertIsNone(problem)
        self.assertTrue(inferred, "a shared host is a judgement, not a reading")
        self.assertEqual(len(pairing), 3)

    def test_two_endpoints_claiming_one_environment_is_refused(self):
        environments = ["DEV"]
        endpoints = [
            {"current": "dev.a.lseg.com", "post_cutover": None},
            {"current": "dev.b.lseg.com", "post_cutover": None},
        ]
        pairing, problem, _ = expand.pair(environments, endpoints)
        self.assertIsNone(pairing)
        self.assertIn("both look like DEV", problem)

    def test_no_endpoints_is_refused(self):
        pairing, problem, _ = expand.pair(["DEV"], [])
        self.assertIsNone(pairing)
        self.assertIn("No endpoint", problem)


class BuildTests(unittest.TestCase):
    def row(self, **overrides) -> dict:
        cells = {
            "connection_type": "LSEG App",
            "source_application": "OTC CBIC (APP-52775)",
            "destination_application": "Product Studio II (APP-53435)",
            "endpoints": "https://dev.psii.lseg.com\nhttps://uat.psii.lseg.com",
            "protocol_encryption": "443 / HTTPS TLS 1.2",
            "authentication_method": "Entra ID Service Principal / OAuth 2.0",
            "security_proxy": "App Gateway",
            "purpose": "Content consumption via PSII API",
            "environment": "Dev, UAT",
        }
        cells.update(overrides)
        return {"row_index": 0, "cells": cells}

    def test_clean_row_expands(self):
        requirements, problem = expand.build(self.row(), 0, "SAD.docx", "current", {})
        self.assertIsNone(problem)
        self.assertEqual(len(requirements), 2)
        self.assertEqual({r["environment"] for r in requirements}, {"DEV", "UAT"})
        for requirement in requirements:
            self.assertNotIn("review", requirement,
                             "a fully parsed row should not need review")

    def test_every_field_records_its_derivation(self):
        requirements, _ = expand.build(self.row(), 0, "SAD.docx", "current", {})
        self.assertEqual(expand.check_derivation_coverage(requirements[0]), [])

    def test_empty_purpose_is_refused(self):
        requirements, problem = expand.build(self.row(purpose=""), 0, "SAD.docx", "current", {})
        self.assertEqual(requirements, [])
        self.assertIn("business justification", problem["reason"])

    def test_merged_cell_marks_fields_inferred_and_requires_review(self):
        row = self.row()
        row["merged_from_above"] = True
        requirements, _ = expand.build(row, 0, "SAD.docx", "current", {})
        self.assertTrue(requirements[0]["review"]["required"])
        self.assertEqual(requirements[0]["derivation"]["purpose"], "INFERRED")

    def test_cutover_both_produces_two_per_environment(self):
        row = self.row(endpoints="https://dev.temp.x.com (after cutover https://dev.x.com)",
                       environment="Dev")
        requirements, problem = expand.build(row, 0, "SAD.docx", "both", {})
        self.assertIsNone(problem)
        self.assertEqual(len(requirements), 2)
        self.assertEqual(
            {r["endpoint"]["cutover_state"] for r in requirements},
            {"CURRENT", "POST_CUTOVER"},
        )

    def test_pairing_override_resolves_but_stays_under_review(self):
        row = self.row(
            endpoints="https://dev.temp.x.com\nhttps://qa.temp.x.com",
            environment="Dev, CI",
        )
        # Without help this row is refused - qa does not mean CI.
        _, problem = expand.build(row, 0, "SAD.docx", "current", {})
        self.assertIsNotNone(problem)

        overrides = {0: {"DEV": "dev.temp.x.com", "CI": "qa.temp.x.com"}}
        requirements, problem = expand.build(row, 0, "SAD.docx", "current", overrides)
        self.assertIsNone(problem)
        self.assertEqual(len(requirements), 2)
        self.assertTrue(
            all(r["review"]["required"] for r in requirements),
            "a human-stated pairing is a decision and must still be reviewed",
        )

    def test_pairing_override_naming_an_absent_host_is_refused(self):
        overrides = {0: {"DEV": "nowhere.example.com"}}
        requirements, problem = expand.build(self.row(), 0, "SAD.docx", "current", overrides)
        self.assertEqual(requirements, [])
        self.assertIn("not in this row", problem["reason"])

    def test_refusals_say_whether_a_flag_can_fix_them(self):
        """The remedy printed for a refusal has to match the refusal.

        Telling someone to supply --pairing for an empty Purpose cell sends them
        looking for a pairing to state, and there isn't one - the document is
        what has to change. main() groups the refusal footer on this field.
        """
        unpairable = self.row(
            endpoints="https://dev.temp.x.com\nhttps://qa.temp.x.com",
            environment="Dev, CI",
        )
        _, problem = expand.build(unpairable, 0, "SAD.docx", "current", {})
        self.assertEqual(problem["kind"], "PAIRING")

        _, problem = expand.build(self.row(purpose=""), 0, "SAD.docx", "current", {})
        self.assertEqual(problem["kind"], "SAD_GAP")

        no_twin = self.row(endpoints="https://dev.x.com", environment="Dev")
        _, problem = expand.build(no_twin, 0, "SAD.docx", "post", {})
        self.assertEqual(problem["kind"], "CUTOVER")

    def test_a_stated_pairing_reads_differently_from_a_guessed_one(self):
        """Both are INFERRED, but an approver needs to tell them apart.

        "an operator asserted CI means qa.temp.x.com" and "the script worked it
        out from the row" carry different weight, and a single boolean flattened
        them into the same sentence.
        """
        row = self.row(
            endpoints="https://dev.temp.x.com\nhttps://qa.temp.x.com",
            environment="Dev, CI",
        )
        overrides = {0: {"DEV": "dev.temp.x.com", "CI": "qa.temp.x.com"}}
        stated, _ = expand.build(row, 0, "SAD.docx", "current", overrides)
        guessed, _ = expand.build(
            self.row(endpoints="https://api.x.com", environment="Dev, UAT"),
            0, "SAD.docx", "current", {},
        )

        for requirement in stated:
            self.assertIn("--pairing", requirement["review"]["reason"])
        for requirement in guessed:
            self.assertNotIn("--pairing", requirement["review"]["reason"])
            self.assertIn("worked out", requirement["review"]["reason"])

        # And the specific pairing is named, so the suspicious one is visible
        # without opening the SAD.
        by_environment = {r["environment"]: r["review"]["reason"] for r in stated}
        self.assertIn("qa.temp.x.com", by_environment["CI"])


class ValidatorTests(unittest.TestCase):
    def test_accepts_a_well_formed_requirements_document(self):
        requirements, _ = expand.build(
            BuildTests().row(), 0, "SAD.docx", "current", {}
        )
        document = {
            "source_document": "SAD.docx",
            "generated_at": "2026-01-01T00:00:00+00:00",
            "requirements": requirements,
        }
        target = schema("connectivity-requirement.schema.json")
        self.assertEqual(validator.validate(document, target, target), [])

    def test_rejects_an_unknown_property(self):
        target = schema("plan.schema.json")
        document = {
            "generated_at": "x", "base_url": "x", "tenant_id": "x", "spec_version": "x",
            "entries": [], "surprise": True,
            "summary": {"create": 0, "exists": 0, "covered_by_policy": 0,
                        "needs_review": 0, "blocked": 0},
        }
        errors = validator.validate(document, target, target)
        self.assertTrue(any("surprise" in error for error in errors))

    def test_rejects_a_bad_enum(self):
        target = schema("plan.schema.json")
        document = {
            "generated_at": "x", "base_url": "x", "tenant_id": "x", "spec_version": "x",
            "entries": [{"requirement_key": "0" * 16, "disposition": "MAYBE", "reason": "x"}],
            "summary": {"create": 0, "exists": 0, "covered_by_policy": 0,
                        "needs_review": 0, "blocked": 0},
        }
        errors = validator.validate(document, target, target)
        self.assertTrue(any("MAYBE" in error for error in errors))

    def test_boolean_is_not_an_integer(self):
        target = {"type": "integer"}
        self.assertTrue(validator.validate(True, target, target))

    def test_unimplemented_keyword_is_refused_not_ignored(self):
        target = {"type": "object", "propertyNames": {"pattern": "^a"}}
        with self.assertRaises(validator.SchemaUnusable):
            validator.validate({}, target, target)

    def test_a_nested_unimplemented_keyword_is_still_caught(self):
        """validate() is instance-driven, so it only checks branches the data reaches.

        A schema can carry an unimplemented keyword three levels down and never
        raise, because no document has populated that field yet - and since an
        unimplemented keyword validates nothing, that is a silent hole. This is
        why check_schema walks the schema itself.
        """
        target = {
            "type": "object",
            "properties": {
                "entries": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {"kind": {"type": "string", "default": "X"}},
                    },
                }
            },
        }
        # The hole: an empty instance reaches none of it, so validate is happy.
        self.assertEqual(validator.validate({}, target, target), [])
        with self.assertRaises(validator.SchemaUnusable):
            validator.check_schema(target, target)

    def test_all_shipped_schemas_are_usable(self):
        for name in os.listdir(SCHEMAS):
            with self.subTest(schema=name):
                target = schema(name)
                # check_schema, not validate: the question is whether the schema
                # is usable at all, which must not depend on which branches some
                # particular document happens to reach.
                try:
                    validator.check_schema(target, target)
                except validator.SchemaUnusable as error:
                    self.fail(f"{name}: {error}")


def build_docx(tables: list[list[list[str]]]) -> bytes:
    """A minimal but genuine .docx holding the given tables.

    Built here rather than committed as a binary fixture so that what the
    extractor is tested against is visible in the diff.
    """
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    def cell(text: str) -> str:
        paragraphs = "".join(
            f"<w:p><w:r><w:t xml:space='preserve'>{escape(line)}</w:t></w:r></w:p>"
            for line in text.split("\n")
        )
        return f"<w:tc>{paragraphs or '<w:p/>'}</w:tc>"

    body = ""
    for rows in tables:
        body += "<w:tbl>" + "".join(
            "<w:tr>" + "".join(cell(value) for value in row) + "</w:tr>" for row in rows
        ) + "</w:tbl>"

    document = (
        f"<?xml version='1.0' encoding='UTF-8'?>"
        f"<w:document xmlns:w='{W}'><w:body>{body}</w:body></w:document>"
    )
    content_types = (
        "<?xml version='1.0' encoding='UTF-8'?>"
        "<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'>"
        "<Default Extension='xml' ContentType='application/xml'/>"
        "<Override PartName='/word/document.xml' ContentType='application/vnd."
        "openxmlformats-officedocument.wordprocessingml.document.main+xml'/></Types>"
    )
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("word/document.xml", document)
    return buffer.getvalue()


SAD_HEADER = [
    "Connection Type (Delete as appropriate)",
    "Source application (LeanIX ID and Name)",
    "Destination application (LeanIX ID & Name)",
    "Public / Private IP",
    "Protocol / encryption",
    "Authentication Method",
    "Security Proxy (External Services Only)",
    "Purpose",
    "Environment (Default is All unless specified, e.g. Dev)",
]
SAD_ROW = [
    "LSEG App",
    "OTC CBIC (APP-52775)",
    "Product Studio II (APP-53435)",
    "https://dev.temp.psii.lseg.com\nhttps://qa.temp.psii.lseg.com",
    "443 / HTTPS TLS 1.2",
    "Entra ID Service Principal / OAuth 2.0",
    "App Gateway",
    "Content consumption via PSII API",
    "Dev, CI, Alpha & Pre-Prod",
]


class ExtractorTests(unittest.TestCase):
    def extract(self, docx_bytes: bytes, **kwargs):
        with tempfile.TemporaryDirectory() as directory:
            docx_path = os.path.join(directory, "SAD.docx")
            out_path = os.path.join(directory, "rows.json")
            with open(docx_path, "wb") as handle:
                handle.write(docx_bytes)
            argv = ["extract_sad_table.py", "--docx", docx_path, "--out", out_path]
            for key, value in kwargs.items():
                argv += [f"--{key.replace('_', '-')}", str(value)]
            original = sys.argv
            sys.argv = argv
            try:
                code = extract.main()
            except SystemExit as exit_error:
                return exit_error.code, None
            finally:
                sys.argv = original
            with open(out_path, encoding="utf-8") as handle:
                return code, json.load(handle)

    def test_reads_the_connectivity_table(self):
        code, document = self.extract(build_docx([[SAD_HEADER, SAD_ROW]]))
        self.assertEqual(code, 0)
        self.assertEqual(len(document["rows"]), 1)
        cells = document["rows"][0]["cells"]
        self.assertEqual(cells["source_application"], "OTC CBIC (APP-52775)")
        self.assertEqual(cells["environment"], "Dev, CI, Alpha & Pre-Prod")

    def test_preserves_the_newlines_that_separate_endpoints(self):
        _, document = self.extract(build_docx([[SAD_HEADER, SAD_ROW]]))
        endpoints = document["rows"][0]["cells"]["endpoints"]
        self.assertEqual(len(endpoints.split("\n")), 2,
                         "joining endpoint paragraphs loses requirements")

    def test_ignores_an_unrelated_table(self):
        other = [["Term", "Definition"], ["SWAT", "The delivery team"]]
        code, document = self.extract(build_docx([other, [SAD_HEADER, SAD_ROW]]))
        self.assertEqual(code, 0)
        self.assertEqual(len(document["rows"]), 1)

    def test_no_matching_table_cannot_assess(self):
        other = [["Term", "Definition"], ["SWAT", "The delivery team"]]
        code, _ = self.extract(build_docx([other]))
        self.assertEqual(code, 2, "a missing table is 'cannot assess', not 'no requirements'")

    def test_two_matching_tables_refuse_to_merge(self):
        code, _ = self.extract(build_docx([[SAD_HEADER, SAD_ROW], [SAD_HEADER, SAD_ROW]]))
        self.assertEqual(code, 2)

    def test_table_index_disambiguates(self):
        # 0-based, matching the indices the refusal message above reports.
        code, document = self.extract(
            build_docx([[SAD_HEADER, SAD_ROW], [SAD_HEADER, SAD_ROW]]), table_index=1
        )
        self.assertEqual(code, 0)
        self.assertEqual(document["table_index"], 1)

    def test_output_validates_against_its_schema(self):
        _, document = self.extract(build_docx([[SAD_HEADER, SAD_ROW]]))
        target = schema("sad-rows.schema.json")
        self.assertEqual(validator.validate(document, target, target), [])

    def test_end_to_end_row_is_refused_by_the_expander(self):
        # The full path: this real-shaped row reaches the expander and is refused,
        # rather than becoming eight connections.
        _, document = self.extract(build_docx([[SAD_HEADER, SAD_ROW]]))
        requirements, problem = expand.build(
            document["rows"][0], 0, "SAD.docx", "current", {}
        )
        self.assertEqual(requirements, [])
        self.assertIn("Cannot pair", problem["reason"])


class ClientSafetyTests(unittest.TestCase):
    def test_dry_run_refuses_writes(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x", dry_run=True)
        with self.assertRaises(AppConError) as caught:
            client.request("POST", "/connections", body={"a": 1})
        self.assertIn("dry-run", str(caught.exception))

    def test_dry_run_allows_the_evaluative_posts(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x", dry_run=True)
        # Reaches the network rather than the dry-run guard, which is the point.
        with self.assertRaises(AppConError) as caught:
            client.request("POST", "/connections/policy-overlap", body={"connections": []})
        self.assertNotIn("dry-run", str(caught.exception))

    def test_verify_body_refuses_an_undocumented_field(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {
            "paths": {
                "/connections": {
                    "post": {
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {"consumerId": {}, "providerId": {}},
                                        "required": ["consumerId"],
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        client._spec_hash = "test"
        with self.assertRaises(Exception) as caught:
            client.verify_body("POST", "/connections",
                               {"consumerId": "a", "madeUpField": "b"})
        self.assertIn("madeUpField", str(caught.exception))

    def test_verify_body_refuses_a_missing_required_field(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {
            "paths": {
                "/connections": {
                    "post": {
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {"consumerId": {}},
                                        "required": ["consumerId"],
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        client._spec_hash = "test"
        with self.assertRaises(Exception) as caught:
            client.verify_body("POST", "/connections", {})
        self.assertIn("consumerId", str(caught.exception))

    def test_path_templates_are_matched(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {"paths": {"/connections/{connectionId}/change-request": {"post": {}}}}
        client._spec_hash = "test"
        self.assertEqual(
            client._template_for("/connections/abc-123/change-request"),
            "/connections/{connectionId}/change-request",
        )

    def test_unknown_path_is_refused(self):
        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {"paths": {}}
        client._spec_hash = "test"
        with self.assertRaises(Exception) as caught:
            client.verify_body("POST", "/nope", {"a": 1})
        self.assertIn("does not match any path", str(caught.exception))


class LedgerFittingTests(unittest.TestCase):
    def test_fit_body_uses_the_name_the_spec_documents(self):
        import apply_plan

        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {
            "paths": {
                "/connections": {
                    "post": {
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        # The spec says "consumer", not "consumerId".
                                        "properties": {"consumer": {}, "provider": {}},
                                        "required": ["consumer"],
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        client._spec_hash = "test"
        body = apply_plan.fit_body(client, "POST", "/connections", [
            (("consumerId", "consumer"), "c-1"),
            (("providerId", "provider"), "p-1"),
        ])
        self.assertEqual(body, {"consumer": "c-1", "provider": "p-1"})

    def test_fit_body_refuses_when_a_required_field_has_no_value(self):
        import apply_plan

        client = AppConClient(base_url="https://example/appconn", cookie="x")
        client._spec = {
            "paths": {
                "/connections": {
                    "post": {
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {"consumer": {}, "bandwidthProfile": {}},
                                        "required": ["consumer", "bandwidthProfile"],
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        client._spec_hash = "test"
        with self.assertRaises(Exception) as caught:
            apply_plan.fit_body(client, "POST", "/connections", [
                (("consumerId", "consumer"), "c-1"),
            ])
        self.assertIn("bandwidthProfile", str(caught.exception))


class PlanningTests(unittest.TestCase):
    """plan_connections.py against a local AppCon, over real HTTP.

    The planner is the part that decides whether a firewall request gets raised,
    and every branch of that decision depends on how a response is shaped. Those
    shapes cannot be checked by reading the endpoint inventory - it names schemas
    without defining them - so they are checked against a server that returns
    them. tests/mock_appcon_server.py is that server; the fixture there is
    arranged so one pass produces every disposition.
    """

    @classmethod
    def setUpClass(cls) -> None:
        # Port 0: the OS picks a free one, so a test run never collides with a
        # mock server someone left running.
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), mock_appcon.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        host, port = cls.server.server_address
        cls.base_url = f"http://{host}:{port}"

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=5)

    def setUp(self) -> None:
        self.client = AppConClient(base_url=self.base_url, cookie="test=1", dry_run=True)
        self.resolver = planner.Resolver(self.client, mock_appcon.TENANT_ID)

    def plan(self, **overrides) -> dict:
        cells = {
            "connection_type": "LSEG App",
            "source_application": "OTC CBIC (APP-52775)",
            "destination_application": "Product Studio II (APP-53435)",
            "endpoints": "https://dev.psii.lseg.com",
            "protocol_encryption": "443 / HTTPS TLS 1.2",
            "purpose": "Content consumption via PSII API",
            "environment": "Dev",
        }
        cells.update(overrides)
        requirements, problem = expand.build(
            {"row_index": 0, "cells": cells}, 0, "SAD.docx", "current", {})
        self.assertIsNone(problem, problem)
        self.assertEqual(len(requirements), 1)
        return planner.plan_one(requirements[0], self.resolver, self.client, False)

    def test_a_connection_we_already_created_is_recognised_by_its_stamp(self):
        """The durable idempotency record is the stamp, not the local ledger.

        A run killed halfway through, on a machine whose out/ was then deleted,
        still must not raise the same firewall request twice.
        """
        entry = self.plan()
        self.assertEqual(entry["disposition"], "EXISTS")
        self.assertIn(mock_appcon.ALREADY_CREATED, entry["reason"])

    def test_traffic_a_base_policy_already_permits_is_dropped(self):
        entry = self.plan(endpoints="https://uat.psii.lseg.com", environment="UAT")
        self.assertEqual(entry["disposition"], "COVERED_BY_POLICY")
        self.assertIn("POL-100294", entry["policy_matches"])

    def test_a_missing_hosting_environment_blocks_rather_than_creating_one(self):
        entry = self.plan(
            source_application="Datascope Select (APP-50021)",
            endpoints="https://prod.psii.lseg.com",
            environment="Prod",
        )
        self.assertEqual(entry["disposition"], "BLOCKED")
        self.assertIn("no PROD hosting environment", entry["reason"])

    def test_an_ordinary_requirement_plans_a_create(self):
        entry = self.plan(
            source_application="Yield Book (APP-51190)",
            endpoints="https://ppe.temp.psii.lseg.com",
            protocol_encryption="8443 / HTTPS TLS 1.3",
            environment="Pre-Prod",
        )
        self.assertEqual(entry["disposition"], "CREATE")
        self.assertEqual(entry["will_create"], ["CONSUMER", "PROVIDER", "CONNECTION"])
        # Advisory only - it changes how long the change takes, not whether we
        # create it - but it must be a real answer and not a constant.
        self.assertEqual(entry["auto_approval_prediction"], "MANUAL_REVIEW")

    def test_a_requirement_under_review_never_reaches_appcon(self):
        requirements, _ = expand.build(
            {"row_index": 0, "cells": {
                "source_application": "OTC CBIC (APP-52775)",
                "destination_application": "Product Studio II (APP-53435)",
                "endpoints": "https://api.psii.lseg.com",
                "protocol_encryption": "443 / HTTPS TLS 1.2",
                "purpose": "Shared host across environments",
                "environment": "Dev, UAT",
            }}, 0, "SAD.docx", "current", {})
        self.assertTrue(all(r["review"]["required"] for r in requirements))

        # A resolver with no client at all: touching AppCon would raise.
        entry = planner.plan_one(requirements[0], None, None, False)
        self.assertEqual(entry["disposition"], "NEEDS_REVIEW")

    def test_the_planner_cannot_write_even_though_the_server_would_answer(self):
        """dry_run is a structural guarantee, not a convention.

        The mock answers write paths with a 403 that says so, but the refusal
        has to happen in the client - a plan run must not be able to depend on
        the server being the one that says no.
        """
        with self.assertRaises(AppConError) as caught:
            self.client.request("POST", "/connections", body={"consumerId": "x"})
        self.assertIn("dry-run", str(caught.exception))


    def test_the_saved_spec_is_the_document_the_pinned_hash_covers(self):
        """Otherwise pinning it is theatre.

        apply_plan.py refuses when the hash has moved, and the saved document is
        what you read to find out what moved. If the two could drift - a
        re-fetch between hashing and writing, say - the file would be evidence
        for a different spec than the one the plan was built against, which is
        worse than having no file at all.
        """
        import hashlib

        document = self.client.spec()
        canonical = json.dumps(document, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
        self.assertEqual(digest, self.client.spec_hash())

        # And it survives the round trip through the file, which is where an
        # encoding or float-repr difference would show up.
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "spec.json")
            write_json_atomic(path, document)
            with open(path, encoding="utf-8") as handle:
                reloaded = json.load(handle)
        recanonical = json.dumps(reloaded, sort_keys=True, separators=(",", ":"))
        self.assertEqual(
            hashlib.sha256(recanonical.encode("utf-8")).hexdigest()[:16], digest)


class StatusClassificationTests(unittest.TestCase):
    def test_approved_pending_implementation_is_not_approved_or_pending_approval(self):
        import track_status

        self.assertEqual(
            track_status.classify({"status": "APPROVED_PENDING_IMPLEMENTATION"}),
            "APPROVED_PENDING_IMPLEMENTATION",
        )
        self.assertEqual(
            track_status.classify({"status": "Pending Approval"}), "PENDING_APPROVAL"
        )
        self.assertEqual(track_status.classify({"status": "On Hold"}), "ON_HOLD")

    def test_unreadable_status_is_unknown_not_new(self):
        import track_status

        self.assertEqual(track_status.classify({"status": "???"}), "UNKNOWN")


if __name__ == "__main__":
    unittest.main(verbosity=2)
