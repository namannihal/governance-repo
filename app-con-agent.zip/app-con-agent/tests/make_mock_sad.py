#!/usr/bin/env python3
"""Build a mock LMP SAD .docx for local testing.

Not a fixture file. Committed as a generator so what the pipeline is being
tested against is visible in the diff rather than sealed inside a binary.

The table it writes is deliberately mixed. One row is clean and expands without
a question; one is the real Dev/CI/Alpha/Pre-Prod row that must be refused; one
has cutover twins; one is missing its business justification. A mock where every
row parses tests nothing, because the refusals are the part worth testing.

Usage:
    make_mock_sad.py --out out/appcon/MOCK-SAD.docx
    make_mock_sad.py --out out/appcon/MOCK-SAD-rev2.docx --revised
"""

from __future__ import annotations

import argparse
import os
import zipfile
from xml.sax.saxutils import escape

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

HEADER = [
    "Connection Type (Delete as appropriate)",
    "Source application (LeanIX ID and Name)",
    "Destination application (LeanIX ID & Name)",
    "Public / Private IP / Endpoints",
    "Protocol / encryption",
    "Authentication Method",
    "Security Proxy (External Services Only)",
    "Purpose",
    "Environment (Default is All unless specified, e.g. Dev)",
]

ROWS = [
    # 1. Clean. Two environments, two matching hostnames. Expands to 2, no questions.
    [
        "LSEG App",
        "OTC CBIC (APP-52775)",
        "Product Studio II (APP-53435)",
        "https://dev.psii.lseg.com\nhttps://uat.psii.lseg.com",
        "443 / HTTPS TLS 1.2",
        "Entra ID Service Principal / OAuth 2.0",
        "App Gateway",
        "Content consumption via the PSII catalogue API",
        "Dev, UAT",
    ],
    # 2. The one this package exists for. Four environments, four hostnames, no
    #    correspondence. Must be refused, not cross-multiplied into 16.
    [
        "LSEG App",
        "Product Studio I APP--52208",
        "Product Studio II (APP-53435)",
        "https://dev.temp.psii.lseg.com\nhttps://qa.temp.psii.lseg.com\n"
        "https://uat.temp.psii.lseg.com\nhttps://ppe.temp.psii.lseg.com",
        "443 / HTTPS TLS 1.2",
        "Entra ID Service Principal / OAuth 2.0",
        "App Gateway",
        "Migration of instrument reference data during PSI to PSII cutover",
        "Dev, CI, Alpha & Pre-Prod",
    ],
    # 3. Cutover twins on a single environment. One requirement under the default
    #    policy, two under --cutover-policy both.
    [
        "LSEG App",
        "Yield Book (APP-51190)",
        "Product Studio II (APP-53435)",
        "https://ppe.temp.psii.lseg.com (after cutover https://ppe.psii.lseg.com)",
        "8443 / HTTPS TLS 1.3",
        "mTLS",
        "N/A",
        "Analytics pricing feed",
        "Pre-Prod",
    ],
    # 4. No business justification. AppCon requires one; must be refused.
    [
        "LSEG App",
        "Datascope Select (APP-50021)",
        "Product Studio II (APP-53435)",
        "https://prod.psii.lseg.com",
        "443 / HTTPS TLS 1.2",
        "API Key",
        "App Gateway",
        "",
        "Prod",
    ],
    # 5. One shared host across several environments. Resolvable, but the
    #    fan-out is a judgement, so it should come out INFERRED and flagged.
    [
        "External",
        "Product Studio II (APP-53435)",
        "Refinitiv Tick History (APP-50884)",
        "https://api.trth.lseg.com",
        "443 / HTTPS TLS 1.2",
        "OAuth 2.0",
        "App Gateway",
        "Historical tick retrieval for backtesting",
        "Dev, UAT, Prod",
    ],
]

# An unrelated table, so the extractor has to find the right one by fingerprint
# rather than by being handed the only candidate.
GLOSSARY = [
    ["Term", "Definition"],
    ["PSII", "Product Studio II"],
    ["SWAT", "The delivery team"],
]

PURPOSE_COLUMN = HEADER.index("Purpose")

# --revised: the same SAD after the author answered the question the expander
# raised. Only the empty Purpose is filled, because that is the only refusal a
# document revision can settle - the Dev/CI/Alpha/Pre-Prod row in row 1 needs a
# pairing stated at expansion time, not a new paragraph in the SAD. Keeping the
# two apart here mirrors the SAD_GAP / PAIRING split the expander reports.
REVISIONS = {
    3: {
        PURPOSE_COLUMN: "Reference data snapshot for end-of-day Datascope reconciliation",
    },
}


def revise(rows: list[list[str]]) -> list[list[str]]:
    revised = [list(row) for row in rows]
    for row_index, changes in REVISIONS.items():
        for column, value in changes.items():
            revised[row_index][column] = value
    return revised


def cell(text: str) -> str:
    paragraphs = "".join(
        f"<w:p><w:r><w:t xml:space='preserve'>{escape(line)}</w:t></w:r></w:p>"
        for line in text.split("\n")
    )
    return f"<w:tc>{paragraphs or '<w:p/>'}</w:tc>"


def table(rows: list[list[str]]) -> str:
    return "<w:tbl>" + "".join(
        "<w:tr>" + "".join(cell(value) for value in row) + "</w:tr>" for row in rows
    ) + "</w:tbl>"


def paragraph(text: str) -> str:
    return f"<w:p><w:r><w:t xml:space='preserve'>{escape(text)}</w:t></w:r></w:p>"


def build(path: str, rows: list[list[str]]) -> None:
    body = (
        paragraph("Solution Architecture Document - Product Studio II (MOCK)")
        + paragraph("4.2 Glossary")
        + table(GLOSSARY)
        + paragraph("7.3 Connectivity Requirements")
        + paragraph(
            "The following connections are required. Environments are as stated; "
            "where an endpoint is marked 'after cutover', both names are in use "
            "during the transition window."
        )
        + table([HEADER] + rows)
    )
    document = (
        "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
        f"<w:document xmlns:w='{W}'><w:body>{body}</w:body></w:document>"
    )
    content_types = (
        "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
        "<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'>"
        "<Default Extension='rels' ContentType='application/vnd.openxmlformats-package.relationships+xml'/>"
        "<Default Extension='xml' ContentType='application/xml'/>"
        "<Override PartName='/word/document.xml' ContentType='application/vnd."
        "openxmlformats-officedocument.wordprocessingml.document.main+xml'/></Types>"
    )
    rels = (
        "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
        "<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'>"
        "<Relationship Id='rId1' Type='http://schemas.openxmlformats.org/officeDocument/"
        "2006/relationships/officeDocument' Target='word/document.xml'/></Relationships>"
    )

    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", rels)
        archive.writestr("word/document.xml", document)
        archive.writestr("word/_rels/document.xml.rels",
                         "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
                         "<Relationships xmlns='http://schemas.openxmlformats.org/"
                         "package/2006/relationships'/>")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="out/appcon/MOCK-SAD.docx")
    parser.add_argument(
        "--revised", action="store_true",
        help="Emit the SAD as it would read after the author filled in the missing "
             "business justification. The unpairable row is left alone - that one "
             "is answered with --pairing, not by editing the document.",
    )
    args = parser.parse_args()

    rows = revise(ROWS) if args.revised else ROWS
    build(args.out, rows)

    print(f"Wrote {args.out}: 2 tables, {len(rows)} connectivity rows.")
    if args.revised:
        print("Revised: row 3 now has a Purpose. Expected: rows 0, 2, 3 and 4 expand;")
        print("row 1 is still refused until --pairing states which host serves which environment.")
    else:
        print("Expected: rows 0, 2 and 4 expand; rows 1 and 3 are refused.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
