#!/usr/bin/env python3
"""A local stand-in for AppCon, serving the read-only surface /create-plan uses.

Without this, local testing stops at /create-requirements: everything past it
needs a live AppCon and an SSO session, so the only thing you can observe is the
client failing to connect. That tests the error path and nothing else.

What it serves is deliberately not a happy path. The fixture is arranged so one
run of plan_connections.py produces every disposition it can produce:

  EXISTS             a connection already carrying our stamp, as a re-run after
                     an interruption would find
  COVERED_BY_POLICY  traffic a base policy already permits
  CREATE             the ordinary case
  BLOCKED            an application with no hosting environment for the
                     environment the SAD asked for
  NEEDS_REVIEW       requirements the expander marked INFERRED, which never
                     reach the API at all

It also serves an OpenAPI document, because the client refuses to send a body
the spec does not describe. That is not ceremony here: if the spec below omits
`connections` from the policy-overlap request body, the client refuses the call
and the plan reports it as BLOCKED rather than sending it anyway. The refusal is
worth watching work.

The stamped connection is computed with the real requirement_key, not typed in,
so the EXISTS path is matched the same way a real re-run would match it.

Usage:
    mock_appcon_server.py --port 8765
    APPCON_BASE_URL=http://127.0.0.1:8765 APPCON_COOKIE='mock=1' \
        APPCON_TENANT_ID=tenant-mock python .apm/scripts/python/plan_connections.py ...

This is a test fixture. It stores nothing, validates nothing, and must never be
pointed at by anything that thinks it is talking to AppCon.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    ".apm", "scripts", "python",
))
from _common import requirement_key  # noqa: E402

TENANT_ID = "tenant-mock"

APPLICATIONS = [
    {"id": "app-52775", "leanIxId": "APP-52775", "name": "OTC CBIC"},
    {"id": "app-53435", "leanIxId": "APP-53435", "name": "Product Studio II"},
    {"id": "app-52208", "leanIxId": "APP-52208", "name": "Product Studio I"},
    {"id": "app-51190", "leanIxId": "APP-51190", "name": "Yield Book"},
    # Present, but has no PROD hosting environment. The SAD asks for PROD, so
    # this is the BLOCKED case - and blocked on the thing AppCon actually wants
    # you to do first, which is create the environment in planning state.
    {"id": "app-50021", "leanIxId": "APP-50021", "name": "Datascope Select"},
    # APP-50884 (Refinitiv Tick History) is deliberately absent: an external
    # provider that was never onboarded into this tenant.
]


def environments(application_id: str, *names: str) -> list[dict]:
    return [
        {
            "id": f"he-{application_id.removeprefix('app-')}-{name.lower()}",
            "environment": name,
            # Planning is a normal state, not an error. Connectivity is raised
            # while the infrastructure is being built.
            "deploymentState": "PLANNING" if name in ("CI", "ALPHA") else "DEPLOYED",
        }
        for name in names
    ]


HOSTING_ENVIRONMENTS = {
    "app-52775": environments("app-52775", "DEV", "UAT", "PRE_PROD"),
    "app-53435": environments(
        "app-53435", "DEV", "CI", "QA", "UAT", "ALPHA", "PRE_PROD", "PROD"),
    "app-52208": environments("app-52208", "DEV", "CI", "ALPHA", "PRE_PROD"),
    "app-51190": environments("app-51190", "PRE_PROD"),
    "app-50021": environments("app-50021", "DEV", "UAT"),
}

# Row 0 of the mock SAD in DEV. Computed rather than pasted, so this stays
# matched to the real key function - if requirement_key ever changes shape, this
# fixture stops claiming EXISTS instead of quietly claiming it about nothing.
ALREADY_CREATED = requirement_key(
    "APP-52775", "APP-53435", "dev.psii.lseg.com", "TCP", 443, "DEV", "CURRENT")

CONNECTIONS = {
    "he-52775-dev": [{
        "id": "conn-existing-0001",
        "name": "OTC CBIC to Product Studio II (DEV)",
        "description": f"appcon-agent:{ALREADY_CREATED}",
        "status": "PENDING_APPROVAL",
    }],
}

# Traffic a base policy already permits, as (fqdn, port, environment).
COVERED_BY_POLICY = {
    ("uat.psii.lseg.com", 443, "UAT"): "POL-100294",
}

SPEC = {
    "openapi": "3.0.1",
    "info": {"title": "AppCon (mock)", "version": "mock-1"},
    "paths": {
        "/tenancy/user-tenants": {"get": {"responses": {"200": {"description": "ok"}}}},
        "/tenants/{tenantId}/applications": {
            "get": {"responses": {"200": {"description": "ok"}}}},
        "/applications/{applicationId}/hosting-environments": {
            "get": {"responses": {"200": {"description": "ok"}}}},
        "/hosting-environments/{hostingEnvironmentId}/connections": {
            "get": {"responses": {"200": {"description": "ok"}}}},
        "/connections/policy-overlap": {
            "post": {
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ConnectionQuery"}
                        }
                    }
                },
                "responses": {"200": {"description": "ok"}},
            }
        },
        "/connections/auto-approval-evaluation": {
            "post": {
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ConnectionQuery"}
                        }
                    }
                },
                "responses": {"200": {"description": "ok"}},
            }
        },
    },
    "components": {
        "schemas": {
            "ConnectionQuery": {
                "type": "object",
                "required": ["connections"],
                "properties": {
                    "connections": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "consumerLeanIxId": {"type": "string"},
                                "providerFqdn": {"type": "string"},
                                "protocol": {"type": "string"},
                                "port": {"type": "integer"},
                                "environment": {"type": "string"},
                            },
                        },
                    }
                },
            }
        }
    },
}

TENANT_APPLICATIONS = re.compile(r"^/tenants/([^/]+)/applications$")
APPLICATION_ENVIRONMENTS = re.compile(r"^/applications/([^/]+)/hosting-environments$")
ENVIRONMENT_CONNECTIONS = re.compile(r"^/hosting-environments/([^/]+)/connections$")


class Handler(BaseHTTPRequestHandler):
    verbose = False

    # ------------------------------------------------------------------ plumbing

    def log_message(self, fmt: str, *args) -> None:
        if Handler.verbose:
            sys.stderr.write(f"  mock-appcon: {fmt % args}\n")

    def send(self, status: int, payload: object) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authenticated(self) -> bool:
        """Real AppCon requires an SSO session, so this does too.

        Accepting anything would leave the one auth-shaped mistake that actually
        happens - forgetting to send the cookie at all - undetected locally and
        discovered against the real deployment.
        """
        if self.headers.get("Cookie"):
            return True
        self.send(401, {"error": "No SSO session. Set APPCON_COOKIE."})
        return False

    def read_body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except ValueError:
            return {}

    # -------------------------------------------------------------------- routes

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler's naming
        path = urlsplit(self.path).path

        if path == "/v3/api-docs/All":
            # Served without auth, like most OpenAPI endpoints. The session is
            # proved by /tenancy/user-tenants instead, which is what probe() calls.
            self.send(200, SPEC)
            return

        if not self.authenticated():
            return

        if path == "/tenancy/user-tenants":
            self.send(200, {"data": [{"id": TENANT_ID, "name": "Mock tenant"}]})
            return

        match = TENANT_APPLICATIONS.match(path)
        if match:
            if match.group(1) != TENANT_ID:
                self.send(404, {"error": f"No tenant {match.group(1)}. This mock "
                                         f"serves {TENANT_ID}."})
                return
            # Spring paging inside ApiResponse, which is the shape the real
            # deployment returns and the one as_list() has to unwrap.
            self.send(200, {"data": {"content": APPLICATIONS,
                                     "totalElements": len(APPLICATIONS)}})
            return

        match = APPLICATION_ENVIRONMENTS.match(path)
        if match:
            self.send(200, {"data": HOSTING_ENVIRONMENTS.get(match.group(1), [])})
            return

        match = ENVIRONMENT_CONNECTIONS.match(path)
        if match:
            self.send(200, {"data": {"content": CONNECTIONS.get(match.group(1), [])}})
            return

        self.send(404, {"error": f"{path} is not served by this mock."})

    def do_POST(self) -> None:  # noqa: N802
        path = urlsplit(self.path).path
        if not self.authenticated():
            return
        body = self.read_body()
        queries = body.get("connections") or []

        if path == "/connections/policy-overlap":
            covered, not_covered, policies = [], [], []
            for query in queries:
                key = (query.get("providerFqdn"), query.get("port"),
                       query.get("environment"))
                policy = COVERED_BY_POLICY.get(key)
                if policy:
                    covered.append(query)
                    policies.append({"id": policy, "name": f"Base policy {policy}"})
                else:
                    not_covered.append(query)
            self.send(200, {"data": {"notCovered": not_covered,
                                     "matchedPolicies": policies}})
            return

        if path == "/connections/auto-approval-evaluation":
            # Port 443 to a *.lseg.com host is the ordinary shape and sails
            # through; anything else gets a human. Enough variation to show the
            # prediction is per-requirement and not a constant.
            decisions = [
                "AUTO_APPROVE"
                if query.get("port") == 443 and str(query.get("providerFqdn", "")).endswith(".lseg.com")
                else "MANUAL_REVIEW"
                for query in queries
            ]
            decision = "MANUAL_REVIEW" if "MANUAL_REVIEW" in decisions else "AUTO_APPROVE"
            self.send(200, {"data": {"decision": decision}})
            return

        # Every write path. Reaching one of these from /create-plan means the
        # dry-run guard in appcon_client.py did not hold, which is worth a loud
        # answer rather than a 404.
        self.send(403, {
            "error": f"{path} is a write endpoint. This mock serves the read-only "
                     f"surface /create-plan uses; a plan run reaching here means "
                     f"the dry-run guard failed."
        })


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--verbose", action="store_true", help="Log every request.")
    args = parser.parse_args()

    Handler.verbose = args.verbose
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    base_url = f"http://{args.host}:{args.port}"
    print(f"Mock AppCon on {base_url}")
    print(f"  export APPCON_BASE_URL='{base_url}'")
    print("  export APPCON_COOKIE='mock=1'")
    print(f"  export APPCON_TENANT_ID='{TENANT_ID}'")
    print(f"  stamped connection: appcon-agent:{ALREADY_CREATED} in he-52775-dev")
    sys.stdout.flush()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
