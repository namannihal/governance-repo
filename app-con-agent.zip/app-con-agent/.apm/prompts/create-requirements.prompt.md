---
mode: agent
description: "Expand SAD rows into typed connectivity requirements, and resolve with the user any row whose environment-to-endpoint pairing the document does not state."
---

# /create-requirements

Agent: [requirement-normalizer](../agents/requirement-normalizer.agent.md) |
Instructions: [derivation-typing](../instructions/derivation-typing.instructions.md) |
Schema: `schemas/connectivity-requirement.schema.json`

Usage: `/create-requirements [<root>] [--cutover-policy current|post|both]`

One row of the table is not one connection. This is where the fan-out happens,
and where it stops when the document runs out of information.

## Steps

1. **Expand.**

   ```bash
   python .apm/scripts/python/expand_requirements.py \
       --rows <root>/out/appcon/sad-rows.json \
       --out <root>/out/appcon/requirements.json \
       --cutover-policy current
   ```

2. **Exit 0** - every row expanded. Go to step 5.

3. **Exit 2** - some rows are in `unresolved[]`. This is the expected outcome on
   a real SAD and it is the package working.

   Each entry carries a `kind`, which says who can answer it. Route on that
   before asking anything - three of these questions go to three different
   people, and asking the wrong one wastes a day:

   | `kind` | Means | Goes to |
   |---|---|---|
   | `PAIRING` | the document does not say which endpoint serves which environment | the user, now, via `--pairing` |
   | `CUTOVER` | `--cutover-policy` asks for a host the cell does not name | the user, as a policy choice |
   | `SAD_GAP` | something is missing that no flag supplies | the SAD's author - the document has to change |

   A `SAD_GAP` is not yours to close. An empty Purpose cell has no defensible
   default, and filling one in from context is inventing the business
   justification that a cyber reviewer is going to read.

   For each `PAIRING` row, put the question to the user with the row visible:

   > Row 2 lists environments **Dev, CI, Alpha & Pre-Prod** and endpoints
   > **dev.temp.psii.lseg.com, qa.temp.psii.lseg.com, uat.temp.psii.lseg.com,
   > ppe.temp.psii.lseg.com**. `dev` and `ppe` map cleanly. Which host serves
   > **CI**, and which serves **Alpha**? (`qa` and `uat` are unclaimed.)
   >
   > Guessing would produce 16 connections from a row that probably wants 4.

   Ask about the environments, not about the pairing algorithm. They know the
   estate; they do not know what the script needs.

4. **Re-run with their answer as an override** - do not edit the JSON:

   ```bash
   python .apm/scripts/python/expand_requirements.py \
       --rows <root>/out/appcon/sad-rows.json \
       --out <root>/out/appcon/requirements.json \
       --pairing "2=DEV:dev.temp.psii.lseg.com,CI:qa.temp.psii.lseg.com,ALPHA:uat.temp.psii.lseg.com,PRE_PROD:ppe.temp.psii.lseg.com"
   ```

   The override is an input. It is visible in the command, it survives a re-run,
   and it is reviewable. A hand-edited requirements file is none of those.

   Everything it resolves is typed `INFERRED` with `review.required: true`. That
   is correct and is not to be argued down - the user told you, the SAD still
   does not say it, and the approver should know which it is.

5. **Validate.**

   ```bash
   python .apm/scripts/python/validate_instance.py \
       --schema schemas/connectivity-requirement.schema.json \
       --document <root>/out/appcon/requirements.json
   ```

6. **Report.** Requirement count and how it relates to row count - "4 rows → 11
   requirements" is the number that tells the user whether the fan-out matched
   their expectation. Then requirements by environment, and every requirement
   carrying `review.required` with the field that caused it.

## The cutover policy

`--cutover-policy` decides what to do with `(after cutover https://...)`:

| Value | Creates | Use when |
|---|---|---|
| `current` (default) | temporary hostnames only | DNS has not moved yet |
| `post` | post-cutover hostnames only | connectivity is being raised for the end state |
| `both` | both, doubling the count | both must be live across the transition |

This is a scheduling decision about DNS, not a parsing one. If the table shows
cutover twins, ask rather than take the default silently.

## Refusals you will meet

- *"All" in the environment column* - the header says All is the default, but
  AppCon needs named environments. Ask which.
- *No APP- id* - the LeanIX id is the join key into AppCon. A name alone cannot
  be resolved without guessing at a real application.
- *Empty Purpose* - AppCon requires a business justification and there is no
  defensible default for one.
- *No port in the protocol cell* - a provider without a port is a firewall rule
  that does not match the SAD.

Next: [`/create-plan`](create-plan.prompt.md). It refuses to run while
`unresolved[]` is non-empty.
