---
mode: agent
description: "Report where every connection in the ledger has reached in the AppCon status machine. Re-reads AppCon each time; never quotes a previous run."
---

# /appcon-status

Agent: [appcon-master](../agents/appcon-master.agent.md)

Usage: `/appcon-status [<root>] [--json]`

Read-only. Answers "where has this batch got to" without a morning in the UI.

## Steps

1. **Poll.**

   ```bash
   python .apm/scripts/python/track_status.py \
       --ledger <root>/out/appcon/ledger.json \
       --requirements <root>/out/appcon/requirements.json
   ```

   `--requirements` is optional and only supplies readable labels -
   `dev.temp.psii.lseg.com [DEV]` instead of a sixteen-character key.

2. **Report the chart it prints**, in its order. That order is the status
   machine read left to right, so it shows progress rather than a tally.

3. **On exit 2, report the UNKNOWN count separately and prominently.**

## The status machine

```
New ──USER: Request Approval──▶ Pending Approval ──CYBER──▶ Approved / Pending Implementation
                                      │                              │
                                      │ CYBER: Hold                  │ ENGINEER: Schedule
                                      ▼                              ▼
                                   On Hold                       Scheduled
                                                                     │ ENGINEER: Implement
                                                                     ▼
                                                                 Implemented
```

`Implemented` means the firewall change is in. That is when the Jira ticket in
the onboarding flow can be tested and closed - not when the connection was
created, and not when it was approved.

## UNKNOWN

A connection whose status could not be read is UNKNOWN. It is counted
separately and never folded into New, because New and unreadable look identical
in a summary and mean opposite things: one is work not yet submitted, the other
is work whose state nobody knows.

Causes worth checking in order: expired session cookie, a connection deleted in
the UI (the ledger still references it), or a status value AppCon has added that
`track_status.py` does not recognise. The third is a one-line fix in `PATTERNS`
with a test alongside it.

## Do not

- Report a cached answer. Statuses change because other people change them;
  re-run the command every time this is asked.
- Describe a connection as approved when it is Approved / Pending
  Implementation. The firewall change has not happened yet.
- Infer progress from the ledger alone. The ledger records what was created,
  which says nothing about what was approved.
