---
mode: agent
description: "Record what the SAD's connectivity table contains, cell by cell. Deliberately not named create- : nothing here is interpreted."
---

# /read-sad

Agent: [sad-reader](../agents/sad-reader.agent.md) |
Schema: `schemas/sad-rows.schema.json`

Usage: `/read-sad <path to SAD.docx> [<root>]`

This command is not named `/create-...` like the others, and that is the point.
It creates nothing. It records what the Word document already says, so that
every requirement produced later can be diffed against the original.

## Steps

1. **Extract.**

   ```bash
   python .apm/scripts/python/extract_sad_table.py \
       --docx "<path to SAD.docx>" --out <root>/out/appcon/sad-rows.json
   ```

   The script finds the table by column fingerprint - it needs source
   application, destination application, endpoints, protocol/encryption and
   environment columns - rather than by position, because the connectivity
   section moves between SAD versions.

2. **On exit 2, handle it as a question, not a result.**

   - *No table matched.* The headings may differ, the section may be in an
     appendix, or the file may be a `.doc` renamed to `.docx`. Say which columns
     it looked for and ask the user to point at the right table. Do **not**
     report "the SAD has no connectivity requirements" - that is a claim about
     the system, and this is a failure to read a file.
   - *Several tables matched.* It names the indices. Ask which one, or read each
     in turn with `--table-index <n>` (0-based) into separate files. Never merge.

3. **Validate the output.**

   ```bash
   python .apm/scripts/python/validate_instance.py \
       --schema schemas/sad-rows.schema.json --document <root>/out/appcon/sad-rows.json
   ```

4. **Report the table.** Row count, and per row the source and destination cells
   as written. Then, separately:

   - Rows with `merged_from_above: true` - a vertically merged cell in Word,
     carried down. Usually right; worth the user's eye.
   - Empty cells in columns that matter: Purpose (no business justification
     means the row is refused later), Environment, Protocol.
   - Endpoint cells containing `(after cutover ...)` - these will double the
     connection count if the cutover policy is `both`.

## What this does not do

Parse `APP-53435` out of a cell, split `443 / HTTPS TLS 1.2`, or expand "Dev,
CI, Alpha & Pre-Prod". That is
[`/create-requirements`](create-requirements.prompt.md), where the parsing is
deterministic and allowed to refuse.

Next: [`/create-requirements`](create-requirements.prompt.md).
