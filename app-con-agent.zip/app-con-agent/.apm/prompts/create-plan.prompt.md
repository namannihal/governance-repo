---
mode: agent
description: "Resolve every requirement against AppCon and produce the plan a human approves: what exists, what base policy already covers, and what would be created. Read-only."
---

# /create-plan

Agent: [appcon-master](../agents/appcon-master.agent.md) |
Instructions: [write-safety](../instructions/write-safety.instructions.md) |
Schema: `schemas/plan.schema.json`

Usage: `/create-plan [<root>]`

This is the last read-only step and it produces the document everything after it
executes. Nothing is created here - the client runs with `dry_run=True`, which
refuses every write endpoint.

## Steps

1. **Plan.**

   ```bash
   python .apm/scripts/python/plan_connections.py \
       --requirements <root>/out/appcon/requirements.json \
       --out <root>/out/appcon/plan.json
   ```

   For each requirement it resolves the LeanIX applications, finds their hosting
   environments, checks for an existing connection carrying this package's
   `appcon-agent:<key>` stamp, asks `/connections/policy-overlap` whether a base
   policy already permits it, and asks `/connections/auto-approval-evaluation`
   whether it would clear review without a human.

2. **Refusals.**

   - *Exit 3, `unresolved` is non-empty* - go back to
     [`/create-requirements`](create-requirements.prompt.md). Planning a subset
     of a document that could not be fully read would quietly deliver partial
     connectivity that looks complete.
   - *Exit 2, nothing to create* - everything already exists or is covered by
     policy. Say which; "nothing to do" and "already done" are the same output
     and very different situations.

3. **Validate.**

   ```bash
   python .apm/scripts/python/validate_instance.py \
       --schema schemas/plan.schema.json --document <root>/out/appcon/plan.json
   ```

4. **Present the plan properly.** This is the moment the user can catch a wrong
   pairing, and a summary line does not let them.

   - Counts by disposition.
   - **Every** CREATE entry, as `consumer (APP-x) → fqdn:port [environment]`.
     All of them - if there are thirty, show thirty.
   - Entries with `review.required`, and the field that caused it. An `INFERRED`
     pairing is the thing most worth a second look.
   - `COVERED_BY_POLICY` entries and which policy. These are being dropped, and
     dropping a requirement deserves as much scrutiny as adding one.
   - `auto_approval_prediction: UNKNOWN` - the evaluation could not be read. It
     is not a prediction of manual review; it is no prediction.

## The dispositions

| Disposition | Means |
|---|---|
| `CREATE` | Nothing matching exists. `/apply-plan` will create it. |
| `EXISTS` | A connection with this requirement's stamp is already there. |
| `COVERED_BY_POLICY` | A base policy already permits this. Creating it would be noise. |
| `NEEDS_REVIEW` | Resolvable, but something about it wants a human. |
| `BLOCKED` | Could not be resolved - a missing application, or no hosting environment for that environment. |

`BLOCKED` is usually real: an application whose hosting environment does not
exist in AppCon yet is the flowchart's "planning" state, and the environment has
to be created before connectivity can be requested against it.

## Do not

- Pass anything that makes this write. If you need a write, you are in the wrong
  command.
- Treat `UNKNOWN` auto-approval as a problem. Most connections need human
  approval; that is the normal path.
- Proceed to [`/apply-plan`](apply-plan.prompt.md) without the user answering.

Next: [`/apply-plan`](apply-plan.prompt.md), after the user has read this.
