---
mode: agent
description: "Check that AppCon is reachable and authenticated, fetch the API spec this run will validate against, and prepare the output directory. Writes nothing to AppCon."
---

# /appcon-init

Agent: [appcon-master](../agents/appcon-master.agent.md)

Usage: `/appcon-init [<root>]`

Run this first. It costs one request and it turns the two failures that would
otherwise appear halfway through a batch - expired session, changed API - into
failures that happen before anything has been created.

## Steps

1. **Check the environment.** `APPCON_BASE_URL` and `APPCON_COOKIE` are
   required; `APPCON_TENANT_ID` is required from `/create-plan` onwards.
   `APPCON_GOV_ID` is optional and can be supplied later.

   ```bash
   python .apm/scripts/python/appcon_client.py --probe
   ```

   Exit 4 means something is unset - say which. Exit 2 with a 401 or 403 means
   the SSO session cookie has expired; sign in to AppCon in a browser and copy a
   fresh one. **Report that as an auth failure, not as "you lack permission"** -
   the script cannot tell the difference and neither can you from one response.

2. **Fetch and pin the spec.**

   ```bash
   python .apm/scripts/python/appcon_client.py --save-spec <root>/out/appcon/spec.json
   ```

   This prints the hash and writes the document. Record the hash: `plan.json`
   stores it and `apply_plan.py` refuses to run against a different one, so that
   a plan reviewed on Tuesday cannot be applied against a Thursday API with
   different field names. Keep the document next to it - when that refusal fires
   months later, the hash says the spec changed and this says how. It also
   creates `<root>/out/appcon/`.

   `--spec-hash` prints the hash alone, for when you only want to compare.

3. **Confirm the tenant.**

   ```bash
   python .apm/scripts/python/appcon_client.py --tenants
   ```

   This lists what the session can see and marks `APPCON_TENANT_ID` with `*`. It
   exits 2 if that id is not in the list, and you should stop there rather than
   press on: everything downstream would resolve to nothing and report it as "no
   existing connections", which looks identical to a clean slate.

## Getting the cookie

The AppCon API requires an SSO session - the spec says so explicitly and there
is no documented token path. Until a service principal is confirmed:

1. Sign in to AppCon in a browser.
2. Copy the session cookie header from a request in the network tab.
3. `export APPCON_COOKIE='<the header value>'`

It expires. When a long run stops with a 401, this is why, and `ledger.json`
tells you where to resume.

Do not put the cookie in a file, a command you echo back, or anything under
`out/`.

## Report

Base URL, tenant name and id, spec hash, and the expiry behaviour above if the
user has not run this before. Then stop - this command does not read the SAD.
