---
mode: agent
description: "Submit created connections for cyber approval with a validated GOV-ID. Moves them from New to Pending Approval and onto someone else's queue."
---

# /request-approval

Agent: [appcon-submitter](../agents/appcon-submitter.agent.md) |
Instructions: [write-safety](../instructions/write-safety.instructions.md)

Usage: `/request-approval [<root>] [--gov-id GOVI123456] [--limit N]`

This is the transition marked **USER: Request Approval** in the AppCon status
machine: New → Pending Approval. Everything before it was private. This puts
work in front of the cyber team.

## Prerequisites

- `ledger.json` contains connections.
- A GOV-ID in `GOVI######` form, either `--gov-id` or `APPCON_GOV_ID`. AppCon's
  business justification dialog requires one and there is no default.
- The user has said to submit, knowing it goes to review.

## Steps

1. **Dry run.**

   ```bash
   python .apm/scripts/python/submit_approval.py \
       --ledger <root>/out/appcon/ledger.json \
       --requirements <root>/out/appcon/requirements.json
   ```

   Exits 3 with the count. Name the connections, not just the number.

2. **Submit.**

   ```bash
   ... --confirm --gov-id GOVI123456
   ```

   The GOV-ID is checked against `/service-now-integration/gov-items` before
   anything is sent. If it does not resolve, nothing is submitted - the whole
   batch, not just that one.

3. **Read the exit code.** 0 all submitted, 2 partially submitted with the
   ledger accurate, 5 everything already has a change request. On 2, name the
   failures; the successful ones are already on the queue and re-running will
   not duplicate them.

## The business justification

Built from the requirement, not written by you:

> *Content consumption via PSII API. OTC CBIC (APP-52775) to Product Studio II
> (APP-53435) over TCP/443 in DEV. Source: LMP-SAD.docx table 3 row 2.*

Purpose, both parties with their LeanIX ids, the transport, the environment, and
where in the SAD it came from. The last part matters most: the approver can open
the document and check, which is the difference between reviewing a request and
rubber-stamping it.

Note what it does **not** contain - any inference you made about pairing. If a
requirement is `INFERRED`, that was visible in `plan.json` and should have been
resolved with the user then. Do not paper over it in the justification.

## Why the GOV-ID is checked first

An unverified GOV-ID is not rejected by AppCon. It is rejected by a human at
cyber review, days later, with the whole batch already queued behind it. One
call now avoids that, and the check failing usually means the governance record
needs raising before any of this proceeds.

## After this

The connections are **Pending Approval**. They are not approved, and saying so
is wrong in a way that matters - someone will plan a release around it.

From here the transitions belong to other people: CYBER approves or holds,
ENGINEER schedules and implements. Nothing in this package can move them, by
design. Use [`/appcon-status`](appcon-status.prompt.md) to see where they are.
