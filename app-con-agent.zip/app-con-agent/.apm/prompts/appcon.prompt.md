---
mode: agent
description: "Run the whole pipeline from an LMP SAD to submitted AppCon change requests, stopping for review before anything is created."
---

# /appcon

Agent: [appcon-master](../agents/appcon-master.agent.md) |
Instructions: [write-safety](../instructions/write-safety.instructions.md)

Usage: `/appcon <path to SAD.docx> [<root>]`

`<root>` defaults to the current directory. Outputs land in `<root>/out/appcon/`.

This runs the individual commands in order. Use them directly when you want to
stop and look at something in between - which, the first time you point this at
a new SAD, you should.

## Steps

1. **[`/appcon-init`](appcon-init.prompt.md)** - check auth and fetch the API
   spec. Stop here if it fails; every later step needs both.

   If it fails in a way that does not name a cause, run
   [`/appcon-doctor`](appcon-doctor.prompt.md) before debugging the connection.
   It answers "can this package run at all", which is the question you have to
   settle before "can it reach AppCon" means anything.

2. **[`/read-sad`](read-sad.prompt.md)** `<path to SAD.docx>` - extract the
   connectivity table to `out/appcon/sad-rows.json`.

3. **[`/create-requirements`](create-requirements.prompt.md)** - expand the rows.
   If any row is unresolved this stops and asks; that is expected on a first run
   and is not a failure.

4. **[`/create-plan`](create-plan.prompt.md)** - resolve against AppCon,
   read-only. Checks base policy overlap, existing objects and likely
   auto-approval.

5. **Show the plan and stop.**

   Report counts by disposition, then every CREATE entry as
   `consumer → fqdn:port [environment]`, then anything with
   `review.required` and why. Ask explicitly whether to proceed.

   **Nothing below this line runs without the user saying so in reply to that
   question.**

6. **[`/apply-plan`](apply-plan.prompt.md)** - create the objects. Canary with
   `--limit 1` first for anything beyond a handful.

7. **[`/request-approval`](request-approval.prompt.md)** - submit change
   requests. Needs a GOV-ID and its own confirmation.

8. **[`/appcon-status`](appcon-status.prompt.md)** - where everything got to.

## Stop rules

- Any non-zero exit stops the run. Report the script's own message; it names the
  row or the field.
- Exit 2 from step 3 means the document does not state something that is needed.
  Go to [`/create-requirements`](create-requirements.prompt.md) and work through
  it with the user. Do not proceed with the rows that did parse.
- Do not pass `--confirm` anywhere in this command on the user's behalf.

## What this produces

```
out/appcon/
  spec.json          the OpenAPI document this run validated against, as fetched
  sad-rows.json      what the table says, verbatim
  requirements.json  typed requirements, each field marked VERBATIM/PARSED/INFERRED
  plan.json          what would be created, and what already exists
  ledger.json        what was created, written after every single call
```

`plan.json` is the reviewable artefact and `ledger.json` is the record of truth.
Neither is disposable - keep them with the SAD.
