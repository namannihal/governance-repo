---
mode: agent
description: "Check that this machine can run the package at all: Python version, the standard library modules it actually needs, its own modules, schemas, and which environment variables block which commands. Touches no network."
---

# /appcon-doctor

Agent: [appcon-master](../agents/appcon-master.agent.md)

Usage: `/appcon-doctor [<root>] [--json <path>]`

Run this once on a new machine, and again whenever something fails in a way that
does not name a cause. It touches no network and reads no SAD.

## Steps

1. **Run it.**

   ```bash
   python .apm/scripts/python/doctor.py
   ```

   Use `python`, not `python3` - on Windows `python3` is usually a Microsoft
   Store alias stub that prints nothing and exits 9009.

2. **Read the exit code.**

   | Code | Means | Do |
   |---|---|---|
   | 0 | everything present | proceed |
   | 2 | usable, but variables are unset | the read-only steps work; set what the warnings name before `/create-plan` |
   | 4 | something required is missing or broken | stop; nothing else in the package will work |

3. **Report the failing and warning lines verbatim.** Each one says what the
   missing thing is for. Do not summarise four warnings into "some environment
   variables are missing" - which ones are set determines how far the pipeline
   can go.

## What it checks, and why each one is worth a line

**Python 3.10+.** Declared in `apm.yml` and what the tests run against.

**`ssl` and `zlib`.** These are the two standard library modules that genuinely
go missing, in minimal, embedded and container builds. Without `ssl` no AppCon
call works. Without `zlib` a `.docx` opens as an empty archive, because Word
deflates every part - which presents as "the SAD has no tables", a sentence
somebody will believe.

**Its own nine modules import cleanly.** Catches a syntax error or a broken
import before it surfaces mid-batch.

**Each schema is usable by `validate_instance.py`.** The validator refuses
keywords it does not implement rather than skipping them, which is the right
behaviour and a confusing thing to meet for the first time halfway through a
run.

**`requirement_key` still produces `245beaa74614f6a5`.** This value is stamped
into every AppCon object the package creates and is how a re-run recognises its
own work. If it differs on this machine, objects created elsewhere are invisible
here and applying would duplicate them. If this fails, **do not change the pin** -
find out why it moved.

**`os.replace` works in the output directory.** The ledger is rewritten after
every single API call and depends on that being atomic. On a cloud-synced folder
- OneDrive, Dropbox - the sync client can hold a lock on the file being
replaced, and the doctor says so explicitly when the path looks synced.

**Environment variables, per command.** Unset is a warning rather than a
failure, because `/read-sad` and `/create-requirements` need none of them. Each
line names the commands it blocks.

## What it does not check

Whether AppCon is reachable, whether your session is valid, or whether the
tenant exists. That is [`/appcon-init`](appcon-init.prompt.md), which costs a
request and needs the variables this command tells you about.

The split is deliberate: doctor answers "can this package run", init answers
"can it reach AppCon". Diagnosing the second while the first is broken wastes
time.

## What it never does

Print the value of `APPCON_COOKIE`. It reports the length and nothing else - it
is a live session.
