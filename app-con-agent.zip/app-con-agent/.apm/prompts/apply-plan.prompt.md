---
mode: agent
description: "Create the consumers, providers and connections an approved plan calls for. The first command in this package that writes to AppCon."
---

# /apply-plan

Agent: [appcon-submitter](../agents/appcon-submitter.agent.md) |
Instructions: [write-safety](../instructions/write-safety.instructions.md) |
Schema: `schemas/ledger.schema.json`

Usage: `/apply-plan [<root>] [--limit N]`

Everything before this was read-only. This creates real objects in AppCon.

## Prerequisites

- `plan.json` exists and validates.
- The user has seen the CREATE entries - not a summary of them - and said to
  proceed.
- The live spec hash still matches `plan.spec_version`. The script checks; if it
  has changed, re-plan rather than editing the file.

## Steps

1. **Dry run. Always, even after a `--limit 1` canary.**

   ```bash
   python .apm/scripts/python/apply_plan.py \
       --plan <root>/out/appcon/plan.json \
       --requirements <root>/out/appcon/requirements.json \
       --ledger <root>/out/appcon/ledger.json
   ```

   Exits 3 having sent nothing, and prints what it would create. Show that
   output verbatim - it is what the user is agreeing to.

2. **Canary**, for anything beyond two or three entries:

   ```bash
   ... --confirm --limit 1
   ```

   Then look at the object in AppCon. A wrong field name or profile value is
   wrong on every entry; one object is far easier to withdraw than fifteen.

3. **Apply the rest**, with `--confirm`, once the user confirms the canary.

4. **Read the exit code.**

   | Code | Means | Do |
   |---|---|---|
   | 0 | all applied | report the ledger path |
   | 2 | partially applied | name the failures from stderr; the ledger is accurate |
   | 3 | refused | spec mismatch or no `--confirm` - relay the reason |
   | 5 | nothing to create | say so plainly |

5. **Validate the ledger.**

   ```bash
   python .apm/scripts/python/validate_instance.py \
       --schema schemas/ledger.schema.json --document <root>/out/appcon/ledger.json
   ```

## Why re-running is safe

Every object created carries `appcon-agent:<requirement_key>` in its
description, and `ledger.json` is rewritten atomically after each individual
API call - not at the end of the run. A run killed halfway leaves a ledger that
accurately describes what exists. Re-running resumes from there and creates
nothing twice.

So the correct response to a timeout, a 401, or a partial failure is to fix the
cause and re-run the same command. It is not to create the missing objects by
hand: the stamp is what makes the next run idempotent, and you cannot write it
from the UI.

## Refusals, and what they actually mean

- *"requires `<field>` and this script has no value to put there"* - AppCon
  needs something the SAD does not supply. Ask the user which column supplies
  it, then add the alias to the candidate list in `apply_plan.py`. Do not invent
  a value; a provider created without its port is a firewall rule that does not
  match the SAD.
- *"The AppCon API has changed since this plan was made"* - a field valid at
  plan time may not exist now. Re-run
  [`/create-plan`](create-plan.prompt.md).
- *"Ledger was written against a different base URL"* - one deployment's ledger
  replayed against another reports objects as existing that do not.

None of these are worked around. See
[write-safety](../instructions/write-safety.instructions.md).

## What this does not do

Submit anything for approval. Everything created here sits in New, visible only
to your team, until [`/request-approval`](request-approval.prompt.md). That
separation is deliberate - it is the last point at which a mistake costs nobody
else anything.
