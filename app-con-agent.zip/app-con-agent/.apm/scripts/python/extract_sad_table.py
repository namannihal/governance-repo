#!/usr/bin/env python3
"""Read the connectivity requirements table out of an LMP SAD .docx.

No python-docx. A .docx is a zip holding XML, and the parts of it this script
needs - tables, cell text, hyperlink relationships, vertical merges - are a few
dozen lines of ElementTree. The trade is deliberate: a dependency that fails to
install on one engineer's machine turns an extraction step into a step somebody
does by hand, and hand extraction of this table is the thing the package exists
to remove.

Three details in these documents that a naive reader loses:

1. **Cell newlines are data.** The endpoint column holds one FQDN per paragraph.
   Joining paragraphs with a space produces one unparseable string; joining with
   a newline keeps four endpoints.
2. **The visible text and the link target differ.** These tables are full of
   hyperlinks whose display text was edited after the link was made. Both are
   recorded; neither is trusted over the other here.
3. **Vertically merged cells.** Word stores the value once and marks the rows
   below as continuations. Carrying the value down is correct, but a carried
   value is not a value the document states on that row, so the row is flagged
   and the normalizer must treat it as INFERRED.

Usage:
    extract_sad_table.py --docx SAD.docx --out out/sad-rows.json [--table-index N]

Exit: 0 extracted, 2 no table matched the fingerprint, 4 file unreadable.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import zipfile
from xml.etree import ElementTree

from _common import (
    CANNOT_ASSESS, MISCONFIGURED, PROCEED, fail, utc_now, write_json_atomic,
)

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"

# Canonical column key -> tokens that must all appear in the normalised header
# cell. Matching on tokens rather than the full string because these headers
# carry parenthetical instructions ("Delete as appropriate", "Default is All
# unless specified") that differ between SAD revisions while the column does not.
COLUMN_FINGERPRINT: dict[str, tuple[str, ...]] = {
    "connection_type": ("connection", "type"),
    "source_application": ("source", "application"),
    "destination_application": ("destination", "application"),
    "endpoints": ("ip",),
    "protocol_encryption": ("protocol",),
    "authentication_method": ("authentication",),
    "security_proxy": ("security", "proxy"),
    "purpose": ("purpose",),
    "environment": ("environment",),
}

# A table must supply at least these to be the connectivity table. Purpose and
# security proxy are genuinely optional in older SADs; the five below are not,
# because without them there is no requirement to build.
REQUIRED_COLUMNS = frozenset(
    {"source_application", "destination_application", "endpoints",
     "protocol_encryption", "environment"}
)


def normalise(text: str) -> str:
    """Lowercase, collapse whitespace, drop punctuation. For header matching only."""
    return re.sub(r"[^a-z0-9 ]+", " ", text.lower())


def cell_text(cell: ElementTree.Element) -> str:
    """Paragraph-per-line text of a table cell.

    w:br and w:tab inside a run are rendered too - the endpoint column sometimes
    uses line breaks rather than separate paragraphs, and the two look identical
    on screen.
    """
    paragraphs: list[str] = []
    for paragraph in cell.iter(f"{W}p"):
        pieces: list[str] = []
        for node in paragraph.iter():
            if node.tag == f"{W}t":
                pieces.append(node.text or "")
            elif node.tag == f"{W}br":
                pieces.append("\n")
            elif node.tag == f"{W}tab":
                pieces.append(" ")
        paragraphs.append("".join(pieces).strip())
    lines = [line for line in "\n".join(paragraphs).split("\n") if line.strip()]
    return "\n".join(line.strip() for line in lines)


def cell_hyperlinks(cell: ElementTree.Element, relationships: dict[str, str]) -> list[dict]:
    """Link targets in a cell, paired with the text the reader actually sees."""
    found: list[dict] = []
    for link in cell.iter(f"{W}hyperlink"):
        rel_id = link.get(f"{R}id")
        if not rel_id:
            continue
        url = relationships.get(rel_id)
        if not url:
            continue
        text = "".join(node.text or "" for node in link.iter(f"{W}t")).strip()
        found.append({"url": url, "text": text})
    return found


def is_vertical_continuation(cell: ElementTree.Element) -> bool:
    """True when Word marked this cell as merged into the one above.

    A vMerge element with no val, or val="continue", is a continuation. val="restart"
    begins a new merged group and carries the real value.
    """
    for properties in cell.findall(f"{W}tcPr"):
        for merge in properties.findall(f"{W}vMerge"):
            return merge.get(f"{W}val", "continue") != "restart"
    return False


def read_relationships(archive: zipfile.ZipFile) -> dict[str, str]:
    try:
        raw = archive.read("word/_rels/document.xml.rels")
    except KeyError:
        return {}
    root = ElementTree.fromstring(raw)
    return {
        node.get("Id"): node.get("Target")
        for node in root.findall(f"{REL_NS}Relationship")
        if node.get("Id") and node.get("Target")
    }


def match_header(header_cells: list[str]) -> dict[int, str]:
    """Map column position to canonical key. Unmatched columns are dropped."""
    mapping: dict[int, str] = {}
    taken: set[str] = set()
    for index, raw in enumerate(header_cells):
        text = normalise(raw)
        best: str | None = None
        best_score = 0
        for key, tokens in COLUMN_FINGERPRINT.items():
            if key in taken or not all(token in text for token in tokens):
                continue
            # Longer fingerprints win, so "source application" is not stolen by a
            # one-token rule that also happens to match.
            if len(tokens) > best_score:
                best, best_score = key, len(tokens)
        if best:
            mapping[index] = best
            taken.add(best)
    return mapping


def rows_of(table: ElementTree.Element) -> list[list[ElementTree.Element]]:
    """Direct child rows and their direct child cells.

    iter() is wrong here: a nested table would have its rows hoisted into the
    parent and silently invent requirements.
    """
    return [row.findall(f"{W}tc") for row in table.findall(f"{W}tr")]


def extract_table(
    table: ElementTree.Element, relationships: dict[str, str]
) -> tuple[dict[int, str], list[dict]] | None:
    raw_rows = rows_of(table)
    if len(raw_rows) < 2:
        return None

    header_cells = [cell_text(cell) for cell in raw_rows[0]]
    mapping = match_header(header_cells)
    if not REQUIRED_COLUMNS.issubset(set(mapping.values())):
        return None

    carried: dict[str, str] = {}
    rows: list[dict] = []
    for row_index, cells in enumerate(raw_rows[1:]):
        record_cells: dict[str, str] = {}
        hyperlinks: list[dict] = []
        merged = False

        for position, cell in enumerate(cells):
            key = mapping.get(position)
            if key is None:
                continue
            if is_vertical_continuation(cell):
                # Carry the value down, but remember that this row did not state it.
                record_cells[key] = carried.get(key, "")
                merged = True
                continue
            text = cell_text(cell)
            record_cells[key] = text
            carried[key] = text
            for link in cell_hyperlinks(cell, relationships):
                hyperlinks.append({"column": key, **link})

        if not any(value.strip() for value in record_cells.values()):
            continue  # spacer row

        record: dict = {"row_index": row_index, "cells": record_cells}
        if hyperlinks:
            record["hyperlinks"] = hyperlinks
        if merged:
            record["merged_from_above"] = True
        rows.append(record)

    return mapping, rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--docx", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--table-index", type=int, default=None,
        help="Force a specific table. Use when a SAD holds more than one "
             "connectivity table and the fingerprint matches several.",
    )
    args = parser.parse_args()

    if not os.path.isfile(args.docx):
        fail(f"No such file: {args.docx}", MISCONFIGURED)

    try:
        with zipfile.ZipFile(args.docx) as archive:
            relationships = read_relationships(archive)
            document = ElementTree.fromstring(archive.read("word/document.xml"))
    except (zipfile.BadZipFile, KeyError, ElementTree.ParseError) as error:
        fail(
            f"{args.docx} is not a readable .docx ({error}). A .doc saved with the "
            f".docx extension is the usual cause; re-save it from Word.",
            MISCONFIGURED,
        )

    tables = document.iter(f"{W}tbl")
    matches: list[tuple[int, dict[int, str], list[dict]]] = []
    for index, table in enumerate(tables):
        if args.table_index is not None and index != args.table_index:
            continue
        result = extract_table(table, relationships)
        if result is not None:
            matches.append((index, result[0], result[1]))

    if not matches:
        fail(
            "No table matched the connectivity fingerprint. Required columns: "
            + ", ".join(sorted(REQUIRED_COLUMNS))
            + ". Nothing was written - this is a 'cannot assess', not an empty "
              "result, and must not be reported as 'the SAD has no connectivity'.",
            CANNOT_ASSESS,
        )

    if len(matches) > 1 and args.table_index is None:
        indices = ", ".join(str(index) for index, _, _ in matches)
        fail(
            f"{len(matches)} tables matched the fingerprint (indices: {indices}). "
            f"Re-run with --table-index to choose. Merging them automatically "
            f"would hide a second, different requirement set.",
            CANNOT_ASSESS,
        )

    table_index, mapping, rows = matches[0]
    header = [""] * (max(mapping) + 1 if mapping else 0)
    for position, key in mapping.items():
        header[position] = key

    write_json_atomic(args.out, {
        "source_document": os.path.basename(args.docx),
        "extracted_at": utc_now(),
        "table_index": table_index,
        "header": header,
        "rows": rows,
    })

    merged_count = sum(1 for row in rows if row.get("merged_from_above"))
    print(f"Extracted {len(rows)} rows from table {table_index} -> {args.out}")
    if merged_count:
        print(
            f"  {merged_count} rows inherit a vertically merged cell. Those values "
            f"are carried, not stated, and will be typed INFERRED."
        )
    missing = sorted(set(COLUMN_FINGERPRINT) - set(mapping.values()))
    if missing:
        print(f"  Columns not present in this SAD: {', '.join(missing)}")
    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
