#!/usr/bin/env python3
"""Validate a JSON document against a subset of JSON Schema.

Why a subset rather than the `jsonschema` package: this package is run inside a
Copilot session on whatever machine the engineer happens to have, and a pip
install that fails halfway turns a validation step into a skipped validation
step. The subset below covers everything the schemas in `schemas/` actually use,
and refuses loudly when a schema uses a keyword it does not implement - an
unimplemented keyword is silently-skipped validation, which is worse than none.

Supported: type, properties, required, additionalProperties, items, enum,
pattern, minimum, maximum, minLength, minItems, const, $ref (local $defs only).

Usage:
    validate_instance.py --schema schemas/plan.schema.json --document out/plan.json

Exit: 0 valid, 3 invalid (errors listed), 4 schema unusable.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from typing import Any

from _common import MISCONFIGURED, PROCEED, REFUSED, fail, read_json

KNOWN_KEYWORDS = {
    "$schema", "$defs", "$ref", "title", "description", "type", "properties",
    "required", "additionalProperties", "items", "enum", "pattern", "minimum",
    "maximum", "minLength", "minItems", "const",
}

TYPE_MAP = {
    "object": dict,
    "array": list,
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "null": type(None),
}


class SchemaUnusable(Exception):
    """The schema asks for something this validator does not implement."""


def _resolve(node: Any, root: dict) -> dict:
    """Follow a local $ref. Remote refs are refused rather than ignored."""
    if not isinstance(node, dict) or "$ref" not in node:
        return node
    ref = node["$ref"]
    if not ref.startswith("#/"):
        raise SchemaUnusable(f"only local $ref is supported, got {ref!r}")
    target: Any = root
    for segment in ref[2:].split("/"):
        if not isinstance(target, dict) or segment not in target:
            raise SchemaUnusable(f"$ref {ref!r} does not resolve")
        target = target[segment]
    return _resolve(target, root)


def _check_keywords(schema: dict) -> None:
    unknown = set(schema) - KNOWN_KEYWORDS
    if unknown:
        raise SchemaUnusable(
            "schema uses keywords this validator does not implement: "
            + ", ".join(sorted(unknown))
            + ". Extend validate_instance.py or simplify the schema; do not "
              "ignore this, because an unimplemented keyword validates nothing."
        )


def validate(instance: Any, schema: dict, root: dict, path: str = "$") -> list[str]:
    """Return a list of human-readable errors. Empty means valid."""
    schema = _resolve(schema, root)
    _check_keywords(schema)
    errors: list[str] = []

    expected = schema.get("type")
    if expected is not None:
        python_type = TYPE_MAP.get(expected)
        if python_type is None:
            raise SchemaUnusable(f"unknown type {expected!r} at {path}")
        # bool is a subclass of int in Python; an integer field must not accept True.
        if expected in ("integer", "number") and isinstance(instance, bool):
            return [f"{path}: expected {expected}, got boolean"]
        if not isinstance(instance, python_type):
            got = type(instance).__name__
            return [f"{path}: expected {expected}, got {got}"]

    if "const" in schema and instance != schema["const"]:
        errors.append(f"{path}: expected the constant {schema['const']!r}")

    if "enum" in schema and instance not in schema["enum"]:
        allowed = ", ".join(repr(v) for v in schema["enum"])
        errors.append(f"{path}: {instance!r} is not one of [{allowed}]")

    if isinstance(instance, str):
        pattern = schema.get("pattern")
        if pattern is not None and re.search(pattern, instance) is None:
            errors.append(f"{path}: {instance!r} does not match /{pattern}/")
        minimum_length = schema.get("minLength")
        if minimum_length is not None and len(instance) < minimum_length:
            errors.append(f"{path}: shorter than minLength {minimum_length}")

    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{path}: {instance} is below minimum {schema['minimum']}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{path}: {instance} is above maximum {schema['maximum']}")

    if isinstance(instance, list):
        minimum_items = schema.get("minItems")
        if minimum_items is not None and len(instance) < minimum_items:
            errors.append(f"{path}: fewer than minItems {minimum_items}")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(instance):
                errors += validate(item, item_schema, root, f"{path}[{index}]")

    if isinstance(instance, dict):
        for name in schema.get("required", []):
            if name not in instance:
                errors.append(f"{path}: missing required property {name!r}")

        properties = schema.get("properties", {})
        for name, value in instance.items():
            if name in properties:
                errors += validate(value, properties[name], root, f"{path}.{name}")
                continue
            extra = schema.get("additionalProperties", True)
            if extra is False:
                errors.append(f"{path}: unexpected property {name!r}")
            elif isinstance(extra, dict):
                errors += validate(value, extra, root, f"{path}.{name}")

    return errors


def check_schema(schema: Any, root: dict, path: str = "$", seen: set | None = None) -> None:
    """Walk every subschema and refuse keywords we do not implement.

    validate() only checks the keywords on branches the instance reaches, so a
    schema can carry an unimplemented keyword deep in `properties` for months
    and only raise the first time a document happens to populate that field.
    Since an unimplemented keyword validates nothing, that is a silent hole
    rather than a loud one. This walks the schema itself, instance or no
    instance, so the answer to "is this schema usable" does not depend on which
    document you happened to hand it.
    """
    if not isinstance(schema, dict):
        return
    if "$ref" in schema:
        # Guard against a schema that refs itself; the ref target is walked once
        # at its own location rather than at every use.
        seen = seen or set()
        if schema["$ref"] in seen:
            return
        seen = seen | {schema["$ref"]}
        check_schema(_resolve(schema, root), root, path, seen)
        return

    _check_keywords(schema)
    if "type" in schema and schema["type"] not in TYPE_MAP:
        raise SchemaUnusable(f"unknown type {schema['type']!r} at {path}")

    for name, subschema in schema.get("properties", {}).items():
        check_schema(subschema, root, f"{path}.{name}", seen)
    for name, subschema in schema.get("$defs", {}).items():
        check_schema(subschema, root, f"$defs.{name}", seen)
    if isinstance(schema.get("items"), dict):
        check_schema(schema["items"], root, f"{path}[]", seen)
    if isinstance(schema.get("additionalProperties"), dict):
        check_schema(schema["additionalProperties"], root, f"{path}.*", seen)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--document", required=True)
    parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress the success line. Errors are always printed.",
    )
    args = parser.parse_args()

    try:
        schema = read_json(args.schema)
    except (OSError, json.JSONDecodeError) as error:
        fail(f"Cannot read schema {args.schema}: {error}", MISCONFIGURED)
    try:
        document = read_json(args.document)
    except (OSError, json.JSONDecodeError) as error:
        fail(f"Cannot read document {args.document}: {error}", REFUSED)

    try:
        # Whole schema first: "this schema is usable" must not depend on which
        # branches this particular document happens to reach.
        check_schema(schema, schema)
        errors = validate(document, schema, schema)
    except SchemaUnusable as error:
        fail(f"Schema {args.schema} is unusable: {error}", MISCONFIGURED)

    if errors:
        print(f"{args.document} failed validation against {args.schema}:", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return REFUSED

    if not args.quiet:
        print(f"{args.document} is valid against {args.schema}.")
    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
