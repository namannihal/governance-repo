#!/usr/bin/env python3
"""Report where every connection this package created has reached.

Read-only. Renders the AppCon status machine - New, Pending Approval, On Hold,
Approved/Pending Implementation, Scheduled, Implemented - against what is in the
ledger, so "where has this batch got to" is one command rather than a morning
spent in the UI.

A status this script could not read is reported as UNKNOWN and counted separately.
It is never folded into New, which is the status that would make an un-submitted
connection and an unreadable one look identical.

Usage:
    track_status.py --ledger out/ledger.json [--requirements out/requirements.json]
                    [--json out/status.json]

Exit: 0 read cleanly, 2 one or more statuses unknown.
"""

from __future__ import annotations

import argparse
import sys

from _common import CANNOT_ASSESS, MISCONFIGURED, PROCEED, fail, read_json, utc_now, write_json_atomic
from appcon_client import AppConClient, AppConError
from plan_connections import pick, text_of

# Order matters: this is the left-to-right order of the status machine, and the
# report reads as progress only if it is printed in that order.
STATUSES = (
    "NEW",
    "PENDING_APPROVAL",
    "ON_HOLD",
    "APPROVED_PENDING_IMPLEMENTATION",
    "SCHEDULED",
    "IMPLEMENTED",
    "UNKNOWN",
)

# AppCon's own spelling varies by field; match on distinctive substrings instead.
# Checked most-specific first - "approved pending implementation" contains
# "approved", and testing in the wrong order collapses two distinct states.
PATTERNS = (
    ("APPROVED_PENDING_IMPLEMENTATION", ("pendingimplementation", "approvedpending")),
    ("PENDING_APPROVAL", ("pendingapproval",)),
    ("ON_HOLD", ("onhold",)),
    ("SCHEDULED", ("scheduled",)),
    ("IMPLEMENTED", ("implemented",)),
    ("NEW", ("new",)),
)

# Whitespace, underscores, hyphens and slashes all separate words somewhere in
# AppCon's vocabulary - "On Hold", "ON_HOLD" and "on-hold" are the same state.
# Stripping every separator before matching means the needles above describe the
# words, not one field's spelling of them.
SEPARATORS = str.maketrans("", "", " \t\n\r_-/")


def classify(connection: object) -> str:
    raw = pick(connection, "status", "connectionStatus", "state")
    text = str(raw) if raw is not None else text_of(connection)
    text = text.lower().translate(SEPARATORS)
    for status, needles in PATTERNS:
        if any(needle in text for needle in needles):
            return status
    return "UNKNOWN"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", required=True)
    parser.add_argument("--requirements", default=None)
    parser.add_argument("--json", dest="json_out", default=None)
    args = parser.parse_args()

    try:
        ledger = read_json(args.ledger)
    except (OSError, ValueError) as error:
        fail(f"Cannot read {args.ledger}: {error}", MISCONFIGURED)

    requirements: dict = {}
    if args.requirements:
        try:
            requirements = {
                r["requirement_key"]: r
                for r in read_json(args.requirements)["requirements"]
            }
        except (OSError, ValueError, KeyError):
            requirements = {}  # labels only; absence does not affect correctness

    connections = [e for e in ledger["entries"] if e["object_type"] == "CONNECTION"]
    if not connections:
        print("The ledger holds no connections yet. Run apply_plan.py first.")
        return PROCEED

    client = AppConClient()
    counts = {status: 0 for status in STATUSES}
    rows: list[dict] = []

    for entry in connections:
        key = entry["requirement_key"]
        try:
            payload = client.get(f"/connections/{entry['appcon_id']}")
            status = classify(AppConClient.unwrap(payload))
        except AppConError as error:
            status = "UNKNOWN"
            rows.append({"requirement_key": key, "status": status, "error": str(error)})
        else:
            rows.append({"requirement_key": key, "status": status})
        counts[status] += 1

    print(f"{len(connections)} connection(s), as at {utc_now()}\n")
    width = max(len(status) for status in STATUSES)
    for status in STATUSES:
        count = counts[status]
        if count:
            bar = "#" * min(count, 40)
            print(f"  {status.replace('_', ' ').title():<{width}}  {count:>4}  {bar}")

    if counts["UNKNOWN"]:
        print(f"\n{counts['UNKNOWN']} connection(s) could not be read:", file=sys.stderr)
        for row in rows:
            if row["status"] == "UNKNOWN":
                requirement = requirements.get(row["requirement_key"])
                label = (
                    f"{requirement['endpoint']['fqdn']} [{requirement['environment']}]"
                    if requirement else row["requirement_key"]
                )
                print(f"  {label}: {row.get('error', 'status field not recognised')}",
                      file=sys.stderr)
        print(
            "\nUNKNOWN is counted separately on purpose - it is not New, and "
            "reporting it as New would make an unsubmitted connection and an "
            "unreadable one look the same.",
            file=sys.stderr,
        )

    if args.json_out:
        write_json_atomic(args.json_out, {
            "generated_at": utc_now(),
            "counts": counts,
            "connections": rows,
        })
        print(f"\nWritten to {args.json_out}")

    return CANNOT_ASSESS if counts["UNKNOWN"] else PROCEED


if __name__ == "__main__":
    sys.exit(main())
