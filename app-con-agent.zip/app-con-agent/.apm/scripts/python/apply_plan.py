#!/usr/bin/env python3
"""Create the objects an approved plan calls for. The only script here that writes.

Three properties matter more than anything else in this file.

**It executes the plan, it does not re-derive it.** The only decisions read are the
ones in plan.json, which is the document a human approved. If the SAD changed since
the plan was made, this script does not notice and must not - re-plan instead.

**It is idempotent, and it is interrupted often.** Every created object carries a
stamp containing its requirement key, and the ledger is rewritten atomically after
each individual call rather than at the end of the run. A run killed halfway leaves
a ledger that accurately describes what exists. Re-running resumes.

**It fits request bodies to the live spec instead of asserting them.** We do not
know AppCon's exact field names - the inventory lists schema names, not their
contents. So for each value we hold, this script offers the spec several plausible
field names and uses whichever one the spec actually documents. If a field the spec
marks required has no value we can supply, the entry is refused rather than sent
half-populated: a provider created without its port is a firewall rule that does
not match the SAD.

Usage:
    apply_plan.py --plan out/plan.json --requirements out/requirements.json \\
                  --ledger out/ledger.json --confirm [--limit N]

Exit: 0 everything applied, 2 partially applied (ledger is accurate), 3 refused,
      4 misconfigured, 5 nothing left to do.
"""

from __future__ import annotations

import argparse
import sys
from typing import Any, Iterable

from _common import (
    ALREADY_EXISTS, CANNOT_ASSESS, MISCONFIGURED, PROCEED, REFUSED, fail,
    read_json, utc_now, write_json_atomic,
)
from appcon_client import AppConClient, AppConError, SpecViolation
from plan_connections import identifier, stamp_for


class Ledger:
    """What exists, written after every successful call.

    Deliberately not buffered. A ledger flushed at the end of the run is a ledger
    that does not survive the interruption it exists to survive.
    """

    def __init__(self, path: str, base_url: str, tenant_id: str) -> None:
        self.path = path
        try:
            existing = read_json(path)
        except (OSError, ValueError):
            existing = {"base_url": base_url, "tenant_id": tenant_id, "entries": []}

        if existing.get("base_url") not in (None, base_url):
            fail(
                f"Ledger {path} was written against {existing['base_url']} but this "
                f"run targets {base_url}. Replaying one deployment's ledger against "
                f"another would report objects as existing that do not.",
                MISCONFIGURED,
            )
        self.document = existing
        self.document["base_url"] = base_url
        self.document["tenant_id"] = tenant_id
        self.document.setdefault("entries", [])

    def has(self, requirement_key: str, object_type: str) -> str | None:
        for entry in self.document["entries"]:
            if entry["requirement_key"] == requirement_key and entry["object_type"] == object_type:
                return entry["appcon_id"]
        return None

    def record(self, requirement_key: str, object_type: str, appcon_id: str) -> None:
        self.document["entries"].append({
            "requirement_key": requirement_key,
            "object_type": object_type,
            "appcon_id": appcon_id,
            "created_at": utc_now(),
            "idempotency_stamp": stamp_for(requirement_key),
        })
        write_json_atomic(self.path, self.document)


def fit_body(
    client: AppConClient,
    method: str,
    path: str,
    candidates: Iterable[tuple[tuple[str, ...], Any]],
) -> dict:
    """Build a request body using only field names the spec documents.

    `candidates` is (aliases, value) pairs: aliases are the names this field might
    plausibly carry, most likely first. The first alias the spec knows wins.

    Raises SpecViolation when the spec marks a field required and none of our
    candidates map to it. Sending a partially populated body to AppCon creates a
    real object that does not match the SAD, which is harder to find and fix than
    a refusal here.
    """
    properties = client._body_properties(method, path)
    if properties is None:
        raise SpecViolation(f"{method} {path} documents no JSON request body.")
    allowed, required = properties

    body: dict = {}
    placed: set[str] = set()
    unplaceable: list[str] = []
    for aliases, value in candidates:
        if value is None:
            continue
        for alias in aliases:
            match = next((name for name in allowed if name.lower() == alias.lower()), None)
            if match is not None:
                body[match] = value
                placed.add(match)
                break
        else:
            unplaceable.append(aliases[0])

    missing_required = sorted(required - placed)
    if missing_required:
        raise SpecViolation(
            f"{method} {path} requires {', '.join(missing_required)} and this script "
            f"has no value to put there. Add it to the candidate list in apply_plan.py "
            f"once you know which SAD column supplies it. Values we hold but could not "
            f"place: {', '.join(unplaceable) or 'none'}."
        )
    return body


def create_provider(client: AppConClient, requirement: dict, hosting_environment_id: str) -> str:
    path = f"/hosting-environments/{hosting_environment_id}/providers"
    endpoint = requirement["endpoint"]
    transport = requirement["transport"]
    stamp = stamp_for(requirement["requirement_key"])
    description = f"{requirement['purpose']} [{stamp}]"

    body = fit_body(client, "POST", path, [
        (("name", "providerName", "displayName"), endpoint["fqdn"]),
        (("description", "comment", "notes"), description),
        (("fqdns", "fqdn", "hostnames", "targets"), [endpoint["fqdn"]]),
        (("protocolPortAssociations", "protocolPorts", "ports"),
         [{"protocol": transport["protocol"], "port": transport["port"]}]),
        (("profile", "providerProfile"), "PUBLIC"),
        (("environment", "environmentType"), requirement["environment"]),
    ])
    payload = client.request("POST", path, body=body)
    provider_id = identifier(AppConClient.unwrap(payload))
    if not provider_id:
        raise AppConError(
            f"Provider creation returned no id for {endpoint['fqdn']}. The object may "
            f"exist and be unfindable; check AppCon before re-running."
        )
    return provider_id


def create_consumer(client: AppConClient, requirement: dict, hosting_environment_id: str) -> str:
    path = f"/hosting-environments/{hosting_environment_id}/consumers"
    stamp = stamp_for(requirement["requirement_key"])
    body = fit_body(client, "POST", path, [
        (("name", "consumerName", "displayName"),
         f"{requirement['consumer']['name']} ({requirement['environment']})"),
        (("description", "comment", "notes"), f"{requirement['purpose']} [{stamp}]"),
        (("environment", "environmentType"), requirement["environment"]),
    ])
    payload = client.request("POST", path, body=body)
    consumer_id = identifier(AppConClient.unwrap(payload))
    if not consumer_id:
        raise AppConError("Consumer creation returned no id.")
    return consumer_id


def create_connection(
    client: AppConClient, requirement: dict, consumer_id: str, provider_id: str
) -> str:
    stamp = stamp_for(requirement["requirement_key"])
    body = fit_body(client, "POST", "/connections", [
        (("consumerId", "consumer"), consumer_id),
        (("providerId", "provider"), provider_id),
        (("description", "comment", "notes"), f"{requirement['purpose']} [{stamp}]"),
        (("profile", "connectionProfile"), "PUBLIC"),
    ])
    payload = client.request("POST", "/connections", body=body)
    connection_id = identifier(AppConClient.unwrap(payload))
    if not connection_id:
        raise AppConError("Connection creation returned no id.")
    return connection_id


def apply_entry(
    client: AppConClient, requirement: dict, entry: dict, ledger: Ledger
) -> tuple[bool, str]:
    key = requirement["requirement_key"]
    resolved = entry.get("resolved", {})
    consumer_he = resolved.get("consumer_hosting_environment_id")
    provider_he = resolved.get("provider_hosting_environment_id")
    if not consumer_he or not provider_he:
        return False, "Plan entry carries no hosting environment ids; re-plan."

    consumer_id = ledger.has(key, "CONSUMER")
    if consumer_id is None:
        consumer_id = create_consumer(client, requirement, consumer_he)
        ledger.record(key, "CONSUMER", consumer_id)

    provider_id = ledger.has(key, "PROVIDER")
    if provider_id is None:
        provider_id = create_provider(client, requirement, provider_he)
        ledger.record(key, "PROVIDER", provider_id)

    connection_id = ledger.has(key, "CONNECTION")
    if connection_id is None:
        connection_id = create_connection(client, requirement, consumer_id, provider_id)
        ledger.record(key, "CONNECTION", connection_id)

    return True, connection_id


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--requirements", required=True)
    parser.add_argument("--ledger", required=True)
    parser.add_argument(
        "--confirm", action="store_true",
        help="Required. Without it this script reports what it would do and exits 3.",
    )
    parser.add_argument(
        "--limit", type=int, default=None,
        help="Apply at most N entries. Use 1 for a canary before committing the batch.",
    )
    args = parser.parse_args()

    try:
        plan = read_json(args.plan)
        requirements_document = read_json(args.requirements)
    except (OSError, ValueError) as error:
        fail(f"Cannot read inputs: {error}", MISCONFIGURED)

    requirements = {r["requirement_key"]: r for r in requirements_document["requirements"]}
    actionable = [entry for entry in plan["entries"] if entry["disposition"] == "CREATE"]
    if args.limit is not None:
        actionable = actionable[: args.limit]

    if not actionable:
        print("Plan holds nothing to create. Nothing was sent to AppCon.")
        return ALREADY_EXISTS

    if not args.confirm:
        print(f"Would create {len(actionable)} connection(s) in {plan['base_url']}:")
        for entry in actionable:
            requirement = requirements.get(entry["requirement_key"])
            if requirement:
                print(
                    f"  {requirement['consumer']['lean_ix_id']} -> "
                    f"{requirement['endpoint']['fqdn']}:{requirement['transport']['port']} "
                    f"[{requirement['environment']}]"
                )
        print("\nRe-run with --confirm to apply. Nothing was sent.")
        return REFUSED

    client = AppConClient()
    try:
        live_spec = client.spec_hash()
    except AppConError as error:
        fail(f"{error}\nNothing was sent.", CANNOT_ASSESS)

    if live_spec != plan["spec_version"]:
        fail(
            f"The AppCon API has changed since this plan was made (plan "
            f"{plan['spec_version']}, live {live_spec}). A field that was valid at "
            f"plan time may no longer exist. Re-run plan_connections.py. Nothing "
            f"was sent.",
            REFUSED,
        )

    ledger = Ledger(args.ledger, plan["base_url"], plan["tenant_id"])
    applied = 0
    failures: list[tuple[str, str]] = []

    for entry in actionable:
        key = entry["requirement_key"]
        requirement = requirements.get(key)
        if requirement is None:
            failures.append((key, "Plan references a requirement absent from the requirements file."))
            continue
        try:
            ok, detail = apply_entry(client, requirement, entry, ledger)
        except (AppConError, SpecViolation) as error:
            failures.append((key, str(error)))
            continue
        if ok:
            applied += 1
            print(
                f"  created {requirement['consumer']['lean_ix_id']} -> "
                f"{requirement['endpoint']['fqdn']}:{requirement['transport']['port']} "
                f"[{requirement['environment']}] connection {detail}"
            )
        else:
            failures.append((key, detail))

    print(f"\nApplied {applied} of {len(actionable)}. Ledger: {args.ledger}")

    if failures:
        print(f"\n{len(failures)} entr(ies) failed:", file=sys.stderr)
        for key, reason in failures:
            print(f"  {key}: {reason}", file=sys.stderr)
        print(
            "\nThe ledger records everything that did succeed, so re-running after "
            "fixing these will not duplicate anything.",
            file=sys.stderr,
        )
        return CANNOT_ASSESS

    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
