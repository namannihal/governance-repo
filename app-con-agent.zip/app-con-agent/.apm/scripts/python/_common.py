"""Shared helpers: exit codes, atomic writes, and the requirement key.

Kept in one place because three of these are correctness-critical and were
previously easy to get subtly different in each script.

The exit codes are the house convention and the reason this package can be run
from a prompt without the model interpreting failure. In particular `CANNOT_ASSESS`
is not a soft failure: a check that did not run must never be reported as a check
that passed.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from typing import Any

# House exit codes. Mirrored in apm.yml - change both or neither.
PROCEED = 0
CANNOT_ASSESS = 2
REFUSED = 3
MISCONFIGURED = 4
ALREADY_EXISTS = 5


def utc_now() -> str:
    """ISO-8601 in UTC, second precision. Used for every timestamp we emit."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def requirement_key(
    consumer_lean_ix: str,
    provider_lean_ix: str,
    fqdn: str,
    protocol: str,
    port: int,
    environment: str,
    cutover_state: str,
) -> str:
    """The identity of a connectivity requirement.

    This value is stamped into the AppCon objects we create and is how a re-run
    recognises its own previous work. Two consequences follow, and both matter
    more than they look:

    1. It must not depend on anything cosmetic. Application display names,
       cell whitespace and URL schemes are all excluded, because a SAD edit that
       retitles an application must not orphan a live connection.
    2. It must never change. If it does, every object created by an earlier
       version becomes invisible to this one and the next apply run duplicates
       the lot. test_all.py pins the output for a known input for exactly this
       reason - if that test fails, the fix is almost never to update the test.
    """
    parts = [
        consumer_lean_ix.strip().upper(),
        provider_lean_ix.strip().upper(),
        fqdn.strip().lower().rstrip("."),
        protocol.strip().upper(),
        str(int(port)),
        environment.strip().upper(),
        cutover_state.strip().upper(),
    ]
    joined = "|".join(parts)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:16]


def read_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json_atomic(path: str, payload: Any) -> None:
    """Write via a temp file in the same directory, then replace.

    The ledger is rewritten after every single successful API call, so a
    half-written file here means a run that cannot recover. os.replace is atomic
    on both POSIX and Windows when source and destination share a volume, which
    is why the temp file is placed next to the target rather than in /tmp.
    """
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=directory, delete=False, suffix=".tmp"
    )
    try:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        handle.close()
        os.replace(handle.name, path)
    except BaseException:
        handle.close()
        if os.path.exists(handle.name):
            os.unlink(handle.name)
        raise


def fail(message: str, code: int) -> None:
    """Print to stderr and exit. Every refusal in this package goes through here."""
    print(message, file=sys.stderr)
    sys.exit(code)


def require_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        fail(
            f"{name} is not set. See the environment section of apm.yml.",
            MISCONFIGURED,
        )
    return value
