#!/usr/bin/env python3
"""Expand SAD rows into one connectivity requirement per connection AppCon needs.

This is the script the package is really about, and the interesting thing it does
is refuse.

One row of the SAD table reads:

    Source: OTC CBIC (APP-52775)   Destination: Product Studio II (APP-53435)
    Endpoints: dev.temp.psii.lseg.com  (after cutover dev.psii.lseg.com)
               qa.temp.psii.lseg.com   (after cutover qa.psii.lseg.com)
               uat.temp.psii.lseg.com  (after cutover uat.psii.lseg.com)
               ppe.temp.psii.lseg.com  (after cutover ppe.psii.lseg.com)
    Environment: Dev, CI, Alpha & Pre-Prod

Four environments, four endpoints. The obvious move is a cross product, and the
obvious move is wrong twice over: it produces sixteen connections where at most
four are wanted, and it pairs CI with a hostname that says `uat`. Look at the two
lists again - the declared environments are Dev, CI, Alpha, Pre-Prod, and the
hostnames say dev, qa, uat, ppe. Those sets do not correspond. Nothing in the
document says how they correspond.

So this script matches endpoints to environments by hostname prefix, and when the
match is not a bijection it emits nothing for that row, records why under
`unresolved`, and exits 2. A human or the normalizer agent then states the pairing
explicitly. Sixteen wrong firewall requests are much more expensive than one
question.

Usage:
    expand_requirements.py --rows out/sad-rows.json --out out/requirements.json
                           [--cutover-policy current|post|both]
                           [--pairing row_index=ENV:fqdn,ENV:fqdn ...]

Exit: 0 all rows expanded, 2 at least one row unresolved (the rest still written),
      4 input unreadable.
"""

from __future__ import annotations

import argparse
import re
import sys

from _common import (
    CANNOT_ASSESS, MISCONFIGURED, PROCEED, fail, read_json, requirement_key,
    utc_now, write_json_atomic,
)

ENVIRONMENTS = ("DEV", "CI", "QA", "UAT", "ALPHA", "PRE_PROD", "PROD")

# Free text in the Environment column -> enum. Deliberately not fuzzy: an
# environment we cannot name exactly is an environment we must not guess.
ENVIRONMENT_WORDS = {
    "dev": "DEV", "development": "DEV",
    "ci": "CI",
    "qa": "QA", "test": "QA",
    "uat": "UAT",
    "alpha": "ALPHA",
    "preprod": "PRE_PROD", "pre prod": "PRE_PROD", "pre-prod": "PRE_PROD",
    "ppe": "PRE_PROD", "preproduction": "PRE_PROD", "staging": "PRE_PROD",
    "prod": "PROD", "production": "PROD", "live": "PROD",
}

# Leftmost hostname label -> environment. The same table, read from the other side.
HOST_PREFIX = {
    "dev": "DEV", "ci": "CI", "qa": "QA", "uat": "UAT",
    "alpha": "ALPHA", "ppe": "PRE_PROD", "preprod": "PRE_PROD",
    "stg": "PRE_PROD", "prod": "PROD", "www": "PROD",
}

# Tolerant about the separator because these cells are hand-typed: "APP-53435",
# "APP- 53435" and "APP--52208" all appear, and an en-dash arrives whenever Word
# autocorrects. Still requires at least one dash, so a bare "APP 12345" is not
# silently accepted as an id.
APPLICATION_PATTERN = re.compile(r"\bAPP\s*[-‐-―][\s\-‐-―]*(\d+)\b", re.IGNORECASE)
CUTOVER_PATTERN = re.compile(r"\(\s*after\s+cutover\s*:?\s*(.+?)\s*\)", re.IGNORECASE)
HOST_PATTERN = re.compile(r"(?:[a-z0-9-]+\.)+[a-z]{2,}", re.IGNORECASE)


def parse_party(cell: str) -> dict | None:
    """'Product Studio II (APP-53435)' -> id and name.

    A cell without a well-formed APP- id returns None and the row goes to
    `unresolved`. The LeanIX id is the join key into AppCon; a name alone cannot
    be resolved to an application without guessing, and guessing here would point
    a firewall rule at the wrong system.
    """
    match = APPLICATION_PATTERN.search(cell)
    if not match:
        return None
    lean_ix_id = f"APP-{match.group(1)}"
    name = APPLICATION_PATTERN.sub("", cell)
    # Strip the brackets the id lived in, and the trailing dashes these cells use.
    name = re.sub(r"[()]", " ", name)
    name = re.sub(r"\s+", " ", name).strip(" -–—,;")
    return {"lean_ix_id": lean_ix_id, "name": name or lean_ix_id}


def parse_environments(cell: str) -> tuple[list[str], str | None]:
    """'Dev, CI, Alpha & Pre-Prod' -> ['DEV','CI','ALPHA','PRE_PROD'].

    Returns (environments, problem). 'All' is a problem, not an expansion: the
    column header says the default is All, but AppCon needs named environments and
    this script has no way to enumerate which ones an application actually has.
    """
    text = cell.strip()
    if not text:
        return [], "Environment cell is empty."
    if re.fullmatch(r"all", text, re.IGNORECASE):
        return [], (
            "Environment is 'All'. Name the environments explicitly - this script "
            "cannot enumerate which environments the application has, and creating "
            "connections for environments that do not exist raises change requests "
            "nobody can implement."
        )

    tokens = [token.strip() for token in re.split(r"[,&/]|\band\b", text, flags=re.IGNORECASE)]
    found: list[str] = []
    unknown: list[str] = []
    for token in tokens:
        if not token:
            continue
        key = re.sub(r"[^a-z ]+", " ", token.lower()).strip()
        key = re.sub(r"\s+", " ", key)
        resolved = ENVIRONMENT_WORDS.get(key) or ENVIRONMENT_WORDS.get(key.replace(" ", ""))
        if resolved is None:
            unknown.append(token)
        elif resolved not in found:
            found.append(resolved)

    if unknown:
        return found, f"Unrecognised environment name(s): {', '.join(unknown)}."
    if not found:
        return [], f"No environment could be read from {text!r}."
    return found, None


def parse_endpoints(cell: str) -> list[dict]:
    """One entry per host, with its post-cutover twin attached where present.

    Both the current host and the replacement are recorded. Which of them gets
    raised is decided by --cutover-policy, not here, because that is a scheduling
    decision and this script does not make those.
    """
    endpoints: list[dict] = []
    for line in cell.split("\n"):
        line = line.strip()
        if not line:
            continue
        cutover_match = CUTOVER_PATTERN.search(line)
        post_cutover_host = None
        if cutover_match:
            hosts = HOST_PATTERN.findall(cutover_match.group(1))
            post_cutover_host = hosts[0].lower() if hosts else None
            line = CUTOVER_PATTERN.sub("", line)
        hosts = HOST_PATTERN.findall(line)
        if not hosts:
            continue
        endpoints.append({
            "current": hosts[0].lower(),
            "post_cutover": post_cutover_host,
        })
    return endpoints


def parse_transport(cell: str) -> tuple[dict | None, str | None]:
    """'443 / HTTPS TLS 1.2' -> protocol, port, encryption, application protocol."""
    text = cell.strip()
    if not text:
        return None, "Protocol/encryption cell is empty."

    port_match = re.search(r"\b(\d{1,5})\b", text)
    if not port_match:
        return None, f"No port number in {text!r}."
    port = int(port_match.group(1))
    if not 1 <= port <= 65535:
        return None, f"Port {port} is out of range."

    upper = text.upper()
    if re.search(r"\bUDP\b", upper):
        protocol = "UDP"
    elif re.search(r"\bICMP\b", upper):
        protocol = "ICMP"
    else:
        # HTTPS, HTTP, TLS, TCP and a bare port number all mean TCP here.
        protocol = "TCP"

    application_protocol = None
    for candidate in ("HTTPS", "HTTP", "GRPC", "AMQP", "SFTP", "LDAPS", "LDAP"):
        if re.search(rf"\b{candidate}\b", upper):
            application_protocol = candidate
            break

    encryption = None
    encryption_match = re.search(r"\bTLS\s*\d+(?:\.\d+)?\b", text, re.IGNORECASE)
    if encryption_match:
        encryption = re.sub(r"\s+", " ", encryption_match.group(0)).strip()

    transport: dict = {"protocol": protocol, "port": port}
    if encryption:
        transport["encryption"] = encryption
    if application_protocol:
        transport["application_protocol"] = application_protocol
    return transport, None


def host_environment(fqdn: str) -> str | None:
    """Environment implied by the leftmost hostname label, or None."""
    label = fqdn.split(".")[0].lower()
    # `dev.temp.psii` and `dev-01.psii` both start with the same environment word.
    label = re.split(r"[-_0-9]", label)[0]
    return HOST_PREFIX.get(label)


def pair(environments: list[str], endpoints: list[dict]) -> tuple[dict[str, dict] | None, str | None, bool]:
    """Decide which endpoint serves which environment.

    Returns (pairing, problem, inferred). `inferred` marks a pairing that is
    defensible but not stated, so the requirement is flagged for review.

    Three cases, and only three:

    * One endpoint, no environment word in its hostname. A shared host serving
      every listed environment is normal, so pair it with all of them - but this
      is a judgement, not a reading, so it comes back INFERRED.
    * Every endpoint carries an environment word and those words are exactly the
      declared environments. A clean bijection, PARSED.
    * Anything else. Refused. This is where the real SAD row lands: declared
      Dev/CI/Alpha/Pre-Prod against hosts saying dev/qa/uat/ppe means two
      environments have no host and two hosts belong to no environment.
    """
    if not endpoints:
        return None, "No endpoint could be read from the IP/FQDN cell.", False

    if len(endpoints) == 1 and host_environment(endpoints[0]["current"]) is None:
        return {environment: endpoints[0] for environment in environments}, None, True

    mapped: dict[str, dict] = {}
    unmapped_hosts: list[str] = []
    for endpoint in endpoints:
        environment = host_environment(endpoint["current"])
        if environment is None:
            unmapped_hosts.append(endpoint["current"])
        elif environment in mapped:
            return None, (
                f"Two endpoints both look like {environment}: "
                f"{mapped[environment]['current']} and {endpoint['current']}."
            ), False
        else:
            mapped[environment] = endpoint

    declared = set(environments)
    matched = set(mapped)
    missing = sorted(declared - matched)
    extra = sorted(matched - declared)

    if unmapped_hosts or missing or extra:
        details: list[str] = []
        if missing:
            details.append(f"declared but no endpoint matches: {', '.join(missing)}")
        if extra:
            details.append(
                f"endpoint environments not declared: {', '.join(extra)} "
                f"({', '.join(mapped[e]['current'] for e in extra)})"
            )
        if unmapped_hosts:
            details.append(f"hostnames with no environment word: {', '.join(unmapped_hosts)}")
        return None, (
            "Cannot pair environments to endpoints - " + "; ".join(details)
            + ". State the pairing with --pairing and re-run. A cross product here "
              "would create "
            + str(len(environments) * len(endpoints))
            + " connections from a row that wants at most "
            + str(len(environments)) + "."
        ), False

    return mapped, None, False


def parse_pairing_overrides(values: list[str]) -> dict[int, dict[str, str]]:
    """--pairing 2=DEV:dev.x.com,CI:qa.x.com -> {2: {'DEV': 'dev.x.com', ...}}"""
    overrides: dict[int, dict[str, str]] = {}
    for value in values:
        if "=" not in value:
            fail(f"--pairing expects row_index=ENV:fqdn,... but got {value!r}", MISCONFIGURED)
        row_part, pairs_part = value.split("=", 1)
        try:
            row_index = int(row_part)
        except ValueError:
            fail(f"--pairing row index must be an integer, got {row_part!r}", MISCONFIGURED)
        mapping: dict[str, str] = {}
        for pair_text in pairs_part.split(","):
            if ":" not in pair_text:
                fail(f"--pairing expects ENV:fqdn pairs, got {pair_text!r}", MISCONFIGURED)
            environment, fqdn = pair_text.split(":", 1)
            environment = environment.strip().upper()
            if environment not in ENVIRONMENTS:
                fail(
                    f"{environment!r} is not a known environment. One of: "
                    + ", ".join(ENVIRONMENTS),
                    MISCONFIGURED,
                )
            mapping[environment] = fqdn.strip().lower()
        overrides[row_index] = mapping
    return overrides


def check_derivation_coverage(requirement: dict) -> list[str]:
    """Every substantive field must say where it came from.

    JSON Schema cannot express "the keys of this object mirror the keys of its
    siblings", so it is checked here. A field with no derivation entry reads to a
    reviewer as a fact, and some of these fields are guesses.
    """
    exempt = {"requirement_key", "origin", "derivation", "review"}
    missing = [
        name for name in requirement
        if name not in exempt and name not in requirement["derivation"]
    ]
    return missing


def build(
    row: dict, table_index: int, document: str, cutover_policy: str,
    overrides: dict[int, dict[str, str]],
) -> tuple[list[dict], dict | None]:
    """One SAD row -> its requirements, or an unresolved record."""
    cells = row["cells"]
    row_index = row["row_index"]
    carried = bool(row.get("merged_from_above"))

    def unresolved(reason: str, kind: str = "SAD_GAP", **extra) -> dict:
        # kind says whether a flag can fix this. Defaulting to SAD_GAP means a
        # refusal added later without thinking about it is reported as "the
        # document has to change", which is the answer that sends nobody
        # looking for a flag that does not exist.
        return {"row_index": row_index, "kind": kind, "reason": reason, **extra}

    consumer = parse_party(cells.get("source_application", ""))
    if consumer is None:
        return [], unresolved(
            f"No APP- id in the source application cell "
            f"({cells.get('source_application', '')!r})."
        )
    provider = parse_party(cells.get("destination_application", ""))
    if provider is None:
        return [], unresolved(
            f"No APP- id in the destination application cell "
            f"({cells.get('destination_application', '')!r})."
        )

    environments, problem = parse_environments(cells.get("environment", ""))
    if problem:
        return [], unresolved(problem, environments=environments)

    transport, problem = parse_transport(cells.get("protocol_encryption", ""))
    if problem:
        return [], unresolved(problem)

    purpose = cells.get("purpose", "").strip()
    if not purpose:
        return [], unresolved(
            "Purpose is empty. It becomes the business justification on the change "
            "request, and cyber review rejects a request without one - so the gap "
            "is reported now rather than at submission."
        )

    endpoints = parse_endpoints(cells.get("endpoints", ""))
    # How the environment/endpoint pairing was arrived at. "STATED" means the
    # document was unambiguous; the other two are both INFERRED, but an approver
    # needs to tell "an operator asserted this" from "the script worked it out",
    # and a single boolean flattens them into the same sentence.
    pairing_source = "STATED"

    if row_index in overrides:
        by_host = {endpoint["current"]: endpoint for endpoint in endpoints}
        pairing: dict[str, dict] = {}
        for environment, fqdn in overrides[row_index].items():
            if fqdn not in by_host:
                return [], unresolved(
                    f"--pairing names {fqdn!r} for {environment}, but that host is "
                    f"not in this row's endpoint cell. Known hosts: "
                    f"{', '.join(sorted(by_host)) or 'none'}.",
                    kind="PAIRING",
                )
            pairing[environment] = by_host[fqdn]
        # An override is a human stating the pairing, which is a decision, so the
        # environment field stays INFERRED and the requirement stays under review.
        pairing_source = "OVERRIDE"
    else:
        pairing, problem, guessed = pair(environments, endpoints)
        if problem:
            return [], unresolved(
                problem,
                kind="PAIRING",
                environments=environments,
                endpoints=[endpoint["current"] for endpoint in endpoints],
            )
        if guessed:
            pairing_source = "GUESSED"

    pairing_inferred = pairing_source != "STATED"

    wanted_states: list[str] = {
        "current": ["CURRENT"],
        "post": ["POST_CUTOVER"],
        "both": ["CURRENT", "POST_CUTOVER"],
    }[cutover_policy]

    requirements: list[dict] = []
    for environment, endpoint in pairing.items():
        for state in wanted_states:
            fqdn = endpoint["current"] if state == "CURRENT" else endpoint["post_cutover"]
            if not fqdn:
                if state == "POST_CUTOVER" and cutover_policy == "both":
                    continue  # no twin for this host; not an error
                return [], unresolved(
                    f"--cutover-policy {cutover_policy} needs a post-cutover host for "
                    f"{endpoint['current']}, and the cell does not give one.",
                    kind="CUTOVER",
                )

            derivation = {
                "consumer": "PARSED",
                "provider": "PARSED",
                "environment": "INFERRED" if pairing_inferred else "PARSED",
                "endpoint": "PARSED",
                "transport": "PARSED",
                "purpose": "VERBATIM",
            }
            requirement: dict = {
                "requirement_key": requirement_key(
                    consumer["lean_ix_id"], provider["lean_ix_id"], fqdn,
                    transport["protocol"], transport["port"], environment, state,
                ),
                "origin": {
                    "document": document,
                    "table_index": table_index,
                    "row_index": row_index,
                },
                "consumer": consumer,
                "provider": provider,
                "environment": environment,
                "endpoint": {"fqdn": fqdn, "cutover_state": state},
                "transport": transport,
                "purpose": purpose,
            }

            for key, column in (
                ("authentication", "authentication_method"),
                ("security_proxy", "security_proxy"),
                ("connection_type", "connection_type"),
            ):
                value = cells.get(column, "").strip()
                if value:
                    requirement[key] = value
                    derivation[key] = "INFERRED" if carried else "VERBATIM"

            if carried:
                # A vertically merged cell means this row did not state these values;
                # Word drew them from the row above and a reader assumed they applied.
                for key in ("consumer", "provider", "transport", "purpose"):
                    derivation[key] = "INFERRED"

            requirement["derivation"] = derivation
            inferred = sorted(k for k, v in derivation.items() if v == "INFERRED")
            if inferred:
                reasons = []
                if pairing_source == "OVERRIDE":
                    reasons.append(
                        f"the endpoint-to-environment pairing "
                        f"({environment} -> {fqdn}) was supplied with --pairing, not "
                        f"stated in the document - confirm it against whoever owns "
                        f"the estate"
                    )
                elif pairing_source == "GUESSED":
                    reasons.append(
                        f"the document does not state which endpoint serves which "
                        f"environment; {environment} -> {fqdn} was worked out from "
                        f"the row"
                    )
                if carried:
                    reasons.append("values inherited from a vertically merged cell above")
                requirement["review"] = {
                    "required": True,
                    "reason": f"INFERRED: {', '.join(inferred)}. " + "; ".join(reasons) + ".",
                }

            missing = check_derivation_coverage(requirement)
            if missing:  # a coding error in this script, not a data problem
                fail(
                    f"Internal: fields without a derivation entry: {', '.join(missing)}. "
                    f"Every field must record how it was arrived at.",
                    MISCONFIGURED,
                )
            requirements.append(requirement)

    return requirements, None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rows", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--cutover-policy", choices=("current", "post", "both"), default="current",
        help="Which host to raise. Default 'current': raising both doubles the "
             "change requests and is a scheduling decision, so it must be asked for.",
    )
    parser.add_argument(
        "--pairing", action="append", default=[],
        help="State an endpoint-to-environment pairing the script refused to guess: "
             "--pairing 2=DEV:dev.x.com,CI:qa.x.com",
    )
    args = parser.parse_args()

    try:
        rows_document = read_json(args.rows)
    except (OSError, ValueError) as error:
        fail(f"Cannot read {args.rows}: {error}", MISCONFIGURED)

    overrides = parse_pairing_overrides(args.pairing)
    document = rows_document["source_document"]
    table_index = rows_document["table_index"]

    requirements: list[dict] = []
    unresolved: list[dict] = []
    for row in rows_document["rows"]:
        built, problem = build(row, table_index, document, args.cutover_policy, overrides)
        if problem:
            unresolved.append(problem)
        else:
            requirements.extend(built)

    duplicates = {
        key for key in (r["requirement_key"] for r in requirements)
        if [r["requirement_key"] for r in requirements].count(key) > 1
    }
    if duplicates:
        # Two SAD rows asking for identical traffic. Deduplicate rather than raise
        # the same firewall change twice.
        seen: set[str] = set()
        deduplicated = []
        for requirement in requirements:
            if requirement["requirement_key"] in seen:
                continue
            seen.add(requirement["requirement_key"])
            deduplicated.append(requirement)
        print(
            f"  {len(requirements) - len(deduplicated)} duplicate requirements "
            f"collapsed (identical consumer, provider, host, port and environment)."
        )
        requirements = deduplicated

    payload: dict = {
        "source_document": document,
        "generated_at": utc_now(),
        "requirements": requirements,
    }
    if unresolved:
        payload["unresolved"] = unresolved
    write_json_atomic(args.out, payload)

    under_review = sum(1 for r in requirements if r.get("review", {}).get("required"))
    print(f"Expanded {len(requirements)} requirements -> {args.out}")
    if under_review:
        print(f"  {under_review} need review before apply (they contain INFERRED fields).")

    if unresolved:
        print(f"\n{len(unresolved)} row(s) could not be expanded:", file=sys.stderr)
        for entry in unresolved:
            print(f"  row {entry['row_index']}: {entry['reason']}", file=sys.stderr)

        # Name a remedy only where one exists. Telling someone to supply
        # --pairing for an empty Purpose cell sends them looking for a pairing
        # to state, and there isn't one - the document is what has to change.
        by_kind: dict[str, list[dict]] = {}
        for entry in unresolved:
            by_kind.setdefault(entry.get("kind", "SAD_GAP"), []).append(entry)

        pairable = by_kind.get("PAIRING", [])
        if pairable:
            print(
                f"\n{len(pairable)} row(s): the document does not state which endpoint "
                f"serves which environment. State it yourself and re-run, e.g.:\n"
                f"  --pairing \"{pairable[0]['row_index']}=DEV:dev.example.lseg.com,"
                f"CI:qa.example.lseg.com\"\n"
                f"A pairing you supply is recorded as INFERRED, so the requirement "
                f"still needs review before apply.",
                file=sys.stderr,
            )

        cutover = by_kind.get("CUTOVER", [])
        if cutover:
            print(
                f"\n{len(cutover)} row(s): --cutover-policy asks for a host the cell "
                f"does not name. Either the SAD is missing the twin, or this row "
                f"should run under a different policy.",
                file=sys.stderr,
            )

        gaps = by_kind.get("SAD_GAP", [])
        if gaps:
            print(
                f"\n{len(gaps)} row(s): a gap in the SAD itself, which no flag fixes - "
                f"the document has to be corrected, or the row dropped deliberately.",
                file=sys.stderr,
            )

        print(
            "\nNothing was invented for these rows. plan_connections.py will refuse "
            "to plan while any row is unresolved.",
            file=sys.stderr,
        )
        return CANNOT_ASSESS

    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
