#!/usr/bin/env python3
"""Work out what creating these requirements in AppCon would actually do.

Nothing here writes. The client is constructed in dry-run mode, so a coding
mistake in this file cannot raise a firewall request - it raises an exception.

The plan is the artefact a human approves, and apply_plan.py consumes *only* the
plan. It does not re-derive anything. That separation is the whole safety model:
what gets reviewed is exactly what gets executed.

Four questions are asked of AppCon for each requirement, all read-only:

  1. Does the consumer application exist, and does it have a hosting environment
     for this environment?  (Same for the provider.)
  2. Have we already created this? Matched on the stamp we write into every object
     we make, so a re-run after an interruption recognises its own work even if the
     local ledger was lost.
  3. Is this traffic already covered by a base policy? `/connections/policy-overlap`
     answers it, and a covered requirement is dropped - raising it would add an
     approval nobody needs for traffic that is already permitted.
  4. Would it auto-approve? `/connections/auto-approval-evaluation`. Advisory only:
     it changes how long the change takes, not whether we create it.

Response shapes are read tolerantly, because the endpoint inventory we were given
names schemas but does not define them. Tolerant reading is safe in one direction
only - when a field cannot be found the entry becomes BLOCKED or UNKNOWN, never a
default that lets the run continue as though the check had passed.

Usage:
    plan_connections.py --requirements out/requirements.json --out out/plan.json

Exit: 0 plan written and something to do, 2 plan written but nothing actionable,
      3 refused (unresolved rows present), 4 misconfigured.
"""

from __future__ import annotations

import argparse
import sys
from typing import Any

from _common import (
    CANNOT_ASSESS, MISCONFIGURED, PROCEED, REFUSED, fail, read_json,
    require_env, utc_now, write_json_atomic,
)
from appcon_client import AppConClient, AppConError

STAMP_PREFIX = "appcon-agent:"


def stamp_for(requirement_key: str) -> str:
    """The marker written into every object we create.

    The ledger is a convenience; this is the durable record. A run whose ledger
    was deleted can still recognise its own objects by searching for the stamp.
    """
    return f"{STAMP_PREFIX}{requirement_key}"


def pick(payload: Any, *names: str) -> Any:
    """First present key among `names`, case-insensitively. None if absent.

    Used because the inventory names response schemas without defining them, so
    the exact casing of a field is not knowable ahead of time. Callers must treat
    None as "not determined" and never as a default value.
    """
    if not isinstance(payload, dict):
        return None
    lowered = {key.lower(): value for key, value in payload.items()}
    for name in names:
        value = lowered.get(name.lower())
        if value is not None:
            return value
    return None


def as_list(payload: Any) -> list:
    """Unwrap ApiResponse<T> and Spring paging into a plain list."""
    data = AppConClient.unwrap(payload)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("content", "items", "results", "elements"):
            if isinstance(data.get(key), list):
                return data[key]
    return []


def text_of(item: Any) -> str:
    """Everything textual on an object, lowercased. Used only for stamp matching."""
    if isinstance(item, str):
        return item.lower()
    if isinstance(item, dict):
        return " ".join(text_of(value) for value in item.values())
    if isinstance(item, list):
        return " ".join(text_of(value) for value in item)
    return ""


class Resolver:
    """Read-only lookups, cached. One AppCon call per distinct question."""

    def __init__(self, client: AppConClient, tenant_id: str) -> None:
        self.client = client
        self.tenant_id = tenant_id
        self._applications: dict[str, dict] | None = None
        self._environments: dict[str, list] = {}
        self._connections: dict[str, list] = {}

    def applications(self) -> dict[str, dict]:
        """LeanIX id -> AppCon application."""
        if self._applications is None:
            payload = self.client.get(f"/tenants/{self.tenant_id}/applications", size=500)
            index: dict[str, dict] = {}
            for application in as_list(payload):
                lean_ix = pick(
                    application, "leanIxId", "lean_ix_id", "leanIXId",
                    "externalId", "leanIxReference",
                )
                if isinstance(lean_ix, str):
                    index[lean_ix.strip().upper()] = application
            self._applications = index
        return self._applications

    def hosting_environments(self, application_id: str) -> list:
        if application_id not in self._environments:
            payload = self.client.get(
                f"/applications/{application_id}/hosting-environments", size=200
            )
            self._environments[application_id] = as_list(payload)
        return self._environments[application_id]

    def hosting_environment_for(self, application_id: str, environment: str) -> dict | None:
        for candidate in self.hosting_environments(application_id):
            value = pick(candidate, "environment", "environmentType", "env")
            if isinstance(value, str) and value.strip().upper().replace("-", "_") == environment:
                return candidate
        return None

    def connections_in(self, hosting_environment_id: str) -> list:
        if hosting_environment_id not in self._connections:
            payload = self.client.get(
                f"/hosting-environments/{hosting_environment_id}/connections", size=500
            )
            self._connections[hosting_environment_id] = as_list(payload)
        return self._connections[hosting_environment_id]

    def existing_connection(self, hosting_environment_id: str, key: str) -> dict | None:
        marker = stamp_for(key)
        for connection in self.connections_in(hosting_environment_id):
            if marker in text_of(connection):
                return connection
        return None


def identifier(item: Any) -> str | None:
    value = pick(item, "id", "uuid", "guid", "connectionId", "identifier")
    return str(value) if value is not None else None


def policy_matches(client: AppConClient, requirement: dict) -> tuple[list[str], str | None]:
    """Base policies that already permit this traffic.

    A failure here is reported, not swallowed. Treating an unreachable
    policy-overlap check as "not covered" would create duplicates of connections
    the estate already permits.
    """
    body = {
        "connections": [{
            "consumerLeanIxId": requirement["consumer"]["lean_ix_id"],
            "providerFqdn": requirement["endpoint"]["fqdn"],
            "protocol": requirement["transport"]["protocol"],
            "port": requirement["transport"]["port"],
            "environment": requirement["environment"],
        }]
    }
    try:
        payload = client.request("POST", "/connections/policy-overlap", body=body)
    except AppConError as error:
        return [], str(error)

    data = AppConClient.unwrap(payload)
    not_covered = pick(data, "notCovered", "notCoveredConnections", "notCoveredEntries")
    if isinstance(not_covered, list) and not not_covered:
        matched = pick(data, "matchedPolicies", "basePolicies", "coveredBy") or []
        ids = [identifier(entry) or str(entry) for entry in matched] if isinstance(matched, list) else []
        return ids or ["covered"], None

    status = pick(data, "coverageStatus", "status")
    if isinstance(status, str) and status.strip().upper() in ("COVERED", "FULLY_COVERED"):
        return ["covered"], None
    return [], None


def auto_approval(client: AppConClient, requirement: dict) -> str:
    """AUTO_APPROVE / MANUAL_REVIEW / UNKNOWN. UNKNOWN is not MANUAL_REVIEW."""
    body = {
        "connections": [{
            "consumerLeanIxId": requirement["consumer"]["lean_ix_id"],
            "providerFqdn": requirement["endpoint"]["fqdn"],
            "protocol": requirement["transport"]["protocol"],
            "port": requirement["transport"]["port"],
            "environment": requirement["environment"],
        }]
    }
    try:
        payload = client.request("POST", "/connections/auto-approval-evaluation", body=body)
    except AppConError:
        return "UNKNOWN"
    data = AppConClient.unwrap(payload)
    text = text_of(data)
    if "auto" in text and "approv" in text:
        return "AUTO_APPROVE"
    if "manual" in text or "review" in text:
        return "MANUAL_REVIEW"
    return "UNKNOWN"


def plan_one(requirement: dict, resolver: Resolver, client: AppConClient, skip_policy: bool) -> dict:
    key = requirement["requirement_key"]
    entry: dict = {"requirement_key": key}

    if requirement.get("review", {}).get("required") and not requirement["review"].get("cleared_by"):
        entry["disposition"] = "NEEDS_REVIEW"
        entry["reason"] = requirement["review"]["reason"]
        return entry

    applications = resolver.applications()
    consumer_app = applications.get(requirement["consumer"]["lean_ix_id"])
    provider_app = applications.get(requirement["provider"]["lean_ix_id"])

    for label, application, party in (
        ("consumer", consumer_app, requirement["consumer"]),
        ("provider", provider_app, requirement["provider"]),
    ):
        if application is None:
            entry["disposition"] = "BLOCKED"
            entry["reason"] = (
                f"No AppCon application carries LeanIX id {party['lean_ix_id']} "
                f"({party['name']}) in this tenant. Onboard it first - creating an "
                f"application from a SAD cell would invent an owner."
            )
            return entry

    consumer_app_id = identifier(consumer_app)
    provider_app_id = identifier(provider_app)
    if not consumer_app_id or not provider_app_id:
        entry["disposition"] = "BLOCKED"
        entry["reason"] = "An application matched but carries no readable id field."
        return entry

    environment = requirement["environment"]
    consumer_he = resolver.hosting_environment_for(consumer_app_id, environment)
    provider_he = resolver.hosting_environment_for(provider_app_id, environment)

    for label, hosting_environment, party in (
        ("consumer", consumer_he, requirement["consumer"]),
        ("provider", provider_he, requirement["provider"]),
    ):
        if hosting_environment is None:
            entry["disposition"] = "BLOCKED"
            entry["reason"] = (
                f"{party['lean_ix_id']} has no {environment} hosting environment. "
                f"Per the AppCon onboarding flow, create it in planning state and "
                f"share the environment link before raising connectivity."
            )
            return entry

    consumer_he_id = identifier(consumer_he)
    provider_he_id = identifier(provider_he)
    resolved = {
        "consumer_application_id": consumer_app_id,
        "consumer_hosting_environment_id": consumer_he_id or "",
        "provider_application_id": provider_app_id,
        "provider_hosting_environment_id": provider_he_id or "",
    }

    existing = resolver.existing_connection(consumer_he_id, key) if consumer_he_id else None
    if existing is not None:
        resolved["connection_id"] = identifier(existing) or ""
        entry.update({
            "disposition": "EXISTS",
            "reason": (
                f"A connection stamped {stamp_for(key)} already exists in "
                f"{environment}. A previous run created it."
            ),
            "resolved": resolved,
        })
        return entry

    if not skip_policy:
        matches, problem = policy_matches(client, requirement)
        if problem:
            entry.update({
                "disposition": "BLOCKED",
                "reason": (
                    f"The base policy overlap check could not run ({problem}). Not "
                    f"planning this requirement: an unanswered coverage question is "
                    f"not a 'no', and assuming so duplicates permitted traffic."
                ),
                "resolved": resolved,
            })
            return entry
        if matches:
            entry.update({
                "disposition": "COVERED_BY_POLICY",
                "reason": (
                    f"Already permitted by base policy {', '.join(matches)}. Raising "
                    f"it would add an approval for traffic that already flows."
                ),
                "resolved": resolved,
                "policy_matches": matches,
            })
            return entry

    entry.update({
        "disposition": "CREATE",
        "reason": (
            f"No existing connection and no base policy covers "
            f"{requirement['consumer']['lean_ix_id']} -> "
            f"{requirement['endpoint']['fqdn']}:{requirement['transport']['port']} "
            f"in {environment}."
        ),
        "resolved": resolved,
        "will_create": ["CONSUMER", "PROVIDER", "CONNECTION"],
        "auto_approval_prediction": auto_approval(client, requirement),
    })
    return entry


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requirements", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--skip-policy-check", action="store_true",
        help="Skip base policy overlap. Only for a deployment where the endpoint is "
             "unavailable - it means the plan may duplicate already-permitted traffic.",
    )
    args = parser.parse_args()

    try:
        document = read_json(args.requirements)
    except (OSError, ValueError) as error:
        fail(f"Cannot read {args.requirements}: {error}", MISCONFIGURED)

    unresolved = document.get("unresolved", [])
    if unresolved:
        rows = ", ".join(str(entry["row_index"]) for entry in unresolved)
        fail(
            f"Refusing to plan: {len(unresolved)} SAD row(s) are unresolved (rows "
            f"{rows}). Planning around them would quietly drop requirements the "
            f"document asked for. Resolve them in expand_requirements.py first.",
            REFUSED,
        )

    tenant_id = require_env("APPCON_TENANT_ID")
    client = AppConClient(dry_run=True)

    try:
        spec_version = client.spec_hash()
    except AppConError as error:
        fail(
            f"{error}\nNo plan was produced. Without the spec no request body can be "
            f"verified, and an unverified body is a guess.",
            CANNOT_ASSESS,
        )

    resolver = Resolver(client, tenant_id)
    entries: list[dict] = []
    for requirement in document["requirements"]:
        try:
            entries.append(plan_one(requirement, resolver, client, args.skip_policy_check))
        except AppConError as error:
            entries.append({
                "requirement_key": requirement["requirement_key"],
                "disposition": "BLOCKED",
                "reason": f"AppCon call failed while planning: {error}",
            })

    summary = {
        "create": sum(1 for e in entries if e["disposition"] == "CREATE"),
        "exists": sum(1 for e in entries if e["disposition"] == "EXISTS"),
        "covered_by_policy": sum(1 for e in entries if e["disposition"] == "COVERED_BY_POLICY"),
        "needs_review": sum(1 for e in entries if e["disposition"] == "NEEDS_REVIEW"),
        "blocked": sum(1 for e in entries if e["disposition"] == "BLOCKED"),
    }

    write_json_atomic(args.out, {
        "generated_at": utc_now(),
        "base_url": client.base_url,
        "tenant_id": tenant_id,
        "spec_version": spec_version,
        "entries": entries,
        "summary": summary,
    })

    print(f"Plan written to {args.out} (spec {spec_version})")
    for name, count in summary.items():
        print(f"  {name:<18} {count}")

    if summary["blocked"] or summary["needs_review"]:
        print(
            "\nEntries needing attention before apply:",
            file=sys.stderr,
        )
        for entry in entries:
            if entry["disposition"] in ("BLOCKED", "NEEDS_REVIEW"):
                print(f"  [{entry['disposition']}] {entry['requirement_key']}: {entry['reason']}",
                      file=sys.stderr)

    if summary["create"] == 0:
        print(
            "\nNothing to create. This is a complete answer, not a failure - but "
            "check the blocked and review counts above before reporting it as "
            "'no connectivity needed'.",
            file=sys.stderr,
        )
        return CANNOT_ASSESS
    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
