#!/usr/bin/env python3
"""Check that this machine can actually run the package, before it matters.

This package deliberately has no pip dependencies, which makes "it doesn't work
on my machine" a confusing failure when it happens: there is no requirements.txt
to point at. The things that do go wrong are less obvious than a missing
package, and each of them fails late and unhelpfully:

  - A Python build without `ssl` cannot reach AppCon at all, and says so with a
    NameError deep inside urllib.
  - A Python build without `zlib` reads an empty .docx, because Word compresses
    every part with deflate. The zipfile opens; the parts are unreadable.
  - `os.replace` on a cloud-synced folder can fail mid-run. The ledger is
    rewritten after every API call and depends on that call being atomic.
  - A schema using a JSON Schema keyword our validator does not implement makes
    validation raise rather than pass, which is correct but confusing if the
    first time you see it is halfway through a batch.
  - `requirement_key` drifting across platforms would make every object created
    on another machine invisible to this one.

Each of those is one cheap check here instead of one late failure there.

Usage:
    doctor.py [--root .] [--json out/appcon/doctor.json]

Exit: 0 everything needed is present, 2 something could not be checked,
      4 something required is missing or broken.
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import platform
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PACKAGE_ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, HERE)

from _common import CANNOT_ASSESS, MISCONFIGURED, PROCEED  # noqa: E402

MINIMUM_PYTHON = (3, 10)

# Stdlib modules this package genuinely imports. Listed rather than discovered so
# that the check says which script needs the missing one.
STDLIB = {
    "ssl": "HTTPS to AppCon. Absent from some minimal builds; without it every API call fails.",
    "zlib": "Reading .docx. Word deflates every part, so without zlib the zip opens empty.",
    "zipfile": "Reading .docx.",
    "xml.etree.ElementTree": "Parsing word/document.xml.",
    "urllib.request": "The AppCon client.",
    "hashlib": "requirement_key and the spec hash.",
    "tempfile": "Atomic writes.",
    "unittest": "tests/test_all.py.",
}

OWN_MODULES = (
    "_common",
    "validate_instance",
    "extract_sad_table",
    "expand_requirements",
    "appcon_client",
    "plan_connections",
    "apply_plan",
    "submit_approval",
    "track_status",
)

SCHEMAS = (
    "sad-rows.schema.json",
    "connectivity-requirement.schema.json",
    "plan.schema.json",
    "ledger.schema.json",
)

# Packages people reach for when they see this problem. None are needed, and
# saying so explicitly saves someone installing python-docx to "fix" an
# extraction failure that has a different cause.
NOT_REQUIRED = ("requests", "jsonschema", "docx", "openpyxl", "yaml")

# Which commands need which variable. Absence is only a problem for the commands
# that use it, so the report says which are blocked rather than failing outright.
ENVIRONMENT = {
    "APPCON_BASE_URL": "/appcon-init, /create-plan, /apply-plan, /request-approval, /appcon-status",
    "APPCON_COOKIE": "/appcon-init, /create-plan, /apply-plan, /request-approval, /appcon-status",
    "APPCON_TENANT_ID": "/create-plan, /apply-plan",
    "APPCON_GOV_ID": "/request-approval (can also be passed as --gov-id)",
}

# Pinned in tests/test_all.py and stamped into every AppCon object we create.
PINNED_INPUT = ("APP-52775", "APP-53435", "dev.temp.psii.lseg.com", "TCP", 443, "DEV", "CURRENT")
PINNED_KEY = "245beaa74614f6a5"

OK, WARN, FAIL = "ok", "warn", "fail"


class Report:
    def __init__(self) -> None:
        self.results: list[tuple[str, str, str, str]] = []

    def add(self, group: str, status: str, name: str, detail: str) -> None:
        self.results.append((group, status, name, detail))

    def counts(self) -> dict[str, int]:
        return {
            status: sum(1 for _, s, _, _ in self.results if s == status)
            for status in (OK, WARN, FAIL)
        }


def check_python(report: Report) -> None:
    version = sys.version_info[:3]
    if version[:2] < MINIMUM_PYTHON:
        report.add(
            "runtime", FAIL, f"Python {'.'.join(map(str, version))}",
            f"This package needs {MINIMUM_PYTHON[0]}.{MINIMUM_PYTHON[1]} or newer. "
            f"On Windows, `python3` is often a Store alias stub - use `python`.",
        )
    else:
        report.add(
            "runtime", OK, f"Python {'.'.join(map(str, version))}",
            f"{platform.python_implementation()} on {platform.system()}",
        )


def check_stdlib(report: Report) -> None:
    for module, why in STDLIB.items():
        try:
            importlib.import_module(module)
        except ImportError as error:
            report.add("runtime", FAIL, module, f"{why} Import failed: {error}")
        else:
            report.add("runtime", OK, module, why)


def check_no_pip_dependencies(report: Report) -> None:
    present = []
    for module in NOT_REQUIRED:
        try:
            importlib.import_module(module)
        except ImportError:
            continue
        present.append(module)
    detail = "No pip install is needed; this package is standard library only."
    if present:
        detail += f" (Installed but unused here: {', '.join(present)}.)"
    report.add("runtime", OK, "third-party packages", detail)


def check_own_modules(report: Report) -> None:
    for module in OWN_MODULES:
        try:
            importlib.import_module(module)
        except Exception as error:  # noqa: BLE001 - a broken module is the finding
            report.add(
                "package", FAIL, f"{module}.py",
                f"{type(error).__name__}: {error}",
            )
        else:
            report.add("package", OK, f"{module}.py", "imports cleanly")


def check_schemas(report: Report, root: str) -> None:
    try:
        validate_instance = importlib.import_module("validate_instance")
    except Exception as error:  # noqa: BLE001
        report.add("package", FAIL, "schemas", f"validator unavailable: {error}")
        return

    for name in SCHEMAS:
        path = os.path.join(root, "schemas", name)
        if not os.path.exists(path):
            report.add("package", FAIL, name, f"Not found at {path}")
            continue
        try:
            with open(path, encoding="utf-8") as handle:
                schema = json.load(handle)
        except (OSError, ValueError) as error:
            report.add("package", FAIL, name, f"Unreadable: {error}")
            continue
        try:
            # The whole schema tree, not just the branches an instance reaches.
            # validate() is instance-driven, so handing it {} would only check
            # the root object and report a schema with an unimplemented keyword
            # three levels down as usable.
            validate_instance.check_schema(schema, schema)
        except validate_instance.SchemaUnusable as error:
            report.add(
                "package", FAIL, name,
                f"Uses a JSON Schema keyword validate_instance.py does not "
                f"implement: {error}. It refuses rather than skipping, so this "
                f"schema cannot validate anything until that is added.",
            )
        except Exception as error:  # noqa: BLE001
            report.add("package", FAIL, name, f"{type(error).__name__}: {error}")
        else:
            report.add("package", OK, name, "parses and is usable by the validator")


def check_requirement_key(report: Report) -> None:
    try:
        from _common import requirement_key
        actual = requirement_key(*PINNED_INPUT)
    except Exception as error:  # noqa: BLE001
        report.add("package", FAIL, "requirement_key", f"{type(error).__name__}: {error}")
        return
    if actual != PINNED_KEY:
        report.add(
            "package", FAIL, "requirement_key",
            f"Produces {actual}, expected {PINNED_KEY}. This value is stamped into "
            f"every AppCon object this package creates. If it differs here, objects "
            f"created elsewhere are invisible to this machine and applying would "
            f"duplicate them. Do not change the pin to match - find out why it moved.",
        )
    else:
        report.add("package", OK, "requirement_key", f"stable at {PINNED_KEY}")


def check_atomic_write(report: Report, root: str) -> None:
    """os.replace into the output directory, which is where the ledger lives."""
    out_dir = os.path.join(root, "out", "appcon")
    try:
        os.makedirs(out_dir, exist_ok=True)
    except OSError as error:
        report.add("package", FAIL, "output directory", f"Cannot create {out_dir}: {error}")
        return

    target = os.path.join(out_dir, ".doctor-write-test")
    try:
        handle = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=out_dir, delete=False, suffix=".tmp"
        )
        handle.write("{}")
        handle.flush()
        os.fsync(handle.fileno())
        handle.close()
        os.replace(handle.name, target)
        os.unlink(target)
    except OSError as error:
        hint = ""
        if "OneDrive" in os.path.abspath(out_dir) or "Dropbox" in os.path.abspath(out_dir):
            hint = (
                " This path is inside a cloud-synced folder; the sync client can "
                "hold a lock on a file being replaced. The ledger is rewritten "
                "after every API call and needs this to be atomic - consider "
                "running with --root outside the synced tree."
            )
        report.add("package", FAIL, "atomic write", f"os.replace failed in {out_dir}: {error}.{hint}")
    else:
        report.add("package", OK, "atomic write", f"os.replace works in {out_dir}")


def check_environment(report: Report) -> None:
    for name, used_by in ENVIRONMENT.items():
        value = os.environ.get(name, "").strip()
        if value:
            # Never echo the value. APPCON_COOKIE is a live session.
            report.add("environment", OK, name, f"set ({len(value)} chars), used by {used_by}")
        else:
            report.add(
                "environment", WARN, name,
                f"not set. Blocks {used_by}. Read-only steps up to "
                f"/create-requirements do not need it.",
            )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=PACKAGE_ROOT,
                        help="Package root. Defaults to the installed package.")
    parser.add_argument("--json", dest="json_out", default=None)
    args = parser.parse_args()
    root = os.path.abspath(args.root)

    report = Report()
    check_python(report)
    check_stdlib(report)
    check_no_pip_dependencies(report)
    check_own_modules(report)
    check_schemas(report, root)
    check_requirement_key(report)
    check_atomic_write(report, root)
    check_environment(report)

    marks = {OK: "  ok  ", WARN: " warn ", FAIL: " FAIL "}
    width = max(len(name) for _, _, name, _ in report.results)
    current_group = None
    for group, status, name, detail in report.results:
        if group != current_group:
            print(f"\n{group}")
            current_group = group
        print(f"  [{marks[status]}] {name:<{width}}  {detail}")

    counts = report.counts()
    print(f"\n{counts[OK]} ok, {counts[WARN]} warning(s), {counts[FAIL]} failure(s)")

    if args.json_out:
        from _common import write_json_atomic, utc_now
        write_json_atomic(args.json_out, {
            "generated_at": utc_now(),
            "python": sys.version,
            "root": root,
            "results": [
                {"group": g, "status": s, "name": n, "detail": d}
                for g, s, n, d in report.results
            ],
            "counts": counts,
        })
        print(f"Written to {args.json_out}")

    if counts[FAIL]:
        print(
            "\nFix the failures above before running anything else. None of them "
            "are fixed by installing a package - this is a standard-library-only "
            "package and a missing pip module is never the cause.",
            file=sys.stderr,
        )
        return MISCONFIGURED
    if counts[WARN]:
        print(
            "\nUsable for the read-only steps. The warnings above are variables "
            "that are not set; each names the commands it blocks.",
            file=sys.stderr,
        )
        return CANNOT_ASSESS
    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
