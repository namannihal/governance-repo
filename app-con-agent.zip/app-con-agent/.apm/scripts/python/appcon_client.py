#!/usr/bin/env python3
"""AppCon HTTP client that refuses to send a body the live spec does not describe.

The problem this solves is specific. The endpoint inventory we were given lists
paths and schema *names* but no request bodies. A client written from that list is
a client written from guesses, and a guessed field on a POST to /connections does
not fail cleanly - it either 400s, or worse, it succeeds while quietly dropping
the field, and a firewall rule goes in narrower or wider than the SAD asked for.

So every write goes through `request()`, which:

  1. loads the OpenAPI document from the running deployment,
  2. finds the operation for (method, path),
  3. checks every field in the body against that operation's request schema,
  4. refuses the call if the spec does not describe a field being sent.

That last step is the point. The spec is the only authority on what AppCon accepts,
it is available at runtime, and consulting it costs one request.

Auth is a second known unknown. The spec says the server "Requires SSO session",
so this client sends a session cookie and nothing else. If your deployment issues
bearer tokens for service principals, add it in `_auth_headers` - do not paper over
it by disabling verification.

Usage as a CLI (used by /appcon-init to prove the environment works):
    appcon_client.py --probe
    appcon_client.py --spec-hash
    appcon_client.py --tenants
    appcon_client.py --save-spec out/appcon/spec.json

Exit: 0 reachable and authenticated, 2 reachable but auth rejected, 4 misconfigured.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from _common import (
    CANNOT_ASSESS,
    MISCONFIGURED,
    PROCEED,
    fail,
    require_env,
    write_json_atomic,
)

SPEC_PATH = "/v3/api-docs/All"
DEFAULT_TIMEOUT = 60

# POSTs that evaluate rather than mutate. AppCon models several genuinely
# read-only questions as POSTs because the question needs a body - "would this
# connection be covered by a base policy?" cannot be asked in a query string.
# They are allowed during a dry run; everything else is not. This is an explicit
# allowlist rather than a heuristic on the path, because the cost of being wrong
# in one direction is a stray change request.
READ_ONLY_POSTS = frozenset({
    "/connections/policy-overlap",
    "/connections/auto-approval-evaluation",
    "/providers/similar",
    "/providers/validate",
})


class AppConError(RuntimeError):
    """A call failed in a way the caller is expected to handle, not retry blindly."""


class SpecViolation(AppConError):
    """We were about to send something the API does not document. Refused."""


class AppConClient:
    def __init__(
        self,
        base_url: str | None = None,
        cookie: str | None = None,
        dry_run: bool = False,
    ) -> None:
        self.base_url = (base_url or require_env("APPCON_BASE_URL")).rstrip("/")
        self.cookie = cookie if cookie is not None else os.environ.get("APPCON_COOKIE", "")
        # dry_run is not a debugging aid - plan_connections.py sets it so that a
        # coding mistake there cannot write to AppCon. Writes raise instead.
        self.dry_run = dry_run
        self._spec: dict | None = None
        self._spec_hash: str | None = None

    # ---------------------------------------------------------------- transport

    def _auth_headers(self) -> dict[str, str]:
        if not self.cookie:
            fail(
                "APPCON_COOKIE is empty. The AppCon spec states the server requires "
                "an SSO session, so there is no anonymous or token path configured. "
                "See the auth section of README.md.",
                MISCONFIGURED,
            )
        return {"Cookie": self.cookie}

    def _raw(
        self, method: str, path: str, body: Any = None, query: dict | None = None
    ) -> tuple[int, Any]:
        url = self.base_url + path
        if query:
            cleaned = {k: v for k, v in query.items() if v is not None}
            if cleaned:
                url += "?" + urllib.parse.urlencode(cleaned)

        data = None
        headers = {"Accept": "application/json", **self._auth_headers()}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=DEFAULT_TIMEOUT) as response:
                payload = response.read().decode("utf-8")
                return response.status, (json.loads(payload) if payload.strip() else None)
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")[:2000]
            if error.code in (401, 403):
                raise AppConError(
                    f"{error.code} on {method} {path}. The SSO session is missing or "
                    f"expired - refresh APPCON_COOKIE. This is an auth failure, not "
                    f"a permissions verdict on the object."
                ) from error
            raise AppConError(f"{error.code} on {method} {path}: {detail}") from error
        except urllib.error.URLError as error:
            raise AppConError(f"Cannot reach {url}: {error.reason}") from error

    # --------------------------------------------------------------------- spec

    def spec(self) -> dict:
        if self._spec is None:
            status, payload = self._raw("GET", SPEC_PATH)
            if status != 200 or not isinstance(payload, dict):
                raise AppConError(
                    f"Could not load the OpenAPI document from {self.base_url}{SPEC_PATH}. "
                    f"Without it no request body can be verified, so nothing will be sent."
                )
            self._spec = payload
            canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
            self._spec_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
        return self._spec

    def spec_hash(self) -> str:
        self.spec()
        assert self._spec_hash is not None
        return self._spec_hash

    def _resolve_ref(self, node: Any) -> Any:
        """Follow $ref inside the OpenAPI document."""
        seen: set[str] = set()
        while isinstance(node, dict) and "$ref" in node:
            ref = node["$ref"]
            if ref in seen or not ref.startswith("#/"):
                return node
            seen.add(ref)
            target: Any = self.spec()
            for segment in ref[2:].split("/"):
                if not isinstance(target, dict) or segment not in target:
                    return node
                target = target[segment]
            node = target
        return node

    def _template_for(self, path: str) -> str | None:
        """Match a concrete path back to its templated form.

        /connections/abc-123/change-request has to be recognised as
        /connections/{connectionId}/change-request before the spec can be consulted.
        """
        paths = self.spec().get("paths", {})
        if path in paths:
            return path
        wanted = path.strip("/").split("/")
        for template in paths:
            segments = template.strip("/").split("/")
            if len(segments) != len(wanted):
                continue
            if all(
                segment.startswith("{") or segment == actual
                for segment, actual in zip(segments, wanted)
            ):
                return template
        return None

    def _body_properties(self, method: str, path: str) -> tuple[set[str], set[str]] | None:
        """(allowed field names, required field names) for an operation's body.

        Returns None when the spec documents no request body for the operation,
        which is itself a finding - sending one anyway is a guess.
        """
        template = self._template_for(path)
        if template is None:
            raise SpecViolation(
                f"{method} {path} does not match any path in the AppCon OpenAPI "
                f"document. Either the path is wrong or this deployment does not "
                f"expose it."
            )
        operation = self.spec()["paths"][template].get(method.lower())
        if operation is None:
            raise SpecViolation(
                f"The spec documents {template} but not the {method} method on it."
            )
        request_body = operation.get("requestBody")
        if not request_body:
            return None

        content = self._resolve_ref(request_body).get("content", {})
        schema = None
        for media_type, entry in content.items():
            if "json" in media_type:
                schema = entry.get("schema")
                break
        if schema is None:
            return None

        allowed: set[str] = set()
        required: set[str] = set()

        def collect(node: Any, depth: int = 0) -> None:
            if depth > 10:
                return
            node = self._resolve_ref(node)
            if not isinstance(node, dict):
                return
            for composite in ("allOf", "anyOf", "oneOf"):
                for member in node.get(composite, []):
                    collect(member, depth + 1)
            properties = node.get("properties")
            if isinstance(properties, dict):
                allowed.update(properties)
            for name in node.get("required", []):
                required.add(name)

        collect(schema)
        return allowed, required

    def verify_body(self, method: str, path: str, body: dict) -> None:
        """Refuse fields the spec does not document. Called before every write."""
        properties = self._body_properties(method, path)
        if properties is None:
            raise SpecViolation(
                f"{method} {path} documents no JSON request body, but a body of "
                f"{sorted(body)} was about to be sent."
            )
        allowed, required = properties

        unknown = sorted(set(body) - allowed)
        if unknown:
            raise SpecViolation(
                f"{method} {path}: the spec does not describe field(s) "
                f"{', '.join(unknown)}. Known fields: {', '.join(sorted(allowed))}. "
                f"Sending an undocumented field is how a rule ends up wider or "
                f"narrower than the SAD asked for - fix the caller, do not bypass "
                f"this check."
            )
        missing = sorted(required - set(body))
        if missing:
            raise SpecViolation(
                f"{method} {path}: the spec requires field(s) {', '.join(missing)} "
                f"which were not supplied."
            )

    # ------------------------------------------------------------------ requests

    def get(self, path: str, **query: Any) -> Any:
        _, payload = self._raw("GET", path, query=query)
        return payload

    def request(self, method: str, path: str, body: dict | None = None, **query: Any) -> Any:
        """The only way this package writes to AppCon."""
        method = method.upper()
        if method == "GET":
            return self.get(path, **query)
        if self.dry_run and path not in READ_ONLY_POSTS:
            raise AppConError(
                f"Refusing {method} {path}: this client is in dry-run mode and that "
                f"path is not on the read-only allowlist. plan_connections.py must "
                f"not mutate AppCon; if you are seeing this, either a read-only step "
                f"tried to write, or a genuinely evaluative endpoint needs adding to "
                f"READ_ONLY_POSTS after you have confirmed it has no side effects."
            )
        if body is not None:
            self.verify_body(method, path, body)
        _, payload = self._raw(method, path, body=body, query=query)
        return payload

    # ------------------------------------------------------------------- helpers

    @staticmethod
    def unwrap(payload: Any) -> Any:
        """AppCon wraps everything in ApiResponse<T>. Return the payload itself."""
        if isinstance(payload, dict) and "data" in payload:
            return payload["data"]
        return payload

    def probe(self) -> tuple[bool, str]:
        """Can we reach AppCon, load its spec, and act as a logged-in user?"""
        try:
            operations = sum(
                1 for entry in self.spec().get("paths", {}).values()
                for method in entry
                if method in ("get", "put", "post", "patch", "delete")
            )
        except AppConError as error:
            return False, str(error)
        try:
            self.get("/tenancy/user-tenants")
        except AppConError as error:
            return False, f"Spec loaded but the session is not usable: {error}"
        return True, (
            f"Reachable. Spec {self.spec_hash()} describes {operations} operations; "
            f"the SSO session is accepted."
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", action="store_true", help="Check reachability and auth.")
    parser.add_argument("--spec-hash", action="store_true", help="Print the spec hash.")
    parser.add_argument(
        "--save-spec", metavar="PATH",
        help="Write the OpenAPI document this run validated against. Keep it with "
             "the plan: the hash says the spec changed, this says how.",
    )
    parser.add_argument(
        "--tenants", action="store_true",
        help="List the tenants this session can see, so APPCON_TENANT_ID can be "
             "checked against them. A wrong tenant resolves to nothing and reports "
             "it as 'no existing connections', which looks like a clean slate.",
    )
    args = parser.parse_args()

    client = AppConClient()

    if args.save_spec:
        try:
            document = client.spec()
        except AppConError as error:
            fail(str(error), CANNOT_ASSESS)
        write_json_atomic(args.save_spec, document)
        print(f"Spec {client.spec_hash()} written to {args.save_spec}")
        return PROCEED

    if args.tenants:
        try:
            payload = client.get("/tenancy/user-tenants")
        except AppConError as error:
            fail(str(error), CANNOT_ASSESS)
        tenants = AppConClient.unwrap(payload)
        if not isinstance(tenants, list) or not tenants:
            fail(
                "The session is valid but lists no tenants. That is not an empty "
                "estate - it means this account has no AppCon access, and every "
                "later lookup would return nothing and look like a clean slate.",
                CANNOT_ASSESS,
            )
        wanted = os.environ.get("APPCON_TENANT_ID", "").strip()
        found = False
        for tenant in tenants:
            identifier = tenant.get("id") if isinstance(tenant, dict) else str(tenant)
            name = tenant.get("name", "") if isinstance(tenant, dict) else ""
            mark = "*" if wanted and str(identifier) == wanted else " "
            found = found or mark == "*"
            print(f" {mark} {identifier}  {name}")
        if wanted and not found:
            # Flush first: the list above goes to stdout, the refusal below goes to
            # stderr, and when stdout is piped it block-buffers and lands after the
            # message it is the evidence for.
            sys.stdout.flush()
            fail(
                f"APPCON_TENANT_ID is {wanted}, which is not in that list. Stop here: "
                f"planning against a tenant this session cannot see resolves every "
                f"application to nothing.",
                CANNOT_ASSESS,
            )
        return PROCEED

    if args.spec_hash:
        try:
            print(client.spec_hash())
        except AppConError as error:
            fail(str(error), CANNOT_ASSESS)
        return PROCEED

    if args.probe:
        ok, message = client.probe()
        print(message if ok else f"AppCon probe failed: {message}", file=sys.stdout if ok else sys.stderr)
        return PROCEED if ok else CANNOT_ASSESS

    parser.print_help()
    return MISCONFIGURED


if __name__ == "__main__":
    sys.exit(main())
