#!/usr/bin/env python3
"""Request approval for connections this package created.

This is the transition marked "USER: Request Approval" in the AppCon status
machine - New -> Pending Approval. Everything before it is private bookkeeping;
this step puts work on the cyber team's queue, so it is separated from apply and
needs its own --confirm.

The GOV-ID is validated against ServiceNow before anything is submitted. A change
request carrying a GOV-ID that does not exist is rejected at review, days later,
by a human - and by then the whole batch is sitting in the queue. Checking costs
one call.

Usage:
    submit_approval.py --ledger out/ledger.json --requirements out/requirements.json \\
                       --confirm [--gov-id GOVI123456] [--limit N]

Exit: 0 all submitted, 2 partially submitted, 3 refused, 4 misconfigured,
      5 nothing pending.
"""

from __future__ import annotations

import argparse
import os
import re
import sys

from _common import (
    ALREADY_EXISTS, CANNOT_ASSESS, MISCONFIGURED, PROCEED, REFUSED, fail,
    read_json, utc_now, write_json_atomic,
)
from appcon_client import AppConClient, AppConError, SpecViolation
from apply_plan import fit_body
from plan_connections import as_list, pick, text_of

GOV_ID_PATTERN = re.compile(r"^GOVI\d{6}$")


def validate_gov_id(client: AppConClient, gov_id: str) -> None:
    """Confirm the GOV-ID exists before it is attached to anything."""
    if not GOV_ID_PATTERN.match(gov_id):
        fail(
            f"{gov_id!r} is not in the GOVI###### form AppCon's business "
            f"justification dialog requires.",
            MISCONFIGURED,
        )
    try:
        payload = client.get("/service-now-integration/gov-items", search=gov_id)
    except AppConError as error:
        fail(
            f"Could not check {gov_id} against ServiceNow ({error}). Not submitting: "
            f"an unverified GOV-ID fails at cyber review days from now, with the whole "
            f"batch already queued.",
            CANNOT_ASSESS,
        )
    if gov_id.lower() not in text_of(as_list(payload)):
        fail(
            f"ServiceNow returned no governance item matching {gov_id}. Check the id, "
            f"or raise the governance record first.",
            REFUSED,
        )


def submit(client: AppConClient, connection_id: str, requirement: dict, gov_id: str) -> str:
    path = f"/connections/{connection_id}/change-request"
    justification = (
        f"{requirement['purpose']}. "
        f"{requirement['consumer']['name']} ({requirement['consumer']['lean_ix_id']}) to "
        f"{requirement['provider']['name']} ({requirement['provider']['lean_ix_id']}) "
        f"over {requirement['transport']['protocol']}/{requirement['transport']['port']} "
        f"in {requirement['environment']}. "
        f"Source: {requirement['origin']['document']} "
        f"table {requirement['origin']['table_index']} row {requirement['origin']['row_index']}."
    )
    body = fit_body(client, "POST", path, [
        (("govId", "governanceId", "govItemId"), gov_id),
        (("businessJustification", "justification", "comment", "description"), justification),
    ])
    payload = client.request("POST", path, body=body)
    data = AppConClient.unwrap(payload)
    return str(pick(data, "id", "changeRequestId", "uuid") or "submitted")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", required=True)
    parser.add_argument("--requirements", required=True)
    parser.add_argument("--gov-id", default=os.environ.get("APPCON_GOV_ID", "").strip())
    parser.add_argument("--confirm", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    try:
        ledger = read_json(args.ledger)
        requirements = {
            r["requirement_key"]: r
            for r in read_json(args.requirements)["requirements"]
        }
    except (OSError, ValueError, KeyError) as error:
        fail(f"Cannot read inputs: {error}", MISCONFIGURED)

    submitted_keys = {
        entry["requirement_key"] for entry in ledger["entries"]
        if entry["object_type"] == "CHANGE_REQUEST"
    }
    pending = [
        entry for entry in ledger["entries"]
        if entry["object_type"] == "CONNECTION"
        and entry["requirement_key"] not in submitted_keys
    ]
    if args.limit is not None:
        pending = pending[: args.limit]

    if not pending:
        print("Every connection in the ledger already has a change request.")
        return ALREADY_EXISTS

    if not args.confirm:
        print(f"Would request approval for {len(pending)} connection(s).")
        print("This puts them on the cyber review queue. Re-run with --confirm.")
        return REFUSED

    if not args.gov_id:
        fail(
            "No GOV-ID. Pass --gov-id or set APPCON_GOV_ID. AppCon requires one on "
            "the business justification and there is no sensible default.",
            MISCONFIGURED,
        )

    client = AppConClient()
    validate_gov_id(client, args.gov_id)

    done = 0
    failures: list[tuple[str, str]] = []
    for entry in pending:
        key = entry["requirement_key"]
        requirement = requirements.get(key)
        if requirement is None:
            failures.append((key, "No requirement in the requirements file for this key."))
            continue
        gov_id = requirement.get("gov_id", args.gov_id)
        try:
            change_request_id = submit(client, entry["appcon_id"], requirement, gov_id)
        except (AppConError, SpecViolation) as error:
            failures.append((key, str(error)))
            continue
        ledger["entries"].append({
            "requirement_key": key,
            "object_type": "CHANGE_REQUEST",
            "appcon_id": change_request_id,
            "created_at": utc_now(),
        })
        write_json_atomic(args.ledger, ledger)
        done += 1
        print(f"  {requirement['endpoint']['fqdn']} [{requirement['environment']}] "
              f"-> change request {change_request_id}")

    print(f"\nRequested approval for {done} of {len(pending)}.")
    if failures:
        print(f"\n{len(failures)} failed:", file=sys.stderr)
        for key, reason in failures:
            print(f"  {key}: {reason}", file=sys.stderr)
        return CANNOT_ASSESS
    return PROCEED


if __name__ == "__main__":
    sys.exit(main())
