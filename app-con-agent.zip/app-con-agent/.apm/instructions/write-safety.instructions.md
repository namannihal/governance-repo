---
description: "What may call an AppCon write endpoint, when, and what is never allowed to substitute for a refusal. Applies to every agent in this package."
applyTo: "**"
---

# Write safety

An AppCon write is not a database row. A connection submitted for approval
becomes a firewall change request on the cyber team's queue, reviewed by people
who will assume somebody checked it. Creating ten of those by accident is not
recoverable by deleting ten records.

So this package is read-only by default and writes only where it is told to.

## The boundary

Exactly two scripts may write:

| Script | Writes | Gate |
|---|---|---|
| `apply_plan.py` | consumers, providers, connections | `--confirm` **and** a plan whose `spec_version` still matches live |
| `submit_approval.py` | change requests | `--confirm` **and** a GOV-ID validated against ServiceNow |

Everything else constructs `AppConClient(dry_run=True)`, which refuses any
`POST`/`PUT`/`PATCH`/`DELETE` outside a short allowlist of evaluative endpoints
(`policy-overlap`, `auto-approval-evaluation`, `providers/similar`,
`providers/validate`). Those are POSTs because they take a body, not because
they change anything.

Only [appcon-submitter](../agents/appcon-submitter.agent.md) invokes the two
writing scripts. No other agent runs them, and no agent runs them without having
shown the user what will be created first.

## Rules

**Never pass `--confirm` on the user's behalf.** Not because they said "go
ahead" earlier in the conversation, not to save a round trip, not when the plan
looks obviously fine. The un-confirmed run prints what it would create and exits
3; that output is the thing the user is agreeing to, and they cannot agree to it
before it exists.

**Never work around a refusal.** These are the refusals you will meet and what
they mean:

- *"spec_version does not match"* - the API changed since the plan was reviewed.
  Re-plan. Do not edit `spec_version` in `plan.json`.
- *"requires <field> and this script has no value to put there"* - AppCon needs
  something the SAD does not supply. Ask the user which column supplies it, then
  add the alias in `apply_plan.py`. Do not invent a value.
- *"is not on the read-only allowlist"* - you are trying to write from a script
  that plans. Whatever you were about to do belongs in `apply_plan.py`.
- *"unresolved is non-empty"* - some rows could not be read. Resolve or drop
  them explicitly; do not filter them out of the file.

Editing a script to weaken one of these, or reconstructing its request with
`curl`, is out of bounds. If a refusal is wrong, the fix is a change to the
script that is reviewed and tested - not a bypass in one run.

**Treat a failed write as unknown, not as failed.** A timeout after `POST
/connections` may well have created the connection. Re-running is safe because
the ledger and the `appcon-agent:<key>` stamp make creates idempotent - but only
if you re-run the script. Do not "just create the missing one" by hand; you
cannot see the stamp from here.

**Never report a write you did not observe.** If `apply_plan.py` exits 2, some
entries failed. Say which, from its stderr. The ledger is accurate at all times
and is the source of truth for what exists - not the transcript, and not your
recollection of what you intended to do.

## Auth

The client authenticates with `APPCON_COOKIE`, an SSO session cookie, because
the API requires an SSO session and no service-principal path is confirmed. Two
consequences:

- The session expires. A 401 mid-batch is an expired cookie, not a permissions
  problem, and the ledger tells you where to resume.
- Writes happen as the signed-in human. Everything this package creates is
  attributable to them, which is a good reason for them to see it first.

Never print the cookie, never write it into an output file, and never put it in
a command line you echo back to the user.
