---
description: "How every value in a connectivity requirement records where it came from: read, parsed, or inferred. Applies to any agent that writes or reviews requirements.json."
applyTo: "**/out/appcon/requirements.json"
---

# Derivation typing

A connectivity requirement becomes a firewall rule. Somebody will be asked to
approve it who was not in the room when it was derived, and their only way to
tell "the SAD says this" from "we worked this out" is the `derivation` map.

Every field in a requirement carries one of three types. `expand_requirements.py`
sets them while it parses, and `check_derivation_coverage()` refuses a
requirement where any field lacks one. When you resolve something the expander
could not, you are setting these types by hand, so they are your judgement.

## The three types

| Type | Means | Example |
|---|---|---|
| `VERBATIM` | The cell said exactly this | `purpose` lifted whole from the Purpose column |
| `PARSED` | The cell said this in another form | `443 / HTTPS TLS 1.2` → port 443, TLS 1.2 |
| `INFERRED` | The document does not state it; someone decided | pairing `CI` to `qa.temp.psii.lseg.com` |

`VERBATIM` and `PARSED` are both readings - the difference is only whether a
machine had to reshape the text. Either can be checked by reading the SAD.

`INFERRED` cannot. It is the type that matters.

## The rule that makes this worth doing

**Never mark something `PARSED` because you are confident about it.**

Confidence is not evidence. "The row lists Dev, CI, Alpha and Pre-Prod, and the
hostnames are dev, qa, uat and ppe, so obviously qa is CI" may well be right. It
is still `INFERRED`, because nothing in the document says so and the person
approving the change request needs to know that.

The failure this prevents is specific and it is not hypothetical: four
environments and four hostnames that do not correspond, typed as `PARSED`,
produce a requirements file that looks fully sourced. Nobody reviews what looks
fully sourced.

## Consequences you are choosing when you type a field

- A requirement containing any `INFERRED` field gets `review.required: true`.
- `create-plan` reports those separately and `apply-plan` will still create
  them - the flag is for the human reading the plan, not a hard gate.
- The business justification submitted with the change request does **not**
  repeat your inference. If the pairing is a guess, the approver is approving a
  guess, and it should be visible in the plan before it reaches them.

## When you cannot type a field honestly

Leave the row unresolved. `unresolved[]` at the top of the requirements document
exists for this and costs nothing: `create-plan` refuses to run while it is
non-empty, so an unresolved row stops the batch rather than silently shrinking
it.

An unresolved row is a question for the SAD's author. A wrongly typed one is a
firewall rule nobody can trace.

## What is not a derivation question

Field names in AppCon request bodies. Those come from the live OpenAPI document
via `appcon_client.py`, which refuses to send a field the spec does not describe.
Do not put guessed API field names in a requirement and do not let a failure
there be resolved by inference - see
[write-safety](write-safety.instructions.md).
