# LMP Council

Five agents produce an Azure target architecture, network design, migration plan
and SAD from a folder of application documents. A deterministic script checks
their work.

## Why this exists

An LLM asked to design a migration will produce a confident, well-structured
document containing values nobody can source. The failure is not that it is
wrong often - it is that a fabricated value and a measured one look identical on
the page.

So every value here is a **claim** with a type:

| Type | Means | Must carry |
|---|---|---|
| `FACT` | Read in a source document | A citation that resolves to a real line |
| `DECISION` | An agent chose it | Why, and what was rejected |
| `ASSUMPTION` | Nobody knows yet | Why, and what would settle it |

`Audit-Claims.ps1` opens the cited file and checks the line exists. It runs no
model. A council where one LLM reviews another rewards fluency, and fabricated
architecture is fluent - only the file check measures truth.

## The members

```
reader ──> source-facts.json ──┬──> target-architect ──> target-architecture.json ──┐
                               ├──> network-designer  ──> network-design.json      ─┤
                               └──> migration-planner ──> migration-plan.json      ─┤
                                                                                    v
                                          master: audit each, arbitrate ──> sad-writer ──> SAD.md
```

- **One witness.** Only the reader may state a fact. The specialists work from
  its document and never re-read the sources, so every fact has one owner and one
  claim id to correct.
- **Parallel, then arbitrated.** The specialists do not see each other's
  reasoning. Independent work makes disagreement visible instead of averaging it
  away.
- **The SAD holds ids, not values.** It cannot drift from the documents behind
  it; `Render-Sad.ps1` joins ids back to values at render time and refuses to
  render a reference to a claim nobody made.
- **One revision.** A rejected claim gets a second attempt, then becomes an open
  question. Unbounded retries produce output the audit accepts by attrition.

## Schemas own the field names

Agent instructions name no fields - they say "read the schema for your document
type". Change `schemas\sad.schema.json` and the agents follow it without being
rewritten, which was the point of putting the contract in JSON rather than in
prose.

`Test-SchemaInstance.ps1` is a hand-written validator because `Test-Json` is
PowerShell 6+. It **rejects any keyword it does not implement** rather than
ignoring it - a validator that silently skips `oneOf` gives false assurance,
which is worse than no validator.

## Use

In Copilot Chat. `/council-init <root>` scaffolds an empty workspace; put the
application documents in `<root>\src` (loose files or subfolders, both work) and
run it again to extract them.

| Command | Does |
|---|---|
| `/council <root>` | all of it, in order |
| `/council-init` | create the workspace, extract the documents |
| `/read-sources` | record cited facts - not `create`, because nothing is invented |
| `/create-target-architecture` | the Azure target |
| `/create-network-design` | connectivity, segmentation, DNS |
| `/create-migration-plan` | waves, cutover, rollback |
| `/create-sad` | arbitrate, assemble, render |
| `/council-status` | where things stand, checks re-run |

Each `/create-*` runs the minimum chain it needs - ask for a network design first
and it will read the sources and design the target before it starts, rather than
inventing an estate to connect. Re-running one step after a correction does not
re-read the corpus.

Outputs land in `<root>\out\council\`: `documents\` (the claims), `reports\` (the
audits), `deliverables\SAD.md` and `open-questions.md`.

Set `LMP_CPF_CATALOG` to the CPF `_catalog.json` so service choices are checked
against the clearlist. Without it `Check-Cpf.ps1` exits `2` - **not assessed**,
which is deliberately not the same as allowed.

## Tests

```powershell
.\tests\Invoke-Tests.ps1
```

29 tests, most of them rejection paths: an uncited fact, a citation to a file
that does not exist, a citation past the end of a file, a quote that is not at
the cited line, a decision with no alternatives, a duplicate id, a SAD
referencing a claim nobody made, and a SAD handed to the claim audit - which
refuses it rather than reporting "0 claims, clean".

Rejection is what the suite is for. During development the audit briefly passed
decisions that had no alternatives at all, because `@($null)` counts as one item
in PowerShell - it was caught by a test asserting a refusal, not by any test
asserting success.

## Verification status

29/29 on **Windows PowerShell 5.1.26100** (Desktop) and **PowerShell 7.6.6**
(Core). Run it on both before shipping a change - the two editions disagree in
ways that pass silently:

- `Write-Output -NoEnumerate` on a **scalar** returns the scalar on 5.1 and a
  `List[object]` on 7, where `@()` over it throws `Argument types do not match`.
  Apply it only to collections.
- `return (Write-Output -NoEnumerate $x)` re-enumerates on both editions - the
  parentheses collect the pipeline and `return` unrolls it again. Emit it as the
  final statement instead.
- `ConvertFrom-Json` on 7 parses an ISO-8601 string into a `DateTime`; 5.1 leaves
  it a string. `Get-JsonType` reports it as a string, because that is what the
  document on disk holds.

The suite prints the edition it ran under, so a run that only proves one of them
is obvious in the output.

