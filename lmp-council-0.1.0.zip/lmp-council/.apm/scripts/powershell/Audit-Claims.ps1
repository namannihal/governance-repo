<#
.SYNOPSIS
    Check a council document: schema shape, then whether its claims stand up.

.DESCRIPTION
    The schema fixes the shape. This checks the thing a schema cannot: that a
    claim typed FACT actually points at a line in a real document, and that a
    DECISION says what it rejected.

    It is deliberately dumb. It reads files and compares strings; no model is
    asked whether the work is good. That is the point - an LLM reviewing another
    LLM rewards fluency, and fabricated architecture is fluent.

    Runs on Windows PowerShell 5.1 and PowerShell 7.

.PARAMETER Document
    The council document (JSON) to audit.

.PARAMETER SchemaDir
    Folder holding the schemas. Defaults to ..\..\..\schemas relative to here.

.PARAMETER ExtractedRoot
    Folder the citations are relative to - the extracted intake.

.PARAMETER RequireQuoteMatch
    Also require that a claim's quote appears at the cited line. Off by default
    because extraction reflows text; on for a final deliverable.

.OUTPUTS
    A report on stdout and out\council\reports\<document>.audit.md

.NOTES
    Exit codes: 0 clean - 2 cannot assess (missing input) - 3 claims rejected
                4 misconfigured (bad schema, unknown document type).
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Document,
    [string]$SchemaDir,
    [string]$ExtractedRoot,
    [switch]$RequireQuoteMatch
)

$ErrorActionPreference = 'Stop'

if (-not $SchemaDir) {
    $SchemaDir = Join-Path (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))) 'schemas'
}

. (Join-Path $PSScriptRoot 'Test-SchemaInstance.ps1')

function Fail([string]$Message, [int]$Code) {
    [Console]::Error.WriteLine("audit: $Message")
    exit $Code
}

# @($null) is an array of one in PowerShell, so an absent list would count as a
# present one - that alone would let a DECISION with no alternatives pass.
function AsList($Value) {
    if ($null -eq $Value) { return @() }
    @($Value) | Where-Object { $null -ne $_ }
}

if (-not (Test-Path -LiteralPath $Document)) { Fail "document not found: $Document" 2 }
if (-not (Test-Path -LiteralPath $SchemaDir)) { Fail "schema folder not found: $SchemaDir" 4 }

try { $doc = Read-JsonFile $Document } catch { Fail $_.Exception.Message 2 }

$docType = Get-Prop $doc 'document_type'
if (-not $docType) { Fail 'document has no document_type' 4 }

$schemaPath = Join-Path $SchemaDir ("{0}.schema.json" -f $docType)
if ($docType -eq 'source-facts') { $schemaPath = Join-Path $SchemaDir 'source-facts.schema.json' }
if (-not (Test-Path -LiteralPath $schemaPath)) { Fail "no schema for document_type '$docType'" 4 }

$schema = Read-JsonFile $schemaPath
$shapeErrors = @(Test-JsonSchemaInstance -Schema $schema -InstanceBox (, $doc) -SchemaDir (Resolve-Path -LiteralPath $SchemaDir).Path)

# A SAD references claims by id and states none of its own, so "0 claims, clean"
# would be a pass from a check that never ran. Decided by the schema, not by
# document type, so a new claim-bearing document works without editing this.
$claimBearing = Test-HasProp (Get-Prop $schema 'properties') 'claims'

$problems = New-Object System.Collections.ArrayList
foreach ($e in $shapeErrors) { [void]$problems.Add([ordered]@{ claim = ''; kind = 'schema'; detail = $e }) }

# Citations are relative to the extracted intake, because that is what the agents
# were given. Citing an original PDF would be untraceable - nobody can point at
# line 59 of a binary.
if (-not $ExtractedRoot) {
    # <root>\out\council\documents\<doc>.json - four levels up is the workspace root.
    $docDir = Split-Path -Parent (Resolve-Path -LiteralPath $Document).Path
    $root = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $docDir))
    $ExtractedRoot = Join-Path $root 'out\extracted'
}

$claims = @(AsList (Get-Prop $doc 'claims'))
$prefix = Get-Prop $doc 'claim_prefix'
$seen = @{}
$counts = @{ FACT = 0; DECISION = 0; ASSUMPTION = 0 }
$resolved = 0

foreach ($c in $claims) {
    $id = [string](Get-Prop $c 'id')
    $type = [string](Get-Prop $c 'claim_type')
    $field = [string](Get-Prop $c 'field')
    if ($counts.ContainsKey($type)) { $counts[$type]++ }

    if ($seen.ContainsKey($id)) {
        [void]$problems.Add([ordered]@{ claim = $id; kind = 'duplicate-id'; detail = "id '$id' is used more than once" })
    }
    $seen[$id] = $true

    if ($prefix -and $id -and -not $id.StartsWith("$prefix-")) {
        [void]$problems.Add([ordered]@{ claim = $id; kind = 'wrong-prefix'; detail = "id does not start with this document's prefix '$prefix'" })
    }

    switch ($type) {
        'FACT' {
            $cit = [string](Get-Prop $c 'citation')
            if (-not $cit) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'uncited-fact'; detail = "FACT '$field' has no citation. State it as an ASSUMPTION or cite a document." })
                break
            }
            $m = [regex]::Match($cit, '^(?<file>.+?)#L(?<from>\d+)(?:-L(?<to>\d+))?$')
            if (-not $m.Success) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'bad-citation'; detail = "citation '$cit' is not of the form <file>#L<n> or <file>#L<a>-L<b>" })
                break
            }
            $file = $m.Groups['file'].Value
            $from = [int]$m.Groups['from'].Value
            $to = $from
            if ($m.Groups['to'].Success) { $to = [int]$m.Groups['to'].Value }

            $full = Join-Path $ExtractedRoot $file
            if (-not (Test-Path -LiteralPath $full)) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'missing-source'; detail = "cited file does not exist: $file" })
                break
            }
            $lines = @(Get-Content -LiteralPath $full)
            if ($from -lt 1 -or $to -gt $lines.Count) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'line-out-of-range'; detail = "cited L$from-L$to but $file has $($lines.Count) line(s)" })
                break
            }
            $resolved++

            $quote = [string](Get-Prop $c 'quote')
            if ($RequireQuoteMatch -and $quote) {
                $window = ($lines[($from - 1)..($to - 1)] -join ' ')
                $norm = ($window -replace '\s+', ' ').Trim()
                $q = ($quote -replace '\s+', ' ').Trim()
                if ($norm.IndexOf($q, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
                    [void]$problems.Add([ordered]@{ claim = $id; kind = 'quote-not-found'; detail = "quote does not appear at $cit" })
                }
            }
        }
        'DECISION' {
            if (-not (Get-Prop $c 'rationale')) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'unjustified-decision'; detail = "DECISION '$field' has no rationale" })
            }
            if (@(AsList (Get-Prop $c 'alternatives_considered')).Count -eq 0) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'no-alternatives'; detail = "DECISION '$field' rejected nothing - if there was no alternative it is a FACT or an ASSUMPTION" })
            }
        }
        'ASSUMPTION' {
            if (-not (Get-Prop $c 'rationale')) {
                [void]$problems.Add([ordered]@{ claim = $id; kind = 'bare-assumption'; detail = "ASSUMPTION '$field' does not say why it cannot be known" })
            }
        }
        default {
            [void]$problems.Add([ordered]@{ claim = $id; kind = 'unknown-type'; detail = "claim_type '$type' is not FACT, DECISION or ASSUMPTION" })
        }
    }
}

# A required field with no claim is the quiet failure: the section simply is not
# there, and a reader assumes it was considered and found unremarkable.
$covered = @($claims | ForEach-Object { [string](Get-Prop $_ 'field') })
$uncovered = @()
foreach ($rf in (AsList (Get-Prop $doc 'required_fields'))) {
    if ($covered -notcontains $rf) { $uncovered += $rf }
}

$outDir = Join-Path (Split-Path -Parent (Split-Path -Parent (Resolve-Path -LiteralPath $Document).Path)) 'reports'
if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
$reportPath = Join-Path $outDir ((Split-Path $Document -Leaf) + '.audit.md')

$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine('<!-- GENERATED. Rebuilt by Audit-Claims.ps1. -->')
[void]$sb.AppendLine('')
[void]$sb.AppendLine("# Claim audit - $docType")
[void]$sb.AppendLine('')
[void]$sb.AppendLine('| metric | count |')
[void]$sb.AppendLine('|---|---|')
[void]$sb.AppendLine("| claims | $($claims.Count) |")
[void]$sb.AppendLine("| FACT | $($counts['FACT']) |")
[void]$sb.AppendLine("| DECISION | $($counts['DECISION']) |")
[void]$sb.AppendLine("| ASSUMPTION | $($counts['ASSUMPTION']) |")
[void]$sb.AppendLine("| citations resolved | $resolved |")
[void]$sb.AppendLine("| required fields with no claim | $($uncovered.Count) |")
[void]$sb.AppendLine("| problems | $($problems.Count) |")
[void]$sb.AppendLine('')

if ($problems.Count -gt 0) {
    [void]$sb.AppendLine('## Rejected')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('| claim | kind | detail |')
    [void]$sb.AppendLine('|---|---|---|')
    foreach ($p in $problems) {
        [void]$sb.AppendLine(("| {0} | {1} | {2} |" -f $p.claim, $p.kind, ($p.detail -replace '\|', '\|')))
    }
    [void]$sb.AppendLine('')
}
if ($uncovered.Count -gt 0) {
    [void]$sb.AppendLine('## Required fields with no claim')
    [void]$sb.AppendLine('')
    foreach ($u in $uncovered) { [void]$sb.AppendLine("- ``$u``") }
    [void]$sb.AppendLine('')
}

Set-Content -LiteralPath $reportPath -Value $sb.ToString() -Encoding UTF8

Write-Output ("audit {0}: {1} claim(s) - {2} FACT ({3} cited ok), {4} DECISION, {5} ASSUMPTION" -f `
        $docType, $claims.Count, $counts['FACT'], $resolved, $counts['DECISION'], $counts['ASSUMPTION'])
if ($uncovered.Count -gt 0) {
    Write-Output ("  {0} required field(s) carry no claim: {1}" -f $uncovered.Count, ($uncovered -join ', '))
}
Write-Output ("report: {0}" -f $reportPath)

if ($problems.Count -gt 0) {
    foreach ($p in $problems) { [Console]::Error.WriteLine(("  [{0}] {1} {2}" -f $p.kind, $p.claim, $p.detail)) }
    [Console]::Error.WriteLine(("audit: {0} problem(s) - document rejected" -f $problems.Count))
    exit 3
}
if ($uncovered.Count -gt 0) { exit 3 }
if (-not $claimBearing) {
    [Console]::Error.WriteLine("audit: '$docType' holds no claims of its own, so there was nothing here to audit.")
    [Console]::Error.WriteLine('  Its shape is valid. Its claim references are NOT checked by this tool -')
    [Console]::Error.WriteLine('  run Render-Sad.ps1, which resolves every referenced id and exits 3 if one is missing.')
    exit 2
}
exit 0
