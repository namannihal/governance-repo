<#
.SYNOPSIS
    Create a council workspace.

.DESCRIPTION
    Folder names are load-bearing: agents are told where to read and write, and
    a mistyped folder is the difference between a council that read your
    documents and one that read nothing and said so confidently.

    Runs on Windows PowerShell 5.1 and PowerShell 7.

.PARAMETER Root
    Where to create the workspace.

.PARAMETER Application
    Name of the application being migrated.

.PARAMETER Force
    Recreate the scaffolding over an existing root. Never deletes src or
    documents already produced.

.NOTES
    Exit codes: 0 created - 5 already exists (use -Force).
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Root,
    [string]$Application = 'unnamed-application',
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

$marker = Join-Path $Root 'council.json'
if ((Test-Path -LiteralPath $marker) -and -not $Force) {
    [Console]::Error.WriteLine("council: a workspace already exists at $Root")
    [Console]::Error.WriteLine('  Re-run with -Force to refresh the scaffolding. Existing documents are kept.')
    exit 5
}

$folders = @(
    'src',
    'out\extracted',
    'out\council\documents',
    'out\council\reports',
    'out\council\deliverables'
)
foreach ($f in $folders) {
    $p = Join-Path $Root $f
    if (-not (Test-Path -LiteralPath $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

$meta = [ordered]@{
    application  = $Application
    created_at   = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    layout       = [ordered]@{
        sources     = 'src'
        extracted   = 'out/extracted'
        documents   = 'out/council/documents'
        reports     = 'out/council/reports'
        deliverables = 'out/council/deliverables'
    }
}
($meta | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $marker -Encoding UTF8

Write-Output ("council workspace ready: {0}" -f $Root)
Write-Output '  src/                        put the source documents here'
Write-Output '  out/extracted/              text the council actually reads'
Write-Output '  out/council/documents/      member documents (JSON)'
Write-Output '  out/council/reports/        audits and the council log'
Write-Output '  out/council/deliverables/   the SAD and its companions'
exit 0
