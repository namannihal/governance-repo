<#
.SYNOPSIS
    Render sad.json into a readable SAD, resolving every claim id to its value.

.DESCRIPTION
    The SAD references claims by id rather than restating them, so it cannot
    drift from the member documents. That makes it unreadable as JSON, which is
    this script's job: join the ids back to values and show, per line, where
    each came from and whether it was read, decided or assumed.

    A reader should be able to see at a glance which parts of the architecture
    are evidence and which are somebody's choice. That distinction is the whole
    point and it must survive into the printed document.

    Runs on Windows PowerShell 5.1 and PowerShell 7.

.PARAMETER Sad
    sad.json to render.

.PARAMETER DocumentDir
    Folder holding the member documents. Defaults to the SAD's own folder.

.PARAMETER Out
    Output markdown path.

.NOTES
    Exit codes: 0 rendered - 2 cannot assess - 3 a referenced claim is missing.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Sad,
    [string]$DocumentDir,
    [string]$Out
)

$ErrorActionPreference = 'Stop'

function Read-Json([string]$Path) {
    $raw = Get-Content -LiteralPath $Path -Raw
    if ($raw.Length -gt 0 -and [int][char]$raw[0] -eq 65279) { $raw = $raw.Substring(1) }
    $raw | ConvertFrom-Json
}
function Prop($Obj, [string]$Name) {
    # -NoEnumerate: a returned one-element array would otherwise arrive as its
    # single element, and a section with one claim id would stop rendering.
    # Collections only - on PowerShell 7 it wraps a scalar in a List[object].
    if ($null -eq $Obj) { return $null }
    $p = $Obj.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    if ($p.Value -is [System.Collections.IEnumerable] -and -not ($p.Value -is [string])) {
        Write-Output -NoEnumerate $p.Value
        return
    }
    $p.Value
}

if (-not (Test-Path -LiteralPath $Sad)) {
    [Console]::Error.WriteLine("render: sad not found: $Sad"); exit 2
}
$doc = Read-Json $Sad
if (-not $DocumentDir) { $DocumentDir = Split-Path -Parent (Resolve-Path -LiteralPath $Sad).Path }
if (-not $Out) {
    $deliverables = Join-Path (Split-Path -Parent $DocumentDir) 'deliverables'
    if (-not (Test-Path -LiteralPath $deliverables)) { New-Item -ItemType Directory -Path $deliverables -Force | Out-Null }
    $Out = Join-Path $deliverables 'SAD.md'
}

# Index every claim from every member document, so a section can pull from more
# than one member without the SAD copying values.
$index = @{}
foreach ($f in (Get-ChildItem -LiteralPath $DocumentDir -Filter *.json -File)) {
    $d = Read-Json $f.FullName
    $memberClaims = Prop $d 'claims'
    foreach ($c in $memberClaims) {
        $id = [string](Prop $c 'id')
        if ($id) { $index[$id] = $c }
    }
}

$missing = New-Object System.Collections.ArrayList
$sb = New-Object System.Text.StringBuilder
$assumptions = New-Object System.Collections.ArrayList
$decisions = New-Object System.Collections.ArrayList

[void]$sb.AppendLine('<!-- GENERATED. Rebuilt by Render-Sad.ps1 from sad.json. Do not edit. -->')
[void]$sb.AppendLine('')
[void]$sb.AppendLine(("# Solution Architecture - {0}" -f (Prop $doc 'application')))
[void]$sb.AppendLine('')
[void]$sb.AppendLine(("Generated {0} by {1}." -f (Prop $doc 'generated_at'), (Prop $doc 'author_agent')))
[void]$sb.AppendLine('')
[void]$sb.AppendLine('> Every line below is tagged. **FACT** was read from a source document and cites it.')
[void]$sb.AppendLine('> **DECISION** was chosen by an agent. **ASSUMPTION** is a stand-in for something')
[void]$sb.AppendLine('> nobody has decided. Only FACT is evidence; the rest needs a human.')
[void]$sb.AppendLine('')

$sections = Prop $doc 'sections'
foreach ($sec in $sections) {
    [void]$sb.AppendLine(("## {0}" -f (Prop $sec 'title')))
    [void]$sb.AppendLine('')
    $narrative = Prop $sec 'narrative'
    if ($narrative) { [void]$sb.AppendLine($narrative); [void]$sb.AppendLine('') }

    $ids = Prop $sec 'claim_ids'
    if ($null -eq $ids) { $ids = @() }
    if (@($ids).Count -eq 0) { [void]$sb.AppendLine('_No claims in this section._'); [void]$sb.AppendLine(''); continue }

    [void]$sb.AppendLine('| field | value | type | source or rationale |')
    [void]$sb.AppendLine('|---|---|---|---|')
    foreach ($id in $ids) {
        $c = $index[[string]$id]
        if ($null -eq $c) {
            [void]$missing.Add($id)
            [void]$sb.AppendLine(("| _{0}_ | **MISSING CLAIM** | | referenced but not found in any member document |" -f $id))
            continue
        }
        $type = [string](Prop $c 'claim_type')
        $where = ''
        if ($type -eq 'FACT') { $where = [string](Prop $c 'citation') }
        else { $where = [string](Prop $c 'rationale') }
        $value = [string](Prop $c 'value')
        [void]$sb.AppendLine(("| {0} | {1} | {2} | {3} |" -f `
            (Prop $c 'field'), ($value -replace '\|', '\|'), $type, ($where -replace '\|', '\|')))

        if ($type -eq 'ASSUMPTION') { [void]$assumptions.Add($c) }
        if ($type -eq 'DECISION') { [void]$decisions.Add($c) }
    }
    [void]$sb.AppendLine('')
}

$arbs = Prop $doc 'arbitrations'
if ($null -eq $arbs) { $arbs = @() }
if (@($arbs).Count -gt 0) {
    [void]$sb.AppendLine('## Where the council disagreed')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('| id | conflict | chosen | rejected | why |')
    [void]$sb.AppendLine('|---|---|---|---|---|')
    foreach ($a in $arbs) {
        [void]$sb.AppendLine(("| {0} | {1} | {2} | {3} | {4} |" -f `
            (Prop $a 'id'), (Prop $a 'conflict'), (Prop $a 'chosen'), ((Prop $a 'rejected') -join '; '), (Prop $a 'why')))
    }
    [void]$sb.AppendLine('')
}

Set-Content -LiteralPath $Out -Value $sb.ToString() -Encoding UTF8

# The open questions are the point of the single human review, so they are their
# own file rather than a section somebody scrolls past.
$openPath = Join-Path (Split-Path -Parent $Out) 'open-questions.md'
$ob = New-Object System.Text.StringBuilder
[void]$ob.AppendLine('<!-- GENERATED. Rebuilt by Render-Sad.ps1. -->')
[void]$ob.AppendLine('')
[void]$ob.AppendLine('# Open questions')
[void]$ob.AppendLine('')
[void]$ob.AppendLine('These are the only places the council chose or guessed. Everything else in the')
[void]$ob.AppendLine('SAD cites a document. Review these and the SAD is reviewed.')
[void]$ob.AppendLine('')
[void]$ob.AppendLine(("## Assumptions ({0}) - nobody knows these yet" -f $assumptions.Count))
[void]$ob.AppendLine('')
if ($assumptions.Count -eq 0) { [void]$ob.AppendLine('_None._') }
else {
    [void]$ob.AppendLine('| id | field | assumed value | why |')
    [void]$ob.AppendLine('|---|---|---|---|')
    foreach ($a in $assumptions) {
        [void]$ob.AppendLine(("| {0} | {1} | {2} | {3} |" -f (Prop $a 'id'), (Prop $a 'field'), (Prop $a 'value'), (Prop $a 'rationale')))
    }
}
[void]$ob.AppendLine('')
[void]$ob.AppendLine(("## Decisions ({0}) - an agent chose these" -f $decisions.Count))
[void]$ob.AppendLine('')
if ($decisions.Count -eq 0) { [void]$ob.AppendLine('_None._') }
else {
    [void]$ob.AppendLine('| id | field | chosen | rejected | why |')
    [void]$ob.AppendLine('|---|---|---|---|---|')
    foreach ($d in $decisions) {
        [void]$ob.AppendLine(("| {0} | {1} | {2} | {3} | {4} |" -f `
            (Prop $d 'id'), (Prop $d 'field'), (Prop $d 'value'), ((Prop $d 'alternatives_considered') -join '; '), (Prop $d 'rationale')))
    }
}
Set-Content -LiteralPath $openPath -Value $ob.ToString() -Encoding UTF8

Write-Output ("sad:            {0}" -f $Out)
Write-Output ("open questions: {0}" -f $openPath)
Write-Output ("{0} assumption(s), {1} decision(s) need a human" -f $assumptions.Count, $decisions.Count)

if ($missing.Count -gt 0) {
    [Console]::Error.WriteLine(("render: {0} referenced claim(s) do not exist: {1}" -f $missing.Count, ($missing -join ', ')))
    exit 3
}
exit 0
