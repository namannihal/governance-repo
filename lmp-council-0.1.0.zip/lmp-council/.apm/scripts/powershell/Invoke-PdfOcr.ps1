<#
.SYNOPSIS
    Read a scanned or image-only PDF using the OCR engine built into Windows.

.DESCRIPTION
    Renders each page with Windows.Data.Pdf and recognises it with
    Windows.Media.Ocr. Both ship with Windows 10 and later, so this needs no
    modules, no installs and no network.

    OCR text is NOT the document's own words in the way a text layer is - it is a
    machine's reading of a picture of them. Recognition errors are silent and
    plausible ('15' for '5', 'l' for '1'), which is exactly the failure this
    system exists to prevent elsewhere. So anything extracted here is marked as
    OCR-derived, and a human has to check a quote before it becomes evidence.

    Exit 0 with text on stdout, 2 if nothing could be recognised, 4 on setup or
    argument problems.

.EXAMPLE
    .\Invoke-PdfOcr.ps1 -Path .\scan.pdf
    .\Invoke-PdfOcr.ps1 -Path .\scan.pdf -MaxPages 5 -Scale 2.5 -Password 01011990
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Path,
    [int]$MaxPages = 100,
    # Rendering above the page's natural size materially improves recognition of
    # body text; below about 1.5 small print is routinely missed.
    [double]$Scale = 2.0,
    [string]$Language,
    [string]$Password
)

$ErrorActionPreference = 'Stop'

# WinRT interop lives in the .NET Framework surface that PowerShell 7 does not
# carry, so the reflection below throws PlatformNotSupported there. The machine can
# still do OCR - only this shell cannot - so hand the work to Windows PowerShell
# rather than reporting the document as unreadable.
if ($PSVersionTable.PSEdition -eq 'Core') {
    $winPs = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $winPs)) {
        [Console]::Error.WriteLine('ocr: needs Windows PowerShell 5.1 for WinRT, which is not present on this machine')
        exit 4
    }
    $relaunch = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath,
        '-Path', $Path, '-MaxPages', $MaxPages, '-Scale', $Scale)
    if ($Language) { $relaunch += @('-Language', $Language) }
    # Handed over out of band: a command line is readable by any process on the box.
    if ($Password) { $env:LMP_PDF_PASSWORD = $Password }
    $prev = $ErrorActionPreference
    # The child writes progress to stderr, which 'Stop' would promote to a terminating
    # NativeCommandError and abort a caller that was about to succeed.
    $ErrorActionPreference = 'Continue'
    try {
        & $winPs $relaunch 2>&1 | ForEach-Object {
            if ($_ -is [System.Management.Automation.ErrorRecord]) { [Console]::Error.WriteLine($_.ToString()) }
            else { $_ }
        }
        $code = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $prev
        if ($Password) { Remove-Item Env:\LMP_PDF_PASSWORD -ErrorAction SilentlyContinue }
    }
    exit $code
}

if (-not $Password -and $env:LMP_PDF_PASSWORD) { $Password = $env:LMP_PDF_PASSWORD }

if (-not (Test-Path -LiteralPath $Path)) {
    [Console]::Error.WriteLine("ocr: file not found: $Path")
    exit 4
}
$full = (Resolve-Path -LiteralPath $Path).Path

Add-Type -AssemblyName System.Runtime.WindowsRuntime | Out-Null

# WinRT returns IAsyncOperation/IAsyncAction, which PowerShell 5.1 cannot await
# directly. These reflect out the AsTask extension methods and block on the task.
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    })[0]
$asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.FullName -eq 'Windows.Foundation.IAsyncAction'
    })[0]

function Await($Op, $ResultType) {
    $m = $asTaskGeneric.MakeGenericMethod($ResultType)
    $t = $m.Invoke($null, @($Op))
    $t.Wait(-1) | Out-Null
    $t.Result
}
function AwaitAction($Action) {
    $t = $asTaskAction.Invoke($null, @($Action))
    $t.Wait(-1) | Out-Null
}

try {
    [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType = WindowsRuntime] | Out-Null
    [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
}
catch {
    [Console]::Error.WriteLine('ocr: the Windows OCR and PDF components are not available on this machine')
    exit 4
}

# --- engine ---------------------------------------------------------------- #
$engine = $null
if ($Language) {
    $lang = New-Object Windows.Globalization.Language($Language)
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
}
if ($null -eq $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if ($null -eq $engine) {
    $available = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | ForEach-Object { $_.LanguageTag })
    if ($available.Count -gt 0) {
        $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language($available[0])))
    }
}
if ($null -eq $engine) {
    [Console]::Error.WriteLine('ocr: no OCR language pack is installed - add one under Settings > Time & language')
    exit 4
}

# --- document -------------------------------------------------------------- #
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($full)) ([Windows.Storage.StorageFile])
try {
    $pdf = if ($Password) {
        Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file, $Password)) ([Windows.Data.Pdf.PdfDocument])
    }
    else {
        Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
    }
}
catch {
    [Console]::Error.WriteLine('ocr: the PDF could not be opened - it may need a password (pass -Password)')
    exit 2
}

$pageCount = [int]$pdf.PageCount
$limit = [Math]::Min($pageCount, $MaxPages)
$sb = New-Object System.Text.StringBuilder
$recognised = 0

if ($pageCount -gt $limit) {
    # Truncation has to travel with the text. A reader who cannot see that pages are
    # missing will read absence of evidence as evidence of absence.
    [void]$sb.AppendLine(("> **TRUNCATED: only the first {0} of {1} pages were read.** Raise -MaxPages to read the rest." -f $limit, $pageCount))
    [void]$sb.AppendLine('')
    [Console]::Error.WriteLine(("ocr: WARNING - reading only {0} of {1} pages (-MaxPages {0})" -f $limit, $pageCount))
}

for ($i = 0; $i -lt $limit; $i++) {
    $page = $pdf.GetPage([uint32]$i)
    try {
        $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
        try {
            $opts = New-Object Windows.Data.Pdf.PdfPageRenderOptions
            $opts.DestinationWidth = [uint32]([Math]::Round($page.Size.Width * $Scale))
            AwaitAction ($page.RenderToStreamAsync($stream, $opts))

            $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            try {
                $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
                $text = $result.Text
                if ($text -and $text.Trim()) {
                    $recognised++
                    [void]$sb.AppendLine(("## Page {0}" -f ($i + 1)))
                    [void]$sb.AppendLine('')
                    foreach ($line in $result.Lines) { [void]$sb.AppendLine($line.Text) }
                    [void]$sb.AppendLine('')
                }
            }
            finally { $bitmap.Dispose() }
        }
        finally { $stream.Dispose() }
    }
    finally { $page.Dispose() }
}

if ($recognised -eq 0) {
    [Console]::Error.WriteLine('ocr: no text could be recognised on any page')
    exit 2
}

if ($pageCount -gt $limit) {
    [void]$sb.AppendLine(("_Only the first {0} of {1} pages were read (-MaxPages)._" -f $limit, $pageCount))
}

Write-Output $sb.ToString()
[Console]::Error.WriteLine(("ocr: {0} of {1} page(s) produced text" -f $recognised, $limit))
exit 0
