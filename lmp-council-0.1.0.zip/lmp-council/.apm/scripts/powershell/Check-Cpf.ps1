<#
.SYNOPSIS
    Answer whether an Azure service is CPF clear-listed. Deterministic, no model.

.DESCRIPTION
    A design agent proposing an Azure service needs a fast, factual answer to
    "is this even allowed here". This gives one from the CPF catalogue, so the
    answer comes from the enterprise list rather than from what the model
    remembers about Azure.

    Runs on Windows PowerShell 5.1 and PowerShell 7.

.PARAMETER Module
    One or more CPF module ids to check.

.PARAMETER Catalogue
    _catalog.json from the governance repo. Falls back to LMP_CPF_CATALOG.

.PARAMETER Search
    Free text - list clear-listed modules whose id contains this.

.NOTES
    Exit codes: 0 all found - 2 cannot assess (no catalogue) - 3 one or more
                not clear-listed.
#>
[CmdletBinding()]
param(
    [string[]]$Module,
    [string]$Catalogue,
    [string]$Search
)

$ErrorActionPreference = 'Stop'

if (-not $Catalogue) { $Catalogue = $env:LMP_CPF_CATALOG }
if (-not $Catalogue -or -not (Test-Path -LiteralPath $Catalogue)) {
    [Console]::Error.WriteLine('cpf: catalogue not found. Pass -Catalogue <_catalog.json> or set LMP_CPF_CATALOG.')
    [Console]::Error.WriteLine('cpf: not assessed - do not read this as "allowed".')
    exit 2
}

$raw = Get-Content -LiteralPath $Catalogue -Raw
if ($raw.Length -gt 0 -and [int][char]$raw[0] -eq 65279) { $raw = $raw.Substring(1) }
$cat = $raw | ConvertFrom-Json

# The catalogue is a list of module records; only the id matters here.
$ids = New-Object System.Collections.ArrayList
function Add-Ids($node) {
    if ($null -eq $node) { return }
    if ($node -is [System.Collections.IEnumerable] -and -not ($node -is [string])) {
        foreach ($n in $node) { Add-Ids $n }
        return
    }
    $p = $node.PSObject.Properties['cpf_id']
    if ($p -and $p.Value) { [void]$ids.Add([string]$p.Value); return }
    foreach ($prop in $node.PSObject.Properties) {
        if ($prop.Value -is [System.Collections.IEnumerable] -and -not ($prop.Value -is [string])) { Add-Ids $prop.Value }
    }
}
Add-Ids $cat

$all = @($ids | Sort-Object -Unique)
Write-Output ("cpf: {0} clear-listed module(s) from {1}" -f $all.Count, (Split-Path $Catalogue -Leaf))

if ($Search) {
    $hits = @($all | Where-Object { $_ -like "*$Search*" })
    if ($hits.Count -eq 0) { Write-Output "  no module id contains '$Search'"; exit 3 }
    foreach ($h in $hits) { Write-Output "  $h" }
    exit 0
}

if (-not $Module -or $Module.Count -eq 0) {
    [Console]::Error.WriteLine('cpf: pass -Module <id> or -Search <text>')
    exit 2
}

$missing = @()
foreach ($m in $Module) {
    if ($all -contains $m) { Write-Output ("  OK       {0}" -f $m) }
    else { Write-Output ("  NOT-CPF  {0}" -f $m); $missing += $m }
}
if ($missing.Count -gt 0) {
    [Console]::Error.WriteLine(("cpf: {0} module(s) are not clear-listed: {1}" -f $missing.Count, ($missing -join ', ')))
    exit 3
}
exit 0
