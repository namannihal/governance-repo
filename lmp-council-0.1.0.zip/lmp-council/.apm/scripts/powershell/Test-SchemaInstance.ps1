<#
.SYNOPSIS
    Validate a JSON document against a JSON Schema subset. Works on 5.1 and 7.

.DESCRIPTION
    Test-Json is PowerShell 6+, so it cannot be used here. This implements the
    keywords the council schemas actually use and refuses anything it does not
    understand, rather than passing it silently - a validator that ignores a
    keyword it has not implemented gives false assurance, which is worse than
    having no validator at all.

    Supported: type, required, properties, additionalProperties (false),
    items, enum, pattern, minItems, minLength, $ref to a sibling schema file.

    Dot-source it to reuse Test-JsonSchemaInstance, or run it directly to check
    one file.

.PARAMETER SchemaPath
    Schema to validate against.

.PARAMETER InstancePath
    JSON document to check.

.OUTPUTS
    Errors on stderr, one per line.

.NOTES
    Exit codes: 0 valid - 2 cannot assess (unreadable input) - 3 invalid.
#>
[CmdletBinding()]
param(
    [string]$SchemaPath,
    [string]$InstancePath
)

$ErrorActionPreference = 'Stop'

$script:KnownKeywords = @(
    '$schema', '$id', '$ref', 'title', 'description', 'type', 'required',
    'properties', 'additionalProperties', 'items', 'enum', 'pattern',
    'minItems', 'minLength', 'definitions'
)

function Read-JsonFile([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "file not found: $Path" }
    $raw = Get-Content -LiteralPath $Path -Raw
    # 5.1 writes a BOM by default and ConvertFrom-Json chokes on it in some hosts.
    if ($raw.Length -gt 0 -and [int][char]$raw[0] -eq 65279) { $raw = $raw.Substring(1) }
    $raw | ConvertFrom-Json
}

function Get-PropNames($Obj) {
    # Bare Write-Output, never `return (...)` - parentheses collect the pipeline and
    # `return` then unrolls the array again, which is the bug this guards against.
    if ($null -eq $Obj) { Write-Output -NoEnumerate @(); return }
    if ($Obj -is [System.Collections.IDictionary]) { Write-Output -NoEnumerate @($Obj.Keys); return }
    Write-Output -NoEnumerate @($Obj.PSObject.Properties | ForEach-Object { $_.Name })
}

function Get-Prop($Obj, [string]$Name) {
    # -NoEnumerate is load-bearing for collections: a return value is enumerated,
    # so a one-element array would hand the caller the element and a document with
    # a single claim would look like an object rather than a list.
    # It is applied ONLY to collections. On PowerShell 7 -NoEnumerate wraps a
    # scalar in a List[object], and @() over that throws "Argument types do not
    # match" - 5.1 returns the scalar unchanged, so this differs by edition.
    if ($null -eq $Obj) { return $null }
    $value = $null
    if ($Obj -is [System.Collections.IDictionary]) {
        if (-not $Obj.Contains($Name)) { return $null }
        $value = $Obj[$Name]
    }
    else {
        $p = $Obj.PSObject.Properties[$Name]
        if ($null -eq $p) { return $null }
        $value = $p.Value
    }
    if ($value -is [System.Collections.IEnumerable] -and -not ($value -is [string])) {
        Write-Output -NoEnumerate $value
        return
    }
    $value
}

function Test-HasProp($Obj, [string]$Name) {
    (Get-PropNames $Obj) -contains $Name
}

function Get-JsonType($Value) {
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [bool]) { return 'boolean' }
    if ($Value -is [string]) { return 'string' }
    # JSON has no date type. PowerShell 7's ConvertFrom-Json turns an ISO-8601
    # string into a DateTime; 5.1 leaves it alone. The file on disk holds a
    # string either way, so report what the document actually says.
    if ($Value -is [datetime]) { return 'string' }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [System.Int16]) { return 'integer' }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [single]) { return 'number' }
    if ($Value -is [System.Collections.IEnumerable] -and -not ($Value -is [string])) { return 'array' }
    'object'
}

function Test-TypeMatch($Value, [string]$Expected) {
    $actual = Get-JsonType $Value
    if ($Expected -eq $actual) { return $true }
    # An integer is a valid number; nothing else is widened.
    if ($Expected -eq 'number' -and $actual -eq 'integer') { return $true }
    $false
}

function Test-JsonSchemaInstance {
    param(
        [object]$Schema,
        # Boxed deliberately. Parameter binding unrolls a one-element array, so a
        # document holding a single claim would arrive as an object and be
        # rejected for the wrong type. Callers pass (,$value); this unwraps it.
        [object[]]$InstanceBox,
        [string]$Path = '$',
        [string]$SchemaDir = '.'
    )

    $Instance = $null
    if ($null -ne $InstanceBox -and $InstanceBox.Count -gt 0) { $Instance = $InstanceBox[0] }

    $errors = New-Object System.Collections.ArrayList

    $ref = Get-Prop $Schema '$ref'
    if ($ref) {
        $refPath = Join-Path $SchemaDir $ref
        if (-not (Test-Path -LiteralPath $refPath)) {
            [void]$errors.Add("$Path : cannot resolve `$ref '$ref'")
            return $errors.ToArray()
        }
        $refSchema = Read-JsonFile $refPath
        return (Test-JsonSchemaInstance -Schema $refSchema -InstanceBox (, $Instance) -Path $Path -SchemaDir $SchemaDir)
    }

    foreach ($kw in (Get-PropNames $Schema)) {
        if ($script:KnownKeywords -notcontains $kw) {
            [void]$errors.Add("$Path : schema uses unsupported keyword '$kw' - this validator would ignore it, so it is treated as an error")
        }
    }

    $type = Get-Prop $Schema 'type'
    if ($type) {
        $allowed = @($type)
        $ok = $false
        foreach ($t in $allowed) { if (Test-TypeMatch $Instance $t) { $ok = $true } }
        if (-not $ok) {
            [void]$errors.Add(("$Path : expected type {0} but found {1}" -f ($allowed -join '|'), (Get-JsonType $Instance)))
            return $errors.ToArray()
        }
    }

    $enumValues = Get-Prop $Schema 'enum'
    if ($null -ne $enumValues) {
        $match = $false
        foreach ($e in $enumValues) { if ("$e" -eq "$Instance") { $match = $true } }
        if (-not $match) {
            [void]$errors.Add(("$Path : '{0}' is not one of {1}" -f $Instance, ($enumValues -join ', ')))
        }
    }

    if ($Instance -is [string]) {
        $pattern = Get-Prop $Schema 'pattern'
        if ($pattern -and ($Instance -notmatch $pattern)) {
            [void]$errors.Add("$Path : '$Instance' does not match pattern $pattern")
        }
        $minLength = Get-Prop $Schema 'minLength'
        if ($null -ne $minLength -and $Instance.Length -lt [int]$minLength) {
            [void]$errors.Add("$Path : shorter than minLength $minLength")
        }
    }

    if ((Get-JsonType $Instance) -eq 'array') {
        $arr = @($Instance)
        $minItems = Get-Prop $Schema 'minItems'
        if ($null -ne $minItems -and $arr.Count -lt [int]$minItems) {
            [void]$errors.Add("$Path : has $($arr.Count) item(s), minimum is $minItems")
        }
        $items = Get-Prop $Schema 'items'
        if ($items) {
            for ($i = 0; $i -lt $arr.Count; $i++) {
                foreach ($e in (Test-JsonSchemaInstance -Schema $items -InstanceBox (, $arr[$i]) -Path "$Path[$i]" -SchemaDir $SchemaDir)) {
                    [void]$errors.Add($e)
                }
            }
        }
    }

    if ((Get-JsonType $Instance) -eq 'object') {
        $requiredNames = Get-Prop $Schema 'required'
        foreach ($r in $requiredNames) {
            if (-not (Test-HasProp $Instance $r)) {
                [void]$errors.Add("$Path : missing required property '$r'")
            }
        }

        $props = Get-Prop $Schema 'properties'
        $declared = Get-PropNames $props
        if ($props) {
            foreach ($name in $declared) {
                if (Test-HasProp $Instance $name) {
                    $sub = Get-Prop $props $name
                    $val = Get-Prop $Instance $name
                    foreach ($e in (Test-JsonSchemaInstance -Schema $sub -InstanceBox (, $val) -Path "$Path.$name" -SchemaDir $SchemaDir)) {
                        [void]$errors.Add($e)
                    }
                }
            }
        }

        $addl = Get-Prop $Schema 'additionalProperties'
        if ($null -ne $addl -and $addl -is [bool] -and -not $addl) {
            foreach ($name in (Get-PropNames $Instance)) {
                if ($declared -notcontains $name) {
                    [void]$errors.Add("$Path : property '$name' is not allowed")
                }
            }
        }
    }

    $errors.ToArray()
}

if ($SchemaPath -and $InstancePath) {
    try {
        $schema = Read-JsonFile $SchemaPath
        $instance = Read-JsonFile $InstancePath
    }
    catch {
        [Console]::Error.WriteLine("schema-check: " + $_.Exception.Message)
        exit 2
    }
    $dir = Split-Path -Parent (Resolve-Path -LiteralPath $SchemaPath).Path
    $found = @(Test-JsonSchemaInstance -Schema $schema -InstanceBox (, $instance) -SchemaDir $dir)
    if ($found.Count -eq 0) {
        Write-Output ("valid: {0} against {1}" -f (Split-Path $InstancePath -Leaf), (Split-Path $SchemaPath -Leaf))
        exit 0
    }
    foreach ($e in $found) { [Console]::Error.WriteLine("  $e") }
    [Console]::Error.WriteLine(("schema-check: {0} error(s)" -f $found.Count))
    exit 3
}
