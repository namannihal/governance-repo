---
mode: agent
description: "Run the whole council end to end: extract, read, design in parallel, audit every claim, arbitrate, and render the SAD. Every step is also available as its own command."
---

# /council

Agent: [council-master](../agents/master.agent.md)

Usage: `/council <root>` - `<root>\src` holds the application documents. If no
root is given, ask for one rather than guessing.

This runs every step below in order. Use it for a first pass. Once something
needs correcting, re-run just that step with its own command - there is no reason
to re-read the whole corpus because one decision was wrong.

| Step | Command | Produces |
|---|---|---|
| 1 | [`/council-init`](council-init.prompt.md) | extracted text |
| 2 | [`/read-sources`](read-sources.prompt.md) | cited facts |
| 3 | [`/create-target-architecture`](create-target-architecture.prompt.md) | the Azure target |
| 4 | [`/create-network-design`](create-network-design.prompt.md) | connectivity |
| 5 | [`/create-migration-plan`](create-migration-plan.prompt.md) | waves and cutover |
| 6 | [`/create-sad`](create-sad.prompt.md) | the assembled document |

At any point, [`/council-status`](council-status.prompt.md) says where things
stand.

## How to run it

1. **Steps 1 and 2, in order.** Nothing else starts until `source-facts.json`
   passes its audit, because every other agent consumes it.

2. **Steps 3 and 4 in parallel; then 5.** The specialists do not see each other's
   reasoning. Independent work makes disagreement visible instead of averaging it
   away, which is the only reason to run three agents rather than one prompt. The
   planner depends on the other two, so it starts once they have landed.

   Where the runtime allows it, put them on different models. Do not treat their
   agreement as evidence - two models sharing a wrong assumption about Azure will
   agree with each other enthusiastically. The citation check is what catches
   that.

3. **Audit each document as it arrives.** One revision on rejection, then the
   failing claims become open questions. Unbounded retries produce a document the
   audit accepts by attrition rather than by being right.

4. **Step 6.** Arbitrate, assemble, render.

## What to report at the end

Claim counts by type, how many facts carry resolvable citations, what could not
be extracted, what went to a second attempt, and every open question.

If the corpus was thin, say the deliverable is thin. A confident SAD built from
two pages misleads more than an empty one.

## What this will not do

It will not produce a SAD with no open questions unless the documents genuinely
settled everything, which they will not. The open questions are the list of what
a person needs to go and find out, and they are the reason the rest of the
document can be trusted.
