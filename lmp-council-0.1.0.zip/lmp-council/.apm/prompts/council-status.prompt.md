---
mode: agent
description: "Show where the council has got to: which documents exist, whether each still passes its audit, and what is open. Re-runs the checks rather than trusting the last report."
---

# /council-status

Agent: [council-master](../agents/master.agent.md)

Usage: `/council-status <root>`

## Steps

1. **Extraction.** Read `out\extracted\INDEX.md`. Report how many sources were
   read and list every one that was not, with its reason. A corpus that is 60%
   unreadable is the headline, not a detail.

2. **Documents.** For each file in `out\council\documents\`, re-run its check now
   rather than quoting the last report - a document edited after its audit looks
   identical to one that passed.

   | Document | Check |
   |---|---|
   | `source-facts.json` | `Audit-Claims.ps1 -Document <doc> -ExtractedRoot <root>\out\extracted -RequireQuoteMatch` |
   | the three designs | `Audit-Claims.ps1 -Document <doc> -ExtractedRoot <root>\out\extracted` |
   | `sad.json` | `Render-Sad.ps1 -Sad <doc>` - the claim audit cannot assess a SAD |

3. **Report a table**: document, exists, claim counts by type, audit result.

   Translate the exit codes rather than printing numbers: `0` clean, `3`
   rejected, `2` **could not assess - unverified, not passing**, `4`
   misconfigured.

4. **Report what is open**: assumptions with no answer, claims that failed twice
   and became open questions, and required fields nobody has claimed.

5. **Say what to run next** - the one command that moves it forward.

Report a missing document as missing. Do not infer from `network-design.json`
being absent that the network needs no work.
