---
mode: agent
description: "Create the council workspace and extract the intake documents into readable, citable text. Reports what could not be read instead of quietly leaving it out."
---

# /council-init

Agent: [council-master](../agents/master.agent.md)

Usage: `/council-init <root>` - `<root>\src` is where you put the documents.

Run this twice, and that is by design:

1. **First run** creates the empty workspace and stops, because `src` has nothing
   in it yet.
2. **You copy the application documents into `<root>\src`.** Subfolders are fine.
3. **Second run** extracts them.

## Steps

1. **Create the workspace.**

   ```powershell
   .apm\scripts\powershell\New-CouncilRoot.ps1 -Root <root> -Application <name>
   ```

   Exit `5` means one already exists. Keep going with it. Do not pass `-Force`
   without asking - the user's documents may be in there.

2. **If `<root>\src` is empty, stop here.** Tell the user where to put the
   documents and that re-running this command picks them up. This is the expected
   first-run outcome, not a failure - do not report it as an error, and do not go
   looking for documents elsewhere on the machine to fill the gap.

3. **Extract.**

   ```powershell
   .apm\scripts\powershell\Extract-Text.ps1 -Root <root> -Command extract -Out <root>\out\extracted
   ```

   `-Out` is not optional. The script's own default is a different folder, and
   every citation resolves against `out\extracted` - get it wrong and the whole
   run fails to audit for a reason that looks like the reader's fault.

4. **Report what was read, and what was not.**

   Show the counts, then list every file under **Not extracted** with its reason.
   A rights-protected or password-locked PDF needs a person, not a retry, and it
   is not evidence until someone supplies a readable copy.

   Exit `2` means nothing was extracted. The message distinguishes an empty
   folder from one full of unreadable files - pass that distinction on, because
   the two need opposite things from the user.

Extraction is incremental: unchanged files are reused and only new or edited
documents are read again, so running this after adding a document is cheap and
is the right thing to do.
