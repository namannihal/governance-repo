---
mode: agent
description: "Record what the source documents actually say, as cited facts. Everything else the council produces is built on this, so it is deliberately not called create - nothing here is invented."
---

# /read-sources

Agent: [reader](../agents/reader.agent.md) |
Instructions: [claim-typing](../instructions/claim-typing.instructions.md)

Usage: `/read-sources <root>`

This command is not named `/create-...` like the others, and that is the point.
The reader creates nothing. It records what is already in the documents, with a
line reference for each statement, and lists what the documents do not say.

## Prerequisite

Extracted text at `<root>\out\extracted`. If it is missing, run
[`/council-init`](council-init.prompt.md) first - do not read the original PDFs
directly, because a citation to a binary is untraceable.

## Steps

1. **Read `out\extracted\INDEX.md` first.** It lists what was read and what was
   not. Anything under **Not extracted** does not exist for this purpose.

2. **Dispatch the [reader](../agents/reader.agent.md)** to produce
   `out\council\documents\source-facts.json`.

3. **Audit it, strictly.** The reader's claims are all facts, so it is the one
   document that can afford the quote check:

   ```powershell
   .apm\scripts\powershell\Audit-Claims.ps1 -Document <root>\out\council\documents\source-facts.json -ExtractedRoot <root>\out\extracted -RequireQuoteMatch
   ```

   Exit `3` means claims were rejected - return them to the reader with the
   report. Exit `2` means the check could not run; fix that and run it again
   rather than treating it as a pass.

4. **Report the gaps as prominently as the facts.** Say how many facts were
   recorded and which required fields nobody stated. The gaps are what the design
   agents will have to assume, so this is the moment to notice that the corpus is
   thin - not three documents later.
