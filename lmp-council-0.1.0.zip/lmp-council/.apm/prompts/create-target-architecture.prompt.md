---
mode: agent
description: "Design the Azure target from the reader's facts. Each service choice names what it rejected and is checked against the CPF clearlist."
---

# /create-target-architecture

Agent: [target-architect](../agents/target-architect.agent.md) |
Instructions: [claim-typing](../instructions/claim-typing.instructions.md)

Usage: `/create-target-architecture <root>`

## Prerequisites

| Needs | If missing |
|---|---|
| Extracted text | Run [`/council-init`](council-init.prompt.md) |
| `source-facts.json` | Run [`/read-sources`](read-sources.prompt.md) |

Run the missing step rather than continuing without it. Designing a target from
an unread corpus produces a plausible architecture for an application nobody has
looked at, which is worse than no architecture because it looks finished.

## Steps

1. **Check the prerequisites above.** Say which ones you had to run.

2. **Dispatch the [target-architect](../agents/target-architect.agent.md)** to
   produce `out\council\documents\target-architecture.json`.

   It reads `source-facts.json` and nothing else. If it needs a fact the reader
   did not record, that is an assumption with a stated reason - not a licence to
   go back to the source documents and produce a second account of the estate.

3. **Set the clearlist** if you have one, so service choices are checked rather
   than recalled:

   ```powershell
   $env:LMP_CPF_CATALOG = '<path>\_catalog.json'
   ```

   Without it `Check-Cpf.ps1` exits `2` - **not assessed**, which the agent must
   record as an assumption and must not report as allowed.

4. **Audit.**

   ```powershell
   .apm\scripts\powershell\Audit-Claims.ps1 -Document <root>\out\council\documents\target-architecture.json -ExtractedRoot <root>\out\extracted
   ```

   One revision on exit `3`, then the failing claims become open questions.

5. **Report** the decisions with their rejected alternatives, and every
   assumption with what would settle it.
