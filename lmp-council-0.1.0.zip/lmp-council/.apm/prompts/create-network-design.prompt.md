---
mode: agent
description: "Design connectivity, segmentation and name resolution for the target. Expects a high proportion of assumptions, because source documents rarely describe the current network."
---

# /create-network-design

Agent: [network-designer](../agents/network-designer.agent.md) |
Instructions: [claim-typing](../instructions/claim-typing.instructions.md)

Usage: `/create-network-design <root>`

## Prerequisites

| Needs | If missing |
|---|---|
| Extracted text | Run [`/council-init`](council-init.prompt.md) |
| `source-facts.json` | Run [`/read-sources`](read-sources.prompt.md) |
| `target-architecture.json` | Run [`/create-target-architecture`](create-target-architecture.prompt.md) |

The target architecture is a genuine prerequisite, not a formality: you cannot
decide what needs a private endpoint until something has decided what the
services are. Run it rather than guessing at a target.

## Steps

1. **Check the prerequisites above.** Say which ones you had to run.

2. **Dispatch the [network-designer](../agents/network-designer.agent.md)** to
   produce `out\council\documents\network-design.json`.

3. **Audit.**

   ```powershell
   .apm\scripts\powershell\Audit-Claims.ps1 -Document <root>\out\council\documents\network-design.json -ExtractedRoot <root>\out\extracted
   ```

4. **Report, and do not apologise for the assumptions.** Source documents almost
   never record the current network in enough detail, so expect many. Each one
   should say what would settle it - a firewall rule export, an address plan, a
   DNS zone list. That list is a work item list, and it is the most useful thing
   this command produces.

   If the design contradicts the target architecture - something cannot be
   connected safely as chosen - report the contradiction. Do not silently
   substitute a different service; that produces a design no single agent agrees
   with and nobody can review.
