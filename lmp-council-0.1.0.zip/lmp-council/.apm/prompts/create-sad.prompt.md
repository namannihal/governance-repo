---
mode: agent
description: "Assemble the SAD from whatever member documents exist, arbitrate their disagreements on the record, and render it. A partial SAD is allowed - a SAD that hides which parts are missing is not."
---

# /create-sad

Agents: [council-master](../agents/master.agent.md) (arbitrates),
[sad-writer](../agents/sad-writer.agent.md) (assembles) |
Instructions: [claim-typing](../instructions/claim-typing.instructions.md)

Usage: `/create-sad <root>`

## Prerequisites

At least `source-facts.json`. Everything else is optional, and this is the one
command where a missing input is not a blocker: a SAD covering the estate and the
target, with no migration plan yet, is a legitimate interim deliverable.

**But it must say so.** List the member documents included and the ones absent,
in the SAD itself. A document that silently omits the network design reads
exactly like one where the network was considered and found to need nothing.

If you want the full set first, run
[`/council`](council.prompt.md).

## Steps

1. **Take stock.** List which member documents exist and audit each one that has
   not been audited since it was last written:

   ```powershell
   .apm\scripts\powershell\Audit-Claims.ps1 -Document <doc> -ExtractedRoot <root>\out\extracted
   ```

   Do not assemble a SAD from a document that is failing its audit.

2. **Arbitrate.** Where two documents claim incompatible things:
   - Prefer the cited over the uncited.
   - Between two decisions, prefer the one whose rejected alternatives show it
     engaged with the other's position.
   - Where evidence cannot settle it, **do not pick**. Record both as an open
     question. Always producing an answer is fluency, not verification.

   Record each arbitration: the conflict, what was chosen, what was rejected, and
   why. "The master decided" without a reason looks like due process and is not.

3. **Dispatch the [sad-writer](../agents/sad-writer.agent.md)** to produce
   `out\council\documents\sad.json`, referencing claims by id.

   It may not state an architectural value that no agent claimed. If the document
   needs one, that is a gap to report, not prose to write.

4. **Render.**

   ```powershell
   .apm\scripts\powershell\Render-Sad.ps1 -Sad <root>\out\council\documents\sad.json
   ```

   Exit `3` means the SAD references a claim that does not exist. That is a real
   defect - send it back to the writer.

   Note that `Audit-Claims.ps1` will **refuse** a SAD with exit `2`. That is
   correct: a SAD states no claims of its own, so the claim audit has nothing to
   check, and reporting "0 claims, clean" would be a pass from a check that never
   ran. `Render-Sad.ps1` is what verifies a SAD.

5. **Report** the deliverable paths, which member documents were included, which
   were absent, and the open-questions count.
