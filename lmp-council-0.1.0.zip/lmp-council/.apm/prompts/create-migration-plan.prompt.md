---
mode: agent
description: "Sequence the move: waves, data movement, cutover and rollback. Never invents a downtime window or a data volume - those are assumptions, stated out loud."
---

# /create-migration-plan

Agent: [migration-planner](../agents/migration-planner.agent.md) |
Instructions: [claim-typing](../instructions/claim-typing.instructions.md)

Usage: `/create-migration-plan <root>`

## Prerequisites

| Needs | If missing |
|---|---|
| Extracted text | Run [`/council-init`](council-init.prompt.md) |
| `source-facts.json` | Run [`/read-sources`](read-sources.prompt.md) |
| `target-architecture.json` | Run [`/create-target-architecture`](create-target-architecture.prompt.md) |
| `network-design.json` | Run [`/create-network-design`](create-network-design.prompt.md) |

## Steps

1. **Check the prerequisites above.** Say which ones you had to run.

2. **Dispatch the [migration-planner](../agents/migration-planner.agent.md)** to
   produce `out\council\documents\migration-plan.json`.

3. **Audit.**

   ```powershell
   .apm\scripts\powershell\Audit-Claims.ps1 -Document <root>\out\council\documents\migration-plan.json -ExtractedRoot <root>\out\extracted
   ```

4. **Report the two things that decide whether this plan is real:**

   - **The downtime window.** If no document stated one, the plan rests on an
     assumption. Say so at the top of the report, not in a footnote. A plan built
     on an invented four-hour window is worse than no plan, because it looks
     costed and someone will commit to it.
   - **Data volume and change rate.** These decide whether the data move is
     minutes or a weekend. Cited or assumed - never quietly chosen.

   Also report the rollback for each wave. "Restore from backup" with no stated
   recovery point is not a rollback.
