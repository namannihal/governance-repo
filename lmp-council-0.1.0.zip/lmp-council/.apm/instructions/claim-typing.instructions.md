---
description: "How every council agent states a value: read, decided, or assumed. Applies to all agents that write a council document."
applyTo: "**/out/council/documents/*.json"
---

# Claim typing

Everything a council agent produces is a **claim**, never a sentence. A claim
carries where it came from. That is the only reason anyone can trust the output
of this package.

## Read the schema, not this file, for field names

Your document type has a schema in `schemas/`. **Read it before you start and
conform to it.** This file deliberately names no fields, because the schemas are
meant to change without anyone rewriting agent instructions. If the schema and
your memory of a previous run disagree, the schema wins.

The schema fixes the shape. `Audit-Claims.ps1` enforces the rules below, which a
schema cannot express.

## The three types

| Type | Means | Must carry |
|---|---|---|
| `FACT` | You read this in a source document | A citation that resolves to a real line, optionally the quote |
| `DECISION` | You chose this | Why, and what you rejected |
| `ASSUMPTION` | Nobody knows yet and you needed a value to continue | Why you assumed it |

Choosing the type is the whole job. Get it wrong and the SAD tells a reader that
somebody's guess is a measured fact about their estate.

## Rules the audit will enforce

1. **A `FACT` you cannot cite is not a fact.** Cite the extracted file and line
   number, in the form the schema describes. The audit opens the file and checks
   the line exists. A citation to a plausible-sounding filename fails.
2. **Quote the words, do not paraphrase them.** When you supply a quote the audit
   checks it appears at that line.
3. **A `DECISION` with nothing rejected is not a decision.** If only one option
   was ever possible it is a `FACT` about a constraint, so cite the constraint.
4. **An `ASSUMPTION` without a reason is a guess wearing a label.** Say what you
   would need in order to replace it with a fact.
5. **Your claim ids use your document's prefix and are unique.** Ids are how the
   SAD refers to your work, so a duplicate id silently merges two claims.

## What to do when the documents are silent

Record an `ASSUMPTION` and say what would settle it. Do **not**:

- fill the gap from what you know about how systems like this are usually built
- promote a plausible inference to `FACT` because it is probably right
- quietly drop the field

The gap is the finding. A migration plan that admits it does not know the backup
schedule is more useful than one that invents a believable one, because the first
one gets a person to go and look.

## Before you hand over

Run the audit on your own document and fix what it rejects:

```powershell
.apm\scripts\powershell\Audit-Claims.ps1 -Document <your-document.json> -ExtractedRoot <root>\out\extracted
```

Exit `0` clean, `3` claims rejected, `2` it could not assess, `4` misconfigured.
**Treat `2` as a failure, not a pass** - it means the check did not happen.
