<#
.SYNOPSIS
    Tests for the council engine. Runs on Windows PowerShell 5.1 and PowerShell 7.

.DESCRIPTION
    The engine's whole claim is that a fabricated fact cannot pass. Most of these
    tests therefore assert that bad input is REJECTED - a suite that only proves
    good input works would pass just as happily with the audit deleted.

    Fixtures are built under TEMP, never inside the package.
#>
[CmdletBinding()]
param([switch]$KeepFixtures)

$ErrorActionPreference = 'Continue'

$PackageRoot = Split-Path -Parent $PSScriptRoot
$Scripts = Join-Path $PackageRoot '.apm\scripts\powershell'
$SchemaDir = Join-Path $PackageRoot 'schemas'
$Audit = Join-Path $Scripts 'Audit-Claims.ps1'
$Validator = Join-Path $Scripts 'Test-SchemaInstance.ps1'
$Init = Join-Path $Scripts 'New-CouncilRoot.ps1'
$Render = Join-Path $Scripts 'Render-Sad.ps1'
$Cpf = Join-Path $Scripts 'Check-Cpf.ps1'
$Extract = Join-Path $Scripts 'Extract-Text.ps1'

$script:Pass = 0
$script:Fail = 0
$script:Failures = New-Object System.Collections.ArrayList

function Group([string]$Name) {
    Write-Host ''
    Write-Host "  $Name" -ForegroundColor Cyan
}
function Check([string]$Name, [scriptblock]$Body) {
    try {
        & $Body
        $script:Pass++
        Write-Host "    PASS  $Name" -ForegroundColor DarkGray
    }
    catch {
        $script:Fail++
        [void]$script:Failures.Add("$Name : $($_.Exception.Message)")
        Write-Host "    FAIL  $Name" -ForegroundColor Red
        Write-Host "          $($_.Exception.Message)" -ForegroundColor Red
    }
}
function AssertEqual($Expected, $Actual, [string]$Because = '') {
    if ("$Expected" -ne "$Actual") { throw "expected [$Expected] but got [$Actual]. $Because" }
}
function AssertTrue($Condition, [string]$Because = '') {
    if (-not $Condition) { throw "expected true. $Because" }
}
function AssertContains([string]$Haystack, [string]$Needle) {
    if ($Haystack -notlike "*$Needle*") { throw "expected text containing '$Needle'" }
}

function New-Fixture([string]$Name) {
    $dir = Join-Path $env:TEMP ("council-tests\{0}-{1}" -f $Name, ([guid]::NewGuid().ToString('N').Substring(0, 8)))
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $dir
}
function Invoke-Script([string]$Path, [string[]]$Arguments) {
    $all = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $Path) + $Arguments
    $exe = 'powershell.exe'
    if ($PSVersionTable.PSEdition -eq 'Core') { $exe = (Get-Process -Id $PID).Path }
    $out = & $exe $all 2>&1
    [pscustomobject]@{ Code = $LASTEXITCODE; Out = (($out | ForEach-Object { "$_" }) -join "`n") }
}
function Write-Json($Object, [string]$Path) {
    ($Object | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $Path -Encoding UTF8
}

# A workspace with one extracted document to cite against.
function New-Workspace([string]$Name) {
    $root = New-Fixture $Name
    Invoke-Script $Init @('-Root', $root, '-Application', 'cqm') | Out-Null
    $ext = Join-Path $root 'out\extracted'
    $lines = @(
        '# architecture.pdf',                       # L1
        '',                                          # L2
        'The platform is hosted on AWS.',            # L3
        'The main microservices run on Amazon EKS.', # L4
        'Data is held in Aurora PostgreSQL.'         # L5
    )
    Set-Content -LiteralPath (Join-Path $ext 'architecture.md') -Value ($lines -join "`n") -Encoding UTF8
    $root
}
function New-Claim([string]$Id, [string]$Field, $Value, [string]$Type) {
    [ordered]@{ id = $Id; field = $Field; value = $Value; claim_type = $Type }
}
function New-Doc([string]$Type, [string]$Prefix, [object[]]$Claims) {
    # [object[]] matters: an untyped parameter unrolls a one-element array, and the
    # document then serialises "claims" as an object, which the schema rejects.
    [ordered]@{
        document_type = $Type
        application   = 'cqm'
        generated_at  = '2026-09-10T00:00:00Z'
        author_agent  = 'test'
        claim_prefix  = $Prefix
        claims        = $Claims
    }
}
function Save-Doc($Doc, [string]$Root, [string]$Name) {
    $p = Join-Path $Root ('out\council\documents\' + $Name)
    Write-Json $Doc $p
    $p
}

Write-Host ''
Write-Host 'council engine tests' -ForegroundColor White
Write-Host ("PowerShell {0} ({1})" -f $PSVersionTable.PSVersion, $PSVersionTable.PSEdition) -ForegroundColor DarkGray

# ---------------------------------------------------------------- validator
Group 'schema validator'

$vRoot = New-Fixture 'validator'
Check 'a well-formed claim validates' {
    $inst = Join-Path $vRoot 'ok.json'
    Write-Json (New-Claim 'TA-D-001' 'compute.target' 'AKS' 'DECISION') $inst
    $r = Invoke-Script $Validator @('-SchemaPath', (Join-Path $SchemaDir 'claim.schema.json'), '-InstancePath', $inst)
    AssertEqual 0 $r.Code $r.Out
}
Check 'an id that breaks the pattern is rejected' {
    $inst = Join-Path $vRoot 'badid.json'
    Write-Json (New-Claim 'nonsense' 'compute.target' 'AKS' 'DECISION') $inst
    $r = Invoke-Script $Validator @('-SchemaPath', (Join-Path $SchemaDir 'claim.schema.json'), '-InstancePath', $inst)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'does not match pattern'
}
Check 'an unknown claim_type is rejected' {
    $inst = Join-Path $vRoot 'badtype.json'
    Write-Json (New-Claim 'TA-D-001' 'x' 'y' 'GUESS') $inst
    $r = Invoke-Script $Validator @('-SchemaPath', (Join-Path $SchemaDir 'claim.schema.json'), '-InstancePath', $inst)
    AssertEqual 3 $r.Code
}
Check 'an undeclared property is rejected' {
    # additionalProperties:false is what stops an agent inventing its own field
    # and having it silently ignored downstream.
    $inst = Join-Path $vRoot 'extra.json'
    $c = New-Claim 'TA-D-001' 'x' 'y' 'DECISION'
    $c['smuggled'] = 'value'
    Write-Json $c $inst
    $r = Invoke-Script $Validator @('-SchemaPath', (Join-Path $SchemaDir 'claim.schema.json'), '-InstancePath', $inst)
    AssertEqual 3 $r.Code
    AssertContains $r.Out "'smuggled' is not allowed"
}
Check 'a missing required property is rejected' {
    $inst = Join-Path $vRoot 'nofield.json'
    Write-Json ([ordered]@{ id = 'TA-D-001'; value = 'y'; claim_type = 'DECISION' }) $inst
    $r = Invoke-Script $Validator @('-SchemaPath', (Join-Path $SchemaDir 'claim.schema.json'), '-InstancePath', $inst)
    AssertEqual 3 $r.Code
    AssertContains $r.Out "missing required property 'field'"
}

# ---------------------------------------------------------------- audit
Group 'claim audit'

Check 'a cited fact passes' {
    $root = New-Workspace 'cited'
    $c = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $c['citation'] = 'architecture.md#L4'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($c)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 0 $r.Code $r.Out
}
Check 'an uncited fact is rejected' {
    # The core promise: a confident sentence with no source does not get through.
    $root = New-Workspace 'uncited'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @((New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'))) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'uncited-fact'
}
Check 'a citation to a file that does not exist is rejected' {
    $root = New-Workspace 'nofile'
    $c = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $c['citation'] = 'invented-document.md#L4'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($c)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'missing-source'
}
Check 'a citation past the end of the file is rejected' {
    # Hallucinated line numbers are the likely failure once a model knows the
    # citation format, so the line must exist, not merely parse.
    $root = New-Workspace 'oob'
    $c = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $c['citation'] = 'architecture.md#L900'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($c)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'line-out-of-range'
}
Check 'a quote that is not at the cited line is rejected' {
    $root = New-Workspace 'quote'
    $c = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $c['citation'] = 'architecture.md#L4'
    $c['quote'] = 'the platform runs on Kubernetes Engine in Google Cloud'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($c)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p, '-RequireQuoteMatch')
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'quote-not-found'
}
Check 'a real quote at the cited line passes' {
    $root = New-Workspace 'quoteok'
    $c = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $c['citation'] = 'architecture.md#L4'
    $c['quote'] = 'run on Amazon EKS'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($c)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p, '-RequireQuoteMatch')
    AssertEqual 0 $r.Code $r.Out
}
Check 'a decision with no alternatives is rejected' {
    $root = New-Workspace 'noalt'
    $c = New-Claim 'TA-D-001' 'compute.target' 'AKS' 'DECISION'
    $c['rationale'] = 'containerised already'
    $p = Save-Doc (New-Doc 'target-architecture' 'TA' @($c)) $root 'target.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'no-alternatives'
}
Check 'a decision with rationale and alternatives passes' {
    $root = New-Workspace 'goodalt'
    $c = New-Claim 'TA-D-001' 'compute.target' 'AKS' 'DECISION'
    $c['rationale'] = 'source is containerised; CPF module exists'
    $c['alternatives_considered'] = @('App Service', 'Container Apps')
    $p = Save-Doc (New-Doc 'target-architecture' 'TA' @($c)) $root 'target.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 0 $r.Code $r.Out
}
Check 'a bare assumption is rejected' {
    $root = New-Workspace 'bareassume'
    $p = Save-Doc (New-Doc 'migration-plan' 'MP' @((New-Claim 'MP-A-001' 'app.tier' 'Tier 2' 'ASSUMPTION'))) $root 'plan.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'bare-assumption'
}
Check 'a claim using another document prefix is rejected' {
    # Prefixes are how a reader traces a value back to the member that produced
    # it; borrowing one hides authorship.
    $root = New-Workspace 'prefix'
    $c = New-Claim 'ND-D-001' 'compute.target' 'AKS' 'DECISION'
    $c['rationale'] = 'x'; $c['alternatives_considered'] = @('y')
    $p = Save-Doc (New-Doc 'target-architecture' 'TA' @($c)) $root 'target.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'wrong-prefix'
}
Check 'a duplicate claim id is rejected' {
    $root = New-Workspace 'dupe'
    $a = New-Claim 'RD-F-001' 'app.compute' 'EKS' 'FACT'; $a['citation'] = 'architecture.md#L4'
    $b = New-Claim 'RD-F-001' 'app.data' 'Aurora' 'FACT'; $b['citation'] = 'architecture.md#L5'
    $p = Save-Doc (New-Doc 'source-facts' 'RD' @($a, $b)) $root 'source-facts.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'duplicate-id'
}
Check 'a required field with no claim is reported, not passed over' {
    $root = New-Workspace 'uncovered'
    $c = New-Claim 'TA-D-001' 'compute.target' 'AKS' 'DECISION'
    $c['rationale'] = 'x'; $c['alternatives_considered'] = @('y')
    $doc = New-Doc 'target-architecture' 'TA' @($c)
    $doc['required_fields'] = @('compute.target', 'data.target')
    $p = Save-Doc $doc $root 'target.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'data.target'
}
Check 'a missing document is cannot-assess, not a failure' {
    $root = New-Workspace 'absent'
    $r = Invoke-Script $Audit @('-Document', (Join-Path $root 'out\council\documents\nothing.json'))
    AssertEqual 2 $r.Code
}
Check 'a sad is not reported clean by the claim audit, which cannot check it' {
    # A SAD states no claims of its own, so "0 claims, 0 problems" would be a pass
    # from a check that never looked at the thing that can actually be wrong.
    $root = New-Workspace 'sadaudit'
    $sad = [ordered]@{
        document_type = 'sad'
        application   = 'cqm'
        author_agent  = 'sad-writer'
        sources       = @('source-facts.json')
        sections      = @([ordered]@{ id = 'S1'; title = 'Estate'; claim_ids = @('RD-F-999') })
    }
    $p = Save-Doc $sad $root 'sad.json'
    $r = Invoke-Script $Audit @('-Document', $p)
    AssertEqual 2 $r.Code
    AssertContains $r.Out 'Render-Sad.ps1'
}

# ---------------------------------------------------------------- render
Group 'sad rendering'

Check 'the sad resolves claim ids and separates evidence from choice' {
    $root = New-Workspace 'render'
    $f = New-Claim 'RD-F-001' 'app.compute' 'Amazon EKS' 'FACT'
    $f['citation'] = 'architecture.md#L4'
    Save-Doc (New-Doc 'source-facts' 'RD' @($f)) $root 'source-facts.json' | Out-Null

    $d = New-Claim 'TA-D-001' 'compute.target' 'AKS private' 'DECISION'
    $d['rationale'] = 'already containerised'; $d['alternatives_considered'] = @('App Service')
    $a = New-Claim 'MP-A-001' 'app.tier' 'Tier 2' 'ASSUMPTION'
    $a['rationale'] = 'no criticality register was supplied'
    Save-Doc (New-Doc 'target-architecture' 'TA' @($d)) $root 'target.json' | Out-Null
    Save-Doc (New-Doc 'migration-plan' 'MP' @($a)) $root 'plan.json' | Out-Null

    $sad = [ordered]@{
        document_type = 'sad'; application = 'cqm'; generated_at = '2026-09-10T00:00:00Z'
        author_agent = 'master'; sources = @('source-facts.json', 'target.json', 'plan.json')
        sections = @(
            [ordered]@{ id = 'compute'; title = 'Compute'; claim_ids = @('RD-F-001', 'TA-D-001', 'MP-A-001') }
        )
    }
    $sadPath = Save-Doc $sad $root 'sad.json'
    $r = Invoke-Script $Render @('-Sad', $sadPath)
    AssertEqual 0 $r.Code $r.Out

    $md = Get-Content -LiteralPath (Join-Path $root 'out\council\deliverables\SAD.md') -Raw
    AssertContains $md 'Amazon EKS'
    AssertContains $md 'architecture.md#L4'
    AssertContains $md 'DECISION'

    $open = Get-Content -LiteralPath (Join-Path $root 'out\council\deliverables\open-questions.md') -Raw
    AssertContains $open 'Tier 2'
    AssertContains $open 'App Service'
}
Check 'a sad referencing a claim nobody made is rejected' {
    $root = New-Workspace 'ghost'
    $f = New-Claim 'RD-F-001' 'app.compute' 'EKS' 'FACT'; $f['citation'] = 'architecture.md#L4'
    Save-Doc (New-Doc 'source-facts' 'RD' @($f)) $root 'source-facts.json' | Out-Null
    $sad = [ordered]@{
        document_type = 'sad'; application = 'cqm'; generated_at = 'x'; author_agent = 'master'
        sources = @('source-facts.json')
        sections = @([ordered]@{ id = 's'; title = 'S'; claim_ids = @('TA-D-404') })
    }
    $sadPath = Save-Doc $sad $root 'sad.json'
    $r = Invoke-Script $Render @('-Sad', $sadPath)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'TA-D-404'
}

# ---------------------------------------------------------------- cpf
Group 'cpf clearlist'

Check 'a missing catalogue is cannot-assess, never "allowed"' {
    $r = Invoke-Script $Cpf @('-Module', 'cpf-azure-anything', '-Catalogue', (Join-Path $env:TEMP 'no-such-catalog.json'))
    AssertEqual 2 $r.Code
    AssertContains $r.Out 'not assessed'
}
Check 'a module outside the catalogue is refused' {
    $root = New-Fixture 'cpf'
    $cat = Join-Path $root 'catalog.json'
    Write-Json @(@{ cpf_id = 'cpf-azure-prdsvcpat-aks-private' }, @{ cpf_id = 'cpf-azure-storage' }) $cat
    $r = Invoke-Script $Cpf @('-Module', 'cpf-azure-invented', '-Catalogue', $cat)
    AssertEqual 3 $r.Code
    AssertContains $r.Out 'NOT-CPF'
}
Check 'a clear-listed module passes' {
    $root = New-Fixture 'cpf2'
    $cat = Join-Path $root 'catalog.json'
    Write-Json @(@{ cpf_id = 'cpf-azure-prdsvcpat-aks-private' }) $cat
    $r = Invoke-Script $Cpf @('-Module', 'cpf-azure-prdsvcpat-aks-private', '-Catalogue', $cat)
    AssertEqual 0 $r.Code $r.Out
}

# ---------------------------------------------------------------- init
# ---------------------------------------------------------------- extraction
Group 'extraction'

Check 'a document dropped straight into src is extracted, not passed over' {
    # The original walk only descended into subfolders, so a top-level file was
    # ignored without even being listed as skipped - the run still said success.
    $root = New-Fixture 'srctop'
    Invoke-Script $Init @('-Root', $root, '-Application', 'cqm') | Out-Null
    New-Item (Join-Path $root 'src\docs') -ItemType Directory -Force | Out-Null
    Set-Content (Join-Path $root 'src\top.md') -Value "# Top`nRuns on AWS." -Encoding UTF8
    Set-Content (Join-Path $root 'src\docs\nested.md') -Value "# Nested`nAurora." -Encoding UTF8
    $r = Invoke-Script $Extract @('-Root', $root, '-Command', 'extract', '-Out', (Join-Path $root 'out\extracted'))
    AssertEqual 0 $r.Code
    AssertContains $r.Out '2 extracted'
    AssertContains $r.Out 'top.md'
    AssertContains $r.Out 'docs/nested.md'
    if (-not (Test-Path (Join-Path $root 'out\extracted\top.md.md'))) {
        throw 'top-level document was not written to the extraction root'
    }
}
Check 'an empty src says it is empty, not that the files are unreadable' {
    # The two need opposite things from the user, so they must not share a message.
    $root = New-Fixture 'srcempty'
    Invoke-Script $Init @('-Root', $root, '-Application', 'cqm') | Out-Null
    $r = Invoke-Script $Extract @('-Root', $root, '-Command', 'extract', '-Out', (Join-Path $root 'out\extracted'))
    AssertEqual 2 $r.Code
    AssertContains $r.Out 'folder is empty'
}
Check 'an unreadable document lands in the one section the reader is told to check' {
    # Skipped and failed used to sit under different headings. The reader is told to
    # check "Not extracted", so a password-locked PDF under "Failed" was invisible.
    $root = New-Fixture 'srcbad'
    Invoke-Script $Init @('-Root', $root, '-Application', 'cqm') | Out-Null
    Set-Content (Join-Path $root 'src\good.md') -Value "# Good`nRuns on AWS." -Encoding UTF8
    Set-Content (Join-Path $root 'src\broken.pdf') -Value 'not a pdf at all' -Encoding ASCII
    Set-Content (Join-Path $root 'src\picture.png') -Value 'x' -Encoding ASCII
    $r = Invoke-Script $Extract @('-Root', $root, '-Command', 'extract', '-Out', (Join-Path $root 'out\extracted'))
    $index = Get-Content (Join-Path $root 'out\extracted\INDEX.md') -Raw
    AssertContains $index '## Not extracted'
    AssertContains $index 'broken.pdf'
    AssertContains $index 'picture.png'
    if ($index -match '## Failed') { throw 'a second heading has come back; the reader only checks one' }
}

# ---------------------------------------------------------------- workspace
Group 'workspace'

Check 'init creates the folders the agents are told to use' {
    $root = New-Fixture 'init'
    $r = Invoke-Script $Init @('-Root', $root, '-Application', 'cqm')
    AssertEqual 0 $r.Code
    foreach ($f in @('src', 'out\extracted', 'out\council\documents', 'out\council\reports', 'out\council\deliverables')) {
        AssertTrue (Test-Path (Join-Path $root $f)) "missing $f"
    }
}
Check 'init refuses to clobber an existing workspace' {
    $root = New-Fixture 'init2'
    Invoke-Script $Init @('-Root', $root) | Out-Null
    $r = Invoke-Script $Init @('-Root', $root)
    AssertEqual 5 $r.Code
}

Write-Host ''
Write-Host ('-' * 56) -ForegroundColor DarkGray
$verdict = 'passed {0}   failed {1}' -f $script:Pass, $script:Fail
if ($script:Fail -gt 0) { Write-Host $verdict -ForegroundColor Red } else { Write-Host $verdict -ForegroundColor Green }
if ($script:Fail -gt 0) {
    Write-Host ''
    foreach ($f in $script:Failures) { Write-Host "  $f" -ForegroundColor Red }
}
if (-not $KeepFixtures) {
    Remove-Item -Path (Join-Path $env:TEMP 'council-tests') -Recurse -Force -ErrorAction SilentlyContinue
}
exit $(if ($script:Fail -gt 0) { 1 } else { 0 })
