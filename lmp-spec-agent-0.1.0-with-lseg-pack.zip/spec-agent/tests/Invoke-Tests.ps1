<#
.SYNOPSIS
    Test harness for the spec layer and the consumer contract.

.DESCRIPTION
    Self-contained. No Pester, no modules - apm.yml promises this package needs none,
    so its tests must not need any either.

    Three suites:
      unit         pure functions, reached by dot-sourcing Spec.ps1
      integration  the CLI surface and every exit code it can return
      contract     a compliant consumer (tests/mock-consumer.ps1) against the gate

    The contract suite is the one to run in a customer environment. It proves the gate
    refuses and releases correctly without needing their real build agent.

    All fixtures are created under $env:TEMP, never inside the package.

.EXAMPLE
    .\Invoke-Tests.ps1
    .\Invoke-Tests.ps1 -Suite contract
    .\Invoke-Tests.ps1 -KeepFixtures
#>
[CmdletBinding()]
param(
    [ValidateSet('all', 'unit', 'integration', 'contract', 'standards')][string]$Suite = 'all',
    [switch]$KeepFixtures
)

$ErrorActionPreference = 'Continue'

$script:Pass = 0
$script:Fail = 0
$script:Failures = New-Object System.Collections.ArrayList
$script:CurrentGroup = ''

$PackageRoot = Split-Path -Parent $PSScriptRoot
$SpecScript = Join-Path $PackageRoot '.apm\scripts\powershell\Spec.ps1'
$ConsumerScript = Join-Path $PSScriptRoot 'mock-consumer.ps1'
$CheckScript = Join-Path $PackageRoot '.apm\scripts\powershell\Check-Standards.ps1'

# The LSEG pack is optional. The standards suite builds its own synthetic packs for
# every rule kind, so it proves the engine without depending on any organisation's
# content. The few checks that need the real pack skip themselves if it is absent.
$LsegPack = Join-Path (Split-Path -Parent $PackageRoot) 'lseg-constitution-pack'

# --------------------------------------------------------------------------- #
# Micro framework
# --------------------------------------------------------------------------- #

function Group([string]$Name) {
    $script:CurrentGroup = $Name
    Write-Host ''
    Write-Host "  $Name" -ForegroundColor Cyan
}

function Check([string]$Name, [scriptblock]$Body) {
    try {
        & $Body
        $script:Pass++
        Write-Host "    PASS  $Name" -ForegroundColor DarkGreen
    } catch {
        $script:Fail++
        [void]$script:Failures.Add("$($script:CurrentGroup) / $Name : $($_.Exception.Message)")
        Write-Host "    FAIL  $Name" -ForegroundColor Red
        Write-Host "          $($_.Exception.Message)" -ForegroundColor DarkRed
    }
}

function AssertEqual($Expected, $Actual, [string]$Because = '') {
    if ($Expected -ne $Actual) { throw "expected [$Expected] but got [$Actual]. $Because" }
}
function AssertTrue($Condition, [string]$Because = '') {
    if (-not $Condition) { throw "expected true. $Because" }
}
function AssertContains([string]$Haystack, [string]$Needle) {
    if ($Haystack -notlike "*$Needle*") { throw "expected to find '$Needle'" }
}
function AssertFileExists([string]$Path) {
    if (-not (Test-Path $Path)) { throw "expected file to exist: $Path" }
}
function AssertFileMissing([string]$Path) {
    if (Test-Path $Path) { throw "expected file NOT to exist: $Path" }
}

# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

function New-Fixture([string]$Name) {
    $dir = Join-Path $env:TEMP ("lmp-spec-tests\{0}-{1}" -f $Name, ([guid]::NewGuid().ToString('N').Substring(0, 8)))
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    return $dir
}

function New-SrcDocs([string]$Root) {
    $docs = Join-Path $Root 'src\application-docs'
    New-Item -ItemType Directory -Path $docs -Force | Out-Null
    Set-Content -Path (Join-Path $docs 'architecture.md') -Encoding UTF8 -Value @'
# Claims Intake API

The queue is regional only. SQS does not replicate cross-region.
Primary region is eu-west-1 with a standby in eu-central-1.
'@
    Set-Content -Path (Join-Path $docs 'inventory.csv') -Encoding UTF8 -Value "service,tier`napi-gateway,edge`nlambda,compute`n"
    return $docs
}

function Invoke-Spec {
    param([string]$Root, [string[]]$SpecArgs)
    $all = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $SpecScript, '-Root', $Root) + $SpecArgs
    $out = & powershell.exe $all 2>&1
    return [pscustomobject]@{ Code = $LASTEXITCODE; Out = (($out | ForEach-Object { "$_" }) -join "`n") }
}

function Invoke-Consumer {
    param([string]$Root, [string[]]$ConsumerArgs)
    $all = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $ConsumerScript,
        '-Root', $Root, '-SpecScript', $SpecScript) + $ConsumerArgs
    $out = & powershell.exe $all 2>&1
    return [pscustomobject]@{ Code = $LASTEXITCODE; Out = (($out | ForEach-Object { "$_" }) -join "`n") }
}

function Invoke-Check {
    param([string]$Root, [string[]]$CheckArgs)
    $all = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $CheckScript, '-Root', $Root) + $CheckArgs
    $out = & powershell.exe $all 2>&1
    return [pscustomobject]@{ Code = $LASTEXITCODE; Out = (($out | ForEach-Object { "$_" }) -join "`n") }
}

# Writes a one-file rule pack. Each standards test gets a pack containing only the
# rules it cares about, so a failure names one rule kind instead of one constitution.
function New-RulePack {
    param([string]$Root, [array]$Rules, [hashtable]$Bindings)
    $dir = Join-Path $Root 'pack'
    New-Item -ItemType Directory -Path (Join-Path $dir 'rules') -Force | Out-Null
    $meta = [ordered]@{
        pack_id = 'test-pack'; pack_version = '0.0.1'; constitution_version = 'test'
        rule_files = @('rules/test-rules.json')
    }
    if ($Bindings) { $meta['bindings'] = $Bindings }
    Set-Content -Path (Join-Path $dir 'pack.json') -Encoding UTF8 -NoNewline `
        -Value (($meta | ConvertTo-Json -Depth 40) + "`r`n")
    Set-Content -Path (Join-Path $dir 'rules\test-rules.json') -Encoding UTF8 -NoNewline `
        -Value ((([ordered]@{ rules = $Rules }) | ConvertTo-Json -Depth 40) + "`r`n")
    return $dir
}

# A store containing exactly the given facts, built and ready to check. Statements are
# added against a source id that was never registered, which register-sources-free
# add-statement permits - the standards engine reads the canonical spec, not the source
# register, so a full intake is not needed to test it.
function New-FactStore {
    param([string]$Root, [hashtable]$Facts)
    Invoke-Spec $Root @('-Command', 'init') | Out-Null
    foreach ($k in $Facts.Keys) {
        Invoke-Spec $Root @('-Command', 'add-statement', '-FactKey', $k, '-Value', ([string]$Facts[$k]),
            '-SourceId', 'src-test0001', '-Locator', 'test.md', '-Quote', 'test evidence') | Out-Null
    }
    Invoke-Spec $Root @('-Command', 'build') | Out-Null
}

function Get-Report([string]$Root) {
    return (Get-Content (Join-Path $Root 'out\compliance\constitution-report.json') -Raw | ConvertFrom-Json)
}

# Returns unrolled, like every other PowerShell function. Callers that want a count
# must wrap in @() - `(f).Count` on a single unrolled PSCustomObject is $null, not 1,
# which quietly turns a real assertion into a passing one.
function Get-Finding($Report, [string]$RuleId) {
    return @($Report.findings | Where-Object { $_.rule_id -eq $RuleId })
}

function New-ApprovedStore([string]$Root) {
    Invoke-Spec $Root @('-Command', 'init') | Out-Null
    $facts = @(
        @('azure.target.api', 'apim-premium'),
        @('azure.target.compute', 'functions-premium'),
        @('azure.target.datastore', 'cosmosdb'),
        @('azure.target.queue', 'servicebus-premium'),
        @('nfr.region.primary', 'westeurope'),
        @('risk.sqs.inflight', 'accepted')
    )
    foreach ($f in $facts) {
        Invoke-Spec $Root @('-Command', 'add-statement', '-FactKey', $f[0], '-Value', $f[1],
            '-SourceId', 'src-manual', '-Locator', 'p1', '-Quote', 'q', '-Method', 'explicit-statement') | Out-Null
    }
    Invoke-Spec $Root @('-Command', 'build') | Out-Null
    $store = Get-Content (Join-Path $Root 'out\statements.json') -Raw | ConvertFrom-Json
    foreach ($s in @($store.statements)) {
        Invoke-Spec $Root @('-Command', 'review', '-Target', $s.id, '-Action', 'approve', '-Actor', 'test.runner') | Out-Null
    }
    Invoke-Spec $Root @('-Command', 'build') | Out-Null
}

# --------------------------------------------------------------------------- #
# UNIT
# --------------------------------------------------------------------------- #

function Invoke-UnitSuite {
    . $SpecScript

    Group 'unit / tier assignment'
    Check 'explicit-statement is tier A' { AssertEqual 'A' (Get-Tier 'explicit-statement') }
    Check 'table-cell is tier A' { AssertEqual 'A' (Get-Tier 'table-cell') }
    Check 'diagram-label is tier A' { AssertEqual 'A' (Get-Tier 'diagram-label') }
    Check 'config-value is tier A' { AssertEqual 'A' (Get-Tier 'config-value') }
    Check 'human-assertion is tier A' { AssertEqual 'A' (Get-Tier 'human-assertion') }
    Check 'structure-derived is tier B' { AssertEqual 'B' (Get-Tier 'structure-derived') }
    Check 'cross-reference is tier B' { AssertEqual 'B' (Get-Tier 'cross-reference') }
    Check 'inferred is tier C' { AssertEqual 'C' (Get-Tier 'inferred') }
    Check 'weak-inference is tier D' { AssertEqual 'D' (Get-Tier 'weak-inference') }
    Check 'guess is tier E' { AssertEqual 'E' (Get-Tier 'guess') }
    Check 'unknown method falls back to tier E' { AssertEqual 'E' (Get-Tier 'no-such-method') }

    Group 'unit / confidence'
    Check 'tier A is high' { AssertEqual 'high' (Get-Confidence 'A' $false) }
    Check 'tier C is medium' { AssertEqual 'medium' (Get-Confidence 'C' $false) }
    Check 'tier E is low' { AssertEqual 'low' (Get-Confidence 'E' $false) }
    Check 'conflict forces low even for tier A' { AssertEqual 'low' (Get-Confidence 'A' $true) }

    Group 'unit / status ranking'
    Check 'draft ranks below approved' { AssertTrue ((Get-StatusRank 'draft') -lt (Get-StatusRank 'approved')) }
    Check 'needs-review ranks below approved' { AssertTrue ((Get-StatusRank 'needs-review') -lt (Get-StatusRank 'approved')) }
    Check 'changes-requested ranks below approved' { AssertTrue ((Get-StatusRank 'changes-requested') -lt (Get-StatusRank 'approved')) }
    Check 'unknown status ranks lowest' { AssertEqual 0 (Get-StatusRank 'nonsense') }

    Group 'unit / routing'
    Check 'aws.* routes to devops' { AssertTrue ((Get-Routing 'aws.service.sqs.replication').Domains -contains 'devops') }
    Check 'aws.* also routes to refactoring' { AssertTrue ((Get-Routing 'aws.service.sqs.replication').Domains -contains 'refactoring') }
    Check 'api.* routes to development' { AssertTrue ((Get-Routing 'api.auth.model').Domains -contains 'development') }
    Check 'deploy.* section is deployment' { AssertEqual 'deployment' (Get-Routing 'deploy.window').Section }
    Check 'risk.* routes to devops' { AssertTrue ((Get-Routing 'risk.sqs.inflight').Domains -contains 'devops') }
    Check 'unknown prefix lands in unrouted' { AssertEqual 'unrouted' (Get-Routing 'wibble.thing').Section }

    Group 'unit / identity and hashing'
    Check 'sha256 of empty string is the known vector' {
        AssertEqual 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' (Get-StringSha256 '')
    }
    Check 'statement id is deterministic' {
        AssertEqual (New-StatementId 'a.b' 'v' 'src-1' 'p1') (New-StatementId 'a.b' 'v' 'src-1' 'p1')
    }
    Check 'statement id changes when value changes' {
        AssertTrue ((New-StatementId 'a.b' 'v1' 'src-1' 'p1') -ne (New-StatementId 'a.b' 'v2' 'src-1' 'p1'))
    }
    Check 'statement id changes when locator changes' {
        AssertTrue ((New-StatementId 'a.b' 'v' 'src-1' 'p1') -ne (New-StatementId 'a.b' 'v' 'src-1' 'p2'))
    }

    Group 'unit / AsArray'
    Check 'null becomes empty array' { AssertEqual 0 (AsArray $null).Count }
    Check 'scalar becomes one element' { AssertEqual 1 (AsArray 'x').Count }
    Check 'array keeps its length' { AssertEqual 3 (AsArray @(1, 2, 3)).Count }

    Group 'unit / binding hash'
    Check 'binding hash moves when the source hash moves' {
        $stmt = [ordered]@{ value = 'none'; evidence = @([ordered]@{ source_id = 'src-1'; locator = 'p2'; quote = 'SQS' }) }
        $before = Get-BindingHash $stmt @{ 'src-1' = [pscustomobject]@{ sha256 = 'aaa' } }
        $after = Get-BindingHash $stmt @{ 'src-1' = [pscustomobject]@{ sha256 = 'bbb' } }
        AssertTrue ($before -ne $after) 'a changed document must void the approval'
    }
    Check 'binding hash is stable for identical inputs' {
        $stmt = [ordered]@{ value = 'none'; evidence = @([ordered]@{ source_id = 'src-1'; locator = 'p2'; quote = 'SQS' }) }
        $idx = @{ 'src-1' = [pscustomobject]@{ sha256 = 'aaa' } }
        AssertEqual (Get-BindingHash $stmt $idx) (Get-BindingHash $stmt $idx)
    }
    Check 'binding hash moves when the value moves' {
        $idx = @{ 'src-1' = [pscustomobject]@{ sha256 = 'aaa' } }
        $a = Get-BindingHash ([ordered]@{ value = 'none'; evidence = @([ordered]@{ source_id = 'src-1'; locator = 'p'; quote = 'q' }) }) $idx
        $b = Get-BindingHash ([ordered]@{ value = 'some'; evidence = @([ordered]@{ source_id = 'src-1'; locator = 'p'; quote = 'q' }) }) $idx
        AssertTrue ($a -ne $b)
    }
}

# --------------------------------------------------------------------------- #
# INTEGRATION
# --------------------------------------------------------------------------- #

function Invoke-IntegrationSuite {

    Group 'integration / init'
    $r = New-Fixture 'init'
    Check 'init exits 0' { AssertEqual 0 (Invoke-Spec $r @('-Command', 'init')).Code }
    Check 'init creates the statement store' { AssertFileExists (Join-Path $r 'out\statements.json') }
    Check 'init creates the source register' { AssertFileExists (Join-Path $r 'out\sources\source-register.json') }
    Check 'init creates the conflict file' { AssertFileExists (Join-Path $r 'out\conflicts\unresolved-conflicts.json') }
    Check 'init creates the decision log' { AssertFileExists (Join-Path $r 'out\decisions\decision-log.jsonl') }
    Check 'second init exits 5' { AssertEqual 5 (Invoke-Spec $r @('-Command', 'init')).Code }
    Check 'init -Force exits 0' { AssertEqual 0 (Invoke-Spec $r @('-Command', 'init', '-Force')).Code }

    Group 'integration / guards before init'
    $r2 = New-Fixture 'noinit'
    Check 'add-statement without a store exits 4' {
        AssertEqual 4 (Invoke-Spec $r2 @('-Command', 'add-statement', '-FactKey', 'a.b', '-Value', 'v', '-SourceId', 's')).Code
    }
    Check 'build without a store exits 4' { AssertEqual 4 (Invoke-Spec $r2 @('-Command', 'build')).Code }
    Check 'resolve without a store exits 4' { AssertEqual 4 (Invoke-Spec $r2 @('-Command', 'resolve', '-View', 'devops-spec')).Code }
    Check 'register-sources without src exits 4' { AssertEqual 4 (Invoke-Spec $r2 @('-Command', 'register-sources')).Code }

    Group 'integration / register-sources'
    $r3 = New-Fixture 'sources'
    New-Item -ItemType Directory -Path (Join-Path $r3 'src\application-docs') -Force | Out-Null
    Invoke-Spec $r3 @('-Command', 'init') | Out-Null
    Check 'empty src exits 2 - no evidence is a hard stop' {
        AssertEqual 2 (Invoke-Spec $r3 @('-Command', 'register-sources')).Code
    }
    New-SrcDocs $r3 | Out-Null
    Check 'register-sources exits 0 with readable docs' { AssertEqual 0 (Invoke-Spec $r3 @('-Command', 'register-sources')).Code }
    Check 'source register records both files' {
        $doc = Get-Content (Join-Path $r3 'out\sources\source-register.json') -Raw | ConvertFrom-Json
        AssertEqual 2 $doc.counts.total
    }
    Check 'every source carries a sha256' {
        $doc = Get-Content (Join-Path $r3 'out\sources\source-register.json') -Raw | ConvertFrom-Json
        foreach ($s in @($doc.sources)) { AssertTrue ($s.sha256 -and $s.sha256.Length -eq 64) }
    }
    Check 'an unreadable file is recorded, not skipped and not fatal' {
        $bad = Join-Path $r3 'src\application-docs\legacy-plan.xlsx'
        $bytes = [byte[]](0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1) + [byte[]](1..64)
        [System.IO.File]::WriteAllBytes($bad, $bytes)
        $res = Invoke-Spec $r3 @('-Command', 'register-sources')
        AssertEqual 0 $res.Code 'one bad file among good ones must not abort the scan'
        $doc = Get-Content (Join-Path $r3 'out\sources\source-register.json') -Raw | ConvertFrom-Json
        AssertEqual 3 $doc.counts.total
        AssertEqual 1 $doc.counts.not_read
        $entry = @($doc.sources | Where-Object { $_.path -like '*legacy-plan.xlsx' })[0]
        AssertEqual 'not-read' $entry.read_status
        AssertTrue ($entry.reason -and $entry.reason.Length -gt 0) 'a not-read file must carry a reason'
    }
    Check 'the adapter is inferred from the intake folder' {
        $rc = New-Fixture 'adapters'
        Invoke-Spec $rc @('-Command', 'init') | Out-Null
        foreach ($pair in @(@('comigrate-assessment', 'comigrate'), @('aimigrate-assessment', 'aimigrate'),
                @('existing-sad', 'existing_sad'), @('application-docs', 'appdocs'))) {
            $d = Join-Path $rc ('src\' + $pair[0])
            New-Item -ItemType Directory -Path $d -Force | Out-Null
            Set-Content -Path (Join-Path $d 'doc.md') -Value "# doc`n`nSome content." -Encoding UTF8
        }
        Invoke-Spec $rc @('-Command', 'register-sources') | Out-Null
        $doc = Get-Content (Join-Path $rc 'out\sources\source-register.json') -Raw | ConvertFrom-Json
        $adapters = @($doc.sources | ForEach-Object { $_.adapter } | Sort-Object -Unique)
        AssertEqual 4 $adapters.Count
        foreach ($a in @('aimigrate', 'appdocs', 'comigrate', 'existing_sad')) { AssertTrue ($adapters -contains $a) "missing $a" }
    }

    Group 'integration / add-statement'
    $r4 = New-Fixture 'add'
    Invoke-Spec $r4 @('-Command', 'init') | Out-Null
    Check 'missing FactKey exits 2' {
        AssertEqual 2 (Invoke-Spec $r4 @('-Command', 'add-statement', '-Value', 'v', '-SourceId', 's')).Code
    }
    Check 'missing SourceId exits 2' {
        AssertEqual 2 (Invoke-Spec $r4 @('-Command', 'add-statement', '-FactKey', 'a.b', '-Value', 'v')).Code
    }
    Check 'add-statement exits 0' {
        AssertEqual 0 (Invoke-Spec $r4 @('-Command', 'add-statement', '-FactKey', 'aws.service.sqs.replication',
                '-Value', 'none', '-SourceId', 'src-1', '-Locator', 'page 2', '-Quote', 'SQS regional',
                '-Method', 'diagram-label')).Code
    }
    Check 'statement is stored with tier A' {
        $doc = Get-Content (Join-Path $r4 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 'A' @($doc.statements)[0].tier
    }
    Check 'new statement starts at needs-review' {
        $doc = Get-Content (Join-Path $r4 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 'needs-review' @($doc.statements)[0].review.status
    }
    Check 'adding identical evidence twice does not duplicate' {
        Invoke-Spec $r4 @('-Command', 'add-statement', '-FactKey', 'aws.service.sqs.replication',
            '-Value', 'none', '-SourceId', 'src-1', '-Locator', 'page 2', '-Quote', 'SQS regional',
            '-Method', 'diagram-label') | Out-Null
        $doc = Get-Content (Join-Path $r4 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 1 @($doc.statements).Count
    }

    Group 'integration / build'
    $r5 = New-Fixture 'build'
    Invoke-Spec $r5 @('-Command', 'init') | Out-Null
    Check 'build with no statements exits 2' { AssertEqual 2 (Invoke-Spec $r5 @('-Command', 'build')).Code }
    Invoke-Spec $r5 @('-Command', 'add-statement', '-FactKey', 'azure.target.queue', '-Value', 'servicebus-premium',
        '-SourceId', 'src-1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r5 @('-Command', 'add-statement', '-FactKey', 'api.auth.model', '-Value', 'oauth2',
        '-SourceId', 'src-1', '-Method', 'inferred') | Out-Null
    Check 'build exits 0' { AssertEqual 0 (Invoke-Spec $r5 @('-Command', 'build')).Code }
    Check 'canonical spec is written' { AssertFileExists (Join-Path $r5 'out\specifications\system-spec.json') }
    Check 'all three views are written' {
        foreach ($v in @('development-spec', 'devops-spec', 'refactoring-spec')) {
            AssertFileExists (Join-Path $r5 "out\specifications\$v.json")
        }
    }
    Check 'evidence map is written' { AssertFileExists (Join-Path $r5 'out\evidence-map.json') }
    Check 'review markdown is written for every view' {
        foreach ($v in @('development-spec', 'devops-spec', 'refactoring-spec')) {
            AssertFileExists (Join-Path $r5 "out\review\$v.md")
        }
    }
    Check 'review summary is written' { AssertFileExists (Join-Path $r5 'out\review\review-summary.md') }
    Check 'generated markdown carries a do-not-edit banner' {
        AssertContains (Get-Content (Join-Path $r5 'out\review\review-summary.md') -Raw) 'DO NOT EDIT'
    }
    Check 'canonical holds one fact per fact_key' {
        $c = Get-Content (Join-Path $r5 'out\specifications\system-spec.json') -Raw | ConvertFrom-Json
        AssertEqual 2 $c.fact_count
    }
    Check 'a view holds statement ids, never copied text' {
        $v = Get-Content (Join-Path $r5 'out\specifications\devops-spec.json') -Raw | ConvertFrom-Json
        $ids = @($v.sections[0].statements)
        AssertTrue ($ids[0] -like 'stmt-*') 'sections must reference ids'
        AssertTrue ((Get-Content (Join-Path $r5 'out\specifications\devops-spec.json') -Raw) -notlike '*servicebus-premium*') `
            'a view must not duplicate the value'
    }
    Check 'inferred statement is medium confidence' {
        $doc = Get-Content (Join-Path $r5 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 'medium' @($doc.statements | Where-Object { $_.fact_key -eq 'api.auth.model' })[0].confidence
    }

    Group 'integration / review'
    $r6 = New-Fixture 'review'
    Invoke-Spec $r6 @('-Command', 'init') | Out-Null
    Invoke-Spec $r6 @('-Command', 'add-statement', '-FactKey', 'azure.target.api', '-Value', 'apim-premium',
        '-SourceId', 'src-1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r6 @('-Command', 'build') | Out-Null
    $sid = (Get-Content (Join-Path $r6 'out\statements.json') -Raw | ConvertFrom-Json).statements[0].id
    Check 'review without -Actor exits 2' {
        AssertEqual 2 (Invoke-Spec $r6 @('-Command', 'review', '-Target', $sid, '-Action', 'approve')).Code
    }
    Check 'review of an unknown statement exits 4' {
        AssertEqual 4 (Invoke-Spec $r6 @('-Command', 'review', '-Target', 'stmt-nope', '-Action', 'approve', '-Actor', 'x')).Code
    }
    Check 'approve exits 0' {
        AssertEqual 0 (Invoke-Spec $r6 @('-Command', 'review', '-Target', $sid, '-Action', 'approve', '-Actor', 'n.nihal')).Code
    }
    Check 'approval records the actor' {
        $doc = Get-Content (Join-Path $r6 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 'n.nihal' @($doc.statements)[0].review.reviewed_by
    }
    Check 'approval stores a binding hash' {
        $doc = Get-Content (Join-Path $r6 'out\statements.json') -Raw | ConvertFrom-Json
        AssertTrue (@($doc.statements)[0].review.binding_hash.Length -eq 64)
    }
    Check 'decision log records the approval' {
        $log = Get-Content (Join-Path $r6 'out\decisions\decision-log.jsonl') -Raw
        AssertContains $log 'approve'
        AssertContains $log 'n.nihal'
    }
    Check 'the decision log is append-only across decisions' {
        Invoke-Spec $r6 @('-Command', 'review', '-Target', $sid, '-Action', 'request-changes',
            '-Actor', 'n.nihal', '-Rationale', 'no evidence for the sku') | Out-Null
        $lines = @(Get-Content (Join-Path $r6 'out\decisions\decision-log.jsonl') | Where-Object { $_.Trim() })
        AssertTrue ($lines.Count -ge 2) 'the earlier decision must still be there'
    }

    Group 'integration / resolve gate'
    $r7 = New-Fixture 'resolve'
    Invoke-Spec $r7 @('-Command', 'init') | Out-Null
    Invoke-Spec $r7 @('-Command', 'add-statement', '-FactKey', 'azure.target.api', '-Value', 'apim-premium',
        '-SourceId', 'src-1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r7 @('-Command', 'build') | Out-Null
    Check 'resolve of an unknown view exits 4' { AssertEqual 4 (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'nope-spec')).Code }
    Check 'resolve before approval exits 3' {
        AssertEqual 3 (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'approved')).Code
    }
    Check 'resolve names the statement that is blocking' {
        AssertContains (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'approved')).Out 'azure.target.api'
    }
    Check 'resolve at a lower MinStatus passes' {
        AssertEqual 0 (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'needs-review')).Code
    }
    $sid7 = (Get-Content (Join-Path $r7 'out\statements.json') -Raw | ConvertFrom-Json).statements[0].id
    Invoke-Spec $r7 @('-Command', 'review', '-Target', $sid7, '-Action', 'approve', '-Actor', 'test') | Out-Null
    Check 'resolve after approval exits 0' {
        AssertEqual 0 (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'approved')).Code
    }
    Check 'resolve emits a plan hash' {
        $p = (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-Format', 'json')).Out | ConvertFrom-Json
        AssertTrue ($p.plan_hash.Length -eq 64)
    }
    Check 'plan hash is stable across runs' {
        $a = (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-Format', 'json')).Out | ConvertFrom-Json
        $b = (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'devops-spec', '-Format', 'json')).Out | ConvertFrom-Json
        AssertTrue ($a.plan_hash -and $a.plan_hash.Length -eq 64) 'guard against comparing two nulls'
        AssertEqual $a.plan_hash $b.plan_hash
    }
    Check 'resolve on an empty view exits 2' {
        AssertEqual 2 (Invoke-Spec $r7 @('-Command', 'resolve', '-View', 'refactoring-spec', '-MinStatus', 'needs-review')).Code
    }

    Group 'integration / conflicts'
    $r8 = New-Fixture 'conflict'
    Invoke-Spec $r8 @('-Command', 'init') | Out-Null
    Invoke-Spec $r8 @('-Command', 'add-statement', '-FactKey', 'nfr.rto', '-Value', '4h',
        '-SourceId', 'src-1', '-Locator', 'p1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r8 @('-Command', 'add-statement', '-FactKey', 'nfr.rto', '-Value', '1h',
        '-SourceId', 'src-2', '-Locator', 'p9', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r8 @('-Command', 'build') | Out-Null
    Check 'conflicting values raise a conflict' {
        $c = Get-Content (Join-Path $r8 'out\conflicts\unresolved-conflicts.json') -Raw | ConvertFrom-Json
        AssertEqual 1 @($c.conflicts).Count
    }
    Check 'conflicted statements are forced to low confidence' {
        $doc = Get-Content (Join-Path $r8 'out\statements.json') -Raw | ConvertFrom-Json
        foreach ($s in @($doc.statements)) { AssertEqual 'low' $s.confidence }
    }
    Check 'the affected section is marked blocked' {
        $v = Get-Content (Join-Path $r8 'out\specifications\devops-spec.json') -Raw | ConvertFrom-Json
        AssertEqual 'blocked' @($v.sections | Where-Object { $_.id -eq 'nfr' })[0].status
    }
    Check 'resolve refuses a blocked section with exit 3' {
        AssertEqual 3 (Invoke-Spec $r8 @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'needs-review')).Code
    }
    Check 'conflict summary appears in the review summary' {
        $md = Get-Content (Join-Path $r8 'out\review\review-summary.md') -Raw
        AssertContains $md 'Open conflicts'
        AssertContains $md 'nfr.rto'
    }
    Check 'a conflict opening voids an existing approval' {
        $r9 = New-Fixture 'conflictvoid'
        Invoke-Spec $r9 @('-Command', 'init') | Out-Null
        Invoke-Spec $r9 @('-Command', 'add-statement', '-FactKey', 'nfr.rto', '-Value', '4h',
            '-SourceId', 'src-1', '-Locator', 'p1', '-Method', 'explicit-statement') | Out-Null
        Invoke-Spec $r9 @('-Command', 'build') | Out-Null
        $id = (Get-Content (Join-Path $r9 'out\statements.json') -Raw | ConvertFrom-Json).statements[0].id
        Invoke-Spec $r9 @('-Command', 'review', '-Target', $id, '-Action', 'approve', '-Actor', 'test') | Out-Null
        Invoke-Spec $r9 @('-Command', 'add-statement', '-FactKey', 'nfr.rto', '-Value', '1h',
            '-SourceId', 'src-2', '-Locator', 'p9', '-Method', 'explicit-statement') | Out-Null
        Invoke-Spec $r9 @('-Command', 'build') | Out-Null
        $doc = Get-Content (Join-Path $r9 'out\statements.json') -Raw | ConvertFrom-Json
        $s = @($doc.statements | Where-Object { $_.id -eq $id })[0]
        AssertEqual 'needs-review' $s.review.status
        AssertEqual 'conflict-opened' $s.review.reason
    }

    Group 'integration / verify voids stale approvals'
    $r10 = New-Fixture 'verify'
    Invoke-Spec $r10 @('-Command', 'init') | Out-Null
    New-SrcDocs $r10 | Out-Null
    Invoke-Spec $r10 @('-Command', 'register-sources') | Out-Null
    $srcId = (Get-Content (Join-Path $r10 'out\sources\source-register.json') -Raw | ConvertFrom-Json).sources[0].id
    Invoke-Spec $r10 @('-Command', 'add-statement', '-FactKey', 'azure.target.api', '-Value', 'apim-premium',
        '-SourceId', $srcId, '-Locator', 'p1', '-Quote', 'gateway', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $r10 @('-Command', 'build') | Out-Null
    $vid = (Get-Content (Join-Path $r10 'out\statements.json') -Raw | ConvertFrom-Json).statements[0].id
    Invoke-Spec $r10 @('-Command', 'review', '-Target', $vid, '-Action', 'approve', '-Actor', 'test') | Out-Null
    Check 'verify is a no-op when nothing changed' {
        AssertContains (Invoke-Spec $r10 @('-Command', 'verify')).Out '0 approval(s) voided'
    }
    Check 'editing the source document voids the approval' {
        Add-Content -Path (Join-Path $r10 'src\application-docs\architecture.md') -Value 'A new sentence.' -Encoding UTF8
        Invoke-Spec $r10 @('-Command', 'register-sources') | Out-Null
        AssertContains (Invoke-Spec $r10 @('-Command', 'verify')).Out '1 approval(s) voided'
        $doc = Get-Content (Join-Path $r10 'out\statements.json') -Raw | ConvertFrom-Json
        AssertEqual 'needs-review' @($doc.statements)[0].review.status
        AssertEqual 'source-changed' @($doc.statements)[0].review.reason
    }
    Check 'the void is recorded in the decision log' {
        AssertContains (Get-Content (Join-Path $r10 'out\decisions\decision-log.jsonl') -Raw) 'auto-void'
    }

    Group 'integration / status'
    Check 'status reports counts' {
        $res = Invoke-Spec $r10 @('-Command', 'status')
        AssertEqual 0 $res.Code
        AssertContains $res.Out 'statements'
    }
    Check 'unrouted statements are surfaced in the summary' {
        $r11 = New-Fixture 'unrouted'
        Invoke-Spec $r11 @('-Command', 'init') | Out-Null
        Invoke-Spec $r11 @('-Command', 'add-statement', '-FactKey', 'wibble.thing', '-Value', 'v',
            '-SourceId', 'src-1', '-Method', 'guess') | Out-Null
        Invoke-Spec $r11 @('-Command', 'build') | Out-Null
        $md = Get-Content (Join-Path $r11 'out\review\review-summary.md') -Raw
        AssertContains $md 'unrouted'
        AssertContains $md 'tier E'
    }
}

# --------------------------------------------------------------------------- #
# CONTRACT - run this one in a customer environment
# --------------------------------------------------------------------------- #

function Invoke-ContractSuite {

    Group 'contract / the gate refuses an unapproved spec'
    $c1 = New-Fixture 'contract-refuse'
    Invoke-Spec $c1 @('-Command', 'init') | Out-Null
    Invoke-Spec $c1 @('-Command', 'add-statement', '-FactKey', 'azure.target.queue', '-Value', 'servicebus-premium',
        '-SourceId', 'src-1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $c1 @('-Command', 'build') | Out-Null
    $res1 = Invoke-Consumer $c1 @()
    Check 'a compliant consumer exits 3' { AssertEqual 3 $res1.Code }
    Check 'it reports the refusal rather than crashing' { AssertContains $res1.Out 'REFUSED' }
    Check 'it names the blocking statement' { AssertContains $res1.Out 'azure.target.queue' }
    Check 'it wrote nothing' { AssertFileMissing (Join-Path $c1 'out\consumer\manifest.json') }

    Group 'contract / the gate releases an approved spec'
    $c2 = New-Fixture 'contract-pass'
    New-ApprovedStore $c2
    $res2 = Invoke-Consumer $c2 @()
    Check 'a compliant consumer exits 0' { AssertEqual 0 $res2.Code }
    Check 'it produced its artifact' { AssertFileExists (Join-Path $c2 'out\consumer\manifest.json') }
    Check 'the artifact carries the plan hash from resolve' {
        $man = Get-Content (Join-Path $c2 'out\consumer\manifest.json') -Raw | ConvertFrom-Json
        $res = (Invoke-Spec $c2 @('-Command', 'resolve', '-View', 'devops-spec', '-Format', 'json')).Out | ConvertFrom-Json
        AssertEqual $res.plan_hash $man.plan_hash
    }
    Check 'the artifact cites the statement ids behind it' {
        $man = Get-Content (Join-Path $c2 'out\consumer\manifest.json') -Raw | ConvertFrom-Json
        AssertTrue (@($man.statement_ids).Count -ge 4)
        AssertTrue (@($man.statement_ids)[0] -like 'stmt-*')
    }

    Group 'contract / an unmapped value is a hard stop'
    $c3 = New-Fixture 'contract-unmapped'
    Invoke-Spec $c3 @('-Command', 'init') | Out-Null
    Invoke-Spec $c3 @('-Command', 'add-statement', '-FactKey', 'azure.target.search', '-Value', 'some-new-service',
        '-SourceId', 'src-1', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $c3 @('-Command', 'build') | Out-Null
    foreach ($s in (Get-Content (Join-Path $c3 'out\statements.json') -Raw | ConvertFrom-Json).statements) {
        Invoke-Spec $c3 @('-Command', 'review', '-Target', $s.id, '-Action', 'approve', '-Actor', 'test') | Out-Null
    }
    $res3 = Invoke-Consumer $c3 @()
    Check 'consumer exits 2 rather than guessing' { AssertEqual 2 $res3.Code }
    Check 'it names the value it did not know' { AssertContains $res3.Out 'some-new-service' }
    Check 'it wrote nothing' { AssertFileMissing (Join-Path $c3 'out\consumer\manifest.json') }

    Group 'contract / a blocked section refuses even when approved'
    $c4 = New-Fixture 'contract-blocked'
    New-ApprovedStore $c4
    Invoke-Spec $c4 @('-Command', 'add-statement', '-FactKey', 'azure.target.queue', '-Value', 'storage-queue',
        '-SourceId', 'src-manual', '-Locator', 'other', '-Method', 'explicit-statement') | Out-Null
    Invoke-Spec $c4 @('-Command', 'build') | Out-Null
    Check 'a new competing value re-closes the gate' { AssertEqual 3 (Invoke-Consumer $c4 @()).Code }

    Group 'contract / evidence drift re-closes the gate'
    $c5 = New-Fixture 'contract-drift'
    Invoke-Spec $c5 @('-Command', 'init') | Out-Null
    New-SrcDocs $c5 | Out-Null
    Invoke-Spec $c5 @('-Command', 'register-sources') | Out-Null
    $sid5 = (Get-Content (Join-Path $c5 'out\sources\source-register.json') -Raw | ConvertFrom-Json).sources[0].id
    foreach ($pair in @(@('azure.target.queue', 'servicebus-premium'), @('nfr.region.primary', 'westeurope'))) {
        Invoke-Spec $c5 @('-Command', 'add-statement', '-FactKey', $pair[0], '-Value', $pair[1],
            '-SourceId', $sid5, '-Locator', 'l', '-Quote', 'q', '-Method', 'explicit-statement') | Out-Null
    }
    Invoke-Spec $c5 @('-Command', 'build') | Out-Null
    foreach ($s in (Get-Content (Join-Path $c5 'out\statements.json') -Raw | ConvertFrom-Json).statements) {
        Invoke-Spec $c5 @('-Command', 'review', '-Target', $s.id, '-Action', 'approve', '-Actor', 'test') | Out-Null
    }
    Check 'consumer succeeds while the evidence is intact' { AssertEqual 0 (Invoke-Consumer $c5 @()).Code }
    Check 'editing the source and verifying re-closes the gate' {
        Add-Content -Path (Join-Path $c5 'src\application-docs\architecture.md') -Value 'Correction: northeurope.' -Encoding UTF8
        Invoke-Spec $c5 @('-Command', 'register-sources') | Out-Null
        Invoke-Spec $c5 @('-Command', 'verify') | Out-Null
        AssertEqual 3 (Invoke-Consumer $c5 @()).Code
    }
}

# --------------------------------------------------------------------------- #
# Standards suite - the constraint layer
# --------------------------------------------------------------------------- #

function Invoke-StandardsSuite {

    Group 'standards / rule kinds'

    Check 'requires_fact reports an absent fact as a gap, not a pass' {
        $r = New-Fixture 'std-req'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_fact'; facts = @('nfr.rto'); severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 2 $res.Code 'a missing mandatory fact means the design cannot be assessed'
        AssertEqual 1 @(Get-Finding (Get-Report $r) 'R1').Count
        AssertEqual 'gap' (Get-Finding (Get-Report $r) 'R1')[0].kind
    }

    Check 'allowed_values passes a permitted value' {
        $r = New-Fixture 'std-allow-ok'
        New-FactStore $r @{ 'nfr.region.primary' = 'uksouth' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth', 'ukwest'); severity = 'mandatory' })
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'allowed_values rejects a value outside the list' {
        $r = New-Fixture 'std-allow-bad'
        New-FactStore $r @{ 'nfr.region.primary' = 'eastus' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth', 'ukwest'); severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code
        AssertEqual 'violation' (Get-Finding (Get-Report $r) 'R1')[0].kind
    }

    Check 'forbidden_values rejects an explicitly prohibited value' {
        $r = New-Fixture 'std-forbid'
        New-FactStore $r @{ 'api.gateway_model' = 'dedicated' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'forbidden_values'; fact = 'api.gateway_model'
                forbidden = @('dedicated'); severity = 'mandatory' })
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'numeric_min rejects a value below the minimum' {
        $r = New-Fixture 'std-min-bad'
        New-FactStore $r @{ 'pipeline.branch.min_approvers' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'numeric_min'; fact = 'pipeline.branch.min_approvers'
                min = 2; severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code
        AssertContains (Get-Finding (Get-Report $r) 'R1')[0].message 'below the required minimum'
    }

    Check 'numeric_min accepts a value at the minimum' {
        $r = New-Fixture 'std-min-ok'
        New-FactStore $r @{ 'pipeline.branch.min_approvers' = '2' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'numeric_min'; fact = 'pipeline.branch.min_approvers'
                min = 2; severity = 'mandatory' })
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'numeric_min reports a non-numeric value rather than crashing' {
        $r = New-Fixture 'std-min-nan'
        New-FactStore $r @{ 'pipeline.branch.min_approvers' = 'two' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'numeric_min'; fact = 'pipeline.branch.min_approvers'
                min = 2; severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code
        AssertContains (Get-Finding (Get-Report $r) 'R1')[0].message 'not a number'
    }

    Check 'conditional_prohibition fires when its conditions hold' {
        $r = New-Fixture 'std-prohib'
        New-FactStore $r @{ 'migration.r_type' = 'Replatform'; 'source.containerized' = 'false'
            'azure.target.compute' = 'cpf-azure-prdsvcpat-aks-private'
        }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'conditional_prohibition'
                when = @(@{ fact = 'migration.r_type'; equals = 'Replatform' },
                    @{ fact = 'source.containerized'; equals = 'false' })
                forbid = @{ fact = 'azure.target.compute'; matching = @('aks') }; severity = 'mandatory'
            })
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'conditional_prohibition stays silent when a condition is false' {
        $r = New-Fixture 'std-prohib-off'
        New-FactStore $r @{ 'migration.r_type' = 'Replatform'; 'source.containerized' = 'true'
            'azure.target.compute' = 'cpf-azure-prdsvcpat-aks-private'
        }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'conditional_prohibition'
                when = @(@{ fact = 'migration.r_type'; equals = 'Replatform' },
                    @{ fact = 'source.containerized'; equals = 'false' })
                forbid = @{ fact = 'azure.target.compute'; matching = @('aks') }; severity = 'mandatory'
            })
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'an unstated condition does not satisfy a prohibition' {
        # The important negative case. If "source.containerized is absent" counted as
        # "not false", a SAD that simply never mentions containers would slip through.
        $r = New-Fixture 'std-prohib-unknown'
        New-FactStore $r @{ 'migration.r_type' = 'Replatform'
            'azure.target.compute' = 'cpf-azure-prdsvcpat-aks-private'
        }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'conditional_prohibition'
                when = @(@{ fact = 'migration.r_type'; equals = 'Replatform' },
                    @{ fact = 'source.containerized'; equals = 'false' })
                forbid = @{ fact = 'azure.target.compute'; matching = @('aks') }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 0 $res.Code 'unknown must not fire the rule'
        AssertEqual 0 @(Get-Finding (Get-Report $r) 'R1').Count 'and must not silently pass it either'
    }

    Check 'requires_n_of fails when too few evidence facts are stated' {
        $r = New-Fixture 'std-nof-bad'
        New-FactStore $r @{ 'azure.target.compute' = 'aks'; 'business_case.cost_reduction_pct' = '18' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_n_of'
                when = @(@{ fact = 'azure.target.compute'; matching = @('aks') })
                facts = @('business_case.cost_reduction_pct', 'business_case.reliability_delta',
                    'business_case.scalability_need')
                n = 2; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 2 $res.Code
        AssertContains (Get-Finding (Get-Report $r) 'R1')[0].message 'only 1 of the required 2'
    }

    Check 'requires_n_of passes once enough are stated' {
        $r = New-Fixture 'std-nof-ok'
        New-FactStore $r @{ 'azure.target.compute' = 'aks'; 'business_case.cost_reduction_pct' = '18'
            'business_case.scalability_need' = 'bursts to 40x on close'
        }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_n_of'
                when = @(@{ fact = 'azure.target.compute'; matching = @('aks') })
                facts = @('business_case.cost_reduction_pct', 'business_case.reliability_delta',
                    'business_case.scalability_need')
                n = 2; severity = 'mandatory'
            })
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Group 'standards / derivation'

    Check 'an implication derives a fact nobody stated' {
        $r = New-Fixture 'std-derive'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'implication'
                when = @{ fact = 'app.tier'; in = @('1') }
                then = @{ fact = 'deploy.multi_region'; must_be = 'true' }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 0 $res.Code
        AssertEqual 1 (Get-Report $r).facts_derived
    }

    Check 'a stated value contradicting an implication is a violation' {
        $r = New-Fixture 'std-derive-clash'
        New-FactStore $r @{ 'app.tier' = '1'; 'deploy.multi_region' = 'false' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'implication'
                when = @{ fact = 'app.tier'; in = @('1') }
                then = @{ fact = 'deploy.multi_region'; must_be = 'true' }; severity = 'mandatory'
            })
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'implications chain, and the chain catches a contradiction across two rules' {
        # The case that motivated the whole layer. Tier 1 implies a CDC cutover; CDC
        # implies Refactor or Rearchitect; the SAD says Replatform. No single rule is
        # broken when read on its own.
        $r = New-Fixture 'std-chain'
        New-FactStore $r @{ 'app.tier' = '1'; 'migration.r_type' = 'Replatform' }
        $p = New-RulePack $r @(
            @{ id = 'CUT2'; kind = 'implication'
                when = @{ fact = 'app.tier'; in = @('1') }
                then = @{ fact = 'migration.cutover_pattern'; must_be = 'cdc' }; severity = 'mandatory'
            },
            @{ id = 'CUT3'; kind = 'implication'
                when = @{ fact = 'migration.cutover_pattern'; equals = 'cdc' }
                then = @{ fact = 'migration.r_type'; must_be_in = @('Refactor', 'Rearchitect') }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code
        $f = @(Get-Finding (Get-Report $r) 'CUT3')
        AssertEqual 1 $f.Count 'the chained rule must fire'
        AssertTrue (@($f[0].derivation).Count -ge 2) 'and must show how it got there'
        AssertContains ($f[0].derivation -join ' | ') 'CUT2'
    }

    Check 'two implications forcing different values are reported as an inconsistency' {
        $r = New-Fixture 'std-collide'
        New-FactStore $r @{ 'app.tier' = '1'; 'app.data_classification' = 'public' }
        $p = New-RulePack $r @(
            @{ id = 'A1'; kind = 'implication'; when = @{ fact = 'app.tier'; in = @('1') }
                then = @{ fact = 'deploy.recovery_pattern'; must_be = 'active-active' }; severity = 'mandatory'
            },
            @{ id = 'A2'; kind = 'implication'; when = @{ fact = 'app.data_classification'; equals = 'public' }
                then = @{ fact = 'deploy.recovery_pattern'; must_be = 'pilot-light' }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code
        AssertTrue ((Get-Report $r).tally.inconsistencies -ge 1) 'the collision must be reported'
    }

    Check 'must_exist implications become gaps' {
        $r = New-Fixture 'std-mustexist'
        New-FactStore $r @{ 'deploy.multi_region' = 'true' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'implication'
                when = @{ fact = 'deploy.multi_region'; equals = 'true' }
                then = @{ fact = 'nfr.region.secondary'; must_exist = $true }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 2 $res.Code
        AssertEqual 'gap' (Get-Finding (Get-Report $r) 'R1')[0].kind
    }

    Check 'explain reports the blast radius of a fact' {
        $r = New-Fixture 'std-explain'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(
            @{ id = 'B1'; kind = 'implication'; when = @{ fact = 'app.tier'; in = @('1') }
                then = @{ fact = 'deploy.multi_region'; must_be = 'true' }; severity = 'mandatory'
            },
            @{ id = 'B2'; kind = 'implication'; when = @{ fact = 'deploy.multi_region'; equals = 'true' }
                then = @{ fact = 'deploy.recovery_pattern'; must_be = 'active-active' }; severity = 'mandatory'
            })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'explain', '-FactKey', 'app.tier')
        AssertEqual 0 $res.Code
        AssertContains $res.Out 'deploy.multi_region'
        AssertContains $res.Out 'deploy.recovery_pattern'
    }

    Group 'standards / severity and exceptions'

    Check 'an advisory is reported but never blocks' {
        $r = New-Fixture 'std-advisory'
        New-FactStore $r @{ 'pipeline.app.commit_convention' = 'freeform' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'pipeline.app.commit_convention'
                allowed = @('conventional-commits'); severity = 'advisory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 0 $res.Code 'advisories that block teach people to stop writing SHOULD'
        AssertEqual 1 (Get-Report $r).tally.advisories
    }

    Check '-StrictAdvisory promotes advisories to blocking' {
        $r = New-Fixture 'std-advisory-strict'
        New-FactStore $r @{ 'pipeline.app.commit_convention' = 'freeform' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'pipeline.app.commit_convention'
                allowed = @('conventional-commits'); severity = 'advisory' })
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check', '-StrictAdvisory')).Code
    }

    Check 'an exception requires an approver' {
        $r = New-Fixture 'std-exc-noapprover'
        New-FactStore $r @{ 'app.tier' = '1' }
        $res = Invoke-Check $r @('-Command', 'grant-exception', '-Target', 'R1', '-Actor', 'me',
            '-Rationale', 'why', '-Expires', '2099-01-01')
        AssertEqual 4 $res.Code
        AssertContains $res.Out 'cannot except itself'
    }

    Check 'an exception requires an expiry' {
        $r = New-Fixture 'std-exc-noexpiry'
        New-FactStore $r @{ 'app.tier' = '1' }
        $res = Invoke-Check $r @('-Command', 'grant-exception', '-Target', 'R1', '-Actor', 'me',
            '-Approver', 'gov', '-Rationale', 'why')
        AssertEqual 4 $res.Code
        AssertContains $res.Out 'silent amendment'
    }

    Check 'an exception cannot be backdated' {
        $r = New-Fixture 'std-exc-past'
        New-FactStore $r @{ 'app.tier' = '1' }
        $res = Invoke-Check $r @('-Command', 'grant-exception', '-Target', 'R1', '-Actor', 'me',
            '-Approver', 'gov', '-Rationale', 'why', '-Expires', '2000-01-01')
        AssertEqual 4 $res.Code
    }

    Check 'a valid exception clears a mandatory violation' {
        $r = New-Fixture 'std-exc-clears'
        New-FactStore $r @{ 'nfr.region.primary' = 'eastus' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
        $future = (Get-Date).AddYears(1).ToString('yyyy-MM-dd')
        AssertEqual 0 (Invoke-Check $r @('-Command', 'grant-exception', '-Target', 'R1', '-Actor', 'me',
                '-Approver', 'gov', '-Rationale', 'interim', '-Expires', $future)).Code
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
        AssertEqual $true (Get-Finding (Get-Report $r) 'R1')[0].excepted
    }

    Check 'an expired exception stops clearing it' {
        $r = New-Fixture 'std-exc-expired'
        New-FactStore $r @{ 'nfr.region.primary' = 'eastus' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        # Written straight to the log: grant-exception refuses to backdate, which is the
        # point of the previous test. This simulates the passage of time instead.
        $log = Join-Path $r 'out\decisions\decision-log.jsonl'
        New-Item -ItemType Directory -Path (Split-Path -Parent $log) -Force | Out-Null
        Add-Content -Path $log -Encoding UTF8 -Value (([ordered]@{
                    ts = '2020-01-01T00:00:00Z'; actor = 'me'; action = 'grant-exception'; target = 'R1'
                    approver = 'gov'; rationale = 'interim'; expires = '2020-06-30'
                } | ConvertTo-Json -Compress))
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 3 $res.Code 'an expired exception must re-open the finding'
        $f = (Get-Finding (Get-Report $r) 'R1')[0]
        AssertEqual $false $f.excepted
        AssertContains $f.message 'expired'
    }

    Group 'standards / CPF catalogue binding'

    Check 'the clearlist is read from the catalogue, not from the pack' {
        $r = New-Fixture 'std-cpf'
        New-FactStore $r @{ 'azure.target.compute' = 'cpf-test-approved' }
        $cat = Join-Path $r 'catalog.json'
        Set-Content -Path $cat -Encoding UTF8 -NoNewline -Value ((([ordered]@{
                        modules = @(@{ cpf_id = 'cpf-test-approved' }, @{ cpf_id = 'cpf-test-other' })
                    }) | ConvertTo-Json -Depth 10) + "`r`n")
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact_pattern = 'azure.target.*'
                allowed_from = 'cpf_catalog'; severity = 'mandatory' }) `
            @{ cpf_catalog = @{ path = '..\catalog.json'; json_pointer = 'modules'; id_field = 'cpf_id' } }
        AssertEqual 0 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'a module outside the catalogue is a violation' {
        $r = New-Fixture 'std-cpf-bad'
        New-FactStore $r @{ 'azure.target.compute' = 'cpf-not-in-catalogue' }
        $cat = Join-Path $r 'catalog.json'
        Set-Content -Path $cat -Encoding UTF8 -NoNewline -Value ((([ordered]@{
                        modules = @(@{ cpf_id = 'cpf-test-approved' })
                    }) | ConvertTo-Json -Depth 10) + "`r`n")
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact_pattern = 'azure.target.*'
                allowed_from = 'cpf_catalog'; severity = 'mandatory' }) `
            @{ cpf_catalog = @{ path = '..\catalog.json'; json_pointer = 'modules'; id_field = 'cpf_id' } }
        AssertEqual 3 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'a missing catalogue degrades to not-assessed rather than crashing' {
        $r = New-Fixture 'std-cpf-missing'
        New-FactStore $r @{ 'azure.target.compute' = 'anything' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact_pattern = 'azure.target.*'
                allowed_from = 'cpf_catalog'; severity = 'mandatory' }) `
            @{ cpf_catalog = @{ path = '..\nope.json' } }
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 0 $res.Code
        AssertEqual 'not-assessed' (Get-Finding (Get-Report $r) 'R1')[0].kind
    }

    Check '-CpfCatalog overrides a pack path that does not resolve here' {
        # The deployment case: the pack was authored in one checkout and is being run
        # in another, so its relative catalogue path is wrong.
        $r = New-Fixture 'std-cpf-override'
        New-FactStore $r @{ 'azure.target.compute' = 'cpf-test-approved' }
        $cat = Join-Path $r 'elsewhere.json'
        Set-Content -Path $cat -Encoding UTF8 -NoNewline -Value ((([ordered]@{
                        modules = @(@{ cpf_id = 'cpf-test-approved' })
                    }) | ConvertTo-Json -Depth 10) + "`r`n")
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact_pattern = 'azure.target.*'
                allowed_from = 'cpf_catalog'; severity = 'mandatory' }) `
            @{ cpf_catalog = @{ path = '..\does-not-exist.json' } }
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check', '-CpfCatalog', $cat)
        AssertEqual 0 $res.Code
        AssertEqual 0 @(Get-Finding (Get-Report $r) 'R1').Count 'the override must actually be used'
        AssertContains (Get-Report $r).cpf_clearlist 'module(s)'
    }

    Check 'LMP_CPF_CATALOG is honoured when no argument is given' {
        $r = New-Fixture 'std-cpf-env'
        New-FactStore $r @{ 'azure.target.compute' = 'cpf-env-approved' }
        $cat = Join-Path $r 'from-env.json'
        Set-Content -Path $cat -Encoding UTF8 -NoNewline -Value ((([ordered]@{
                        modules = @(@{ cpf_id = 'cpf-env-approved' })
                    }) | ConvertTo-Json -Depth 10) + "`r`n")
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact_pattern = 'azure.target.*'
                allowed_from = 'cpf_catalog'; severity = 'mandatory' }) `
            @{ cpf_catalog = @{ path = '..\does-not-exist.json' } }
        $env:LMP_CPF_CATALOG = $cat
        try {
            $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
            AssertEqual 0 $res.Code
            AssertEqual 0 @(Get-Finding (Get-Report $r) 'R1').Count
        } finally { Remove-Item Env:\LMP_CPF_CATALOG -ErrorAction SilentlyContinue }
    }

    Group 'standards / rule-guided extraction'

    Check 'required lists the facts the rules need and the spec lacks' {
        $r = New-Fixture 'std-required'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(
            @{ id = 'R1'; kind = 'requires_fact'; facts = @('nfr.rto', 'nfr.rpo'); severity = 'mandatory' },
            @{ id = 'R2'; kind = 'requires_fact'; facts = @('app.tier'); severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'required')
        AssertEqual 0 $res.Code
        AssertContains $res.Out 'nfr.rto'
        AssertContains $res.Out 'nfr.rpo'
        AssertTrue ($res.Out -notlike '*app.tier*') 'a fact already stated must not be asked for again'
    }

    Check 'required emits machine-readable output for an agent to act on' {
        $r = New-Fixture 'std-required-json'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_fact'; facts = @('nfr.rto'); severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'required', '-Format', 'json')
        $doc = $res.Out | ConvertFrom-Json
        AssertEqual 1 $doc.count
        AssertEqual 'nfr.rto' @($doc.required)[0].fact_key
        AssertEqual 'R1' @($doc.required)[0].required_by
    }

    Group 'standards / the gate'

    Check 'resolve refuses while a mandatory violation stands' {
        $r = New-Fixture 'std-gate-block'
        New-ApprovedStore $r
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        $res = Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec')
        AssertEqual 3 $res.Code
        AssertContains $res.Out 'constitution finding'
    }

    Check 'the refusal cannot be cleared by approving harder' {
        $r = New-Fixture 'std-gate-approve'
        New-ApprovedStore $r
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        AssertEqual 3 (Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'draft')).Code
    }

    Check 'resolve releases once the violation is excepted' {
        $r = New-Fixture 'std-gate-release'
        New-ApprovedStore $r
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        AssertEqual 3 (Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec')).Code
        $future = (Get-Date).AddYears(1).ToString('yyyy-MM-dd')
        Invoke-Check $r @('-Command', 'grant-exception', '-Target', 'R1', '-Actor', 'me',
            '-Approver', 'gov', '-Rationale', 'interim', '-Expires', $future) | Out-Null
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        AssertEqual 0 (Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec')).Code
    }

    Check '-SkipStandards bypasses the gate but says so in the payload' {
        $r = New-Fixture 'std-gate-skip'
        New-ApprovedStore $r
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('uksouth'); severity = 'mandatory' })
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        $res = Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-SkipStandards', '-Format', 'json')
        AssertEqual 0 $res.Code
        AssertEqual $true ($res.Out | ConvertFrom-Json).standards_skipped
    }

    Check 'a spec that was never checked is distinguishable from one that passed' {
        $r = New-Fixture 'std-gate-unchecked'
        New-ApprovedStore $r
        $res = Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-Format', 'json')
        AssertEqual 0 $res.Code 'the spec layer still works without the constraint layer'
        AssertEqual $false ($res.Out | ConvertFrom-Json).standards_checked
    }

    Check '-RequireStandards refuses when no check has been run' {
        # The failure mode that makes it safe to keep the rule pack in its own repo:
        # if the pack goes missing, resolve must refuse rather than report no findings.
        $r = New-Fixture 'std-gate-require'
        New-ApprovedStore $r
        $res = Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-RequireStandards')
        AssertEqual 3 $res.Code
        AssertContains $res.Out 'no standards check has been run'
    }

    Check '-RequireStandards passes once a clean check exists' {
        $r = New-Fixture 'std-gate-require-ok'
        New-ApprovedStore $r
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'allowed_values'; fact = 'nfr.region.primary'
                allowed = @('westeurope'); severity = 'mandatory' })
        Invoke-Check $r @('-RulesPack', $p, '-Command', 'check') | Out-Null
        AssertEqual 0 (Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-RequireStandards')).Code
    }

    Check '-RequireStandards and -SkipStandards cannot both be set' {
        $r = New-Fixture 'std-gate-contradict'
        New-ApprovedStore $r
        $res = Invoke-Spec $r @('-Command', 'resolve', '-View', 'devops-spec', '-RequireStandards', '-SkipStandards')
        AssertEqual 4 $res.Code
        AssertContains $res.Out 'contradict'
    }

    Group 'standards / bad input'

    Check 'a missing rule pack exits 4' {
        $r = New-Fixture 'std-nopack'
        New-FactStore $r @{ 'app.tier' = '1' }
        AssertEqual 4 (Invoke-Check $r @('-RulesPack', (Join-Path $r 'nowhere'), '-Command', 'check')).Code
    }

    Check 'an unknown rule kind exits 4 rather than being ignored' {
        $r = New-Fixture 'std-badkind'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'wishful-thinking'; severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 4 $res.Code
        AssertContains $res.Out 'unknown kind'
    }

    Check 'a duplicate rule id exits 4' {
        $r = New-Fixture 'std-dupe'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(
            @{ id = 'R1'; kind = 'requires_fact'; facts = @('a'); severity = 'mandatory' },
            @{ id = 'R1'; kind = 'requires_fact'; facts = @('b'); severity = 'mandatory' })
        $res = Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')
        AssertEqual 4 $res.Code
        AssertContains $res.Out 'duplicate rule id'
    }

    Check 'checking before build exits 4' {
        $r = New-Fixture 'std-nobuild'
        Invoke-Spec $r @('-Command', 'init') | Out-Null
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_fact'; facts = @('a'); severity = 'mandatory' })
        AssertEqual 4 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'check')).Code
    }

    Check 'explain without -FactKey exits 4' {
        $r = New-Fixture 'std-explain-noarg'
        New-FactStore $r @{ 'app.tier' = '1' }
        $p = New-RulePack $r @(@{ id = 'R1'; kind = 'requires_fact'; facts = @('a'); severity = 'mandatory' })
        AssertEqual 4 (Invoke-Check $r @('-RulesPack', $p, '-Command', 'explain')).Code
    }

    Group 'standards / the LSEG pack'

    if (-not (Test-Path (Join-Path $LsegPack 'pack.json'))) {
        Check 'lseg-constitution-pack is present' { throw "not found at $LsegPack - skipping pack content checks" }
    } else {

        Check 'the pack loads and every rule kind in it is understood' {
            $r = New-Fixture 'lseg-load'
            New-FactStore $r @{ 'app.tier' = '3' }
            $res = Invoke-Check $r @('-RulesPack', $LsegPack, '-Command', 'check')
            AssertTrue ($res.Code -ne 4) "pack failed to load: $($res.Out)"
            AssertTrue ((Get-Report $r).rules_evaluated -ge 60) 'expected the full constitution'
        }

        Check 'it binds to the real CPF catalogue where one is reachable' {
            $r = New-Fixture 'lseg-cpf'
            New-FactStore $r @{ 'app.tier' = '3' }
            Invoke-Check $r @('-RulesPack', $LsegPack, '-Command', 'check') | Out-Null
            $clearlist = (Get-Report $r).cpf_clearlist
            if ($clearlist -like '*not found*') {
                # Not a package defect. The catalogue is an external dependency and is
                # deliberately not shipped with the pack, so it is unreachable whenever
                # the package has been copied away from the governance repo. Say so
                # loudly instead of failing - and instead of passing silently, which
                # would hide the fact that the clearlist is not being enforced.
                Write-Host "          catalogue not reachable here - pass -CpfCatalog <path> in this environment" -ForegroundColor DarkYellow
                Write-Host "          ($clearlist)" -ForegroundColor DarkGray
                return
            }
            AssertContains $clearlist 'module(s)'
        }

        Check 'it catches the Tier 1 Replatform contradiction' {
            $r = New-Fixture 'lseg-chain'
            New-FactStore $r @{ 'app.tier' = '1'; 'migration.r_type' = 'Replatform' }
            $res = Invoke-Check $r @('-RulesPack', $LsegPack, '-Command', 'check')
            AssertEqual 3 $res.Code
            AssertEqual 1 @(Get-Finding (Get-Report $r) 'LMP-MIG-CUT-3').Count
        }

        Check 'it enforces the Container Adoption Rule' {
            $r = New-Fixture 'lseg-container'
            New-FactStore $r @{ 'migration.r_type' = 'Replatform'; 'source.containerized' = 'false'
                'azure.target.compute' = 'cpf-azure-prdsvcpat-aks-private'
            }
            Invoke-Check $r @('-RulesPack', $LsegPack, '-Command', 'check') | Out-Null
            AssertEqual 1 @(Get-Finding (Get-Report $r) 'LMP-RT-REPLAT-1').Count
        }

        Check 'it rejects a region outside the LMP-approved set' {
            $r = New-Fixture 'lseg-region'
            New-FactStore $r @{ 'app.tier' = '3'; 'nfr.region.primary' = 'eastus' }
            Invoke-Check $r @('-RulesPack', $LsegPack, '-Command', 'check') | Out-Null
            AssertEqual 1 @(Get-Finding (Get-Report $r) 'LMP-GC-01').Count
        }

        Check 'every rule carries a constitution anchor and a quote' {
            $missing = New-Object System.Collections.ArrayList
            foreach ($rf in (Get-Content (Join-Path $LsegPack 'pack.json') -Raw | ConvertFrom-Json).rule_files) {
                foreach ($rule in (Get-Content (Join-Path $LsegPack $rf) -Raw | ConvertFrom-Json).rules) {
                    if (-not $rule.source -or -not $rule.quote) { [void]$missing.Add($rule.id) }
                }
            }
            AssertEqual 0 $missing.Count ("rules with no provenance: " + ($missing -join ', '))
        }

        Check 'every fact a rule names exists in the vocabulary' {
            $keys = (Get-Content (Join-Path $LsegPack 'fact-keys.json') -Raw | ConvertFrom-Json).keys
            $known = @($keys.PSObject.Properties.Name)
            $unknown = New-Object System.Collections.ArrayList
            foreach ($rf in (Get-Content (Join-Path $LsegPack 'pack.json') -Raw | ConvertFrom-Json).rule_files) {
                foreach ($rule in (Get-Content (Join-Path $LsegPack $rf) -Raw | ConvertFrom-Json).rules) {
                    $named = New-Object System.Collections.ArrayList
                    if ($rule.PSObject.Properties['fact']) { [void]$named.Add($rule.fact) }
                    if ($rule.PSObject.Properties['facts']) { foreach ($f in @($rule.facts)) { [void]$named.Add($f) } }
                    if ($rule.PSObject.Properties['when'] -and $rule.when) {
                        foreach ($c in @($rule.when)) { if ($c.PSObject.Properties['fact']) { [void]$named.Add($c.fact) } }
                    }
                    if ($rule.PSObject.Properties['then'] -and $rule.then) { [void]$named.Add($rule.then.fact) }
                    foreach ($n in $named) {
                        if ($n -and $known -notcontains $n) { [void]$unknown.Add("$($rule.id):$n") }
                    }
                }
            }
            AssertEqual 0 $unknown.Count ("rules naming undeclared facts: " + ($unknown -join ', '))
        }

        Check 'every fact in the vocabulary is routable to a view' {
            # A fact that lands in 'unrouted' never reaches a spec view, so a rule that
            # depends on it can never gate anything. This is the check that would have
            # caught the seven missing routing prefixes.
            $keys = (Get-Content (Join-Path $LsegPack 'fact-keys.json') -Raw | ConvertFrom-Json).keys
            $r = New-Fixture 'lseg-routing'
            Invoke-Spec $r @('-Command', 'init') | Out-Null
            $unrouted = New-Object System.Collections.ArrayList
            foreach ($k in @($keys.PSObject.Properties.Name)) {
                if ($k.StartsWith('_')) { continue }
                Invoke-Spec $r @('-Command', 'add-statement', '-FactKey', $k, '-Value', 'x',
                    '-SourceId', 'src-test0001', '-Locator', 't', '-Quote', 't') | Out-Null
            }
            Invoke-Spec $r @('-Command', 'build') | Out-Null
            foreach ($s in (Get-Content (Join-Path $r 'out\statements.json') -Raw | ConvertFrom-Json).statements) {
                if ($s.section -eq 'unrouted') { [void]$unrouted.Add($s.fact_key) }
            }
            AssertEqual 0 $unrouted.Count ("unroutable fact keys: " + ($unrouted -join ', '))
        }
    }
}

# --------------------------------------------------------------------------- #
# Run
# --------------------------------------------------------------------------- #

Write-Host ''
Write-Host 'lmp-spec-agent test harness' -ForegroundColor White
Write-Host ("PowerShell {0} | suite: {1}" -f $PSVersionTable.PSVersion, $Suite) -ForegroundColor DarkGray

if (-not (Test-Path $SpecScript)) { Write-Host "Spec.ps1 not found at $SpecScript" -ForegroundColor Red; exit 1 }
if (-not (Test-Path $ConsumerScript)) { Write-Host "mock-consumer.ps1 not found at $ConsumerScript" -ForegroundColor Red; exit 1 }
if (-not (Test-Path $CheckScript)) { Write-Host "Check-Standards.ps1 not found at $CheckScript" -ForegroundColor Red; exit 1 }

$sw = [System.Diagnostics.Stopwatch]::StartNew()
if ($Suite -eq 'all' -or $Suite -eq 'unit') { Invoke-UnitSuite }
if ($Suite -eq 'all' -or $Suite -eq 'integration') { Invoke-IntegrationSuite }
if ($Suite -eq 'all' -or $Suite -eq 'contract') { Invoke-ContractSuite }
if ($Suite -eq 'all' -or $Suite -eq 'standards') { Invoke-StandardsSuite }
$sw.Stop()

Write-Host ''
Write-Host ('-' * 60)
Write-Host ("passed {0}   failed {1}   in {2:N1}s" -f $script:Pass, $script:Fail, $sw.Elapsed.TotalSeconds) `
    -ForegroundColor $(if ($script:Fail -eq 0) { 'Green' } else { 'Red' })

if ($script:Fail -gt 0) {
    Write-Host ''
    Write-Host 'Failures:' -ForegroundColor Red
    foreach ($f in $script:Failures) { Write-Host "  $f" -ForegroundColor Red }
}

if (-not $KeepFixtures) {
    Remove-Item -Path (Join-Path $env:TEMP 'lmp-spec-tests') -Recurse -Force -ErrorAction SilentlyContinue
} else {
    Write-Host ''
    Write-Host ("fixtures kept in {0}" -f (Join-Path $env:TEMP 'lmp-spec-tests')) -ForegroundColor DarkGray
}

exit $(if ($script:Fail -gt 0) { 1 } else { 0 })
