<#
.SYNOPSIS
    The constraint layer: evaluates a spec against an organisation's encoded standards.

.DESCRIPTION
    Reads the canonical spec produced by Spec.ps1 and a rule pack (LSEG LMP Constitution,
    encoded as data), and reports where the design breaks the standards.

    Three things it does that a checklist cannot:

      1. Derivation. Implication rules chain. app.tier=1 forces a cutover pattern, which
         forces a migration treatment. A design can satisfy every rule read in isolation
         and still be internally contradictory. Chaining finds that.

      2. Gaps. A rule that requires a fact nobody wrote down is a finding, not a pass.
         Absence of evidence is reported as absence, never as compliance.

      3. Exceptions. A mandatory violation cannot be approved away by the delivery team.
         It is cleared only by a recorded, time-boxed, named exception - which expires.

    The engine never decides compliance with judgement. Where the constitution asks for
    a judgement ("the business case MUST be evidenced in at least two of..."), the engine
    verifies the evidence exists and hands the judgement to a human.

    This is the only writer of everything under out/compliance/.

    Windows PowerShell 5.1. No modules.

.PARAMETER Command
    check            Evaluate the spec against the pack. Writes violations and a report.
    required         List the fact keys the pack needs that the spec has not stated.
                     This is the input to rule-guided extraction.
    explain          Show the derivation chain and blast radius for one fact key.
    grant-exception  Record a time-boxed exception against a rule id.

.EXAMPLE
    .\Check-Standards.ps1 -Root .lmp-migrate\payments -RulesPack ..\lseg-constitution-pack -Command check
    .\Check-Standards.ps1 -Root .lmp-migrate\payments -Command required -Format json
    .\Check-Standards.ps1 -Root .lmp-migrate\payments -Command explain -FactKey app.tier
    .\Check-Standards.ps1 -Root .lmp-migrate\payments -Command grant-exception -Target LMP-RT-REPLAT-1 `
        -Actor "j.smith" -Approver "arch-gov-board" -Rationale "..." -Expires 2026-09-30

.EXAMPLE
    # When the CPF catalogue does not sit where the pack expects it - which is the
    # normal case once the package has been copied into another environment:
    .\Check-Standards.ps1 -Root <root> -RulesPack <pack> -Command check `
        -CpfCatalog D:\gitlab\iac-terraform-4lmp\templates\cpf-schemas\_catalog.json

.NOTES
    Exit codes
      0  compliant - no mandatory violations, no mandatory gaps
      2  cannot assess - mandatory facts are missing, the design is not yet checkable
      3  mandatory violation or internal inconsistency
      4  missing store, missing rule pack, or bad arguments
#>
[CmdletBinding()]
param(
    [string]$Root = '.',

    [ValidateSet('check', 'required', 'explain', 'grant-exception')]
    [string]$Command = 'check',

    [string]$RulesPack,
    [string]$FactKey,

    # Overrides the catalogue path in the pack's bindings. The pack stores a path
    # relative to itself, which only holds while the pack and the catalogue sit in the
    # same checkout. Moving either one breaks it, so it has to be overridable at the
    # call site. Falls back to $env:LMP_CPF_CATALOG.
    [string]$CpfCatalog,

    [string]$Target,
    [string]$Actor,
    [string]$Approver,
    [string]$Rationale,
    [string]$Expires,

    [ValidateSet('text', 'json')][string]$Format = 'text',

    # Report advisories but never let them affect the exit code. On by default:
    # advisories that block teach authors to stop writing SHOULD honestly.
    [switch]$StrictAdvisory
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$script:BoundParams = $PSBoundParameters

# Commands write to the output stream and signal failure through this, because
# `exit (Invoke-Something)` would capture their output as the exit expression.
$script:ExitCode = 0

$script:PACK_VERSION = 1

# Implication chaining needs a fixpoint, and a badly written pack could cycle.
# Ten passes is far more depth than any real constitution has.
$script:MAX_DERIVATION_PASSES = 10

# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

function Fail([string]$Message, [int]$Code) {
    [Console]::Error.WriteLine("ERROR: $Message")
    exit $Code
}

function Now() { (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') }

function Get-StringSha256([string]$Text) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        $hash = $sha.ComputeHash($bytes)
        return (($hash | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $sha.Dispose() }
}

# ConvertFrom-Json collapses one-element arrays to a scalar, so every array read goes
# through this.
#
# It returns unrolled, and every caller that needs a real array wraps the call in @().
# The opposite convention - Write-Output -NoEnumerate - looks safer and is a trap: @()
# around a non-enumerated array produces an array containing that array. It cost a
# debugging session here, where the entire findings list silently became one nested
# element and the report claimed a single blank, already-excepted finding.
function AsArray($Value) {
    if ($null -eq $Value) { return @() }
    if ($Value -is [System.Array]) { return $Value }
    return @($Value)
}

# Set-StrictMode 2.0 throws on a missing property of a PSCustomObject, and rules are
# deliberately sparse - most carry only the fields their kind needs. Every read of a
# rule field goes through this.
function Get-Prop($Object, [string]$Name) {
    if ($null -eq $Object) { return $null }
    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $null
    }
    $p = $Object.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    return $p.Value
}

function Read-JsonFile([string]$Path) {
    if (-not (Test-Path $Path)) { return $null }
    $raw = Get-Content -Path $Path -Raw -Encoding UTF8
    if (-not $raw -or $raw.Trim().Length -eq 0) { return $null }
    return ($raw | ConvertFrom-Json)
}

function Write-JsonFile([string]$Path, $Object) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $json = $Object | ConvertTo-Json -Depth 100
    Set-Content -Path $Path -Value ($json + "`r`n") -Encoding UTF8 -NoNewline
}

function Write-TextFile([string]$Path, [string]$Text) {
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $Path -Value $Text -Encoding UTF8 -NoNewline
}

function Get-Paths([string]$RootPath) {
    $out = Join-Path $RootPath 'out'
    return [ordered]@{
        Root           = $RootPath
        Out            = $out
        Statements     = Join-Path $out 'statements.json'
        Canonical      = Join-Path $out 'specifications\system-spec.json'
        Decisions      = Join-Path $out 'decisions\decision-log.jsonl'
        ComplianceDir  = Join-Path $out 'compliance'
        Violations     = Join-Path $out 'compliance\violations.json'
        Report         = Join-Path $out 'compliance\constitution-report.json'
        ReportMd       = Join-Path $out 'review\constitution-report.md'
    }
}

function New-FindingId([string]$RuleId, [string]$FactName, [string]$Kind) {
    'fnd-' + (Get-StringSha256 "$RuleId|$FactName|$Kind").Substring(0, 8)
}

# --------------------------------------------------------------------------- #
# Pack loading
# --------------------------------------------------------------------------- #

# Resolution order is explicit argument, then a pack vendored next to the spec, then
# the sibling checkout. A demo should not need a path; a pipeline should always pass one.
#
# An explicitly named pack that does not exist is a hard error, never a fallback. Quietly
# checking against a different pack than the one the caller asked for is how you get a
# clean report for the wrong constitution.
function Resolve-PackPath([string]$Supplied, [string]$RootPath) {
    if ($Supplied) {
        if (Test-Path $Supplied -PathType Leaf) { return (Resolve-Path $Supplied).Path }
        $named = Join-Path $Supplied 'pack.json'
        if (Test-Path $named) { return (Resolve-Path $named).Path }
        Fail "rule pack '$Supplied' not found - expected a pack.json there" 4
    }

    $candidates = New-Object System.Collections.ArrayList
    [void]$candidates.Add((Join-Path $RootPath 'rules-pack'))
    if ($PSScriptRoot) {
        # Vendored inside the package - the layout to use when the package is copied
        # into another environment as a single folder.
        [void]$candidates.Add((Join-Path $PSScriptRoot '..\..\..\rules-pack'))
        [void]$candidates.Add((Join-Path $PSScriptRoot '..\..\..\..\lseg-constitution-pack'))
    }

    foreach ($c in $candidates) {
        if (-not $c) { continue }
        if (Test-Path $c -PathType Leaf) { return (Resolve-Path $c).Path }
        $p = Join-Path $c 'pack.json'
        if (Test-Path $p) { return (Resolve-Path $p).Path }
    }
    return $null
}

function Get-Pack([string]$PackFile) {
    $pack = Read-JsonFile $PackFile
    if ($null -eq $pack) { Fail "rule pack '$PackFile' is empty or unreadable" 4 }
    $packDir = Split-Path -Parent $PackFile

    $rules = New-Object System.Collections.ArrayList
    $seen = @{}
    foreach ($rf in (AsArray (Get-Prop $pack 'rule_files'))) {
        $rfPath = Join-Path $packDir $rf
        if (-not (Test-Path $rfPath)) { Fail "rule file '$rf' listed in pack.json does not exist" 4 }
        $doc = Read-JsonFile $rfPath
        foreach ($r in (AsArray (Get-Prop $doc 'rules'))) {
            $id = Get-Prop $r 'id'
            if (-not $id) { Fail "a rule in '$rf' has no id" 4 }
            if ($seen.ContainsKey($id)) { Fail "duplicate rule id '$id' in '$rf'" 4 }
            $seen[$id] = $true
            [void]$rules.Add($r)
        }
    }
    if ($rules.Count -eq 0) { Fail "rule pack '$PackFile' contains no rules" 4 }

    return [ordered]@{
        File    = $PackFile
        Dir     = $packDir
        Meta    = $pack
        Rules   = $rules.ToArray()
        Catalog = (Get-CpfCatalog $pack $packDir)
    }
}

# The CPF clearlist is read live from the catalogue rather than copied into the pack,
# so the pack cannot drift from the 226 modules that actually exist. A missing
# catalogue degrades the CPF rules to 'not assessed' instead of crashing the run.
function Get-CpfCatalog($PackMeta, [string]$PackDir) {
    $result = [ordered]@{ Available = $false; Reason = 'no cpf_catalog binding in pack.json'; Ids = @(); Path = $null }

    $bindings = Get-Prop $PackMeta 'bindings'
    $binding = Get-Prop $bindings 'cpf_catalog'

    # An explicit override wins over the pack, and works even if the pack declares no
    # binding at all.
    $override = $CpfCatalog
    if (-not $override) { $override = $env:LMP_CPF_CATALOG }

    if ($override) {
        $full = $override
        $rel = $override
    } else {
        if ($null -eq $binding) { return $result }
        $rel = Get-Prop $binding 'path'
        if (-not $rel) { $result.Reason = 'cpf_catalog binding has no path'; return $result }
        $full = Join-Path $PackDir $rel
    }

    $result.Path = $full
    if (-not (Test-Path $full)) {
        $result.Reason = "catalogue not found at '$rel'"
        return $result
    }

    $doc = Read-JsonFile $full
    $pointer = Get-Prop $binding 'json_pointer'
    if (-not $pointer) { $pointer = 'modules' }
    $idField = Get-Prop $binding 'id_field'
    if (-not $idField) { $idField = 'cpf_id' }

    $modules = @(AsArray (Get-Prop $doc $pointer))
    if ($modules.Count -eq 0) {
        $result.Reason = "catalogue '$rel' has no entries under '$pointer'"
        return $result
    }

    $ids = New-Object System.Collections.ArrayList
    foreach ($m in $modules) {
        $id = Get-Prop $m $idField
        if ($id) { [void]$ids.Add([string]$id) }
    }

    $result.Available = $true
    $result.Reason = "$($ids.Count) module(s) from $rel"
    $result.Ids = $ids.ToArray()
    return $result
}

# --------------------------------------------------------------------------- #
# Spec loading
# --------------------------------------------------------------------------- #

# Evaluation runs against the canonical spec, not the approved subset. A mandatory
# violation must be visible before anyone is asked to approve it, and it must not be
# possible to hide one by leaving a statement in draft.
function Get-AssertedFacts($Paths) {
    $canon = Read-JsonFile $Paths.Canonical
    if ($null -eq $canon) {
        Fail "no canonical spec at '$($Paths.Canonical)' - run Spec.ps1 build first" 4
    }
    $facts = @{}
    foreach ($f in (AsArray (Get-Prop $canon 'facts'))) {
        $k = Get-Prop $f 'fact_key'
        if (-not $k) { continue }
        $facts[$k] = [ordered]@{
            fact_key     = $k
            value        = [string](Get-Prop $f 'value')
            statement_id = Get-Prop $f 'statement_id'
            tier         = Get-Prop $f 'tier'
            confidence   = Get-Prop $f 'confidence'
            contested    = Get-Prop $f 'contested'
            origin       = 'asserted'
        }
    }
    return $facts
}

# An exception clears a mandatory violation. It must name an approver and it must
# expire - an exception without an end date is a silent amendment to the constitution.
function Get-Exceptions($Paths) {
    $ex = @{}
    if (-not (Test-Path $Paths.Decisions)) { return $ex }
    $today = (Get-Date).ToUniversalTime().Date

    foreach ($line in (Get-Content -Path $Paths.Decisions -Encoding UTF8)) {
        if (-not $line -or $line.Trim().Length -eq 0) { continue }
        $entry = $null
        try { $entry = $line | ConvertFrom-Json } catch { continue }
        if ((Get-Prop $entry 'action') -ne 'grant-exception') { continue }

        $ruleId = Get-Prop $entry 'target'
        if (-not $ruleId) { continue }

        $expiresRaw = Get-Prop $entry 'expires'
        $expired = $true
        $expiresOn = $null
        if ($expiresRaw) {
            $parsed = [datetime]::MinValue
            if ([datetime]::TryParse([string]$expiresRaw, [ref]$parsed)) {
                $expiresOn = $parsed.Date
                $expired = ($expiresOn -lt $today)
            }
        }

        # Later entries win, so an exception can be re-granted or allowed to lapse.
        $ex[$ruleId] = [ordered]@{
            rule_id   = $ruleId
            actor     = Get-Prop $entry 'actor'
            approver  = Get-Prop $entry 'approver'
            rationale = Get-Prop $entry 'rationale'
            granted   = Get-Prop $entry 'ts'
            expires   = $expiresRaw
            expired   = $expired
        }
    }
    return $ex
}

# --------------------------------------------------------------------------- #
# Condition evaluation
# --------------------------------------------------------------------------- #

function Test-Match([string]$Value, $Needles) {
    foreach ($n in @(AsArray $Needles)) {
        if ($Value -and $Value.ToLowerInvariant().Contains(([string]$n).ToLowerInvariant())) { return $true }
    }
    return $false
}

# Returns $true, $false, or $null. $null means "cannot tell - the fact is absent",
# which is what stops an unstated fact from silently satisfying a prohibition.
function Test-Condition($Cond, $Facts) {
    $key = Get-Prop $Cond 'fact'
    if (-not $key) { return $null }
    if (-not $Facts.ContainsKey($key)) { return $null }
    $val = [string]$Facts[$key].value

    $op = Get-Prop $Cond 'equals'
    if ($null -ne $op) { return ($val -eq [string]$op) }

    $op = Get-Prop $Cond 'not_equals'
    if ($null -ne $op) { return ($val -ne [string]$op) }

    $op = Get-Prop $Cond 'in'
    if ($null -ne $op) { return (@(AsArray $op) -contains $val) }

    $op = Get-Prop $Cond 'not_in'
    if ($null -ne $op) { return (-not (@(AsArray $op) -contains $val)) }

    $op = Get-Prop $Cond 'contains'
    if ($null -ne $op) { return (Test-Match $val @($op)) }

    $op = Get-Prop $Cond 'matching'
    if ($null -ne $op) { return (Test-Match $val $op) }

    return $null
}

# All conditions must hold. If any is unknown the whole guard is unknown, so a rule
# never fires on a fact nobody stated.
function Test-AllConditions($Conds, $Facts) {
    $list = @(AsArray $Conds)
    if ($list.Count -eq 0) { return $true }
    $unknown = $false
    foreach ($c in $list) {
        $r = Test-Condition $c $Facts
        if ($null -eq $r) { $unknown = $true; continue }
        if (-not $r) { return $false }
    }
    if ($unknown) { return $null }
    return $true
}

function Get-MatchingFactKeys([string]$Pattern, $Facts) {
    $out = New-Object System.Collections.ArrayList
    $prefix = $Pattern.TrimEnd('*')
    foreach ($k in ($Facts.Keys | Sort-Object)) {
        if ($k.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { [void]$out.Add($k) }
    }
    return $out.ToArray()
}

# --------------------------------------------------------------------------- #
# Derivation graph
# --------------------------------------------------------------------------- #

# Chains implication rules to a fixpoint. Only `must_be` derives a value - `must_be_in`
# and `must_exist` constrain without pinning one, so they validate but never derive.
#
# The result is what lets the engine catch a design that passes every rule read on its
# own and still contradicts itself: tier 1 derives a CDC cutover, CDC derives a
# Refactor-or-Rearchitect treatment, and a stated Replatform then collides with a fact
# nobody ever wrote down.
function Build-Derivation($Rules, $Asserted) {
    $facts = @{}
    foreach ($k in $Asserted.Keys) { $facts[$k] = $Asserted[$k] }

    $chains = @{}          # fact_key -> array of derivation step strings
    $derivedBy = @{}       # fact_key -> rule id that produced it
    $collisions = New-Object System.Collections.ArrayList

    foreach ($k in $Asserted.Keys) {
        $chains[$k] = @(("{0} = {1} (stated, {2})" -f $k, $Asserted[$k].value, $Asserted[$k].statement_id))
    }

    for ($pass = 0; $pass -lt $script:MAX_DERIVATION_PASSES; $pass++) {
        $changed = $false

        foreach ($rule in $Rules) {
            if ((Get-Prop $rule 'kind') -ne 'implication') { continue }
            $when = Get-Prop $rule 'when'
            $then = Get-Prop $rule 'then'
            if ($null -eq $when -or $null -eq $then) { continue }

            $mustBe = Get-Prop $then 'must_be'
            if ($null -eq $mustBe) { continue }        # not a deriving rule

            if ((Test-Condition $when $facts) -ne $true) { continue }

            $targetKey = Get-Prop $then 'fact'
            $ruleId = Get-Prop $rule 'id'
            $whenKey = Get-Prop $when 'fact'

            $step = ("{0} -> {1} requires {2} = {3}" -f $whenKey, $ruleId, $targetKey, $mustBe)
            $priorChain = @()
            if ($chains.ContainsKey($whenKey)) { $priorChain = @($chains[$whenKey]) }

            if (-not $facts.ContainsKey($targetKey)) {
                $facts[$targetKey] = [ordered]@{
                    fact_key     = $targetKey
                    value        = [string]$mustBe
                    statement_id = $null
                    tier         = $null
                    confidence   = 'derived'
                    contested    = $false
                    origin       = 'derived'
                }
                $derivedBy[$targetKey] = $ruleId
                $chains[$targetKey] = @($priorChain + @($step))
                $changed = $true
                continue
            }

            # Already present. If it was derived by a different rule to a different
            # value, the constitution is being applied to a self-contradictory design.
            $existing = $facts[$targetKey]
            if ($existing.origin -eq 'derived' -and [string]$existing.value -ne [string]$mustBe) {
                $key = "$targetKey|$($existing.value)|$mustBe"
                $already = $false
                foreach ($c in $collisions) { if ($c.key -eq $key) { $already = $true; break } }
                if (-not $already) {
                    [void]$collisions.Add([ordered]@{
                            key        = $key
                            fact_key   = $targetKey
                            value_a    = [string]$existing.value
                            rule_a     = $derivedBy[$targetKey]
                            value_b    = [string]$mustBe
                            rule_b     = $ruleId
                            chain      = @($priorChain + @($step))
                        })
                }
            }
        }

        if (-not $changed) { break }
    }

    return [ordered]@{ Facts = $facts; Chains = $chains; DerivedBy = $derivedBy; Collisions = $collisions.ToArray() }
}

# --------------------------------------------------------------------------- #
# Rule evaluation
# --------------------------------------------------------------------------- #

function New-Finding($Rule, [string]$Kind, [string]$FactName, $Actual, [string]$Expected, [string]$Message, $Chain, $Facts) {
    $sev = Get-Prop $Rule 'severity'
    if (-not $sev) { $sev = 'advisory' }
    $ruleId = [string](Get-Prop $Rule 'id')

    $stmtIds = @()
    if ($FactName -and $Facts.ContainsKey($FactName) -and $Facts[$FactName].statement_id) {
        $stmtIds = @($Facts[$FactName].statement_id)
    }

    return [ordered]@{
        id                 = (New-FindingId $ruleId $FactName $Kind)
        rule_id            = $ruleId
        kind               = $Kind
        severity           = $sev
        fact_key           = $FactName
        actual             = $Actual
        expected           = $Expected
        message            = $Message
        statement_ids      = $stmtIds
        derivation         = @(AsArray $Chain)
        source             = [string](Get-Prop $Rule 'source')
        quote              = [string](Get-Prop $Rule 'quote')
        requires_exception = [string](Get-Prop $Rule 'requires_exception')
        llm_role           = [string](Get-Prop $Rule 'llm_role')
        excepted           = $false
        exception          = $null
    }
}

function Get-Chain($Derivation, [string]$Key) {
    if ($Derivation.Chains.ContainsKey($Key)) { return @($Derivation.Chains[$Key]) }
    return @()
}

function Invoke-RuleEvaluation($Pack, $Asserted, $Derivation) {
    $facts = $Derivation.Facts
    $findings = New-Object System.Collections.ArrayList

    foreach ($rule in $Pack.Rules) {
        $kind = [string](Get-Prop $rule 'kind')
        $ruleId = [string](Get-Prop $rule 'id')

        # A rule may carry a guard that decides whether it applies at all.
        $guard = Test-AllConditions (Get-Prop $rule 'applies_when') $facts
        if ($guard -ne $true) { continue }

        switch ($kind) {

            'requires_fact' {
                foreach ($k in (AsArray (Get-Prop $rule 'facts'))) {
                    if (-not $facts.ContainsKey($k)) {
                        [void]$findings.Add((New-Finding $rule 'gap' $k $null 'stated with evidence' `
                            ("required fact '$k' is not stated anywhere in the spec") @() $facts))
                    }
                }
            }

            'conditional_requires_fact' {
                if ((Test-AllConditions (Get-Prop $rule 'when') $facts) -ne $true) { break }
                foreach ($k in (AsArray (Get-Prop $rule 'facts'))) {
                    if (-not $facts.ContainsKey($k)) {
                        [void]$findings.Add((New-Finding $rule 'gap' $k $null 'stated with evidence' `
                            ("'$k' is required because the conditions of $ruleId are met") @() $facts))
                    }
                }
            }

            'allowed_values' {
                $allowed = @(AsArray (Get-Prop $rule 'allowed'))
                $fromCatalog = [string](Get-Prop $rule 'allowed_from')
                if ($fromCatalog -eq 'cpf_catalog') {
                    if (-not $Pack.Catalog.Available) {
                        [void]$findings.Add((New-Finding $rule 'not-assessed' '' $null 'CPF catalogue' `
                            ("cannot check the CPF clearlist: " + $Pack.Catalog.Reason) @() $facts))
                        break
                    }
                    $allowed = @($Pack.Catalog.Ids)
                }

                $keys = @()
                $pattern = [string](Get-Prop $rule 'fact_pattern')
                if ($pattern) { $keys = @(Get-MatchingFactKeys $pattern $facts) }
                else {
                    $single = [string](Get-Prop $rule 'fact')
                    if ($single) { $keys = @($single) }
                }

                foreach ($k in $keys) {
                    if (-not $facts.ContainsKey($k)) { continue }   # absence is a gap rule's job
                    $val = [string]$facts[$k].value
                    if ($allowed -notcontains $val) {
                        $shown = if ($allowed.Count -gt 8) { (($allowed[0..7]) -join ', ') + (", ... ({0} total)" -f $allowed.Count) } else { $allowed -join ', ' }
                        [void]$findings.Add((New-Finding $rule 'violation' $k $val $shown `
                            ("'$k' is '$val', which is not permitted") (Get-Chain $Derivation $k) $facts))
                    }
                }
            }

            'forbidden_values' {
                $k = [string](Get-Prop $rule 'fact')
                if (-not $facts.ContainsKey($k)) { break }
                $val = [string]$facts[$k].value
                $forbidden = @(AsArray (Get-Prop $rule 'forbidden'))
                if ($forbidden -contains $val) {
                    [void]$findings.Add((New-Finding $rule 'violation' $k $val ("not one of: " + ($forbidden -join ', ')) `
                        ("'$k' is '$val', which is explicitly prohibited") (Get-Chain $Derivation $k) $facts))
                }
            }

            'numeric_min' {
                $k = [string](Get-Prop $rule 'fact')
                if (-not $facts.ContainsKey($k)) { break }
                $val = [string]$facts[$k].value
                $min = [double](Get-Prop $rule 'min')
                $parsed = [double]0
                if (-not [double]::TryParse($val, [ref]$parsed)) {
                    [void]$findings.Add((New-Finding $rule 'violation' $k $val ("a number, at least $min") `
                        ("'$k' is '$val', which is not a number") (Get-Chain $Derivation $k) $facts))
                } elseif ($parsed -lt $min) {
                    [void]$findings.Add((New-Finding $rule 'violation' $k $val ("at least $min") `
                        ("'$k' is $parsed, below the required minimum of $min") (Get-Chain $Derivation $k) $facts))
                }
            }

            'implication' {
                $when = Get-Prop $rule 'when'
                $then = Get-Prop $rule 'then'
                if ((Test-Condition $when $facts) -ne $true) { break }

                $tk = [string](Get-Prop $then 'fact')
                $whenKey = [string](Get-Prop $when 'fact')
                $because = ("{0} is '{1}'" -f $whenKey, $facts[$whenKey].value)

                if ((Get-Prop $then 'must_exist') -eq $true) {
                    if (-not $facts.ContainsKey($tk)) {
                        [void]$findings.Add((New-Finding $rule 'gap' $tk $null 'stated with evidence' `
                            ("'$tk' must be stated because $because") (Get-Chain $Derivation $whenKey) $facts))
                    }
                    break
                }

                $mustBe = Get-Prop $then 'must_be'
                if ($null -ne $mustBe) {
                    if (-not $facts.ContainsKey($tk)) { break }   # derivation supplied it
                    $f = $facts[$tk]
                    if ($f.origin -eq 'derived') { break }        # derived to the same value by construction
                    if ([string]$f.value -ne [string]$mustBe) {
                        [void]$findings.Add((New-Finding $rule 'violation' $tk ([string]$f.value) ([string]$mustBe) `
                            ("'$tk' is '$($f.value)' but must be '$mustBe' because $because") (Get-Chain $Derivation $whenKey) $facts))
                    }
                    break
                }

                $mustBeIn = Get-Prop $then 'must_be_in'
                if ($null -ne $mustBeIn) {
                    if (-not $facts.ContainsKey($tk)) { break }
                    $f = $facts[$tk]
                    $allowed = @(AsArray $mustBeIn)
                    if ($allowed -notcontains [string]$f.value) {
                        # The chain is the interesting part here. It is the difference
                        # between "wrong value" and "this design contradicts itself".
                        $chain = @(Get-Chain $Derivation $whenKey) + @(Get-Chain $Derivation $tk)
                        [void]$findings.Add((New-Finding $rule 'violation' $tk ([string]$f.value) ($allowed -join ' or ') `
                            ("'$tk' is '$($f.value)' but must be one of [$($allowed -join ', ')] because $because") $chain $facts))
                    }
                }
            }

            'conditional_prohibition' {
                if ((Test-AllConditions (Get-Prop $rule 'when') $facts) -ne $true) { break }
                $forbid = Get-Prop $rule 'forbid'
                $k = [string](Get-Prop $forbid 'fact')
                if (-not $facts.ContainsKey($k)) { break }
                $val = [string]$facts[$k].value
                $needles = Get-Prop $forbid 'matching'
                if ($null -eq $needles) { $needles = Get-Prop $forbid 'values' }
                if (Test-Match $val $needles) {
                    $why = New-Object System.Collections.ArrayList
                    foreach ($c in (AsArray (Get-Prop $rule 'when'))) {
                        $ck = [string](Get-Prop $c 'fact')
                        if ($facts.ContainsKey($ck)) { [void]$why.Add(("{0}='{1}'" -f $ck, $facts[$ck].value)) }
                    }
                    [void]$findings.Add((New-Finding $rule 'violation' $k $val ("not matching: " + (@(AsArray $needles) -join ', ')) `
                        ("'$k' is '$val', prohibited when " + ($why -join ' and ')) (Get-Chain $Derivation $k) $facts))
                }
            }

            'requires_n_of' {
                if ((Test-AllConditions (Get-Prop $rule 'when') $facts) -ne $true) { break }
                $need = [int](Get-Prop $rule 'n')
                $candidates = @(AsArray (Get-Prop $rule 'facts'))
                $present = @($candidates | Where-Object { $facts.ContainsKey($_) })
                if ($present.Count -lt $need) {
                    $missing = @($candidates | Where-Object { -not $facts.ContainsKey($_) })
                    [void]$findings.Add((New-Finding $rule 'gap' '' ("$($present.Count) of $need") "$need of [$($candidates -join ', ')]" `
                        ("only $($present.Count) of the required $need evidence facts are stated; missing: " + ($missing -join ', ')) @() $facts))
                }
            }

            'cpf_coverage' {
                if (-not $Pack.Catalog.Available) { break }
                $pattern = [string](Get-Prop $rule 'fact_pattern')
                foreach ($k in (Get-MatchingFactKeys $pattern $facts)) {
                    $val = [string]$facts[$k].value
                    if ($Pack.Catalog.Ids -notcontains $val) {
                        [void]$findings.Add((New-Finding $rule 'action-required' $k $val 'a CPF module id' `
                            ("'$val' has no CPF module. " + [string](Get-Prop $rule 'action_when_missing')) @() $facts))
                    }
                }
            }

            default {
                Fail "rule '$ruleId' has unknown kind '$kind'" 4
            }
        }
    }

    # Derivation collisions are not attributable to one rule, so they are added here
    # rather than inside the loop.
    foreach ($c in $Derivation.Collisions) {
        [void]$findings.Add([ordered]@{
                id                 = (New-FindingId ("$($c.rule_a)+$($c.rule_b)") $c.fact_key 'inconsistency')
                rule_id            = "$($c.rule_a) + $($c.rule_b)"
                kind               = 'inconsistency'
                severity           = 'mandatory'
                fact_key           = $c.fact_key
                actual             = "$($c.rule_a) requires '$($c.value_a)'"
                expected           = "$($c.rule_b) requires '$($c.value_b)'"
                message            = ("the spec forces '{0}' to be both '{1}' and '{2}' - these cannot both hold" -f $c.fact_key, $c.value_a, $c.value_b)
                statement_ids      = @()
                derivation         = @($c.chain)
                source             = 'derived'
                quote              = ''
                requires_exception = ''
                llm_role           = ''
                excepted           = $false
                exception          = $null
            })
    }

    return $findings.ToArray()
}

function Set-Exceptions($Findings, $Exceptions) {
    foreach ($f in $Findings) {
        if (-not $Exceptions.ContainsKey($f.rule_id)) { continue }
        $ex = $Exceptions[$f.rule_id]
        $f.exception = $ex
        if (-not $ex.expired) {
            $f.excepted = $true
        } else {
            $f.message = $f.message + " (exception granted $($ex.granted) expired on $($ex.expires))"
        }
    }
}

# --------------------------------------------------------------------------- #
# Reporting
# --------------------------------------------------------------------------- #

function Get-Tally($Findings) {
    $live = @($Findings | Where-Object { -not $_.excepted })
    return [ordered]@{
        total            = @($Findings).Count
        excepted         = @($Findings | Where-Object { $_.excepted }).Count
        violations       = @($live | Where-Object { $_.severity -eq 'mandatory' -and $_.kind -eq 'violation' }).Count
        inconsistencies  = @($live | Where-Object { $_.kind -eq 'inconsistency' }).Count
        gaps             = @($live | Where-Object { $_.severity -eq 'mandatory' -and $_.kind -eq 'gap' }).Count
        advisories       = @($live | Where-Object { $_.severity -eq 'advisory' }).Count
        action_required  = @($live | Where-Object { $_.kind -eq 'action-required' }).Count
        not_assessed     = @($live | Where-Object { $_.kind -eq 'not-assessed' }).Count
    }
}

function Write-ReportMarkdown($Paths, $Pack, $Findings, $Tally, $Derivation) {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('# Constitution compliance report')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('Generated by Check-Standards.ps1. Do not edit - it is overwritten on every check.')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine(("- Pack: {0} v{1}" -f (Get-Prop $Pack.Meta 'pack_id'), (Get-Prop $Pack.Meta 'pack_version')))
    [void]$sb.AppendLine(("- Constitution: v{0}" -f (Get-Prop $Pack.Meta 'constitution_version')))
    [void]$sb.AppendLine(("- Rules evaluated: {0}" -f $Pack.Rules.Count))
    [void]$sb.AppendLine(("- CPF clearlist: {0}" -f $Pack.Catalog.Reason))
    [void]$sb.AppendLine(("- Checked at: {0}" -f (Now)))
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('## Summary')
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('| Finding | Count |')
    [void]$sb.AppendLine('|---|---|')
    foreach ($k in $Tally.Keys) { [void]$sb.AppendLine(("| {0} | {1} |" -f $k, $Tally[$k])) }
    [void]$sb.AppendLine('')

    $order = @('inconsistency', 'violation', 'gap', 'action-required', 'not-assessed')
    foreach ($kind in $order) {
        $group = @($Findings | Where-Object { $_.kind -eq $kind -and -not $_.excepted -and $_.severity -ne 'advisory' })
        if ($group.Count -eq 0) { continue }
        [void]$sb.AppendLine(("## {0} ({1})" -f $kind, $group.Count))
        [void]$sb.AppendLine('')
        foreach ($f in $group) {
            [void]$sb.AppendLine(("### {0} - {1}" -f $f.rule_id, $f.fact_key))
            [void]$sb.AppendLine('')
            [void]$sb.AppendLine(("{0}" -f $f.message))
            [void]$sb.AppendLine('')
            if ($f.actual) { [void]$sb.AppendLine(("- Actual: {0}" -f $f.actual)) }
            if ($f.expected) { [void]$sb.AppendLine(("- Expected: {0}" -f $f.expected)) }
            if ($f.statement_ids -and @($f.statement_ids).Count -gt 0) {
                [void]$sb.AppendLine(("- Statement: {0}" -f (@($f.statement_ids) -join ', ')))
            }
            if ($f.source) { [void]$sb.AppendLine(("- Source: {0}" -f $f.source)) }
            if ($f.quote) { [void]$sb.AppendLine(("- Constitution says: ""{0}""" -f $f.quote)) }
            if ($f.requires_exception) { [void]$sb.AppendLine(("- Clearable only by: {0} exception" -f $f.requires_exception)) }
            if ($f.llm_role -eq 'judgement') { [void]$sb.AppendLine('- This rule requires human judgement. The engine has only checked that the evidence exists.') }
            if (@($f.derivation).Count -gt 0) {
                [void]$sb.AppendLine('- How this was reached:')
                foreach ($step in @($f.derivation)) { [void]$sb.AppendLine(("    - {0}" -f $step)) }
            }
            [void]$sb.AppendLine('')
        }
    }

    $adv = @($Findings | Where-Object { $_.severity -eq 'advisory' -and -not $_.excepted })
    if ($adv.Count -gt 0) {
        [void]$sb.AppendLine(("## advisory ({0})" -f $adv.Count))
        [void]$sb.AppendLine('')
        [void]$sb.AppendLine('Advisories never block. They are recorded so a reviewer can decide.')
        [void]$sb.AppendLine('')
        foreach ($f in $adv) { [void]$sb.AppendLine(("- **{0}** {1}" -f $f.rule_id, $f.message)) }
        [void]$sb.AppendLine('')
    }

    $exc = @($Findings | Where-Object { $_.excepted })
    if ($exc.Count -gt 0) {
        [void]$sb.AppendLine(("## cleared by exception ({0})" -f $exc.Count))
        [void]$sb.AppendLine('')
        foreach ($f in $exc) {
            [void]$sb.AppendLine(("- **{0}** {1}" -f $f.rule_id, $f.message))
            [void]$sb.AppendLine(("    - approved by {0}, expires {1}" -f $f.exception.approver, $f.exception.expires))
        }
        [void]$sb.AppendLine('')
    }

    $derivedKeys = @($Derivation.Facts.Keys | Where-Object { $Derivation.Facts[$_].origin -eq 'derived' } | Sort-Object)
    if ($derivedKeys.Count -gt 0) {
        [void]$sb.AppendLine(("## facts the constitution implies but nobody stated ({0})" -f $derivedKeys.Count))
        [void]$sb.AppendLine('')
        [void]$sb.AppendLine('These were not in the spec. The rules force them. Each one should be stated explicitly and reviewed.')
        [void]$sb.AppendLine('')
        foreach ($k in $derivedKeys) {
            [void]$sb.AppendLine(("- **{0}** = {1}  (via {2})" -f $k, $Derivation.Facts[$k].value, $Derivation.DerivedBy[$k]))
        }
        [void]$sb.AppendLine('')
    }

    Write-TextFile $Paths.ReportMd $sb.ToString()
}

# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #

function Invoke-Check($Paths, $Pack) {
    $asserted = Get-AssertedFacts $Paths
    $derivation = Build-Derivation $Pack.Rules $asserted
    $findings = @(Invoke-RuleEvaluation $Pack $asserted $derivation)
    $exceptions = Get-Exceptions $Paths
    Set-Exceptions $findings $exceptions
    $tally = Get-Tally $findings

    $report = [ordered]@{
        version              = $script:PACK_VERSION
        generated_at         = (Now)
        pack_id              = [string](Get-Prop $Pack.Meta 'pack_id')
        pack_version         = [string](Get-Prop $Pack.Meta 'pack_version')
        constitution_version = [string](Get-Prop $Pack.Meta 'constitution_version')
        rules_evaluated      = $Pack.Rules.Count
        cpf_clearlist        = $Pack.Catalog.Reason
        facts_stated         = $asserted.Count
        facts_derived        = @($derivation.Facts.Keys | Where-Object { $derivation.Facts[$_].origin -eq 'derived' }).Count
        tally                = $tally
        findings             = $findings
    }
    Write-JsonFile $Paths.Report $report

    # The gate file. Spec.ps1 resolve reads this and nothing else, so a consumer that
    # already calls resolve inherits constitution enforcement without changing a line.
    $blocking = @($findings | Where-Object {
            -not $_.excepted -and $_.severity -eq 'mandatory' -and
            @('violation', 'inconsistency', 'gap') -contains $_.kind
        })
    Write-JsonFile $Paths.Violations ([ordered]@{
            version      = $script:PACK_VERSION
            generated_at = (Now)
            pack_id      = [string](Get-Prop $Pack.Meta 'pack_id')
            blocking     = $blocking.Count
            violations   = $blocking
        })

    Write-ReportMarkdown $Paths $Pack $findings $tally $derivation

    if ($Format -eq 'json') {
        Write-Output ($report | ConvertTo-Json -Depth 40)
    } else {
        Write-Output ("constitution v{0}  {1} rule(s)  {2} fact(s) stated, {3} derived" -f `
                $report.constitution_version, $Pack.Rules.Count, $asserted.Count, $report.facts_derived)
        Write-Output ("CPF clearlist: {0}" -f $Pack.Catalog.Reason)
        Write-Output ''
        foreach ($k in $tally.Keys) { Write-Output ("  {0,-16} {1}" -f $k, $tally[$k]) }
        Write-Output ''
        foreach ($f in ($findings | Where-Object { -not $_.excepted -and $_.severity -ne 'advisory' })) {
            Write-Output ("  [{0}] {1}  {2}" -f $f.kind.ToUpperInvariant(), $f.rule_id, $f.message)
            foreach ($step in @($f.derivation)) { Write-Output ("        {0}" -f $step) }
        }
        Write-Output ''
        Write-Output ("report: {0}" -f $Paths.ReportMd)
    }

    # Violations and contradictions are firmer failures than absence, so they win.
    if ($tally.violations -gt 0 -or $tally.inconsistencies -gt 0) { $script:ExitCode = 3; return }
    if ($tally.gaps -gt 0) { $script:ExitCode = 2; return }
    if ($StrictAdvisory -and $tally.advisories -gt 0) { $script:ExitCode = 3; return }
    $script:ExitCode = 0
}

# The answer to "what exactly are you sending to the LLM?". Not the constitution, and
# not the whole document. A computed list of the specific facts the rules need and the
# spec does not have. The agent hunts for those and nothing else.
function Invoke-Required($Paths, $Pack) {
    $asserted = Get-AssertedFacts $Paths
    $derivation = Build-Derivation $Pack.Rules $asserted
    $findings = @(Invoke-RuleEvaluation $Pack $asserted $derivation)

    $wanted = [ordered]@{}
    foreach ($f in $findings) {
        if ($f.kind -ne 'gap') { continue }
        if (-not $f.fact_key) { continue }
        if ($wanted.Contains($f.fact_key)) { continue }
        $wanted[$f.fact_key] = [ordered]@{
            fact_key = $f.fact_key
            required_by = $f.rule_id
            severity = $f.severity
            why = $f.message
            constitution = $f.quote
        }
    }

    # requires_n_of names its candidates in the message rather than in fact_key.
    foreach ($f in $findings) {
        if ($f.kind -ne 'gap' -or $f.fact_key) { continue }
        foreach ($rule in $Pack.Rules) {
            if ((Get-Prop $rule 'id') -ne $f.rule_id) { continue }
            foreach ($k in (AsArray (Get-Prop $rule 'facts'))) {
                if ($derivation.Facts.ContainsKey($k)) { continue }
                if ($wanted.Contains($k)) { continue }
                $wanted[$k] = [ordered]@{
                    fact_key = $k; required_by = $f.rule_id; severity = $f.severity
                    why = $f.message; constitution = $f.quote
                }
            }
        }
    }

    $list = @($wanted.Keys | ForEach-Object { $wanted[$_] })
    if ($Format -eq 'json') {
        Write-Output ([ordered]@{
                generated_at = (Now); count = $list.Count; required = $list
            } | ConvertTo-Json -Depth 20)
    } else {
        Write-Output ("{0} fact(s) required by the constitution and not yet stated:" -f $list.Count)
        foreach ($w in $list) { Write-Output ("  {0,-38} {1}  [{2}]" -f $w.fact_key, $w.required_by, $w.severity) }
    }
    $script:ExitCode = 0
}

# Blast radius. "If I change this fact, what else stops being true?"
function Invoke-Explain($Paths, $Pack) {
    if (-not $FactKey) { Fail '-FactKey is required for explain' 4 }
    $asserted = Get-AssertedFacts $Paths
    $derivation = Build-Derivation $Pack.Rules $asserted

    $downstream = New-Object System.Collections.ArrayList
    $frontier = @($FactKey)
    $seen = @{ $FactKey = $true }
    for ($i = 0; $i -lt $script:MAX_DERIVATION_PASSES; $i++) {
        $next = New-Object System.Collections.ArrayList
        foreach ($rule in $Pack.Rules) {
            if ((Get-Prop $rule 'kind') -ne 'implication') { continue }
            $when = Get-Prop $rule 'when'
            $then = Get-Prop $rule 'then'
            $wk = [string](Get-Prop $when 'fact')
            if ($frontier -notcontains $wk) { continue }
            $tk = [string](Get-Prop $then 'fact')
            [void]$downstream.Add([ordered]@{ via = [string](Get-Prop $rule 'id'); from = $wk; affects = $tk })
            if (-not $seen.ContainsKey($tk)) { $seen[$tk] = $true; [void]$next.Add($tk) }
        }
        if ($next.Count -eq 0) { break }
        $frontier = $next.ToArray()
    }

    $payload = [ordered]@{
        fact_key   = $FactKey
        stated     = $asserted.ContainsKey($FactKey)
        value      = if ($derivation.Facts.ContainsKey($FactKey)) { $derivation.Facts[$FactKey].value } else { $null }
        origin     = if ($derivation.Facts.ContainsKey($FactKey)) { $derivation.Facts[$FactKey].origin } else { 'absent' }
        chain      = (Get-Chain $derivation $FactKey)
        blast_radius = $downstream.ToArray()
    }

    if ($Format -eq 'json') {
        Write-Output ($payload | ConvertTo-Json -Depth 20)
    } else {
        Write-Output ("{0} = {1}  [{2}]" -f $FactKey, $payload.value, $payload.origin)
        if (@($payload.chain).Count -gt 0) {
            Write-Output '  how it was reached:'
            foreach ($s in @($payload.chain)) { Write-Output ("    {0}" -f $s) }
        }
        Write-Output ("  changing it invalidates {0} downstream fact(s):" -f $downstream.Count)
        foreach ($d in $downstream) { Write-Output ("    {0} -> {1}  (via {2})" -f $d.from, $d.affects, $d.via) }
    }
    $script:ExitCode = 0
}

function Invoke-GrantException($Paths) {
    if (-not $Target) { Fail '-Target (a rule id) is required' 4 }
    if (-not $Actor) { Fail '-Actor is required - an exception without a name is not an exception' 4 }
    if (-not $Approver) { Fail '-Approver is required - the delivery team cannot except itself' 4 }
    if (-not $Rationale) { Fail '-Rationale is required' 4 }
    if (-not $Expires) { Fail '-Expires is required - an exception with no end date is a silent amendment' 4 }

    $parsed = [datetime]::MinValue
    if (-not [datetime]::TryParse($Expires, [ref]$parsed)) { Fail "-Expires '$Expires' is not a date" 4 }
    if ($parsed.Date -lt (Get-Date).ToUniversalTime().Date) { Fail "-Expires '$Expires' is in the past" 4 }

    $dir = Split-Path -Parent $Paths.Decisions
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $entry = [ordered]@{
        ts = (Now); actor = $Actor; action = 'grant-exception'; target = $Target
        approver = $Approver; rationale = $Rationale
        expires = $parsed.ToString('yyyy-MM-dd')
    }
    Add-Content -Path $Paths.Decisions -Value (($entry | ConvertTo-Json -Depth 20 -Compress)) -Encoding UTF8
    Write-Output ("exception granted for {0} by {1}, approved by {2}, expires {3}" -f $Target, $Actor, $Approver, $entry.expires)
    Write-Output 'Re-run check to confirm the finding is cleared.'
    $script:ExitCode = 0
}

# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #

$paths = Get-Paths $Root

if ($Command -eq 'grant-exception') {
    Invoke-GrantException $paths
    exit $script:ExitCode
}

$packFile = Resolve-PackPath $RulesPack $Root
if (-not $packFile) {
    Fail 'no rule pack found. Pass -RulesPack <folder containing pack.json>' 4
}
$pack = Get-Pack $packFile

switch ($Command) {
    'check' { Invoke-Check $paths $pack }
    'required' { Invoke-Required $paths $pack }
    'explain' { Invoke-Explain $paths $pack }
}

exit $script:ExitCode
