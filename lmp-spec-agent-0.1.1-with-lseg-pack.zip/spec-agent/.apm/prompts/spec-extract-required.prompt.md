---
mode: agent
description: "Hunt the source documents for the specific facts the constitution requires and the spec is missing. Rule-guided extraction: the checker decides what to look for, the model only finds it."
---

# /spec-extract-required

Skill: [constitution-check](../skills/constitution-check/SKILL.md) |
Agent: [spec-builder](../agents/spec-builder.agent.md)

## What this is

This is the answer to "what exactly are you sending to the model?".

Not the constitution. Not the whole SAD. A **computed list** of specific facts that the
rules need and the spec does not have. You go and find those, with quotes, and nothing
else.

The direction matters. Untargeted extraction reads a document and produces whatever it
noticed - which is unreproducible and impossible to review. Rule-guided extraction
starts from a deterministic list of questions, so two runs ask the same questions and a
reviewer can check the answers one at a time.

## Steps

1. **Get the list. Do not write it yourself.**

   ```
   Check-Standards.ps1 -Root <root> -RulesPack <pack> -Command required -Format json
   ```

   Each entry gives you `fact_key`, the `required_by` rule, and the `constitution`
   sentence that demands it. That sentence is your search brief.

2. **For each required fact, search the registered sources for evidence of it.**

   Work one fact at a time. For each one, you are looking for a sentence, a table cell,
   a diagram label, or a config value that *states* the fact. Not one that implies it.

3. **Record what you find, with its evidence:**

   ```
   Spec.ps1 -Root <root> -Command add-statement `
       -FactKey <key> -Value <value> `
       -SourceId <src-id> -Locator <where> -Quote "<the exact sentence>" `
       -Method <method>
   ```

   Pick `-Method` honestly. It sets the tier, and the tier is what a reviewer uses to
   decide how hard to look:

   | You found | Method |
   |---|---|
   | a sentence that says it outright | `explicit-statement` |
   | a cell in a table | `table-cell` |
   | a label on a diagram | `diagram-label` |
   | a value in a config file | `config-value` |
   | it follows from document structure | `structure-derived` |
   | two documents cross-reference to it | `cross-reference` |
   | you worked it out | `inferred` |
   | you mostly worked it out | `weak-inference` |

   There is no method for "it seemed likely". If you would have to pick `guess`, do not
   add the statement at all - go to step 4.

4. **Report what you could not find. This is the valuable half of the output.**

   A fact the documents genuinely do not contain is a real result. It means the SAD is
   incomplete, and that is exactly what the check was for. List them plainly:

   ```
   Not found in any source:
     rollback.data_divergence   (LMP-MIG-RB-1) - no source document describes how
                                target-side writes are reconciled after a failed cutover
   ```

   Then stop and hand back. Do **not**:

   - fill a gap with an industry default
   - fill a gap with what the other twelve applications did
   - fill a gap with what the constitution says it *should* be

   That last one is the tempting one and the worst one. Writing the required value back
   in as a fact makes the check pass and means nothing - you would be marking your own
   homework, and the resulting spec would assert something no document supports.

5. **Rebuild and re-check:**

   ```
   Spec.ps1 -Root <root> -Command build
   Check-Standards.ps1 -Root <root> -RulesPack <pack> -Command check
   ```

   The list should be shorter. If a new gap appeared, that is derivation working: a fact
   you just added has triggered a rule that needs another one. Repeat from step 1.

## Where a human assertion is allowed

If the user tells you a fact directly - "the tier is 2, it is in ServiceNow, not the
SAD" - record it with `-Method human-assertion` and quote them, naming them in the
locator. That is tier A and legitimate. A person taking responsibility for a fact is
evidence. You inferring the same fact is not.

## Semantic relationships

Some facts are only stated across two places: a diagram shows a queue between two
services, and prose three pages later says the queue is regional. Neither alone states
`nfr.rpo`.

When you join evidence like this:

- use `-Method inferred` (tier C - it will be flagged for review, correctly)
- quote **both** endpoints in the `-Quote`, so the reviewer can check the join
- say in your summary that it was a join, and which two places

Never present a joined fact as `explicit-statement`. The join is the part most likely to
be wrong, and hiding it is how a plausible mistake reaches production.

## What to hand back

```
Required: <n>   Found: <n>   Not found: <n>
Found:
  <fact_key> = <value>   [<method>, tier <x>]   <source>:<locator>
Not found:
  <fact_key>   (<rule id>) - <what you looked for and where>
Joined from multiple places (needs review):
  <fact_key> - <the two sources>
```
