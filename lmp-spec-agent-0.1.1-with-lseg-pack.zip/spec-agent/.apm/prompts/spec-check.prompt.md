---
mode: agent
description: "Check the spec against the organisation's encoded standards, explain every finding in the constitution's own words, and never adjudicate compliance by judgement."
---

# /spec-check

Skill: [constitution-check](../skills/constitution-check/SKILL.md) |
Spec layer: [spec-layer](../skills/spec-layer/SKILL.md)

Checks a built spec against a rule pack. The engine decides compliance; you explain it.

## The one rule

**You never decide whether something is compliant.** `Check-Standards.ps1` does that,
deterministically, from encoded rules. Your job is to run it, read what it found, and
explain it in the constitution's own words.

If you find yourself reasoning "this is probably fine because...", stop. That reasoning
is not reproducible, is not auditable, and will not survive an audit six months from now
when the person who wrote the SAD has left.

## Steps

1. **The spec must be built first.** The checker reads the canonical spec, not the
   source documents.

   ```
   Spec.ps1 -Root <root> -Command build
   ```

2. **Run the check:**

   ```
   Check-Standards.ps1 -Root <root> -RulesPack <pack> -Command check
   ```

   | Exit | Meaning | What to say |
   |---|---|---|
   | 0 | compliant | Nothing mandatory is broken. Advisories may still be listed. |
   | 2 | cannot assess | Facts the rules need are missing. The design is not yet checkable. Go to step 4. |
   | 3 | violation or contradiction | Something is broken. Go to step 3. |
   | 4 | no pack, no store, bad argument | A setup problem, not a design problem. Say which. |

   Exit 2 is not a pass. Say "this cannot be assessed yet", never "no problems found".

3. **For each finding, report four things and nothing else:**

   - the rule id and what the fact actually is
   - what the constitution requires instead
   - the quoted sentence from the constitution (the finding carries it)
   - the statement id the fact came from, so the user can go and read the evidence

   **If the finding has a `derivation` chain, show it.** That chain is the whole point.
   A finding like:

   ```
   app.tier = 1 (stated, stmt-e1fe5d37)
   app.tier -> LMP-MIG-CUT-2 requires migration.cutover_pattern = cdc
   migration.r_type = Replatform (stated, stmt-a42fa727)
   ```

   is saying something a reviewer could not have seen: nobody wrote down a cutover
   pattern, the rules forced one, and the forced value contradicts the stated treatment.
   Explain it in that order - what was stated, what it forced, where it collided.

4. **When facts are missing, do not guess them.** Get the list:

   ```
   Check-Standards.ps1 -Root <root> -RulesPack <pack> -Command required -Format json
   ```

   Then run [`/spec-extract-required`](spec-extract-required.prompt.md). That prompt
   hunts for those specific facts in the source documents. It does not invent them.

5. **Before proposing a change to any fact, check what else it moves:**

   ```
   Check-Standards.ps1 -Root <root> -Command explain -FactKey app.tier
   ```

   Changing a tier is not a one-line edit. It can invalidate a dozen downstream facts.
   Say how many before the user changes it.

## Judgement rules

Some rules carry `llm_role: judgement`. The Container Adoption Rule is one: the
constitution asks for a business case "evidenced in at least two of" three dimensions.

The engine has checked that the three facts exist. It has **not** judged whether the
case is any good, and neither should you. Present the evidence and say plainly that
this one needs a human decision.

## Exceptions

A mandatory finding cannot be approved away. If it is a genuine, accepted deviation, it
needs a recorded exception:

```
Check-Standards.ps1 -Root <root> -Command grant-exception -Target <rule-id> `
    -Actor <who> -Approver <governance body> -Rationale <why> -Expires <date>
```

**Never run this on the user's behalf without being asked to.** An exception is a
governance act, not a build step. Requirements:

- the approver must be someone other than the delivery team
- the expiry is mandatory, and an expired exception re-opens the finding on the next
  check - which is the intended behaviour, not a bug to work around

If a user asks you to "just make the check pass", offer the two honest options: fix the
design, or record an exception with a named approver. Do not offer `-SkipStandards` as a
third - that flag exists for pipeline debugging, and it is recorded in the resolve
payload precisely so that a bypass cannot be mistaken for a pass.

## What to hand back

A short summary in this shape:

```
<n> mandatory finding(s), <n> gap(s), <n> advisory.
Blocking: <rule ids>
The one that matters: <the finding with the longest derivation chain, explained>
Next: <fix the design | find these facts | this needs a governance decision>
```

Full report: `out/review/constitution-report.md`.
