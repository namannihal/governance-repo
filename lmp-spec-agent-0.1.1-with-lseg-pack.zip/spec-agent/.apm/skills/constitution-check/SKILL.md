# Skill: constitution-check

The constraint layer. Turns an organisation's written standards into rules that can be
evaluated, and refuses to hand a non-compliant spec to a build agent.

## Why this exists

The spec layer answers "what does this system do, and who says so". It does not answer
"is that allowed here". Those are different questions and they fail in different ways.

A spec can be perfectly evidenced, fully approved, every fact traced to a quoted
sentence in a real document - and still describe something the organisation forbids.
Approval is not compliance. A delivery team approving its own design against a standard
it has not read is the failure mode this layer exists to remove.

## The four rule shapes

Every clause in a constitution reduces to one of four things. If a clause does not fit,
it is usually two clauses.

| Kind | Shape | Example |
|---|---|---|
| `requires_fact` | these facts must exist | RTO and RPO must be defined per application |
| `allowed_values` / `forbidden_values` | this fact must be in this set | only approved regions |
| `implication` | if X then Y must be Z | Tier 1 must be multi-region |
| `conditional_prohibition` | if X and Y then Z must not match | containers under Replatform |

Plus three supporting kinds: `conditional_requires_fact`, `requires_n_of` (for "evidenced
in at least two of..."), and `numeric_min`.

Every rule carries `source` (where in the constitution) and `quote` (the sentence
itself). A finding that cannot quote the rule it broke is not a finding, it is an
opinion. The test suite enforces this: no rule ships without provenance.

## Derivation is the point

`implication` rules chain, and that is where the value is.

```
app.tier = 1
  -> LMP-RES-MR-1  requires deploy.multi_region = true
  -> LMP-RES-RP-5  requires deploy.recovery_pattern to be stated
  -> LMP-RES-DATA-1 requires nfr.rpo to be stated

app.tier = 1
  -> LMP-MIG-CUT-2 requires migration.cutover_pattern = cdc
  -> LMP-MIG-CUT-3 requires migration.r_type in [Refactor, Rearchitect]
```

Now a SAD says Tier 1 and Replatform, and never mentions a cutover pattern at all.
Every rule read on its own is satisfied. The design is still impossible: Tier 1 forces
near-zero RPO, near-zero RPO forces CDC, and CDC is out of Replatform scope because it
requires application-side awareness of replay semantics.

No reviewer holds three tables in their head at once. The chain does.

This also gives blast radius for free. Changing a tier from 2 to 1 is not a one-line
edit - `-Command explain -FactKey app.tier` will say how many downstream facts it moves
before anyone changes it.

## Absence is never compliance

A rule that needs a fact nobody wrote down produces a **gap**, and the run exits 2 -
"cannot assess" - not 0. This is deliberate and it is the most common way a compliance
check lies: the fact is missing, no rule fires, the report is green.

Exit 2 means the design is not yet checkable. It is never a pass.

## Where the model is allowed to operate

Three places, all of them bounded:

1. **Rule-guided extraction.** The checker computes which facts are missing; the agent
   hunts for those specific facts and quotes them. The list of questions is
   deterministic. Only the finding is probabilistic. See
   [`/spec-extract-required`](../../prompts/spec-extract-required.prompt.md).

2. **Semantic relationships in the application's own documents.** A diagram plus a
   sentence three pages later can jointly state a fact that neither states alone. That
   is legitimate, it is tier C `inferred`, and it must quote both endpoints.

3. **Judgement rules.** Where the constitution asks for a judgement - "the business case
   MUST be evidenced in at least two of..." - the engine verifies the evidence exists
   and stops. A human decides whether the case is good.

The model never decides compliance. Not once. That boundary is what makes the output
defensible when someone asks six months later why a design was allowed through.

## Severity, and why advisories must not block

`MUST` becomes `mandatory`. `SHOULD` becomes `advisory`.

Advisories are reported and never affect the exit code. This is not leniency - it is
the only way to keep the distinction alive. The moment SHOULD blocks a pipeline, authors
stop writing SHOULD, and the constitution loses its ability to express a preference.

`-StrictAdvisory` exists for teams who want to opt in. It is off by default.

## Exceptions, not approvals

A mandatory violation cannot be cleared by approving it. Approval is the delivery team's
signal; the constitution is not theirs to waive. It is cleared by a recorded exception
that must name:

- an actor
- an **approver** who is not the delivery team
- a rationale
- an **expiry**

The expiry is not optional. An exception with no end date is a silent amendment to the
constitution, made by whoever was on the ticket that day. Expired exceptions re-open the
finding on the next check - which is the feature, not a bug.

## Content lives in a pack, not in the code

The engine ships in `spec-agent`. The rules ship in a separate pack
(`lseg-constitution-pack`). Amending a constitution is then a data change with a diff,
not a code change with a release.

The pack binds live to source-of-truth catalogues where one exists. The CPF clearlist is
read from `cpf-schemas/_catalog.json` at check time rather than copied into the pack, so
the approved-module list cannot drift from the 226 modules that actually exist. A missing
catalogue degrades those rules to `not-assessed` rather than silently passing them.

## Integration

`Check-Standards.ps1` writes `out/compliance/violations.json`. `Spec.ps1 resolve` reads
it and exits 3 if anything unexcepted and mandatory remains.

**Consumers need no change.** A build agent that already calls `resolve` and honours
exit 3 inherits constitution enforcement without a line of new code.

A violation blocks every view, not only the one the fact routed to. A Tier 1 application
with a Replatform treatment is not broken in the devops view and fine in the development
view. It is broken.

## Commands

| Command | Purpose | Exits |
|---|---|---|
| `check` | evaluate, write findings and report | 0 compliant, 2 gaps, 3 violation, 4 setup |
| `required` | the facts the rules need and the spec lacks | 0 |
| `explain -FactKey <k>` | derivation chain and blast radius | 0 |
| `grant-exception` | record a time-boxed exception | 0, 4 if incomplete |

## Known limits

- The region-to-network-segment matrix is not machine-readable. Region readiness is
  checked; segment eligibility is not.
- MEC controls and SCF tiers are a pre-production evidence gate with their own
  artefacts, not design-time facts. Out of scope by design.
- The engine checks that a CPF module id exists in the catalogue. It does not check that
  the module was configured correctly - that is the IaC agent's job, downstream.
