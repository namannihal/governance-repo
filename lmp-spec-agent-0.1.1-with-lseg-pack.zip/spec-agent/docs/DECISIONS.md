# Decisions

Design and operating decisions for the spec layer and its constraint layer, recorded as
they were taken. Rule-pack decisions live separately in `lseg-constitution-pack/pack.json`
under `decisions`, because they travel with the pack rather than with this package.

Each entry says what was decided, what was rejected, and what would make us revisit it.
An entry with no rejected alternatives is usually a decision nobody actually made.

---

## DEC-001 — The CPF clearlist is read live, never vendored

**Decided 2026-08-28.** Full record: `lseg-constitution-pack/pack.json` -> `decisions` -> `PACK-DEC-001`.

Rules using `allowed_from: cpf_catalog` resolve the module list at check time from
`-CpfCatalog`, then `$env:LMP_CPF_CATALOG`, then the path in `pack.json`.

**Why, in one line:** the snapshot in this repo held 226 modules; the customer's live
catalogue held 283. A vendored list would have been 57 modules stale on arrival, and a
clearlist that reports approved modules as forbidden trains reviewers to ignore it.

**Known weakness:** an unreachable catalogue degrades to `not-assessed` and does not
block. Proposed fix `-RequireCatalog` is not built.

---

## DEC-002 — `out/` is committed to source control

**Decided 2026-08-28.**

Everything the spec layer writes under `<root>/out/` goes into the repository. It is not
git-ignored as build output.

**Why.** Two of those files are not regenerable at all:

- `out/statements.json` — the claim store. Rebuilding it means re-reading every source
  document and re-deciding every extraction, which will not reproduce the same result.
- `out/decisions/decision-log.jsonl` — append-only. Every approval, rejection, voided
  approval and granted exception. This is the answer to "who allowed this, and when".

The rest (`specifications/`, `review/`, `compliance/`) *is* regenerable, and the
temptation is to ignore it. We commit it anyway, because being diffable is the point: a
merge request then shows exactly which facts moved, which findings opened or closed, and
which approvals were voided — without anyone running the tool.

**Rejected:**

- *Ignore all of `out/`* — throws away the audit trail. The decision log is the artefact
  most likely to be asked for six months later and the one nobody can reconstruct.
- *Ignore only the generated subfolders* — loses the review diff, which is where the
  value shows up in a pull request. Storage is not the constraint here.

**Revisit when:** the generated artefacts become large enough to slow the repository, at
which point ignore `review/` only and keep `compliance/`.

---

## DEC-003 — One spec workspace per application, outside the packages

**Decided 2026-08-28.**

Specs live at `<repo>/.lmp-migrate/<application>/`, not inside `spec-agent/` or the rule
pack.

**Why.** The tooling and the data it produces have different lifecycles and different
owners. `spec-agent` is versioned software that gets replaced wholesale on upgrade;
a spec is an application's evidence, and must survive that upgrade untouched. Nesting
the data inside the tool guarantees someone eventually deletes it while updating.

One folder per application, not one shared store, because approval is per application.
A shared store would make one team's unapproved fact block another team's build.

**Rejected:**

- *Inside `spec-agent/`* — destroyed by the next package upgrade.
- *One store for all applications* — couples unrelated approval gates.

---

## DEC-004 — Intake folder names are load-bearing, so one table drives both

**Decided 2026-08-28. Fixed same day.**

`register-sources` infers the source adapter from the path:

| Folder under `src/` | Adapter |
|---|---|
| `comigrate-assessment` | `comigrate` |
| `aimigrate-assessment` | `aimigrate` |
| `existing-sad` | `existing_sad` |
| anything else | `appdocs` |

Adapter is recorded against every source and is how a reviewer tells machine-generated
fact from a human's stated intent.

**The defect.** `init` created `out/` only, so the first thing a user did was invent the
`src/` folders themselves — and `existing_sad` or `existing-SAD` fell through to
`appdocs` with no warning. A load-bearing convention that nothing creates and nothing
validates is a convention that will be got wrong.

**Fixed.** `init` now creates the four folders, and both creation and adapter inference
read from a single `$script:INTAKE_ADAPTERS` table. Two lists would drift; one cannot.
`init` also prints the folder names, so the convention is visible at the moment it
matters. Test: *init creates the four intake folders with their exact names*.

**Rejected:**

- *Match folder names loosely (case-insensitive, underscore-tolerant)* — hides the typo
  instead of preventing it, and makes `existing-sad-old` match too.
- *Require an explicit `-Adapter` argument per source* — moves the judgement to whoever
  runs the command, which is the person least likely to know.

---

## DEC-005 — Paths are normalised before any prefix arithmetic

**Decided 2026-08-28**, after this bug shipped undetected.

Any code that turns an absolute path into a relative one by trimming a prefix must run
**both** sides through `[System.IO.Path]::GetFullPath()` first.

**The bug it fixes.** `register-sources` computed the relative path as
`$f.FullName.Substring((Resolve-Path $Paths.Root).Path.Length)`. `Resolve-Path`
preserves an 8.3 short root such as `C:\Users\NAMANN~1\...` while `FileInfo.FullName` is
always the long form `C:\Users\namannihal\...`. The two-character difference meant every
relative path kept a fragment of the folder name — `a7\src\existing-sad\sad.md`.

That is not cosmetic. The relative path is hashed into the source id, so the *same file
in the same repository* produced a different `src-xxxxxxxx` depending on whether the
caller happened to pass a short or a long root. Evidence ids are supposed to be stable;
that made them a function of how somebody typed a path.

**Why it went unnoticed:** every test and every demo passed a root built the same way, so
the bug was invisible until a run used `$env:TEMP` (short) against `FileInfo.FullName`
(long). Regression test now asserts the id is identical for both spellings.

**Rule going forward:** never subtract path lengths from raw strings. This is the third
instance of the same class of error in this codebase — see also the archive packaging,
where it silently mangled every entry name in a zip that otherwise looked perfect.

