# lmp-spec-agent

The specification layer, on its own. Turns documents into reviewed, approved,
machine-readable facts — and refuses to hand them to anything until a human has
signed them off.

It also carries a **constraint layer**: given a rule pack encoding your organisation's
standards, it refuses to hand over a spec that breaks them — and cannot be talked round
by approving harder.

**No dependencies.** Not on `lmp-discovery-agent`, not on `State.ps1`, not on any
particular build agent. Windows PowerShell 5.1, no modules.

## What it is for

Migration programmes run on documents nobody re-reads. A fact discovered in week one
becomes a sentence in a Word file, and by the time an IaC agent needs it, someone is
guessing. This package makes every fact carry its evidence, and makes "not approved
yet" a machine-enforced answer rather than a hope.

## The workflow

```
/spec-init             create the store and the four intake folders
/spec-ingest           documents -> statements with evidence -> canonical spec + three views
/spec-check            check the spec against your organisation's standards
/spec-extract-required go and find the specific facts those standards need
/spec-review           human sign-off, in triage order, recorded in an append-only log
/spec-status           is the gate open? which statements are blocking?
```

Then your existing agent calls:

```powershell
Spec.ps1 -Root <root> -Command resolve -View devops-spec -MinStatus approved -Format json
```

Exit **0** = proceed. Exit **3** = a human has not approved this, *or the design breaks
a standard*; write nothing.

Full contract in [docs/INTEGRATION.md](docs/INTEGRATION.md). Hand that file to whoever
owns your IaC agent — it is the only thing they need.

## Quick start

```powershell
$spec = ".\.apm\scripts\powershell\Spec.ps1"
$root = ".\.lmp-migrate\claims-api"

& $spec -Root $root -Command init
# drop documents into $root\src\{comigrate-assessment,aimigrate-assessment,existing-sad,application-docs}

& $spec -Root $root -Command register-sources     # hashes everything, records what could NOT be read
& $spec -Root $root -Command add-statement -FactKey azure.target.queue -Value servicebus-premium `
        -SourceId src-1a25e3bd -Locator "line 3" -Quote "Queue: SQS" -Method inferred
& $spec -Root $root -Command build                # canonical + 3 views + conflicts + review markdown

& $spec -Root $root -Command resolve -View devops-spec -MinStatus approved
# -> exit 3, lists what is blocking

& $spec -Root $root -Command review -Target stmt-7472c831 -Action approve -Actor n.nihal
& $spec -Root $root -Command resolve -View devops-spec -MinStatus approved
# -> exit 0, emits the payload and a plan_hash
```

## Commands

`Spec.ps1` — the spec layer:

| Command | Does | Exits |
|---|---|---|
| `init` | create the store | 0, 5 if it exists |
| `register-sources` | hash every file, record read / not-read **with a reason** | 0, 2 if nothing readable, 4 if no `src/` |
| `add-statement` | one atomic claim with source, locator, quote, method | 0, 2 on bad args, 4 on unknown source |
| `build` | dedupe, project views, detect conflicts, render Markdown | 0, 2 if no statements |
| `resolve` | **the gate** | 0, 2 empty, 3 not approved or standards violated, 4 unknown view |
| `review` | record a human decision | 0, 2 without `-Actor`, 4 unknown statement |
| `verify` | recompute bindings, void approvals whose evidence moved | 0 |
| `status` | triage counts | 0 |

`Check-Standards.ps1` — the constraint layer:

| Command | Does | Exits |
|---|---|---|
| `check` | evaluate the spec against a rule pack | 0 compliant, 2 cannot assess, 3 violation, 4 setup |
| `required` | the facts the rules need and the spec lacks | 0 |
| `explain` | derivation chain and blast radius for one fact | 0 |
| `grant-exception` | record a time-boxed exception | 0, 4 if incomplete |

## The constitution gate

Rules live in a **separate pack**, not in this package — so amending a standard is a
data change reviewed by governance, not a code change reviewed by whoever reviews
PowerShell. See [constitution-check](.apm/skills/constitution-check/SKILL.md).

```powershell
$check = ".\.apm\scripts\powershell\Check-Standards.ps1"

& $check -Root $root -RulesPack ..\lseg-constitution-pack -Command check
# -> exit 3, citing the rule id and the quoted clause it broke

& $spec -Root $root -Command resolve -View devops-spec -RequireStandards
# -> exit 3, because check wrote out/compliance/violations.json
```

Three things worth knowing:

- **Consumers need no change.** `check` writes findings, `resolve` reads them. Anything
  that already honours exit 3 already honours the constitution.
- **Absence is not compliance.** A rule needing a fact nobody stated exits **2 — cannot
  assess**, never 0.
- **Use `-RequireStandards` in pipelines.** Without it, a missing rule pack produces no
  findings, which looks exactly like passing.

Rules chain, which is the point. Tier 1 forces a CDC cutover; CDC forces Refactor or
Rearchitect; a stated Replatform then collides with a fact nobody ever wrote down. No
single rule is broken in isolation, and no reviewer holds three tables in their head.

## Why it does not hallucinate

1. **Read or refuse.** Every file is hashed and recorded as read, or not-read *with a
   reason*. A cloud placeholder or a binary wearing an `.xlsx` name is named explicitly.
2. **No evidence, no run.** Nothing readable → `exit 2`, and nothing is written.
3. **Every claim carries a receipt** — source file, locator, and the actual quote.
4. **Tier is computed, never claimed.** It comes from *how* the fact was obtained.
   Tier E always needs a human.
5. **Absence is a finding.** No RTO in any document becomes an open question, not a
   plausible number.
6. **Approval binds to the evidence.** Edit the source and `verify` voids the approval
   automatically, with reason `source-changed`.

## What is in the store

```
out/
├── sources/source-register.json         id, sha256, read or not-read, why not
├── statements.json                      the atomic claim store
├── evidence-map.json                    source -> statements, for impact analysis
├── conflicts/unresolved-conflicts.json  same fact_key, competing values
├── specifications/
│   ├── system-spec.json                 canonical, deduped by fact_key
│   ├── development-spec.json  ┐
│   ├── devops-spec.json       ├─ views: statement IDs, never copies
│   └── refactoring-spec.json  ┘
├── decisions/decision-log.jsonl         append-only, never regenerated
├── compliance/                          written by Check-Standards.ps1 only
│   ├── constitution-report.json         every finding, with its derivation chain
│   └── violations.json                  the gate file resolve reads
└── review/*.md                          generated, READ-ONLY
```

One statement store. The three specs are **views** over it, organised by audience
rather than by phase, holding statement IDs rather than duplicated text — so a fact
corrected once is corrected everywhere it appears.

Everything under `specifications/` and `review/` can be deleted and rebuilt.
`statements.json` and `decision-log.jsonl` cannot.

## Tests

```powershell
.\tests\Invoke-Tests.ps1                  # 162 checks: unit + integration + contract + standards
.\tests\Invoke-Tests.ps1 -Suite contract  # run this one in a customer environment
.\tests\Invoke-Tests.ps1 -Suite standards # the constraint layer on its own
.\tests\Invoke-StaticAnalysis.ps1
```

The **contract** suite runs `tests/mock-consumer.ps1` — a ~40-line compliant consumer —
against the gate. It proves the refusal and release behaviour without needing your real
build agent, and doubles as the shortest reference for writing one.

The **standards** suite builds its own synthetic rule packs, so it proves the engine
without depending on any organisation's content.

## Known gaps

Not built: the eight downstream artifacts (`requirements`, `nfr`, `adr`, `sad`,
`migration-plan`, `migration-backlog`, `cost-profile`, `test-plan`), artifact versioning
and supersession, and reviewer routing.

The constraint layer checks that a design conforms to encoded rules. It does not check
that what gets built matches the design — that belongs downstream, in whatever applies
the Terraform.

The agent layer (`.agent.md`, `.prompt.md`) has been written and reviewed but never
exercised in a live Copilot session — the scripts beneath it are tested, the prose is not.
