<#
.SYNOPSIS
    End-to-end demonstration of the constraint layer.

.DESCRIPTION
    Walks a realistic LSEG migration through the spec layer and the constitution check,
    and proves four things a checklist cannot do:

      Act 1  A design that looks reasonable is refused, and the refusal cites the
             constitution by clause and by sentence.
      Act 2  The engine catches a contradiction nobody wrote down: Tier 1 forces a CDC
             cutover, CDC forces Refactor or Rearchitect, and the stated Replatform
             collides with a fact that only exists because the rules derived it.
      Act 3  Fixing the design clears the findings, and the build agent is released.
      Act 4  A genuine deviation is cleared by a named, time-boxed exception - not by
             an approval, because a delivery team cannot approve its way past a MUST.

    Runs entirely in a temp directory. Writes nothing to the repository.

.EXAMPLE
    .\Invoke-Demo.ps1
#>
[CmdletBinding()]
param(
    [string]$SpecScript,
    [string]$CheckScript,
    [string]$RulesPack,
    [switch]$KeepWorkspace
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

# --------------------------------------------------------------------------- #
# Locate the pieces
# --------------------------------------------------------------------------- #

$packRoot = Split-Path -Parent $PSScriptRoot
$repoRoot = Split-Path -Parent $packRoot

if (-not $RulesPack) { $RulesPack = $packRoot }
if (-not $SpecScript) { $SpecScript = Join-Path $repoRoot 'spec-agent\.apm\scripts\powershell\Spec.ps1' }
if (-not $CheckScript) { $CheckScript = Join-Path $repoRoot 'spec-agent\.apm\scripts\powershell\Check-Standards.ps1' }

foreach ($p in @($SpecScript, $CheckScript)) {
    if (-not (Test-Path $p)) { throw "cannot find '$p'" }
}

$ws = Join-Path $env:TEMP ('lmp-standards-demo-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path (Join-Path $ws 'src') -Force | Out-Null

function Banner([string]$Text) {
    Write-Host ''
    Write-Host ('=' * 78) -ForegroundColor DarkGray
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ('=' * 78) -ForegroundColor DarkGray
}

function Step([string]$Text) {
    Write-Host ''
    Write-Host ("-- " + $Text) -ForegroundColor Yellow
}

# Child scripts are launched as a real process rather than dot-called. Splatting an
# array into a script binds positionally, which silently put the workspace path into
# -Command on the first attempt; and `exit` inside a dot-called script is not a reliable
# way to read an exit code. A command line has neither problem.
#
# $ErrorActionPreference must be relaxed across the call. With it set to Stop, `2>&1`
# turns anything the child writes to stderr into a *terminating* error in this script -
# so the refusal we are trying to demonstrate would kill the demo instead of being
# reported by it.
function Invoke-Child([string]$Script, [string[]]$ScriptArgs) {
    $all = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $Script) + $ScriptArgs
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = & powershell.exe $all 2>&1
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $prev }
    foreach ($line in $out) { Write-Host ("   " + $line) }
    return $code
}

function Assert-Exit([int]$Actual, [int]$Expected, [string]$What) {
    if ($Actual -eq $Expected) {
        Write-Host ("   PASS  {0} -> exit {1}" -f $What, $Actual) -ForegroundColor Green
    } else {
        Write-Host ("   FAIL  {0} -> exit {1}, expected {2}" -f $What, $Actual, $Expected) -ForegroundColor Red
        $script:Failures++
    }
}

$script:Failures = 0

try {

    # ----------------------------------------------------------------------- #
    Banner 'ACT 1  A Tier 1 payments platform, replatformed to AKS'
    # ----------------------------------------------------------------------- #

    $sad = @'
# Payments Gateway - Solution Architecture Document

## Business criticality
The Payments Gateway is a Tier 1 application.

## Migration approach
Treatment: Replatform. The application currently runs on RHEL virtual machines and is
not containerised today. The target platform is Azure Kubernetes Service.

## Target region
Primary region: uksouth. Network segment 2.
'@
    Set-Content -Path (Join-Path $ws 'src\sad.md') -Value $sad -Encoding UTF8

    Step 'Initialise the spec and register the source document'
    [void](Invoke-Child $SpecScript @('-Root', $ws, '-Command', 'init'))
    [void](Invoke-Child $SpecScript @('-Root', $ws, '-Command', 'register-sources'))

    $reg = Get-Content (Join-Path $ws 'out\sources\source-register.json') -Raw | ConvertFrom-Json
    $src = @($reg.sources)[0].id
    Write-Host ("   source id: {0}" -f $src) -ForegroundColor DarkGray

    Step 'Record what the SAD actually says - every fact carries its quote'
    $facts = @(
        @{ k = 'app.tier';             v = '1';                            q = 'The Payments Gateway is a Tier 1 application.' }
        @{ k = 'migration.r_type';     v = 'Replatform';                   q = 'Treatment: Replatform.' }
        @{ k = 'source.containerized'; v = 'false';                        q = 'not containerised today' }
        @{ k = 'azure.target.compute'; v = 'cpf-azure-prdsvcpat-aks-private'; q = 'The target platform is Azure Kubernetes Service.' }
        @{ k = 'nfr.region.primary';   v = 'uksouth';                      q = 'Primary region: uksouth.' }
        @{ k = 'app.network_segment';  v = '2';                            q = 'Network segment 2.' }
    )
    foreach ($f in $facts) {
        [void](Invoke-Child $SpecScript @(
                '-Root', $ws, '-Command', 'add-statement',
                '-FactKey', $f.k, '-Value', $f.v, '-SourceId', $src,
                '-Locator', 'sad.md', '-Quote', $f.q, '-Method', 'explicit-statement'))
    }

    Step 'Build the canonical spec and the three views'
    [void](Invoke-Child $SpecScript @('-Root', $ws, '-Command', 'build'))

    # ----------------------------------------------------------------------- #
    Banner 'ACT 2  Check it against the constitution'
    # ----------------------------------------------------------------------- #

    Step 'Check-Standards: expect a refusal (exit 3)'
    $code = Invoke-Child $CheckScript @('-Root', $ws, '-RulesPack', $RulesPack, '-Command', 'check')
    Assert-Exit $code 3 'constitution check on the broken design'

    Step 'The contradiction, isolated'
    $rep = Get-Content (Join-Path $ws 'out\compliance\constitution-report.json') -Raw | ConvertFrom-Json
    $chained = @($rep.findings | Where-Object { $_.rule_id -eq 'LMP-MIG-CUT-3' })
    if ($chained.Count -gt 0) {
        Write-Host '   PASS  the derived contradiction was found' -ForegroundColor Green
        foreach ($c in $chained) {
            Write-Host ("         {0}" -f $c.message) -ForegroundColor White
            foreach ($s in @($c.derivation)) { Write-Host ("           {0}" -f $s) -ForegroundColor DarkGray }
        }
        Write-Host '         Nobody wrote a cutover pattern down. The rules derived it, and the' -ForegroundColor DarkGray
        Write-Host '         derived value is what exposes the stated treatment as wrong.' -ForegroundColor DarkGray
    } else {
        Write-Host '   FAIL  expected LMP-MIG-CUT-3 to fire' -ForegroundColor Red
        $script:Failures++
    }

    Step 'The Container Adoption Rule'
    $container = @($rep.findings | Where-Object { $_.rule_id -eq 'LMP-RT-REPLAT-1' })
    if ($container.Count -gt 0) {
        Write-Host '   PASS  containerisation under Replatform was caught' -ForegroundColor Green
        Write-Host ("         {0}" -f $container[0].message) -ForegroundColor White
        Write-Host ("         cons.md: ""{0}""" -f $container[0].quote) -ForegroundColor DarkGray
    } else {
        Write-Host '   FAIL  expected LMP-RT-REPLAT-1 to fire' -ForegroundColor Red
        $script:Failures++
    }

    Step 'What the build agent sees when it asks for the spec'
    $code = Invoke-Child $SpecScript @('-Root', $ws, '-Command', 'resolve', '-View', 'devops-spec', '-MinStatus', 'approved')
    Assert-Exit $code 3 'resolve is refused by the constitution gate'

    Step 'The facts the rules need and the SAD never stated'
    [void](Invoke-Child $CheckScript @('-Root', $ws, '-RulesPack', $RulesPack, '-Command', 'required'))
    Write-Host '   This list is the LLM instruction. Not the constitution, not the whole' -ForegroundColor DarkGray
    Write-Host '   document - a computed set of specific facts to go and find.' -ForegroundColor DarkGray

    Step 'Blast radius of the tier'
    [void](Invoke-Child $CheckScript @('-Root', $ws, '-RulesPack', $RulesPack, '-Command', 'explain', '-FactKey', 'app.tier'))

    # ----------------------------------------------------------------------- #
    Banner 'ACT 3  Fix the design'
    # ----------------------------------------------------------------------- #

    Step 'Rearchitect instead of Replatform, and state the facts the rules asked for'
    $fixes = @(
        @{ k = 'migration.r_type';                   v = 'Rearchitect' }
        @{ k = 'migration.cutover_pattern';          v = 'cdc' }
        @{ k = 'nfr.rto';                            v = '15m' }
        @{ k = 'nfr.rpo';                            v = 'near-zero' }
        @{ k = 'nfr.region.secondary';               v = 'ukwest' }
        @{ k = 'deploy.multi_region';                v = 'true' }
        @{ k = 'deploy.multi_az';                    v = 'true' }
        @{ k = 'deploy.zone_redundant';              v = 'true' }
        @{ k = 'deploy.recovery_pattern';            v = 'active-active' }
        @{ k = 'deploy.env_isolation';               v = 'true' }
        @{ k = 'migration.validation.baseline';      v = 'row counts and p99 latency captured 24h pre-cutover' }
        @{ k = 'migration.validation.post_check';    v = 'row-level checksum equivalence, zero variance required' }
        @{ k = 'migration.validation.smoke_test';    v = 'end-to-end payment authorisation suite' }
        @{ k = 'migration.validation.signoff_owner'; v = 'a.patel, Payments SRE lead' }
        @{ k = 'rollback.trigger';                   v = 'checksum variance or p99 above 400ms for 10 minutes' }
        @{ k = 'rollback.method';                    v = 'repoint DNS to the RHEL estate, replay CDC backlog' }
        @{ k = 'rollback.rto';                       v = '20m' }
        @{ k = 'rollback.data_divergence';           v = 'CDC stream reversed, target writes replayed to source' }
        @{ k = 'rollback.source_parallel';           v = 'true' }
        @{ k = 'security.resource_locks_prod';       v = 'true' }
        @{ k = 'naming.convention';                  v = 'dx1' }
        @{ k = 'business_case.governance_approval';  v = 'ADR-2291 approved by architecture governance 2026-04-02' }
    )
    foreach ($f in $fixes) {
        [void](Invoke-Child $SpecScript @(
                '-Root', $ws, '-Command', 'add-statement',
                '-FactKey', $f.k, '-Value', $f.v, '-SourceId', $src,
                '-Locator', 'sad.md#revised', '-Quote', $f.v, '-Method', 'human-assertion'))
    }

    # The original Replatform statement is still in the store. Supersede it explicitly -
    # the store is append-only, so a correction is a decision, not a deletion.
    $store = Get-Content (Join-Path $ws 'out\statements.json') -Raw | ConvertFrom-Json
    $old = @($store.statements | Where-Object { $_.fact_key -eq 'migration.r_type' -and $_.value -eq 'Replatform' })
    foreach ($o in $old) {
        [void](Invoke-Child $SpecScript @(
                '-Root', $ws, '-Command', 'review', '-Target', $o.id,
                '-Action', 'request-changes', '-Actor', 'demo-reviewer',
                '-Rationale', 'superseded: Tier 1 RPO forces CDC, which is out of Replatform scope'))
    }

    Step 'Rebuild and re-check'
    [void](Invoke-Child $SpecScript @('-Root', $ws, '-Command', 'build'))
    $code = Invoke-Child $CheckScript @('-Root', $ws, '-RulesPack', $RulesPack, '-Command', 'check')
    Write-Host ("   check exit: {0}" -f $code) -ForegroundColor DarkGray

    $rep2 = Get-Content (Join-Path $ws 'out\compliance\constitution-report.json') -Raw | ConvertFrom-Json
    Write-Host ("   findings before: {0} blocking, after: {1} blocking" -f `
        ($rep.tally.violations + $rep.tally.inconsistencies + $rep.tally.gaps), `
        ($rep2.tally.violations + $rep2.tally.inconsistencies + $rep2.tally.gaps)) -ForegroundColor White

    if ($rep2.tally.inconsistencies -eq 0 -and
        @($rep2.findings | Where-Object { $_.rule_id -eq 'LMP-MIG-CUT-3' -and -not $_.excepted }).Count -eq 0) {
        Write-Host '   PASS  the contradiction is gone' -ForegroundColor Green
    } else {
        Write-Host '   FAIL  the contradiction survived the fix' -ForegroundColor Red
        $script:Failures++
    }

    # ----------------------------------------------------------------------- #
    Banner 'ACT 4  Exceptions, not approvals'
    # ----------------------------------------------------------------------- #

    Step 'A remaining mandatory finding cannot be approved away'
    $stillBlocking = @($rep2.findings | Where-Object {
            -not $_.excepted -and $_.severity -eq 'mandatory' -and
            @('violation', 'gap', 'inconsistency') -contains $_.kind
        })
    if ($stillBlocking.Count -gt 0) {
        $pick = $stillBlocking[0]
        Write-Host ("   still blocking: {0}  {1}" -f $pick.rule_id, $pick.message) -ForegroundColor White

        Step 'An exception with no approver is refused'
        $code = Invoke-Child $CheckScript @('-Root', $ws, '-Command', 'grant-exception',
            '-Target', $pick.rule_id, '-Actor', 'demo-engineer', '-Rationale', 'because', '-Expires', '2026-12-31')
        Assert-Exit $code 4 'exception without -Approver'

        Step 'An exception with no expiry is refused'
        $code = Invoke-Child $CheckScript @('-Root', $ws, '-Command', 'grant-exception',
            '-Target', $pick.rule_id, '-Actor', 'demo-engineer', '-Approver', 'arch-gov-board', '-Rationale', 'because')
        Assert-Exit $code 4 'exception without -Expires'

        Step 'A properly recorded exception is accepted'
        $future = (Get-Date).AddMonths(3).ToString('yyyy-MM-dd')
        $code = Invoke-Child $CheckScript @('-Root', $ws, '-Command', 'grant-exception',
            '-Target', $pick.rule_id, '-Actor', 'demo-engineer', '-Approver', 'arch-gov-board',
            '-Rationale', 'Interim: CPF module gap, demand request CPF-DEMAND-0412 raised', '-Expires', $future)
        Assert-Exit $code 0 'exception with actor, approver, rationale and expiry'

        Step 'Re-check: the finding is now cleared, and the clearance is auditable'
        [void](Invoke-Child $CheckScript @('-Root', $ws, '-RulesPack', $RulesPack, '-Command', 'check'))
        $rep3 = Get-Content (Join-Path $ws 'out\compliance\constitution-report.json') -Raw | ConvertFrom-Json
        $cleared = @($rep3.findings | Where-Object { $_.rule_id -eq $pick.rule_id -and $_.excepted })
        if ($cleared.Count -gt 0) {
            Write-Host '   PASS  cleared by exception, not by approval' -ForegroundColor Green
            Write-Host ("         approved by {0}, expires {1}" -f $cleared[0].exception.approver, $cleared[0].exception.expires) -ForegroundColor DarkGray
        } else {
            Write-Host '   FAIL  the exception did not clear the finding' -ForegroundColor Red
            $script:Failures++
        }
    } else {
        Write-Host '   (nothing left blocking - skipping the exception walkthrough)' -ForegroundColor DarkGray
    }

    # ----------------------------------------------------------------------- #
    Banner 'RESULT'
    # ----------------------------------------------------------------------- #

    Write-Host ''
    Write-Host ("   report:     {0}" -f (Join-Path $ws 'out\review\constitution-report.md'))
    Write-Host ("   violations: {0}" -f (Join-Path $ws 'out\compliance\violations.json'))
    Write-Host ("   decisions:  {0}" -f (Join-Path $ws 'out\decisions\decision-log.jsonl'))
    Write-Host ''
    if ($script:Failures -eq 0) {
        Write-Host '   Demo assertions: all passed.' -ForegroundColor Green
    } else {
        Write-Host ("   Demo assertions: {0} FAILED." -f $script:Failures) -ForegroundColor Red
    }

} finally {
    if ($KeepWorkspace) {
        Write-Host ''
        Write-Host ("   workspace kept at {0}" -f $ws) -ForegroundColor DarkGray
    } else {
        Remove-Item -Path $ws -Recurse -Force -ErrorAction SilentlyContinue
    }
}

exit $script:Failures
