# LSEG LMP Constitution — machine-readable rule pack

The LSEG LMP Constitution v1.6.0, encoded as data that a check can evaluate.

This pack contains **no code**. The engine that reads it lives in
[`spec-agent`](../spec-agent/.apm/scripts/powershell/Check-Standards.ps1). Separating the
two means amending the constitution is a data change with a reviewable diff, not a code
change with a release.

## Layout

```
pack.json                        manifest, severity model, catalogue bindings, known gaps
fact-keys.json                   the controlled vocabulary (~70 keys)
rules/
  global-and-cpf.json            global constraints, CPF clearlist, IaC, BCDR
  resiliency.json                tier -> deployment model, recovery patterns, paired regions
  migration-and-rtype.json       R-Type scope, Container Adoption Rule, cutover, rollback
  pipeline-and-security.json     DevSecOps, API gateway, security, observability
demo/
  Invoke-Demo.ps1                end-to-end walkthrough, runs in TEMP, writes nothing here
```

## Running it

```powershell
# Check a built spec
.\spec-agent\.apm\scripts\powershell\Check-Standards.ps1 `
    -Root <spec-root> -RulesPack .\lseg-constitution-pack -Command check

# See the whole thing work
.\lseg-constitution-pack\demo\Invoke-Demo.ps1
```

Exit codes: `0` compliant · `2` cannot assess (required facts missing) · `3` mandatory
violation or contradiction · `4` setup problem.

## What a rule looks like

```json
{
  "id": "LMP-RT-REPLAT-1",
  "kind": "conditional_prohibition",
  "when": [
    { "fact": "migration.r_type", "equals": "Replatform" },
    { "fact": "source.containerized", "equals": "false" }
  ],
  "forbid": { "fact": "azure.target.compute", "matching": ["aks", "kubernetes", "containerapp"] },
  "severity": "mandatory",
  "requires_exception": "architecture-governance",
  "source": "cons.md#container-adoption-rule",
  "quote": "Containerisation MUST NOT be introduced as part of a Rehost or Replatform treatment unless the source application is already containerised..."
}
```

Every rule carries `source` and `quote`. A finding that cannot quote the clause it broke
is an opinion, not a finding — and the test suite fails the pack if any rule is missing
its provenance.

## Conventions worth knowing

**`azure.target.*` values are CPF module ids**, not service nicknames — for example
`cpf-azure-prdsvcpat-aks-private`, not `aks`. Naming the module is what makes clearlist
membership and CPF coverage provable rather than asserted. The one exception is
`azure.target.ingress`, which names the controller because the Global Constraints do.

**The CPF clearlist is read live** from
`governance-repo/IaC_Terraform_Agent_4LMP/templates/cpf-schemas/_catalog.json` (226
modules) at check time. It is never copied into this pack, so it cannot drift. If the
catalogue is missing, those rules report `not-assessed` rather than silently passing.

**Only MUST becomes `mandatory`.** SHOULD becomes `advisory`, which is reported and never
blocks. The moment SHOULD blocks a pipeline, people stop writing SHOULD.

**Mandatory findings are cleared by exception, never by approval** — with a named
approver who is not the delivery team, and a mandatory expiry.

## Amending the pack

1. Add or edit the rule in the relevant `rules/*.json`, with `source` and `quote`.
2. If it names a new fact, add it to `fact-keys.json`.
3. If the fact uses a new prefix, add a routing entry in `Spec.ps1` — otherwise the fact
   lands in `unrouted`, never reaches a view, and the rule can never gate anything. The
   test `every fact in the vocabulary is routable to a view` catches this.
4. Run `spec-agent\tests\Invoke-Tests.ps1 -Suite standards`.

## Scope

**In:** the two pipelines — infrastructure and application — plus the design-time facts
they depend on (tier, resiliency, R-Type, cutover, rollback, region, CPF, security and
observability choices).

**Out, deliberately:**

- **MEC (30 controls) and SCF tiers.** A pre-production evidence gate with its own
  artefacts and its own reviewers. Different animal, different layer.
- **Segment eligibility per region.** The four ready regions are checked. The
  region-to-segment matrix lives in SAD DA-119 page 13 and is not machine-readable.
  Recorded in `pack.json` under `known_gaps` rather than approximated.
- **Whether a CPF module is configured correctly.** This pack checks that the module is
  clear-listed. What goes inside it is the IaC agent's job, downstream.

## Coverage

74 rules across 10 constitution principles, the Global Constraints table, the
Tier-to-Deployment-Model mapping, Recovery Patterns, the R-Type treatment rules, the
Container Adoption Rule, cutover pattern selection, migration validation and rollback
requirements, API gateway selection, and the DevSecOps controls.
